import calendar.controller.CalendarController;
import calendar.controller.InterfaceCalendarController;
import calendar.model.CalendarManager;
import calendar.model.InterfaceCalendarManager;
import calendar.view.CalendarGuiView;
import calendar.view.CalendarTextView;
import calendar.view.InterfaceCalendarView;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Scanner;
import javax.swing.SwingUtilities;

/**
 * Main entry point for the Calendar Application.
 * Supports three modes of operation:
 * - GUI mode: Graphical user interface (default)
 * - Interactive mode: User enters commands interactively via console
 * - Headless mode: Commands are read from a file and executed sequentially
 */
public class CalendarRunner {

  private static final String MODE_FLAG = "--mode";
  private static final String INTERACTIVE_MODE = "interactive";
  private static final String HEADLESS_MODE = "headless";
  private static final String GUI_MODE = "gui";
  private static final String EXIT_COMMAND = "exit";

  /**
   * Main method to run the calendar application.
   * Usage:
   * java -jar calendar-1.0.jar                              (GUI mode)
   * java -jar calendar-1.0.jar --mode interactive
   * java -jar calendar-1.0.jar --mode headless commands.txt
   *
   * @param args command line arguments
   */
  public static void main(String[] args) {
    // Handle GUI mode (no arguments)
    if (args.length == 0) {
      runGuiMode();
      return;
    }

    if (args.length < 2) {
      System.err.println("Error: Invalid arguments.");
      printUsage();
      System.exit(1);
    }

    if (!args[0].equalsIgnoreCase(MODE_FLAG)) {
      System.err.println("Error: First argument must be '--mode'.");
      printUsage();
      System.exit(1);
    }

    String mode = args[1].toLowerCase();

    try {
      switch (mode) {
        case INTERACTIVE_MODE:
          if (args.length != 2) {
            System.err.println("Error: Interactive mode does not take additional arguments.");
            printUsage();
            System.exit(1);
          }
          InterfaceCalendarView interactiveView = new CalendarTextView();
          InterfaceCalendarController interactiveController = new CalendarController();
          runInteractiveMode(interactiveController, interactiveView);
          break;

        case HEADLESS_MODE:
          if (args.length != 3) {
            System.err.println("Error: Headless mode requires a file path argument.");
            printUsage();
            System.exit(1);
          }
          String filePath = args[2];
          InterfaceCalendarView headlessView = new CalendarTextView();
          InterfaceCalendarController headlessController = new CalendarController();
          runHeadlessMode(headlessController, headlessView, filePath);
          break;

        case GUI_MODE:
          if (args.length != 2) {
            System.err.println("Error: GUI mode does not take additional arguments.");
            printUsage();
            System.exit(1);
          }
          runGuiMode();
          break;

        default:
          System.err.println(
              "Error: Invalid mode '" + args[1] + "'. Must be 'interactive', 'headless', "
                  + "or no arguments for GUI mode.");
          printUsage();
          System.exit(1);
      }
    } catch (Exception e) {
      System.err.println("Error: " + e.getMessage());
      System.exit(1);
    }
  }

  /**
   * Runs the application in interactive mode.
   * Continuously reads commands from console until 'exit' command is received.
   *
   * @param controller the calendar controller
   * @param view       the calendar view
   */
  private static void runInteractiveMode(InterfaceCalendarController controller,
                                         InterfaceCalendarView view) {

    view.displayMessage("Calendar Application - Interactive Mode");
    view.displayMessage("Type 'exit' to quit.");
    view.displayMessage("");

    Scanner scanner = new Scanner(System.in);

    boolean running = true;
    while (running) {
      System.out.print("> ");

      if (!scanner.hasNextLine()) {
        break;
      }

      String command = scanner.nextLine().trim();

      if (command.isEmpty()) {
        continue;
      }

      if (command.equalsIgnoreCase(EXIT_COMMAND)) {
        view.displayMessage("Exiting Calendar Application. Goodbye!");
        running = false;
      } else {
        try {
          controller.executeCommand(command, view);
        } catch (Exception e) {
          view.displayError("Error executing command: " + e.getMessage());
        }
      }
    }

    scanner.close();
  }

  /**
   * Runs the application in headless mode.
   * Reads commands from the specified file and executes them sequentially.
   * The file must end with an 'exit' command.
   *
   * @param controller the calendar controller
   * @param view       the calendar view
   * @param filePath   path to the file containing commands
   * @throws IOException if there is an error reading the file
   */
  private static void runHeadlessMode(InterfaceCalendarController controller,
                                      InterfaceCalendarView view,
                                      String filePath) throws IOException {

    Path path = Paths.get(filePath);

    view.displayMessage("Calendar Application - Headless Mode");
    view.displayMessage("Reading commands from: " + path.toAbsolutePath());
    view.displayMessage("");

    try (BufferedReader reader = new BufferedReader(new FileReader(path.toFile()))) {
      String command;
      int lineNumber = 0;
      boolean exitCommandFound = false;

      while ((command = reader.readLine()) != null) {
        lineNumber++;
        command = command.trim();

        if (command.isEmpty() || command.startsWith("#")) {
          continue;
        }

        view.displayMessage("Executing: " + command);

        if (command.equalsIgnoreCase(EXIT_COMMAND)) {
          view.displayMessage("Exit command found. Terminating.");
          exitCommandFound = true;
          break;
        }

        try {
          controller.executeCommand(command, view);
        } catch (Exception e) {
          view.displayError("Error at line " + lineNumber + ": " + e.getMessage());
        }

        view.displayMessage("");
      }

      if (!exitCommandFound) {
        view.displayError("Error: File ended without 'exit' command.");
        System.exit(1);
      }

    } catch (IOException e) {
      throw new IOException("Error reading file '" + filePath + "': " + e.getMessage());
    }

    view.displayMessage("Headless mode execution complete.");
  }

  /**
   * Runs the application in GUI mode.
   * Opens the graphical user interface for interactive calendar management.
   */
  private static void runGuiMode() {
    // Set up system properties for better cross-platform support
    if (System.getenv("WAYLAND_DISPLAY") != null) {
      System.setProperty("java.awt.headless", "false");
      System.setProperty("_JAVA_AWT_WM_NONREPARENTING", "1");
    }

    SwingUtilities.invokeLater(() -> {
      try {
        // Create separate model and controller for GUI
        InterfaceCalendarManager calendarManager = new CalendarManager();
        InterfaceCalendarController controller = new CalendarController(calendarManager);

        // Create GUI view with its own reference to the calendar manager
        CalendarGuiView guiView = new CalendarGuiView(calendarManager);
        guiView.setController(controller);
        guiView.initialize();
        guiView.setVisible(true);

      } catch (Exception e) {
        System.err.println("Error starting GUI: " + e.getMessage());
        e.printStackTrace();
        System.err.println("If you're on Wayland, try: export GDK_BACKEND=x11");
        System.exit(1);
      }
    });
  }

  /**
   * Prints usage information for the application.
   */
  private static void printUsage() {
    System.err.println();
    System.err.println("Usage:");
    System.err.println("  GUI mode (default):");
    System.err.println("    java -jar calendar-1.0.jar");
    System.err.println();
    System.err.println("  Interactive mode:");
    System.err.println("    java -jar calendar-1.0.jar --mode interactive");
    System.err.println();
    System.err.println("  Headless mode:");
    System.err.println("    java -jar calendar-1.0.jar --mode headless <file-path>");
    System.err.println();
    System.err.println("Examples:");
    System.err.println("  java -jar build/libs/calendar-1.0.jar");
    System.err.println("  java -jar build/libs/calendar-1.0.jar --mode interactive");
    System.err.println("  java -jar build/libs/calendar-1.0.jar --mode headless res/commands.txt");
    System.err.println();
  }
}