package calendar.util;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;

/**
 * Utility class for parsing date and time strings.
 */
public class DateTimeParser {

  private static final DateTimeFormatter DATE_FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd");
  private static final DateTimeFormatter TIME_FORMATTER = DateTimeFormatter.ofPattern("H:mm");
  private static final DateTimeFormatter DATETIME_FORMATTER =
      DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm");

  /**
   * Parses a date string in the format "YYYY-MM-DD".
   *
   * @param dateString the date string
   * @return the parsed LocalDate
   * @throws IllegalArgumentException if the format is invalid
   */
  public static LocalDate parseDate(String dateString) {
    if (dateString == null) {
      throw new IllegalArgumentException("Date cannot be null");
    }
    try {
      String[] parts = dateString.split("-");
      if (parts.length != 3) {
        throw new IllegalArgumentException(
            "Invalid date format. Expected YYYY-MM-DD, got: " + dateString);
      }

      int year = Integer.parseInt(parts[0]);
      int month = Integer.parseInt(parts[1]);
      int day = Integer.parseInt(parts[2]);

      if (month < 1 || month > 12) {
        throw new IllegalArgumentException(
            "Invalid date format. Expected YYYY-MM-DD, got: " + dateString);
      }

      if (month == 2 && day == 29) {
        if (!isLeapYear(year)) {
          throw new IllegalArgumentException(
              "Invalid date format. Expected YYYY-MM-DD, got: " + dateString);
        }
      }

      if (month == 2 && day > 29) {
        throw new IllegalArgumentException(
            "Invalid date format. Expected YYYY-MM-DD, got: " + dateString);
      }

      if ((month == 4 || month == 6 || month == 9 || month == 11) && day > 30) {
        throw new IllegalArgumentException(
            "Invalid date format. Expected YYYY-MM-DD, got: " + dateString);
      }

      if ((month == 1 || month == 3 || month == 5 || month == 7 || month == 8 || month == 10
          || month == 12) && day > 31) {
        throw new IllegalArgumentException(
            "Invalid date format. Expected YYYY-MM-DD, got: " + dateString);
      }

      LocalDate result = LocalDate.parse(dateString, DATE_FORMATTER);

      if (result.getYear() != year || result.getMonthValue() != month
          || result.getDayOfMonth() != day) {
        throw new IllegalArgumentException(
            "Invalid date format. Expected YYYY-MM-DD, got: " + dateString);
      }

      return result;
    } catch (DateTimeParseException | NumberFormatException e) {
      throw new IllegalArgumentException(
          "Invalid date format. Expected YYYY-MM-DD, got: " + dateString);
    }
  }

  private static boolean isLeapYear(int year) {
    if (year % 4 != 0) {
      return false;
    } else if (year % 100 != 0) {
      return true;
    } else {
      return year % 400 == 0;
    }
  }

  /**
   * Parses a time string in the format "HH:mm".
   *
   * @param timeString the time string
   * @return the parsed LocalTime
   * @throws IllegalArgumentException if the format is invalid
   */
  public static LocalTime parseTime(String timeString) {
    if (timeString == null) {
      throw new IllegalArgumentException("Time cannot be null");
    }
    try {
      String[] parts = timeString.split(":");
      if (parts.length != 2) {
        throw new IllegalArgumentException(
            "Invalid time format. Expected HH:mm, got: " + timeString);
      }

      int hour = Integer.parseInt(parts[0]);
      int minute = Integer.parseInt(parts[1]);

      if (hour < 0 || hour > 23) {
        throw new IllegalArgumentException(
            "Invalid time format. Expected HH:mm, got: " + timeString);
      }

      if (minute < 0 || minute > 59) {
        throw new IllegalArgumentException(
            "Invalid time format. Expected HH:mm, got: " + timeString);
      }

      return LocalTime.of(hour, minute);
    } catch (DateTimeParseException | NumberFormatException e) {
      throw new IllegalArgumentException("Invalid time format. Expected HH:mm, got: " + timeString);
    }
  }

  /**
   * Parses a date-time string in the format "YYYY-MM-DDTHH:mm".
   *
   * @param dateTimeString the date-time string
   * @return the parsed LocalDateTime
   * @throws IllegalArgumentException if the format is invalid
   */
  public static LocalDateTime parseDateTime(String dateTimeString) {
    if (dateTimeString == null) {
      throw new IllegalArgumentException("Date-time cannot be null");
    }
    try {
      String[] parts = dateTimeString.split("T");
      if (parts.length != 2) {
        throw new IllegalArgumentException(
            "Invalid date-time format. Expected YYYY-MM-DDTHH:mm, got: " + dateTimeString);
      }

      LocalDate date = parseDate(parts[0]);
      LocalTime time = parseTime(parts[1]);

      return LocalDateTime.of(date, time);
    } catch (DateTimeParseException | NumberFormatException e) {
      throw new IllegalArgumentException(
          "Invalid date-time format. Expected YYYY-MM-DDTHH:mm, got: " + dateTimeString);
    }
  }
}