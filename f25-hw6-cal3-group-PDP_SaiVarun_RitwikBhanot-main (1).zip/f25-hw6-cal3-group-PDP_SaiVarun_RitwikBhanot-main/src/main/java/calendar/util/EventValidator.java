package calendar.util;

import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * Centralized validation for event properties.
 */
public class EventValidator {

  /**
   * Validates that a subject is not null or empty.
   *
   * @param subject the subject to validate
   * @throws IllegalArgumentException if invalid
   */
  public static void validateSubject(String subject) {
    if (subject == null || subject.trim().isEmpty()) {
      throw new IllegalArgumentException("Subject cannot be null or empty");
    }
  }

  /**
   * Validates that start and end times are valid.
   *
   * @param start the start time
   * @param end   the end time
   * @throws IllegalArgumentException if invalid
   */
  public static void validateTimes(LocalDateTime start, LocalDateTime end) {
    if (start == null) {
      throw new IllegalArgumentException("Start time cannot be null");
    }
    if (end == null) {
      throw new IllegalArgumentException("End time cannot be null");
    }
    if (start.equals(end)) {
      throw new IllegalArgumentException("Start time must be before end time");
    }
    if (start.isAfter(end)) {
      throw new IllegalArgumentException("Start time must be before end time");
    }
  }

  /**
   * Validates that events in a series start and end on the same day.
   *
   * @param start the start time
   * @param end   the end time
   * @throws IllegalArgumentException if they span multiple days
   */
  public static void validateSameDay(LocalDateTime start, LocalDateTime end) {
    if (!start.toLocalDate().equals(end.toLocalDate())) {
      throw new IllegalArgumentException(
          "Events in a series must start and end on the same day");
    }
  }

  /**
   * Validates weekdays string contains only valid day codes.
   *
   * @param weekdays the weekdays string to validate
   * @throws IllegalArgumentException if invalid characters found
   */
  public static void validateWeekdays(String weekdays) {
    if (weekdays == null || weekdays.trim().isEmpty()) {
      throw new IllegalArgumentException("Weekdays cannot be null or empty");
    }

    if (weekdays.equals("D")) {
      return;
    }
    for (char c : weekdays.toCharArray()) {
      if ("MTWRFSU".indexOf(c) == -1) {
        throw new IllegalArgumentException("Invalid weekday code: " + c);
      }
    }
  }

  /**
   * Validates that occurrences is positive.
   *
   * @param occurrences the number of occurrences
   * @throws IllegalArgumentException if not positive
   */
  public static void validateOccurrences(int occurrences) {
    if (occurrences <= 0) {
      throw new IllegalArgumentException("Invalid number of occurrences: must be positive");
    }
  }

  /**
   * Validates that until date is not before start date.
   *
   * @param startDate the start date
   * @param until     the until date
   * @throws IllegalArgumentException if until is before start
   */
  public static void validateUntilDate(LocalDate startDate, LocalDate until) {
    if (until == null) {
      throw new IllegalArgumentException("Until date cannot be null");
    }
    if (until.isBefore(startDate)) {
      throw new IllegalArgumentException("Until date must be on or after start date");
    }
  }

  /**
   * Validates a property name and value for editing.
   *
   * @param property the property name
   * @param newValue the new value
   * @throws IllegalArgumentException if invalid
   */
  public static void validateEditParameters(String property, String newValue) {
    if (property == null || property.trim().isEmpty()) {
      throw new IllegalArgumentException("Property cannot be null or empty");
    }
    if (newValue == null) {
      throw new IllegalArgumentException("New value cannot be null");
    }
  }
}