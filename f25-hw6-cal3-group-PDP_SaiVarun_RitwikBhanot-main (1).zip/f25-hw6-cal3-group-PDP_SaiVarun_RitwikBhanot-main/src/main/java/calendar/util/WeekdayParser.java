package calendar.util;

import java.time.DayOfWeek;
import java.util.EnumSet;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

/**
 * Utility for parsing weekday strings to Set of DayOfWeek.
 */
public class WeekdayParser {

  private static final Map<Character, DayOfWeek> DAY_MAP = new HashMap<>();

  static {
    DAY_MAP.put('M', DayOfWeek.MONDAY);
    DAY_MAP.put('T', DayOfWeek.TUESDAY);
    DAY_MAP.put('W', DayOfWeek.WEDNESDAY);
    DAY_MAP.put('R', DayOfWeek.THURSDAY);
    DAY_MAP.put('F', DayOfWeek.FRIDAY);
    DAY_MAP.put('S', DayOfWeek.SATURDAY);
    DAY_MAP.put('U', DayOfWeek.SUNDAY);
  }

  /**
   * Parses a weekday string (e.g., "MWF") to a Set of DayOfWeek.
   *
   * @param weekdays the weekday string
   * @return set of DayOfWeek values
   */
  public static Set<DayOfWeek> parse(String weekdays) {
    EventValidator.validateWeekdays(weekdays);

    Set<DayOfWeek> days = EnumSet.noneOf(DayOfWeek.class);
    

    if (weekdays.equals("D")) {
      return EnumSet.allOf(DayOfWeek.class);
    }
    
    for (char c : weekdays.toCharArray()) {
      days.add(DAY_MAP.get(c));
    }
    return days;
  }

  /**
   * Converts a Set of DayOfWeek back to string format.
   *
   * @param days the set of days
   * @return the weekday string (e.g., "MWF")
   */
  public static String toString(Set<DayOfWeek> days) {
    if (days == null) {
      return "";
    }
    StringBuilder sb = new StringBuilder();

    DayOfWeek[] orderedDays = {
        DayOfWeek.MONDAY, DayOfWeek.TUESDAY, DayOfWeek.WEDNESDAY,
        DayOfWeek.THURSDAY, DayOfWeek.FRIDAY, DayOfWeek.SATURDAY, DayOfWeek.SUNDAY
    };
    
    for (DayOfWeek day : orderedDays) {
      if (days.contains(day)) {

        for (Map.Entry<Character, DayOfWeek> entry : DAY_MAP.entrySet()) {
          if (entry.getValue() == day) {
            sb.append(entry.getKey());
            break;
          }
        }
      }
    }
    return sb.toString();
  }
}