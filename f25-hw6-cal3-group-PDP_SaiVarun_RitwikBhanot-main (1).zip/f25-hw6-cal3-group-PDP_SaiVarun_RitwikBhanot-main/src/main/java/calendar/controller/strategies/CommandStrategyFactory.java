package calendar.controller.strategies;

import calendar.controller.components.CommandExecutor;
import calendar.controller.components.CommandParser;
import calendar.controller.components.CommandValidator;
import calendar.controller.components.executors.CopyEventExecutor;
import calendar.controller.components.executors.CopyEventsExecutor;
import calendar.controller.components.executors.CopyEventsOnExecutor;
import calendar.controller.components.executors.CreateCalendarExecutor;
import calendar.controller.components.executors.CreateEventExecutor;
import calendar.controller.components.executors.EditCalendarExecutor;
import calendar.controller.components.executors.EditEventExecutor;
import calendar.controller.components.executors.EditEventsExecutor;
import calendar.controller.components.executors.EditSeriesExecutor;
import calendar.controller.components.executors.ExportCalExecutor;
import calendar.controller.components.executors.PrintEventsExecutor;
import calendar.controller.components.executors.ShowStatusExecutor;
import calendar.controller.components.executors.StubExecutor;
import calendar.controller.components.executors.UseCalendarExecutor;
import calendar.controller.components.parsers.CopyEventParser;
import calendar.controller.components.parsers.CopyEventsOnParser;
import calendar.controller.components.parsers.CopyEventsParser;
import calendar.controller.components.parsers.CreateCalendarParser;
import calendar.controller.components.parsers.CreateEventParser;
import calendar.controller.components.parsers.EditCalendarParser;
import calendar.controller.components.parsers.EditEventParser;
import calendar.controller.components.parsers.EditEventsParser;
import calendar.controller.components.parsers.EditSeriesParser;
import calendar.controller.components.parsers.ExportCalParser;
import calendar.controller.components.parsers.PrintEventsParser;
import calendar.controller.components.parsers.ShowStatusParser;
import calendar.controller.components.parsers.StubParser;
import calendar.controller.components.parsers.UseCalendarParser;
import calendar.controller.components.validators.CopyEventValidator;
import calendar.controller.components.validators.CopyEventsOnValidator;
import calendar.controller.components.validators.CopyEventsValidator;
import calendar.controller.components.validators.CreateCalendarValidator;
import calendar.controller.components.validators.CreateEventValidator;
import calendar.controller.components.validators.EditCalendarValidator;
import calendar.controller.components.validators.EditEventValidator;
import calendar.controller.components.validators.EditEventsValidator;
import calendar.controller.components.validators.EditSeriesValidator;
import calendar.controller.components.validators.ExportCalValidator;
import calendar.controller.components.validators.PrintEventsValidator;
import calendar.controller.components.validators.ShowStatusValidator;
import calendar.controller.components.validators.StubValidator;
import calendar.controller.components.validators.UseCalendarValidator;
import calendar.model.InterfaceCalendarManager;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Factory class responsible for creating command strategies based on command tokens.
 * Maps command types to their corresponding validator, parser, and executor components.
 */
public class CommandStrategyFactory {

  private final Map<String, StrategyCreator> strategyMap;

  @FunctionalInterface
  private interface StrategyCreator {
    CommandStrategy create(InterfaceCalendarManager calendarManager);
  }

  /**
   * Constructs a new CommandStrategyFactory and initializes the strategy mappings.
   */
  public CommandStrategyFactory() {
    this.strategyMap = new HashMap<>();
    initializeStrategies();
  }

  private void initializeStrategies() {
    strategyMap.put("create event", this::createCreateEventStrategy);
    strategyMap.put("create calendar", this::createCreateCalendarStrategy);
    strategyMap.put("edit calendar", this::createEditCalendarStrategy);
    strategyMap.put("use calendar", this::createUseCalendarStrategy);
    strategyMap.put("edit event", this::createEditEventStrategy);
    strategyMap.put("edit events", this::createEditEventsStrategy);
    strategyMap.put("edit series", this::createEditSeriesStrategy);
    strategyMap.put("copy event", this::createCopyEventStrategy);
    strategyMap.put("copy events", cm -> createCopyEventsStrategy(cm));
    strategyMap.put("copy events on", cm -> createCopyEventsOnStrategy(cm));
    strategyMap.put("print events", cm -> createPrintEventsStrategy(cm));
    strategyMap.put("export cal", cm -> createExportCalStrategy(cm));
    strategyMap.put("show status", cm -> createShowStatusStrategy(cm));
  }

  private CommandStrategy createCreateEventStrategy(InterfaceCalendarManager calendarManager) {
    CommandValidator validator = new CreateEventValidator();
    CommandParser parser = new CreateEventParser();
    CommandExecutor executor = new CreateEventExecutor(calendarManager);
    return new CommandStrategy("create event", validator, parser, executor);
  }

  private CommandStrategy createCreateCalendarStrategy(InterfaceCalendarManager calendarManager) {
    CommandValidator validator = new CreateCalendarValidator();
    CommandParser parser = new CreateCalendarParser();
    CommandExecutor executor = new CreateCalendarExecutor(calendarManager);
    return new CommandStrategy("create calendar", validator, parser, executor);
  }

  private CommandStrategy createEditCalendarStrategy(InterfaceCalendarManager calendarManager) {
    CommandValidator validator = new EditCalendarValidator();
    CommandParser parser = new EditCalendarParser();
    CommandExecutor executor = new EditCalendarExecutor(calendarManager);
    return new CommandStrategy("edit calendar", validator, parser, executor);
  }

  private CommandStrategy createUseCalendarStrategy(InterfaceCalendarManager calendarManager) {
    CommandValidator validator = new UseCalendarValidator();
    CommandParser parser = new UseCalendarParser();
    CommandExecutor executor = new UseCalendarExecutor(calendarManager);
    return new CommandStrategy("use calendar", validator, parser, executor);
  }

  private CommandStrategy createEditEventStrategy(InterfaceCalendarManager calendarManager) {
    CommandValidator validator = new EditEventValidator();
    CommandParser parser = new EditEventParser();
    CommandExecutor executor = new EditEventExecutor(calendarManager);
    return new CommandStrategy("edit event", validator, parser, executor);
  }

  private CommandStrategy createEditEventsStrategy(InterfaceCalendarManager calendarManager) {
    CommandValidator validator = new EditEventsValidator();
    CommandParser parser = new EditEventsParser();
    CommandExecutor executor = new EditEventsExecutor(calendarManager);
    return new CommandStrategy("edit events", validator, parser, executor);
  }

  private CommandStrategy createEditSeriesStrategy(InterfaceCalendarManager calendarManager) {
    CommandValidator validator = new EditSeriesValidator();
    CommandParser parser = new EditSeriesParser();
    CommandExecutor executor = new EditSeriesExecutor(calendarManager);
    return new CommandStrategy("edit series", validator, parser, executor);
  }

  private CommandStrategy createCopyEventStrategy(InterfaceCalendarManager calendarManager) {
    CommandValidator validator = new CopyEventValidator();
    CommandParser parser = new CopyEventParser();
    CommandExecutor executor = new CopyEventExecutor(calendarManager);
    return new CommandStrategy("copy event", validator, parser, executor);
  }

  private CommandStrategy createCopyEventsStrategy(InterfaceCalendarManager calendarManager) {
    CommandValidator validator = new CopyEventsValidator();
    CommandParser parser = new CopyEventsParser();
    CommandExecutor executor = new CopyEventsExecutor(calendarManager);
    return new CommandStrategy("copy events", validator, parser, executor);
  }

  private CommandStrategy createCopyEventsOnStrategy(InterfaceCalendarManager calendarManager) {
    CommandValidator validator = new CopyEventsOnValidator();
    CommandParser parser = new CopyEventsOnParser();
    CommandExecutor executor = new CopyEventsOnExecutor(calendarManager);
    return new CommandStrategy("copy events on", validator, parser, executor);
  }

  private CommandStrategy createPrintEventsStrategy(InterfaceCalendarManager calendarManager) {
    CommandValidator validator = new PrintEventsValidator();
    CommandParser parser = new PrintEventsParser();
    CommandExecutor executor = new PrintEventsExecutor(calendarManager);
    return new CommandStrategy("print events", validator, parser, executor);
  }

  private CommandStrategy createExportCalStrategy(InterfaceCalendarManager calendarManager) {
    CommandValidator validator = new ExportCalValidator();
    CommandParser parser = new ExportCalParser();
    CommandExecutor executor = new ExportCalExecutor(calendarManager);
    return new CommandStrategy("export cal", validator, parser, executor);
  }

  private CommandStrategy createShowStatusStrategy(InterfaceCalendarManager calendarManager) {
    CommandValidator validator = new ShowStatusValidator();
    CommandParser parser = new ShowStatusParser();
    CommandExecutor executor = new ShowStatusExecutor(calendarManager);
    return new CommandStrategy("show status", validator, parser, executor);
  }

  private CommandStrategy createStubStrategy(String commandType, 
                                            InterfaceCalendarManager calendarManager) {
    CommandValidator validator = new StubValidator(commandType);
    CommandParser parser = new StubParser(commandType);
    CommandExecutor executor = new StubExecutor(commandType);
    return new CommandStrategy(commandType, validator, parser, executor);
  }

  /**
   * Creates a command strategy based on the provided tokens and calendar manager.
   *
   * @param tokens the command tokens to analyze
   * @param calendarManager the calendar manager to use with the strategy
   * @return the appropriate command strategy
   * @throws IllegalArgumentException if the command is invalid or unknown
   */
  public CommandStrategy createStrategy(List<String> tokens, 
                                       InterfaceCalendarManager calendarManager) {
    if (tokens == null || tokens.isEmpty()) {
      throw new IllegalArgumentException("Invalid command: empty command");
    }

    String firstToken = tokens.get(0);
    if (firstToken.equals("createEvent")
        || firstToken.equals("editCalendar")
        || firstToken.equals("useCalendar")
        || firstToken.equals("copyEvent")
        || firstToken.equals("printEvents")
        || firstToken.equals("exportCal")
        || firstToken.equals("showStatus")) {
      throw new IllegalArgumentException("Unknown command: " + firstToken);
    }

    if (tokens.size() < 2) {
      throw new IllegalArgumentException("Invalid command: command too short");
    }

    String commandType = determineCommandType(tokens);
    StrategyCreator creator = strategyMap.get(commandType);
    
    if (creator == null) {
      throw new IllegalArgumentException("Unknown command: " + tokens.get(0) + " " + tokens.get(1));
    }

    return creator.create(calendarManager);
  }

  private String determineCommandType(List<String> tokens) {
    String firstToken = tokens.get(0).toLowerCase();
    
    if (tokens.size() >= 3
        && firstToken.equals("copy")
        && tokens.get(1).equals("events")
        && tokens.get(2).equals("on")) {
      return "copy events on";
    }
    
    return firstToken + " " + tokens.get(1).toLowerCase();
  }

  public String[] getSupportedCommands() {
    return strategyMap.keySet().toArray(new String[0]);
  }
}