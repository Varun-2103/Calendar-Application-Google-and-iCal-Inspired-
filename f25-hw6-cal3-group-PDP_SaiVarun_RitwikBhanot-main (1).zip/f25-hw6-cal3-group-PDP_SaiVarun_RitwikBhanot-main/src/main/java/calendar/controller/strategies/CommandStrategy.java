package calendar.controller.strategies;

import calendar.controller.CommandResult;
import calendar.controller.components.CommandExecutor;
import calendar.controller.components.CommandParser;
import calendar.controller.components.CommandValidator;
import java.util.List;

/**
 * Represents a command strategy that combines validation, parsing, and execution 
 * for a specific command type.
 */
public class CommandStrategy {

  private final CommandValidator validator;
  private final CommandParser parser;
  private final CommandExecutor executor;
  private final String commandType;

  /**
   * Constructs a new CommandStrategy with the specified components.
   *
   * @param commandType the type of command this strategy handles
   * @param validator the validator for command tokens
   * @param parser the parser for extracting command parameters
   * @param executor the executor for running the command
   */
  public CommandStrategy(String commandType, CommandValidator validator,
                          CommandParser parser, CommandExecutor executor) {
    this.commandType = commandType;
    this.validator = validator;
    this.parser = parser;
    this.executor = executor;
  }

  /**
   * Executes the command strategy by validating, parsing, and executing the given tokens.
   *
   * @param tokens the command tokens to process
   * @return the result of command execution
   */
  public CommandResult execute(List<String> tokens) {
    try {
      validator.validate(tokens);
      Object[] parameters = parser.parse(tokens);
      return executor.execute(parameters);
    } catch (IllegalArgumentException e) {
      return new CommandResult(false, e.getMessage());
    } catch (Exception e) {
      return new CommandResult(false, "Error executing command: " + e.getMessage());
    }
  }

  public String getCommandType() {
    return commandType;
  }
}