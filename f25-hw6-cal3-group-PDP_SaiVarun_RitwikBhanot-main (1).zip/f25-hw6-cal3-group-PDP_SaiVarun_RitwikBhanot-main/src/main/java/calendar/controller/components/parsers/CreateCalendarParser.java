package calendar.controller.components.parsers;

import calendar.controller.components.CommandParser;
import java.time.ZoneId;
import java.util.List;

/**
 * Parser for create calendar commands.
 * Parses commands to create a new calendar with a name and timezone.
 */
public class CreateCalendarParser implements CommandParser {

  @Override
  public Object[] parse(List<String> tokens) {
    String name = removeQuotes(tokens.get(3));
    
    if (tokens.size() < 6) {
      throw new IllegalArgumentException("create calendar requires timezone after --timezone flag");
    }
    
    String timezoneStr = tokens.get(5);
    ZoneId timezone;
    
    try {
      if (timezoneStr.matches("^(UTC|GMT)[+-]\\d+$")) {
        throw new IllegalArgumentException("Invalid timezone: " + timezoneStr 
            + ". Use IANA format like 'America/New_York'");
      }
      timezone = ZoneId.of(timezoneStr);
    } catch (Exception e) {
      throw new IllegalArgumentException("Invalid timezone: " + timezoneStr 
          + ". Use IANA format like 'America/New_York'");
    }
    
    return new Object[]{name, timezone};
  }

  private String removeQuotes(String str) {
    if (str == null) {
      return null;
    }
    if (str.startsWith("\"") && str.endsWith("\"")) {
      return str.substring(1, str.length() - 1);
    }
    return str;
  }
}