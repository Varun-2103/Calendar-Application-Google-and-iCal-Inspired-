package calendar.controller.components.parsers;

import calendar.controller.components.CommandParser;
import java.util.List;

/**
 * Parser for use calendar commands.
 * Parses commands to set the active calendar.
 */
public class UseCalendarParser implements CommandParser {

  @Override
  public Object[] parse(List<String> tokens) {
    String name = removeQuotes(tokens.get(3));
    return new Object[]{name};
  }

  private String removeQuotes(String str) {
    if (str == null) {
      return null;
    }
    if (str.startsWith("\"") && str.endsWith("\"")) {
      return str.substring(1, str.length() - 1);
    }
    return str;
  }
}