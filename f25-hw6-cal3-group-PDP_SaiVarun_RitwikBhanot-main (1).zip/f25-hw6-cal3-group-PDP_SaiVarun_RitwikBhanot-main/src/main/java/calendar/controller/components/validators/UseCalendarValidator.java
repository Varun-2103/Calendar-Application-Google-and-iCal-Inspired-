package calendar.controller.components.validators;

import calendar.controller.components.CommandValidator;
import java.util.List;

/**
 * Validator for use calendar commands.
 */
public class UseCalendarValidator implements CommandValidator {

  @Override
  public void validate(List<String> tokens) {
    if (tokens.size() != 4) {
      throw new IllegalArgumentException(
          "use calendar requires format: use calendar --name <name>");
    }
    
    if (!tokens.get(2).equals("--name")) {
      throw new IllegalArgumentException("use calendar requires --name flag");
    }
  }
}