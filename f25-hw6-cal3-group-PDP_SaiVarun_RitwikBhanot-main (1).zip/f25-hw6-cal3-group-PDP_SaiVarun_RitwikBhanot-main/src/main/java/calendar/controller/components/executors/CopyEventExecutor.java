package calendar.controller.components.executors;

import calendar.controller.CommandResult;
import calendar.controller.components.CommandExecutor;
import calendar.model.InterfaceCalendar;
import calendar.model.InterfaceCalendarManager;
import calendar.model.InterfaceEvent;
import java.time.Duration;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.List;

/**
 * Executor for copying a single event from one calendar to another.
 * Handles timezone conversion and conflict detection when copying events
 * between calendars with different timezones.
 */
public class CopyEventExecutor implements CommandExecutor {
  
  private final InterfaceCalendarManager calendarManager;
  
  /**
   * Constructs a CopyEventExecutor with the specified calendar manager.
   *
   * @param calendarManager the calendar manager to use for event copying
   */
  public CopyEventExecutor(InterfaceCalendarManager calendarManager) {
    this.calendarManager = calendarManager;
  }
  
  @Override
  public CommandResult execute(Object[] parameters) {
    try {
      String eventName = (String) parameters[0];
      LocalDateTime onDateTime = (LocalDateTime) parameters[1];
      String targetCalendarName = (String) parameters[2];
      final LocalDateTime toDateTime = (LocalDateTime) parameters[3];
      
      InterfaceCalendar activeCalendar = calendarManager.getActiveCalendar();
      if (activeCalendar == null) {
        return new CommandResult(false, "No active calendar set");
      }
      
      InterfaceCalendar targetCalendar = calendarManager.getCalendar(targetCalendarName);
      if (targetCalendar == null) {
        return new CommandResult(false, "Target calendar '" + targetCalendarName + "' not found");
      }
      
      InterfaceEvent sourceEvent = null;
      List<InterfaceEvent> sourceEvents = activeCalendar.getAllEvents();
      
      for (InterfaceEvent event : sourceEvents) {
        if (event.getSubject().equals(eventName)
            && event.getStart().equals(onDateTime)) {
          sourceEvent = event;
          break;
        }
      }
      
      if (sourceEvent == null) {
        return new CommandResult(false, "Event '" + eventName + "' at " + onDateTime 
            + " not found");
      }
      
      ZoneId sourceTz = activeCalendar.getTimezone();
      ZoneId targetTz = targetCalendar.getTimezone();
      
      ZonedDateTime sourceStartZoned = sourceEvent.getStart().atZone(sourceTz);
      ZonedDateTime sourceEndZoned = sourceEvent.getEnd().atZone(sourceTz);
      Duration duration = Duration.between(sourceStartZoned, sourceEndZoned);
      
      ZonedDateTime targetStartZoned = toDateTime.atZone(targetTz);
      LocalDateTime newEndTime = targetStartZoned.plus(duration).toLocalDateTime();
      List<InterfaceEvent> targetEvents = targetCalendar.getAllEvents();
      for (InterfaceEvent targetEvent : targetEvents) {
        if (isTimeOverlap(toDateTime, newEndTime, targetEvent)) {
          return new CommandResult(false, "Event conflicts with existing event in target calendar");
        }
      }
      
      targetCalendar.createEvent(
          sourceEvent.getSubject(),
          toDateTime,
          newEndTime
      );
      
      return new CommandResult(true, "Successfully copied event '" + eventName + "' to '" 
          + targetCalendarName + "'");
      
    } catch (Exception e) {
      return new CommandResult(false, "Error copying event: " + e.getMessage());
    }
  }
  
  /**
   * Checks if two time ranges overlap.
   *
   * @param start1 start time of first event
   * @param end1 end time of first event
   * @param event2 second event to check against
   * @return true if time ranges overlap
   */
  private boolean isTimeOverlap(LocalDateTime start1, LocalDateTime end1, InterfaceEvent event2) {
    LocalDateTime start2 = event2.getStart();
    LocalDateTime end2 = event2.getEnd();
    
    return start1.isBefore(end2) && start2.isBefore(end1);
  }
}