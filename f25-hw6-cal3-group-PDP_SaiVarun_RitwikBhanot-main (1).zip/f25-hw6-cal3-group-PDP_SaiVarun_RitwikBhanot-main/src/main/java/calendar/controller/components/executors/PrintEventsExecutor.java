package calendar.controller.components.executors;

import calendar.controller.CommandResult;
import calendar.controller.components.CommandExecutor;
import calendar.model.InterfaceCalendar;
import calendar.model.InterfaceCalendarManager;
import calendar.model.InterfaceEvent;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

/**
 * Executor for displaying calendar events to the user.
 * Supports printing events on a specific date or within a time range.
 */
public class PrintEventsExecutor implements CommandExecutor {

  private final InterfaceCalendarManager calendarManager;

  /**
   * Constructs a PrintEventsExecutor with the specified calendar manager.
   *
   * @param calendarManager the calendar manager to use for displaying events
   */
  public PrintEventsExecutor(InterfaceCalendarManager calendarManager) {
    this.calendarManager = calendarManager;
  }

  @Override
  public CommandResult execute(Object[] parameters) {
    try {
      InterfaceCalendar activeCalendar = calendarManager.getActiveCalendar();
      if (activeCalendar == null) {
        return new CommandResult(false, "No calendar currently in use");
      }

      List<InterfaceEvent> events;

      LocalDate date = (LocalDate) parameters[0];
      LocalDateTime fromDateTime = (LocalDateTime) parameters[1];
      LocalDateTime toDateTime = (LocalDateTime) parameters[2];

      if (date != null) {
        events = activeCalendar.getEventsOn(date);
      } else if (fromDateTime != null && toDateTime != null) {
        if (fromDateTime.isAfter(toDateTime)) {
          return new CommandResult(false, "Invalid date range: start time is after end time");
        }
        events = activeCalendar.getEventsBetween(fromDateTime, toDateTime);
      } else {
        return new CommandResult(false, "Invalid print events parameters");
      }

      // Return events in the CommandResult so the view can display them
      if (events.isEmpty()) {
        String message;
        if (date != null) {
          message = "No events scheduled for " + date;
        } else {
          message = "No events found between " + fromDateTime + " and " + toDateTime;
        }
        return new CommandResult(true, message);
      }

      return new CommandResult(true, "Events found", events);

    } catch (Exception e) {
      return new CommandResult(false, "Error printing events: " + e.getMessage());
    }
  }
}