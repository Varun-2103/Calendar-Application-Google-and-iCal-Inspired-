package calendar.controller.components.parsers;

import calendar.controller.components.CommandParser;
import java.time.ZoneId;
import java.util.List;

/**
 * Parser for edit calendar commands.
 * Parses commands to edit calendar properties like name and timezone.
 */
public class EditCalendarParser implements CommandParser {

  @Override
  public Object[] parse(List<String> tokens) {
    if (tokens.size() < 7) {
      throw new IllegalArgumentException("edit calendar requires property value after " 
          + "--property flag");
    }
    
    String name = removeQuotes(tokens.get(3));
    String value = removeQuotes(tokens.get(6));
    String property = tokens.get(5).toLowerCase();
    
    if (!property.equals("name") && !property.equals("timezone")) {
      throw new IllegalArgumentException("Property must be 'name' or 'timezone'");
    }
    
    if (property.equals("timezone")) {
      try {
        ZoneId.of(value);
      } catch (Exception e) {
        throw new IllegalArgumentException("Invalid timezone: " + value 
            + ". Use IANA format like 'America/New_York'");
      }
    }
    
    return new Object[]{name, property, value};
  }

  private String removeQuotes(String str) {
    if (str == null) {
      return null;
    }
    if (str.startsWith("\"") && str.endsWith("\"")) {
      return str.substring(1, str.length() - 1);
    }
    return str;
  }
}