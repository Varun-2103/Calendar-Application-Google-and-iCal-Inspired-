package calendar.controller.components.validators;

import calendar.controller.components.CommandValidator;
import java.util.List;

/**
 * Validator for edit events commands.
 */
public class EditEventsValidator implements CommandValidator {

  @Override
  public void validate(List<String> tokens) {
    if (tokens.size() < 6) {
      throw new IllegalArgumentException("Edit events command requires at least 6 tokens");
    }

    if (!tokens.get(0).equals("edit")
        || !tokens.get(1).equals("events")) {
      throw new IllegalArgumentException("Command must start with 'edit events'");
    }

    String property = tokens.get(2);
    if (!property.equals("subject")
        && !property.equals("location")
        && !property.equals("description")
        && !property.equals("status")
        && !property.equals("start")) {
      throw new IllegalArgumentException("Invalid property for edit events: " + property);
    }

    // Subject can be with or without quotes - just check it's not empty
    String subject = tokens.get(3);
    if (subject.trim().isEmpty()) {
      throw new IllegalArgumentException("Event subject cannot be empty");
    }

    if (!tokens.get(4).equals("from")) {
      throw new IllegalArgumentException("Expected 'from' after event subject");
    }

    String fromDateTime = tokens.get(5);
    try {
      java.time.LocalDateTime.parse(
          fromDateTime, java.time.format.DateTimeFormatter.ISO_LOCAL_DATE_TIME);
    } catch (Exception e) {
      throw new IllegalArgumentException("Invalid from date-time format: " + fromDateTime);
    }

    if (tokens.size() > 6) {
      if (!tokens.get(6).equals("with")) {
        throw new IllegalArgumentException("Expected 'with' after from date-time");
      }

      if (tokens.size() < 8) {
        throw new IllegalArgumentException("Edit events command requires value after 'with'");
      }
    }
  }
}