package calendar.controller.components.executors;

import calendar.controller.CommandResult;
import calendar.controller.components.CommandExecutor;
import calendar.model.InterfaceCalendarManager;

/**
 * Executor for editing calendar properties such as name and timezone.
 * Validates property changes and handles error cases for calendar modifications.
 */
public class EditCalendarExecutor implements CommandExecutor {

  private final InterfaceCalendarManager calendarManager;

  /**
   * Constructs an EditCalendarExecutor with the specified calendar manager.
   *
   * @param calendarManager the calendar manager to use for calendar editing
   */
  public EditCalendarExecutor(InterfaceCalendarManager calendarManager) {
    this.calendarManager = calendarManager;
  }

  @Override
  public CommandResult execute(Object[] parameters) {
    try {
      String name = (String) parameters[0];
      String property = (String) parameters[1];
      String value = (String) parameters[2];
      
      if (property.equals("name")) {
        if (value == null || value.trim().isEmpty() || value.equals("null")) {
          return new CommandResult(false, "Calendar name cannot be empty");
        }
      }
      
      calendarManager.editCalendar(name, property, value);
      return new CommandResult(true, "Calendar '" + name + "' updated: " + property + " set to " 
          + value);
    } catch (IllegalArgumentException e) {
      return new CommandResult(false, e.getMessage());
    } catch (Exception e) {
      return new CommandResult(false, "Failed to edit calendar: " + e.getMessage());
    }
  }
}