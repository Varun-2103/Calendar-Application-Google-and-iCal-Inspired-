package calendar.controller.components.parsers;

import calendar.controller.components.CommandParser;
import java.time.LocalDate;
import java.util.List;

/**
 * Parser for copy events on date commands.
 * Parses commands to copy all events from a specific date to a target calendar and date.
 */
public class CopyEventsOnParser implements CommandParser {

  @Override
  public Object[] parse(List<String> tokens) {
    LocalDate date = LocalDate.parse(tokens.get(3));
    String targetCalendar = tokens.get(5);
    LocalDate targetDate = LocalDate.parse(tokens.get(7));
    
    return new Object[]{date, targetCalendar, targetDate};
  }
}