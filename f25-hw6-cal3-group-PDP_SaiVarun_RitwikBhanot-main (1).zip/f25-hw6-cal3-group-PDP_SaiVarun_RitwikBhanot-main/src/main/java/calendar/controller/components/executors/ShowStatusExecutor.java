package calendar.controller.components.executors;

import calendar.controller.CommandResult;
import calendar.controller.components.CommandExecutor;
import calendar.model.InterfaceCalendar;
import calendar.model.InterfaceCalendarManager;
import calendar.model.InterfaceEvent;
import java.time.LocalDateTime;
import java.util.List;

/**
 * Executor for checking availability status at a specific time.
 * Determines if the user is busy or available by checking for
 * overlapping events at the queried time.
 */
public class ShowStatusExecutor implements CommandExecutor {

  private final InterfaceCalendarManager calendarManager;

  /**
   * Constructs a ShowStatusExecutor with the specified calendar manager.
   *
   * @param calendarManager the calendar manager to use for status checking
   */
  public ShowStatusExecutor(InterfaceCalendarManager calendarManager) {
    this.calendarManager = calendarManager;
  }

  @Override
  public CommandResult execute(Object[] parameters) {
    try {
      InterfaceCalendar activeCalendar = calendarManager.getActiveCalendar();
      if (activeCalendar == null) {
        return new CommandResult(false, "No calendar currently in use");
      }

      LocalDateTime queryTime = (LocalDateTime) parameters[0];

      List<InterfaceEvent> events = activeCalendar.getAllEvents();
      for (InterfaceEvent event : events) {
        if (isTimeDuringEvent(queryTime, event)) {
          // Return the result, don't call view directly
          return new CommandResult(true, "Busy");
        }
      }

      // Return the result, don't call view directly
      return new CommandResult(true, "Available");

    } catch (Exception e) {
      return new CommandResult(false, "Error checking status: " + e.getMessage());
    }
  }

  /**
   * Checks if the given time falls within an event's time range.
   *
   * @param queryTime the time to check
   * @param event the event to check against
   * @return true if the time is during the event
   */
  private boolean isTimeDuringEvent(LocalDateTime queryTime, InterfaceEvent event) {
    LocalDateTime eventStart = event.getStart();
    LocalDateTime eventEnd = event.getEnd();

    return !queryTime.isBefore(eventStart) && queryTime.isBefore(eventEnd);
  }
}