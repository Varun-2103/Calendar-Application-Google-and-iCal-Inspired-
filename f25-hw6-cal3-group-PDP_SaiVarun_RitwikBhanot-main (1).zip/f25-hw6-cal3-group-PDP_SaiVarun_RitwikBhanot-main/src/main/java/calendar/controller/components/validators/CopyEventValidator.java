package calendar.controller.components.validators;

import calendar.controller.components.CommandValidator;
import java.util.List;

/**
 * Validator for copy event commands.
 */
public class CopyEventValidator implements CommandValidator {

  @Override
  public void validate(List<String> tokens) {

    if (!tokens.get(0).equals("copy")
        || !tokens.get(1).equals("event")) {
      throw new IllegalArgumentException("Command must start with 'copy event'");
    }

    // Event name can be with or without quotes
    String eventName = tokens.get(2);
    if (eventName.trim().isEmpty()) {
      throw new IllegalArgumentException("Event name cannot be empty");
    }

    if (!tokens.get(3).equals("on")) {
      throw new IllegalArgumentException("Missing date time specification");
    }

    String onDateTime = tokens.get(4);
    try {
      java.time.LocalDateTime.parse(
          onDateTime, java.time.format.DateTimeFormatter.ISO_LOCAL_DATE_TIME);
    } catch (Exception e) {
      throw new IllegalArgumentException("Invalid on date-time format: " + onDateTime);
    }

    if (tokens.size() < 6
        || !tokens.get(5).equals("--target")) {
      throw new IllegalArgumentException("Copy event command requires '--target' option");
    }

    if (tokens.size() < 7) {
      throw new IllegalArgumentException("Target calendar name required after '--target'");
    }

    if (tokens.size() < 8
        || !tokens.get(7).equals("to")) {
      throw new IllegalArgumentException("Copy event command requires target time after 'to'");
    }

    if (tokens.size() < 9) {
      throw new IllegalArgumentException("Target date-time required after 'to'");
    }

    String toDateTime = tokens.get(8);
    try {
      java.time.LocalDateTime.parse(
          toDateTime, java.time.format.DateTimeFormatter.ISO_LOCAL_DATE_TIME);
    } catch (Exception e) {
      throw new IllegalArgumentException("Invalid to date-time format: " + toDateTime);
    }
  }
}