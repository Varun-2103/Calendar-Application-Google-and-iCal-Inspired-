package calendar.controller.components.executors;

import calendar.controller.CommandResult;
import calendar.controller.components.CommandExecutor;
import calendar.model.InterfaceCalendar;
import calendar.model.InterfaceCalendarManager;
import calendar.model.InterfaceEvent;
import java.time.LocalDateTime;
import java.util.List;

/**
 * Executor for editing all events in a series (events with the same subject).
 * Applies property changes to all matching events regardless of their scheduled times.
 */
public class EditSeriesExecutor implements CommandExecutor {
  
  private final InterfaceCalendarManager calendarManager;
  
  /**
   * Constructs an EditSeriesExecutor with the specified calendar manager.
   *
   * @param calendarManager the calendar manager to use for editing event series
   */
  public EditSeriesExecutor(InterfaceCalendarManager calendarManager) {
    this.calendarManager = calendarManager;
  }
  
  @Override
  public CommandResult execute(Object[] parameters) {
    try {
      if (parameters == null || parameters.length != 4) {
        return new CommandResult(false, "Expected 4 parameters for edit series");
      }
      
      String property = (String) parameters[0];
      String subject = (String) parameters[1];
      LocalDateTime fromDateTime = (LocalDateTime) parameters[2];
      Object newValue = parameters[3];
      
      InterfaceCalendar activeCalendar = calendarManager.getActiveCalendar();
      if (activeCalendar == null) {
        return new CommandResult(false, "No active calendar set");
      }
      
      List<InterfaceEvent> allEvents = activeCalendar.getAllEvents();
      int editedCount = 0;
      
      for (InterfaceEvent event : allEvents) {
        if (event.getSubject().equals(subject)) {
          switch (property) {
            case "subject":
              event.setSubject((String) newValue);
              break;
            case "location":
              event.setLocation((String) newValue);
              break;
            case "description":
              event.setDescription((String) newValue);
              break;
            case "status":
              event.setStatus((String) newValue);
              break;
            case "start":
              LocalDateTime newStart = LocalDateTime.parse((String) newValue);
              LocalDateTime updatedStart = LocalDateTime.of(
                  event.getStart().toLocalDate(),
                  newStart.toLocalTime()
              );
              event.setStart(updatedStart);
              break;
            case "end":
              LocalDateTime newEnd = LocalDateTime.parse((String) newValue);
              LocalDateTime updatedEnd = LocalDateTime.of(
                  event.getEnd().toLocalDate(),
                  newEnd.toLocalTime()
              );
              event.setEnd(updatedEnd);
              break;
            default:
              return new CommandResult(false, "Invalid property: " + property);
          }
          editedCount++;
        }
      }
      
      if (editedCount == 0) {
        return new CommandResult(false, "No matching events found for series");
      }
      
      return new CommandResult(true, "Successfully edited " + editedCount + " events in series");
      
    } catch (Exception e) {
      return new CommandResult(false, "Error editing series: " + e.getMessage());
    }
  }
}