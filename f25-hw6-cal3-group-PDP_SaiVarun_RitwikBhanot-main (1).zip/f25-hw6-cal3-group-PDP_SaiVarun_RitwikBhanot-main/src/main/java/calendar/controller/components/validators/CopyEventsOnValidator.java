package calendar.controller.components.validators;

import calendar.controller.components.CommandValidator;
import java.util.List;

/**
 * Validator for copy events on commands.
 */
public class CopyEventsOnValidator implements CommandValidator {
  
  @Override
  public void validate(List<String> tokens) {
    if (tokens.size() < 8) {
      throw new IllegalArgumentException(
          "Copy events on command requires at least 8 tokens, got: " + tokens.size());
    }
    
    if (!tokens.get(0).equals("copy")
        || !tokens.get(1).equals("events")) {
      throw new IllegalArgumentException("Command must start with 'copy events'");
    }
    
    if (!tokens.get(2).equals("on")) {
      throw new IllegalArgumentException("Expected 'on' after 'copy events'");
    }
    
    if (tokens.size() < 4) {
      throw new IllegalArgumentException("Date required after 'on'");
    }
    
    String date = tokens.get(3);
    try {
      java.time.LocalDate.parse(date);
    } catch (Exception e) {
      throw new IllegalArgumentException("Invalid date format: " + date);
    }
    
    if (!tokens.get(4).equals("--target")) {
      throw new IllegalArgumentException("Expected '--target' option");
    }
    
    if (tokens.size() < 6) {
      throw new IllegalArgumentException(
          "Target calendar name required after '--target'");
    }
    
    if (!tokens.get(6).equals("to")) {
      throw new IllegalArgumentException("Expected 'to' after target calendar");
    }
    
    if (tokens.size() < 7) {
      throw new IllegalArgumentException(
          "Target date required after 'to'");
    }
    
    String targetDate = tokens.get(7);
    try {
      java.time.LocalDate.parse(targetDate);
    } catch (Exception e) {
      throw new IllegalArgumentException(
          "Invalid target date format: " + targetDate);
    }
  }
}