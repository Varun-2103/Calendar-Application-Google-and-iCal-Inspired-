package calendar.controller.components.executors;

import calendar.controller.CommandResult;
import calendar.controller.components.CommandExecutor;
import calendar.model.InterfaceCalendar;
import calendar.model.InterfaceCalendarManager;
import calendar.model.InterfaceEvent;
import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.List;

/**
 * Executor for copying multiple events within a date range from one calendar to another.
 * Handles timezone conversion and maintains relative timing when copying events
 * between calendars with different timezones.
 */
public class CopyEventsExecutor implements CommandExecutor {
  
  private final InterfaceCalendarManager calendarManager;
  
  /**
   * Constructs a CopyEventsExecutor with the specified calendar manager.
   *
   * @param calendarManager the calendar manager to use for copying multiple events
   */
  public CopyEventsExecutor(InterfaceCalendarManager calendarManager) {
    this.calendarManager = calendarManager;
  }
  
  @Override
  public CommandResult execute(Object[] parameters) {
    try {
      LocalDate startDate = (LocalDate) parameters[0];
      LocalDate endDate = (LocalDate) parameters[1];
      String targetCalendarName = (String) parameters[2];
      final LocalDate targetDate = (LocalDate) parameters[3];
      
      InterfaceCalendar sourceCalendar = calendarManager.getActiveCalendar();
      if (sourceCalendar == null) {
        return new CommandResult(false, "No active calendar set");
      }
      
      InterfaceCalendar targetCalendar = calendarManager.getCalendar(targetCalendarName);
      if (targetCalendar == null) {
        return new CommandResult(false, "Target calendar '" + targetCalendarName
            + "' not found");
      }
      
      if (endDate.isBefore(startDate)) {
        return new CommandResult(false, "Invalid date range: end date cannot be before start date");
      }
      
      LocalDateTime startDateTime = startDate.atStartOfDay();
      LocalDateTime endDateTime = endDate.atTime(LocalTime.MAX);
      List<InterfaceEvent> eventsToCopy = sourceCalendar.getEventsBetween(startDateTime, 
          endDateTime);
      
      if (eventsToCopy.isEmpty()) {
        return new CommandResult(true, "No events found in the specified date range");
      }
      
      int copiedCount = 0;
      ZoneId sourceTz = sourceCalendar.getTimezone();
      ZoneId targetTz = targetCalendar.getTimezone();
      
      LocalDate earliestDate = null;
      for (InterfaceEvent event : eventsToCopy) {
        LocalDate eventDate = event.getStart().toLocalDate();
        if (earliestDate == null || eventDate.isBefore(earliestDate)) {
          earliestDate = eventDate;
        }
      }
      
      for (InterfaceEvent sourceEvent : eventsToCopy) {
        LocalDate originalEventDate = sourceEvent.getStart().toLocalDate();
        long daysOffset = java.time.temporal.ChronoUnit.DAYS.between(earliestDate, targetDate);
        
        LocalDateTime offsetStart = sourceEvent.getStart().plusDays(daysOffset);
        LocalDateTime offsetEnd = sourceEvent.getEnd().plusDays(daysOffset);
        
        ZonedDateTime sourceStartZoned = offsetStart.atZone(sourceTz);
        ZonedDateTime sourceEndZoned = offsetEnd.atZone(sourceTz);
        
        ZonedDateTime targetStartZoned = sourceStartZoned.withZoneSameInstant(targetTz);
        ZonedDateTime targetEndZoned = sourceEndZoned.withZoneSameInstant(targetTz);
        
        LocalDateTime newStart = targetStartZoned.toLocalDateTime();
        LocalDateTime newEnd = targetEndZoned.toLocalDateTime();
        
        targetCalendar.createEvent(sourceEvent.getSubject(), newStart, newEnd);
        copiedCount++;
      }
      
      return new CommandResult(true, "Successfully copied " + copiedCount + " events to '" 
          + targetCalendarName + "'");
      
    } catch (Exception e) {
      return new CommandResult(false, "Error copying events: " + e.getMessage());
    }
  }
}