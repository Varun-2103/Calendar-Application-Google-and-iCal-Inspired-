package calendar.controller.components.parsers;

import calendar.controller.components.CommandParser;
import java.time.LocalDate;
import java.util.List;

/**
 * Parser for copy events range commands.
 * Parses commands to copy events from a date range to a target calendar and date.
 */
public class CopyEventsParser implements CommandParser {

  @Override
  public Object[] parse(List<String> tokens) {
    LocalDate startDate = LocalDate.parse(tokens.get(3));
    LocalDate endDate = LocalDate.parse(tokens.get(5));
    String targetCalendar = tokens.get(7);
    LocalDate targetDate = LocalDate.parse(tokens.get(9));
    
    return new Object[]{startDate, endDate, targetCalendar, targetDate};
  }
}