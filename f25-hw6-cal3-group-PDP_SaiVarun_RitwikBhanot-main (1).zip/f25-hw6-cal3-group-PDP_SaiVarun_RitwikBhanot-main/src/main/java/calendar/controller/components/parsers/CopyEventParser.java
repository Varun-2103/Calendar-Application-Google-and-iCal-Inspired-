package calendar.controller.components.parsers;

import calendar.controller.components.CommandParser;
import calendar.util.DateTimeParser;
import java.time.LocalDateTime;
import java.util.List;

/**
 * Parser for copy event commands.
 * Parses commands to copy a single event to a different calendar and time.
 */
public class CopyEventParser implements CommandParser {

  @Override
  public Object[] parse(List<String> tokens) {
    final String eventName = removeQuotes(tokens.get(2));
    
    int onIndex = findKeywordIndex(tokens, "on", 2);
    if (onIndex == -1) {
      throw new IllegalArgumentException("Expected 'on' after event name");
    }
    String onStr = tokens.get(onIndex + 1);
    LocalDateTime onDateTime = DateTimeParser.parseDateTime(onStr);
    
    int targetIndex = findKeywordIndex(tokens, "--target", onIndex + 2);
    if (targetIndex == -1) {
      throw new IllegalArgumentException("Expected '--target' option");
    }
    String targetCalendar = tokens.get(targetIndex + 1);
    
    int toIndex = findKeywordIndex(tokens, "to", targetIndex + 2);
    if (toIndex == -1) {
      throw new IllegalArgumentException("Expected 'to' after target calendar");
    }
    String toStr = tokens.get(toIndex + 1);
    LocalDateTime toDateTime = DateTimeParser.parseDateTime(toStr);
    
    return new Object[]{eventName, onDateTime, targetCalendar, toDateTime};
  }

  private String removeQuotes(String str) {
    if (str == null) {
      return null;
    }
    if (str.startsWith("\"") && str.endsWith("\"")) {
      return str.substring(1, str.length() - 1);
    }
    return str;
  }

  private int findKeywordIndex(List<String> tokens, String keyword, int startIndex) {
    for (int i = startIndex; i < tokens.size(); i++) {
      if (tokens.get(i).equalsIgnoreCase(keyword)) {
        return i;
      }
    }
    return -1;
  }
}