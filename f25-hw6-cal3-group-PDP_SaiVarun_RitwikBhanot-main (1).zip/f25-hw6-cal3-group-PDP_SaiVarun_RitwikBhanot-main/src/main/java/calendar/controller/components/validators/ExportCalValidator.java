package calendar.controller.components.validators;

import calendar.controller.components.CommandValidator;
import java.util.List;

/**
 * Validator for export calendar commands.
 */
public class ExportCalValidator implements CommandValidator {
  
  @Override
  public void validate(List<String> tokens) {
    if (tokens.size() < 3) {
      throw new IllegalArgumentException("export cal requires filename");
    }
    
    if (!tokens.get(0).equals("export")
        || !tokens.get(1).equals("cal")) {
      throw new IllegalArgumentException("Command must be 'export cal'");
    }
    
    String fileName = tokens.get(2);
    
    // Remove quotes if present
    if (fileName.startsWith("\"") && fileName.endsWith("\"")) {
      fileName = fileName.substring(1, fileName.length() - 1);
    }
    
    if (fileName == null || fileName.trim().isEmpty()) {
      throw new IllegalArgumentException("Filename cannot be empty");
    }
    
    // Check file extension
    if (!fileName.endsWith(".csv")
        && !fileName.endsWith(".ical")) {
      throw new IllegalArgumentException("Filename must end with .csv or .ical");
    }
  }
}