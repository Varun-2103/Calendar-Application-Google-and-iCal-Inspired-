package calendar.controller.components.parsers;

import calendar.controller.components.CommandParser;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

/**
 * Parser for print events commands.
 * Parses commands to print events for a specific date or date range.
 */
public class PrintEventsParser implements CommandParser {

  @Override
  public Object[] parse(List<String> tokens) {
    if (tokens.get(2).equals("on")) {
      LocalDate date = LocalDate.parse(tokens.get(3));
      return new Object[]{date, null, null};
    } else {
      LocalDateTime fromDateTime = LocalDateTime.parse(tokens.get(3), 
          java.time.format.DateTimeFormatter.ISO_LOCAL_DATE_TIME);
      LocalDateTime toDateTime = LocalDateTime.parse(tokens.get(5), 
          java.time.format.DateTimeFormatter.ISO_LOCAL_DATE_TIME);
      return new Object[]{null, fromDateTime, toDateTime};
    }
  }
}