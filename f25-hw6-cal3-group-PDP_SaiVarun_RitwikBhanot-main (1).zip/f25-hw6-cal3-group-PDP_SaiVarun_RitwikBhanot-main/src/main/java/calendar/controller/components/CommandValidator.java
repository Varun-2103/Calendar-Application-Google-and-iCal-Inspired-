package calendar.controller.components;

import java.util.List;

/**
 * Interface for validating command tokens.
 */
public interface CommandValidator {
  /**
   * Validates the provided command tokens.
   *
   * @param tokens the command tokens to validate
   * @throws IllegalArgumentException if validation fails
   */
  void validate(List<String> tokens);
}