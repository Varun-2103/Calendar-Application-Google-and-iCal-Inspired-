package calendar.controller.components.executors;

import calendar.controller.CommandResult;
import calendar.controller.components.CommandExecutor;
import calendar.model.InterfaceCalendar;
import calendar.model.InterfaceCalendarManager;
import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * Executor for creating single events and event series.
 * Supports both individual event creation and recurring event series
 * with specified weekdays and occurrence patterns.
 */
public class CreateEventExecutor implements CommandExecutor {

  private final InterfaceCalendarManager calendarManager;

  /**
   * Constructs a CreateEventExecutor with the specified calendar manager.
   *
   * @param calendarManager the calendar manager to use for event creation
   */
  public CreateEventExecutor(InterfaceCalendarManager calendarManager) {
    this.calendarManager = calendarManager;
  }

  @Override
  public CommandResult execute(Object[] parameters) {
    try {
      InterfaceCalendar calendar = calendarManager.getActiveCalendar();
      if (calendar == null) {
        return new CommandResult(false, 
            "No calendar is currently in use. Use 'use calendar' command first.");
      }
      
      if (parameters.length == 3) {
        String subject = (String) parameters[0];
        LocalDateTime start = (LocalDateTime) parameters[1];
        LocalDateTime end = (LocalDateTime) parameters[2];
        
        calendar.createEvent(subject, start, end);
        return new CommandResult(true, "Event created successfully");
      } else if (parameters.length == 6) {
        String subject = (String) parameters[0];
        LocalDateTime start = (LocalDateTime) parameters[1];
        LocalDateTime end = (LocalDateTime) parameters[2];
        String weekdays = (String) parameters[3];
        boolean isForTimes = (Boolean) parameters[5];
        
        if (isForTimes) {
          int occurrences = (Integer) parameters[4];
          calendar.createEventSeries(subject, start, end, weekdays, occurrences);
          return new CommandResult(true, "Event series created successfully");
        } else {
          LocalDate until = (LocalDate) parameters[4];
          calendar.createEventSeriesUntil(subject, start, end, weekdays, until);
          return new CommandResult(true, "Event series created successfully");
        }
      }
      
      return new CommandResult(false, "Invalid parameters for event creation");
    } catch (IllegalArgumentException e) {
      return new CommandResult(false, e.getMessage());
    } catch (Exception e) {
      return new CommandResult(false, "Failed to create event: " + e.getMessage());
    }
  }
}