package calendar.controller.components.validators;

import calendar.controller.components.CommandValidator;
import java.util.List;

/**
 * Validator for show status commands.
 */
public class ShowStatusValidator implements CommandValidator {

  @Override
  public void validate(List<String> tokens) {
    if (tokens.size() < 4) {
      throw new IllegalArgumentException(
          "show status requires format: show status on datetime");
    }
    
    if (!tokens.get(2).equalsIgnoreCase("on")) {
      throw new IllegalArgumentException(
          "show status requires 'on' keyword followed by datetime");
    }
    
    if (tokens.size() < 4
        || tokens.get(3).trim().isEmpty()) {
      throw new IllegalArgumentException(
          "show status requires datetime after 'on'");
    }
  }
}