package calendar.controller.components.parsers;

import calendar.controller.components.CommandParser;
import java.util.List;

/**
 * Parser for export calendar commands.
 * Parses commands to export calendar data to a file.
 */
public class ExportCalParser implements CommandParser {

  @Override
  public Object[] parse(List<String> tokens) {
    String fileName = tokens.get(2);
    
    // Remove quotes if present
    if (fileName.startsWith("\"") && fileName.endsWith("\"")) {
      fileName = fileName.substring(1, fileName.length() - 1);
    }
    
    return new Object[]{fileName};
  }
}