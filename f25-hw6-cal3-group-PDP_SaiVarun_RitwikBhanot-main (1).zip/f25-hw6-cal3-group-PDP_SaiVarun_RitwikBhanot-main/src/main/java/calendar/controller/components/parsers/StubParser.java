package calendar.controller.components.parsers;

import calendar.controller.components.CommandParser;
import java.util.List;

/**
 * Stub parser for unimplemented commands.
 * Throws UnsupportedOperationException for any parse attempt.
 */
public class StubParser implements CommandParser {
  private final String commandType;
  
  /**
   * Constructs a StubParser for the specified command type.
   *
   * @param commandType the type of command that is not implemented
   */
  public StubParser(String commandType) {
    this.commandType = commandType;
  }
  
  @Override
  public Object[] parse(List<String> tokens) {
    throw new UnsupportedOperationException(commandType + " not implemented yet");
  }
}