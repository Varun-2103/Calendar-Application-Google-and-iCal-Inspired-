package calendar.controller.components.validators;

import calendar.controller.components.CommandValidator;
import java.util.List;

/**
 * Stub validator for unimplemented commands.
 */
public class StubValidator implements CommandValidator {
  private final String commandType;
  
  /**
   * Creates a new StubValidator.
   *
   * @param commandType the type of command
   */
  public StubValidator(String commandType) {
    this.commandType = commandType;
  }
  
  /**
   * Validates the command tokens.
   *
   * @param tokens the command tokens
   */
  @Override
  public void validate(List<String> tokens) {
    throw new UnsupportedOperationException(
        commandType + " not implemented yet");
  }
}