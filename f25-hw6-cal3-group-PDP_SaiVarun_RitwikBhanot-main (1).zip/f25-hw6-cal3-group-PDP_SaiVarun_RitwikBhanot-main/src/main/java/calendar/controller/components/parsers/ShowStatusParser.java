package calendar.controller.components.parsers;

import calendar.controller.components.CommandParser;
import calendar.util.DateTimeParser;
import java.time.LocalDateTime;
import java.util.List;

/**
 * Parser for show status commands.
 * Parses commands to show calendar status at a specific point in time.
 */
public class ShowStatusParser implements CommandParser {

  @Override
  public Object[] parse(List<String> tokens) {
    String dateTimeStr = tokens.get(3);
    LocalDateTime dateTime = DateTimeParser.parseDateTime(dateTimeStr);
    return new Object[]{dateTime};
  }
}