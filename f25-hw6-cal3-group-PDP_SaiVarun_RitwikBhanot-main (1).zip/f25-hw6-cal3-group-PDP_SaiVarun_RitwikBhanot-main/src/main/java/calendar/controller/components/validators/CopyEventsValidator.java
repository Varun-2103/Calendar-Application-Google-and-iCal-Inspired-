package calendar.controller.components.validators;

import calendar.controller.components.CommandValidator;
import java.util.List;

/**
 * Validator for copy events commands.
 */
public class CopyEventsValidator implements CommandValidator {
  
  @Override
  public void validate(List<String> tokens) {
    if (!tokens.get(0).equals("copy")
        || !tokens.get(1).equals("events")) {
      throw new IllegalArgumentException("Command must start with 'copy events'");
    }
    

    if (tokens.size() < 3) {
      throw new IllegalArgumentException(
          "Invalid copy events command: missing date specification");
    }
    
    String thirdToken = tokens.get(2);
    if (thirdToken.equals("between")) {
      validateBetweenFormat(tokens);
    } else if (thirdToken.equals("on")) {
      validateOnFormat(tokens);
    } else {
      throw new IllegalArgumentException(
          "Invalid copy events command: missing date");
    }
  }
  
  private void validateBetweenFormat(List<String> tokens) {
    if (tokens.size() < 4) {
      throw new IllegalArgumentException(
          "Invalid copy events command: missing start date");
    }
    
    String startDate = tokens.get(3);
    try {
      java.time.LocalDate.parse(startDate);
    } catch (Exception e) {
      throw new IllegalArgumentException(
          "Invalid copy events command: invalid start date");
    }
    
    if (tokens.size() < 5) {
      throw new IllegalArgumentException(
          "Invalid copy events command: missing 'and' keyword");
    }
    
    if (!tokens.get(4).equals("and")) {
      throw new IllegalArgumentException(
          "Invalid copy events command: missing end date");
    }
    
    if (tokens.size() < 6) {
      throw new IllegalArgumentException("Invalid copy events command: missing end date");
    }
    
    String endDate = tokens.get(5);
    try {
      java.time.LocalDate.parse(endDate);
    } catch (Exception e) {
      throw new IllegalArgumentException(
          "Invalid copy events command: invalid end date");
    }
    

    try {
      java.time.LocalDate start = java.time.LocalDate.parse(startDate);
      java.time.LocalDate end = java.time.LocalDate.parse(endDate);
      if (start.isAfter(end)) {
        throw new IllegalArgumentException(
            "Invalid copy events command: invalid date range");
      }
    } catch (Exception e) {
      if (e.getMessage().contains("range")) {
        throw e;
      }
      throw new IllegalArgumentException(
          "Invalid copy events command: invalid date range");
    }
    
    if (tokens.size() < 7) {
      throw new IllegalArgumentException(
          "Invalid copy events command: missing target specification");
    }
    
    if (!tokens.get(6).equals("--target")) {
      throw new IllegalArgumentException(
          "Invalid copy events command: expected '--target' option");
    }
    
    if (tokens.size() < 8) {
      throw new IllegalArgumentException(
          "Invalid copy events command: missing target calendar name");
    }
    
    if (tokens.size() < 9) {
      throw new IllegalArgumentException(
          "Invalid copy events command: missing 'to' keyword");
    }
    
    if (!tokens.get(8).equals("to")) {
      throw new IllegalArgumentException(
          "Invalid copy events command: expected 'to' after target calendar");
    }
    
    if (tokens.size() < 10) {
      throw new IllegalArgumentException(
          "Invalid copy events command: missing target date");
    }
    
    String targetDate = tokens.get(9);
    try {
      java.time.LocalDate.parse(targetDate);
    } catch (Exception e) {
      throw new IllegalArgumentException(
          "Invalid copy events command: invalid target date");
    }
  }
  
  private void validateOnFormat(List<String> tokens) {
    if (tokens.size() < 4) {
      throw new IllegalArgumentException(
          "Invalid copy events command: missing date");
    }
    
    String date = tokens.get(3);
    try {
      java.time.LocalDate.parse(date);
    } catch (Exception e) {
      throw new IllegalArgumentException(
          "Invalid copy events command: invalid date");
    }
    
    if (tokens.size() < 5) {
      throw new IllegalArgumentException(
          "Invalid copy events command: missing target specification");
    }
    
    if (!tokens.get(4).equals("--target")) {
      throw new IllegalArgumentException(
          "Invalid copy events command: expected '--target' option");
    }
    
    if (tokens.size() < 6) {
      throw new IllegalArgumentException(
          "Invalid copy events command: missing target calendar name");
    }
    
    if (tokens.size() < 7) {
      throw new IllegalArgumentException(
          "Invalid copy events command: missing 'to' keyword");
    }
    
    if (!tokens.get(6).equals("to")) {
      throw new IllegalArgumentException(
          "Invalid copy events command: expected 'to' after target calendar");
    }
    
    if (tokens.size() < 8) {
      throw new IllegalArgumentException(
          "Invalid copy events command: missing target date");
    }
    
    String targetDate = tokens.get(7);
    try {
      java.time.LocalDate.parse(targetDate);
    } catch (Exception e) {
      throw new IllegalArgumentException(
          "Invalid copy events command: invalid target date");
    }
  }
}