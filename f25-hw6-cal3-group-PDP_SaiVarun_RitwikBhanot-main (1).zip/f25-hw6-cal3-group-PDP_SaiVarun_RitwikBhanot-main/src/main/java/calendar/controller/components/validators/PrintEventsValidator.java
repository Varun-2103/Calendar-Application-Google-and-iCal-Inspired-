package calendar.controller.components.validators;

import calendar.controller.components.CommandValidator;
import java.util.List;

/**
 * Validator for print events commands.
 */
public class PrintEventsValidator implements CommandValidator {
  
  @Override
  public void validate(List<String> tokens) {
    if (tokens.size() < 4) {
      throw new IllegalArgumentException(
          "Print events command requires at least 4 tokens, got: " + tokens.size());
    }
    
    if (!tokens.get(0).equals("print")
        || !tokens.get(1).equals("events")) {
      throw new IllegalArgumentException("Command must start with 'print events'");
    }
    
    if (tokens.get(2).equals("on")) {
      // Syntax: print events on [date]
      if (tokens.size() < 4) {
        throw new IllegalArgumentException("Date required after 'on'");
      }
      
      String date = tokens.get(3);
      try {
        java.time.LocalDate.parse(date);
      } catch (Exception e) {
        throw new IllegalArgumentException("Invalid date format: " + date);
      }
    } else if (tokens.get(2).equals("from")) {
      // Syntax: print events from [datetime] to [datetime]
      if (tokens.size() < 6) {
        throw new IllegalArgumentException(
            "From datetime and 'to' keyword required");
      }
      
      String fromDateTime = tokens.get(3);
      try {
        java.time.LocalDateTime.parse(
            fromDateTime, java.time.format.DateTimeFormatter.ISO_LOCAL_DATE_TIME);
      } catch (Exception e) {
        throw new IllegalArgumentException(
            "Invalid from datetime format: " + fromDateTime);
      }
      
      if (!tokens.get(4).equals("to")) {
        throw new IllegalArgumentException("Expected 'to' after from datetime");
      }
      
      if (tokens.size() < 6) {
        throw new IllegalArgumentException(
            "To datetime required after 'to'");
      }
      
      String toDateTime = tokens.get(5);
      try {
        java.time.LocalDateTime.parse(
            toDateTime, java.time.format.DateTimeFormatter.ISO_LOCAL_DATE_TIME);
      } catch (Exception e) {
        throw new IllegalArgumentException(
            "Invalid to datetime format: " + toDateTime);
      }
    } else {
      throw new IllegalArgumentException(
          "Expected 'on' or 'from' after 'print events'");
    }
  }
}