package calendar.controller.components.executors;

import calendar.controller.CommandResult;
import calendar.controller.components.CommandExecutor;
import calendar.export.CsvCalendarExporter;
import calendar.export.IcalExporter;
import calendar.export.InterfaceCalendarExporter;
import calendar.model.InterfaceCalendar;
import calendar.model.InterfaceCalendarManager;
import calendar.model.InterfaceEvent;
import java.io.IOException;
import java.util.List;

/**
 * Executor for exporting calendar events to external file formats.
 * Supports CSV and iCal export formats with appropriate file handling.
 */
public class ExportCalExecutor implements CommandExecutor {
  
  private final InterfaceCalendarManager calendarManager;
  
  /**
   * Constructs an ExportCalExecutor with the specified calendar manager.
   *
   * @param calendarManager the calendar manager to use for calendar export
   */
  public ExportCalExecutor(InterfaceCalendarManager calendarManager) {
    this.calendarManager = calendarManager;
  }
  
  @Override
  public CommandResult execute(Object[] parameters) {
    try {
      InterfaceCalendar activeCalendar = calendarManager.getActiveCalendar();
      if (activeCalendar == null) {
        return new CommandResult(false, "No calendar currently in use");
      }
      
      String fileName = (String) parameters[0];
      
      List<InterfaceEvent> events = activeCalendar.getAllEvents();
      
      InterfaceCalendarExporter exporter;
      if (fileName.endsWith(".csv")) {
        exporter = new CsvCalendarExporter();
      } else if (fileName.endsWith(".ical")) {
        exporter = new IcalExporter();
      } else {
        return new CommandResult(false, "Unsupported file format. Use .csv or .ical");
      }
      String exportedPath = exporter.export(events, fileName);
      
      return new CommandResult(true, exportedPath);
      
    } catch (IOException e) {
      return new CommandResult(false, "File error: " + e.getMessage());
    } catch (Exception e) {
      return new CommandResult(false, "Error exporting calendar: " + e.getMessage());
    }
  }
}