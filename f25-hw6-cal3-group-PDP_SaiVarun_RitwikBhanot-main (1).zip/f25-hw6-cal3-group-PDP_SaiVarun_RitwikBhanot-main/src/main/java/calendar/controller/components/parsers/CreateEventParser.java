package calendar.controller.components.parsers;

import calendar.controller.components.CommandParser;
import calendar.controller.strategies.CommandStrategy;
import calendar.util.DateTimeParser;
import calendar.util.EventValidator;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

/**
 * Parser for create event commands.
 * Parses commands to create single events or recurring event series with various properties.
 */
public class CreateEventParser implements CommandParser {

  @Override
  public Object[] parse(List<String> tokens) {
    String subject = removeQuotes(tokens.get(2));
    
    String command = String.join(" ", tokens);
    String lower = command.toLowerCase();
    
    LocalDateTime start;
    LocalDateTime end;
    int toIndex = -1;
    
    if (lower.contains(" on ") && !lower.contains(" from ")) {
      int onIdx = findKeywordIndex(tokens, "on", 3);
      String dateStr = tokens.get(onIdx + 1);
      LocalDate date = DateTimeParser.parseDate(dateStr);
      start = date.atTime(8, 0);
      end = date.atTime(17, 0);
      toIndex = onIdx;
    } else if (lower.contains(" from ")) {
      int fromIndex = findKeywordIndex(tokens, "from", 3);
      toIndex = findKeywordIndex(tokens, "to", fromIndex + 2);
      String startStr = tokens.get(fromIndex + 1);
      String endStr = tokens.get(toIndex + 1);
      start = DateTimeParser.parseDateTime(startStr);
      end = DateTimeParser.parseDateTime(endStr);
    } else {
      throw new IllegalArgumentException("Event must specify 'on' (all-day) or 'from' (timed)");
    }
    
    int repeatsIndex = findKeywordIndex(tokens, "repeats", toIndex + 2);
    
    if (repeatsIndex != -1) {
      if (repeatsIndex + 1 >= tokens.size()) {
        throw new IllegalArgumentException("Series requires weekdays after 'repeats'");
      }
      
      String weekdays = tokens.get(repeatsIndex + 1);
      EventValidator.validateWeekdays(weekdays);
      
      if (repeatsIndex + 2 < tokens.size()) {
        String nextToken = tokens.get(repeatsIndex + 2);
        if (nextToken.equalsIgnoreCase("for")) {
          if (repeatsIndex + 4 >= tokens.size()
              || !tokens.get(repeatsIndex + 4).equalsIgnoreCase("times")) {
            throw new IllegalArgumentException("Series format: repeats weekdays for N times");
          }
          int occurrences = Integer.parseInt(tokens.get(repeatsIndex + 3));
          EventValidator.validateOccurrences(occurrences);
          EventValidator.validateSameDay(start, end);
          return new Object[]{subject, start, end, weekdays, occurrences, true};
        } else if (nextToken.equalsIgnoreCase("until")) {
          if (repeatsIndex + 3 >= tokens.size()) {
            throw new IllegalArgumentException("Series format: repeats weekdays until date");
          }
          LocalDate until = DateTimeParser.parseDate(tokens.get(repeatsIndex + 3));
          EventValidator.validateUntilDate(start.toLocalDate(), until);
          EventValidator.validateSameDay(start, end);
          return new Object[]{subject, start, end, weekdays, until, false};
        }
      }
      
      throw new IllegalArgumentException("Series must specify 'for N times' or 'until date'");
    }
    
    return new Object[]{subject, start, end};
  }

  private String removeQuotes(String str) {
    if (str == null) {
      return null;
    }
    if (str.startsWith("\"") && str.endsWith("\"")) {
      return str.substring(1, str.length() - 1);
    }
    return str;
  }

  private int findKeywordIndex(List<String> tokens, String keyword, int startIndex) {
    for (int i = startIndex; i < tokens.size(); i++) {
      if (tokens.get(i).equalsIgnoreCase(keyword)) {
        return i;
      }
    }
    return -1;
  }
}