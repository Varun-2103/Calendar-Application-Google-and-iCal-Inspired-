package calendar.controller.components.validators;

import calendar.controller.components.CommandValidator;
import java.util.List;

/**
 * Validator for edit series commands.
 */
public class EditSeriesValidator implements CommandValidator {

  @Override
  public void validate(List<String> tokens) {
    if (tokens.size() < 7) {
      throw new IllegalArgumentException("Edit series command requires at least 7 tokens");
    }

    if (!tokens.get(0).equals("edit")
        || !tokens.get(1).equals("series")) {
      throw new IllegalArgumentException("Command must start with 'edit series'");
    }

    String property = tokens.get(2);
    if (!property.equals("subject")
        && !property.equals("location")
        && !property.equals("description")
        && !property.equals("status")
        && !property.equals("start")
        && !property.equals("end")) {
      throw new IllegalArgumentException("Invalid property for edit series: " + property);
    }

    // Subject can be with or without quotes - just check it's not empty
    String subject = tokens.get(3);
    if (subject.trim().isEmpty()) {
      throw new IllegalArgumentException("Event subject cannot be empty");
    }

    if (!tokens.get(4).equals("from")) {
      throw new IllegalArgumentException("Expected 'from' after event subject");
    }

    String fromDateTime = tokens.get(5);
    try {
      java.time.LocalDateTime.parse(
          fromDateTime, java.time.format.DateTimeFormatter.ISO_LOCAL_DATE_TIME);
    } catch (Exception e) {
      throw new IllegalArgumentException("Invalid from date-time format: " + fromDateTime);
    }

    if (tokens.size() < 7
        || !tokens.get(6).equals("with")) {
      throw new IllegalArgumentException("Expected 'with' after from date-time");
    }

    if (tokens.size() < 8) {
      throw new IllegalArgumentException("Edit series command requires value after 'with'");
    }
  }
}