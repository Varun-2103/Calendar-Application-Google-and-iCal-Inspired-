package calendar.controller.components.executors;

import calendar.controller.CommandResult;
import calendar.controller.components.CommandExecutor;
import java.util.List;

/**
 * Stub executor for unimplemented commands.
 * Provides a placeholder implementation that returns an error message
 * indicating the command is not yet implemented.
 */
public class StubExecutor implements CommandExecutor {
  private final String commandType;
  
  /**
   * Constructs a StubExecutor for the specified command type.
   *
   * @param commandType the type of command that is not implemented
   */
  public StubExecutor(String commandType) {
    this.commandType = commandType;
  }
  
  @Override
  public CommandResult execute(Object[] parameters) {
    return new CommandResult(false, commandType + " not implemented yet");
  }
}