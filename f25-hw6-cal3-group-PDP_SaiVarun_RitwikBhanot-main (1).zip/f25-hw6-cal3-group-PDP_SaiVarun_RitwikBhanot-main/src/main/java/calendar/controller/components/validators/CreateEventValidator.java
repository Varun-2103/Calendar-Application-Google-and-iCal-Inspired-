package calendar.controller.components.validators;

import calendar.controller.components.CommandValidator;
import java.util.List;

/**
 * Validator for create event commands.
 */
public class CreateEventValidator implements CommandValidator {

  @Override
  public void validate(List<String> tokens) {
    String command = String.join(" ", tokens);
    String lower = command.toLowerCase();

    if (tokens.size() < 5) {
      throw new IllegalArgumentException(
          "create event requires format: create event \"subject\" from start to end [repeats ...] "
              + "or create event \"subject\" on date [repeats ...]");
    }

    // Subject can be with or without quotes
    String subject = tokens.get(2);
    if (subject.trim().isEmpty()) {
      throw new IllegalArgumentException("Subject cannot be empty");
    }

    if (lower.contains(" on ") && !lower.contains(" from ")) {
      int onIdx = lower.indexOf(" on ");
      if (onIdx + 4 >= command.length()) {
        throw new IllegalArgumentException("create event requires date after 'on'");
      }
    } else if (lower.contains(" from ")) {
      int fromIndex = findKeywordIndex(tokens, "from", 3);
      if (fromIndex == -1 || fromIndex + 1 >= tokens.size()) {
        throw new IllegalArgumentException(
            "create event requires 'from' keyword followed by start time");
      }

      int toIndex = findKeywordIndex(tokens, "to", fromIndex + 2);
      if (toIndex == -1 || toIndex + 1 >= tokens.size()) {
        throw new IllegalArgumentException(
            "create event requires 'to' keyword followed by end time");
      }
    } else {
      throw new IllegalArgumentException(
          "create event requires 'on' (all-day) or 'from' (timed) keyword");
    }
  }

  private int findKeywordIndex(List<String> tokens, String keyword, int startIndex) {
    for (int i = startIndex; i < tokens.size(); i++) {
      if (tokens.get(i).equalsIgnoreCase(keyword)) {
        return i;
      }
    }
    return -1;
  }
}