package calendar.controller.components.validators;

import calendar.controller.components.CommandValidator;
import java.util.List;

/**
 * Validator for edit event commands.
 */
public class EditEventValidator implements CommandValidator {

  @Override
  public void validate(List<String> tokens) {
    if (tokens.size() < 8) {
      throw new IllegalArgumentException("Edit event command too short");
    }

    if (!tokens.get(0).equalsIgnoreCase("edit")
        || !tokens.get(1).equalsIgnoreCase("event")) {
      throw new IllegalArgumentException("Command must start with 'edit event'");
    }

    String property = tokens.get(2).toLowerCase();
    if (!isValidProperty(property)) {
      throw new IllegalArgumentException("Invalid property: " + property
          + ". Valid properties: subject, location, start, end, description, status");
    }

    int fromIndex = findKeywordIndex(tokens, "from", 3);
    if (fromIndex == -1) {
      throw new IllegalArgumentException("Missing 'from' keyword");
    }

    int toIndex = findKeywordIndex(tokens, "to", fromIndex + 2);
    if (toIndex == -1) {
      throw new IllegalArgumentException("Missing 'to' keyword");
    }

    int withIndex = findKeywordIndex(tokens, "with", toIndex + 2);
    if (withIndex == -1) {
      throw new IllegalArgumentException("Missing 'with' keyword");
    }

    if (withIndex + 1 >= tokens.size()) {
      throw new IllegalArgumentException("Missing value after 'with'");
    }

    String startStr = tokens.get(fromIndex + 1);
    String endStr = tokens.get(toIndex + 1);

    try {
      calendar.util.DateTimeParser.parseDateTime(startStr);
      calendar.util.DateTimeParser.parseDateTime(endStr);
    } catch (Exception e) {
      throw new IllegalArgumentException(
          "Invalid date-time format: " + e.getMessage());
    }

    if (property.equals("status")) {
      String status = removeQuotes(tokens.get(withIndex + 1));
      if (!isValidStatus(status)) {
        throw new IllegalArgumentException("Invalid status: " + status
            + ". Valid statuses: public, private, tentative, confirmed");
      }
    }
  }

  private boolean isValidProperty(String property) {
    return property.equals("subject")
        || property.equals("location")
        || property.equals("start")
        || property.equals("end")
        || property.equals("description")
        || property.equals("status");
  }

  private boolean isValidStatus(String status) {
    return status.equalsIgnoreCase("public")
        || status.equalsIgnoreCase("private")
        || status.equalsIgnoreCase("tentative")
        || status.equalsIgnoreCase("confirmed");
  }

  private int findKeywordIndex(List<String> tokens, String keyword, int startIndex) {
    for (int i = startIndex; i < tokens.size(); i++) {
      if (tokens.get(i).equalsIgnoreCase(keyword)) {
        return i;
      }
    }
    return -1;
  }

  private String removeQuotes(String str) {
    if (str == null) {
      return null;
    }
    if (str.startsWith("\"") && str.endsWith("\"")) {
      return str.substring(1, str.length() - 1);
    }
    return str;
  }
}