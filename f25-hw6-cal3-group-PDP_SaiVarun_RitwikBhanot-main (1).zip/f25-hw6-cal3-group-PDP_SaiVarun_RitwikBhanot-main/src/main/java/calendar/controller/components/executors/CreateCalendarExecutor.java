package calendar.controller.components.executors;

import calendar.controller.CommandResult;
import calendar.controller.components.CommandExecutor;
import calendar.model.InterfaceCalendarManager;
import java.security.spec.RSAOtherPrimeInfo;
import java.time.ZoneId;

/**
 * Executor for creating new calendars with specified names and timezones.
 * Validates calendar creation parameters and handles error cases.
 */
public class CreateCalendarExecutor implements CommandExecutor {

  private final InterfaceCalendarManager calendarManager;

  /**
   * Constructs a CreateCalendarExecutor with the specified calendar manager.
   *
   * @param calendarManager the calendar manager to use for calendar creation
   */
  public CreateCalendarExecutor(InterfaceCalendarManager calendarManager) {
    this.calendarManager = calendarManager;
  }

  @Override
  public CommandResult execute(Object[] parameters) {
    try {
      String name = (String) parameters[0];
      ZoneId timezone = (ZoneId) parameters[1];
      calendarManager.createCalendar(name, timezone);
      return new CommandResult(true, "Calendar '" + name + "' created successfully with timezone " 
          + timezone);
    } catch (IllegalArgumentException e) {
      return new CommandResult(false, e.getMessage());
    } catch (Exception e) {
      return new CommandResult(false, "Failed to create calendar: " + e.getMessage());
    }
  }
}