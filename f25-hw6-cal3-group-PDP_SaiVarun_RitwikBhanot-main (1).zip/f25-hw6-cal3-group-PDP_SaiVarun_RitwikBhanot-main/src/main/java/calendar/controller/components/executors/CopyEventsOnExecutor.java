package calendar.controller.components.executors;

import calendar.controller.CommandResult;
import calendar.controller.components.CommandExecutor;
import calendar.model.InterfaceCalendar;
import calendar.model.InterfaceCalendarManager;
import calendar.model.InterfaceEvent;
import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.List;

/**
 * Executor for copying all events on a specific date from one calendar to another.
 * Handles timezone conversion and special handling for all-day events
 * when copying between calendars with different timezones.
 */
public class CopyEventsOnExecutor implements CommandExecutor {
  
  private final InterfaceCalendarManager calendarManager;
  
  /**
   * Constructs a CopyEventsOnExecutor with the specified calendar manager.
   *
   * @param calendarManager the calendar manager to use for copying events on specific date
   */
  public CopyEventsOnExecutor(InterfaceCalendarManager calendarManager) {
    this.calendarManager = calendarManager;
  }
  
  @Override
  public CommandResult execute(Object[] parameters) {
    try {
      LocalDate date = (LocalDate) parameters[0];
      String targetCalendarName = (String) parameters[1];
      final LocalDate targetDate = (LocalDate) parameters[2];
      
      InterfaceCalendar sourceCalendar = calendarManager.getActiveCalendar();
      if (sourceCalendar == null) {
        return new CommandResult(false, "No active calendar set");
      }
      
      InterfaceCalendar targetCalendar = calendarManager.getCalendar(targetCalendarName);
      if (targetCalendar == null) {
        return new CommandResult(false, "Target calendar '" + targetCalendarName + "' not found");
      }
      
      List<InterfaceEvent> eventsToCopy = sourceCalendar.getEventsOn(date);
      
      if (eventsToCopy.isEmpty()) {
        return new CommandResult(true, "No events found on " + date);
      }
      
      int copiedCount = 0;
      ZoneId sourceTz = sourceCalendar.getTimezone();
      ZoneId targetTz = targetCalendar.getTimezone();
      
      for (InterfaceEvent sourceEvent : eventsToCopy) {
        boolean isAllDayEvent = sourceEvent.getStart().getHour() == 8
                               && sourceEvent.getStart().getMinute() == 0
                               && sourceEvent.getEnd().getHour() == 17
                               && sourceEvent.getEnd().getMinute() == 0;
        
        if (isAllDayEvent) {
          LocalDateTime newStart = targetDate.atTime(8, 0);
          LocalDateTime newEnd = targetDate.atTime(17, 0);
          targetCalendar.createEvent(sourceEvent.getSubject(), newStart, newEnd);
        } else {
          ZonedDateTime sourceStartZoned = sourceEvent.getStart().atZone(sourceTz);
          ZonedDateTime sourceEndZoned = sourceEvent.getEnd().atZone(sourceTz);
          
          ZonedDateTime targetStartZoned = sourceStartZoned.withZoneSameInstant(targetTz);
          ZonedDateTime targetEndZoned = sourceEndZoned.withZoneSameInstant(targetTz);
          
          LocalDate convertedEventDate = targetStartZoned.toLocalDate();
          long daysOffset = java.time.temporal.ChronoUnit.DAYS.between(convertedEventDate, 
              targetDate);
          
          LocalDateTime newStart = targetStartZoned.toLocalDateTime().plusDays(daysOffset);
          LocalDateTime newEnd = targetEndZoned.toLocalDateTime().plusDays(daysOffset);
          
          targetCalendar.createEvent(sourceEvent.getSubject(), newStart, newEnd);
        }
        copiedCount++;
      }
      
      return new CommandResult(true, "Successfully copied " + copiedCount + " events from " + date 
          + " to '" + targetCalendarName + "' on " + targetDate);
      
    } catch (Exception e) {
      return new CommandResult(false, "Error copying events: " + e.getMessage());
    }
  }
}