package calendar.controller.components.parsers;

import calendar.controller.components.CommandParser;
import calendar.util.DateTimeParser;
import java.time.LocalDateTime;
import java.util.List;

/**
 * Parser for edit events commands.
 * Parses commands to edit properties of multiple events matching criteria.
 */
public class EditEventsParser implements CommandParser {

  @Override
  public Object[] parse(List<String> tokens) {
    String property = tokens.get(2).toLowerCase();
    
    String subject = removeQuotes(tokens.get(3));
    
    int fromIndex = findKeywordIndex(tokens, "from", 3);
    String fromStr = tokens.get(fromIndex + 1);
    LocalDateTime fromDateTime = DateTimeParser.parseDateTime(fromStr);
    
    int withIndex = findKeywordIndex(tokens, "with", fromIndex + 2);
    String newValue = removeQuotes(tokens.get(withIndex + 1));
    
    // Parse new value based on property type
    Object parsedValue = parseValueByProperty(property, newValue);
    
    return new Object[]{property, subject, fromDateTime, parsedValue};
  }

  private Object parseValueByProperty(String property, String value) {
    switch (property) {
      case "subject":
      case "location":
      case "description":
        return value;
      case "status":
        return value.toLowerCase();
      case "start":
        return DateTimeParser.parseDateTime(value);
      default:
        throw new IllegalArgumentException("Unknown property: " + property);
    }
  }

  private String removeQuotes(String str) {
    if (str == null) {
      return null;
    }
    if (str.startsWith("\"") && str.endsWith("\"")) {
      return str.substring(1, str.length() - 1);
    }
    return str;
  }

  private int findKeywordIndex(List<String> tokens, String keyword, int startIndex) {
    for (int i = startIndex; i < tokens.size(); i++) {
      if (tokens.get(i).equalsIgnoreCase(keyword)) {
        return i;
      }
    }
    return -1;
  }
}