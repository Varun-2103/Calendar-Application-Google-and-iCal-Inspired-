package calendar.controller.components;

import calendar.controller.CommandResult;

/**
 * Interface for executing commands with parsed parameters.
 */
public interface CommandExecutor {
  /**
   * Executes a command with the provided parameters.
   *
   * @param parameters the parsed command parameters
   * @return the result of command execution
   */
  CommandResult execute(Object[] parameters);
}