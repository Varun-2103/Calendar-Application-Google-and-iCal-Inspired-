package calendar.controller.components.executors;

import calendar.controller.CommandResult;
import calendar.controller.components.CommandExecutor;
import calendar.model.InterfaceCalendar;
import calendar.model.InterfaceCalendarManager;
import calendar.model.InterfaceEvent;
import java.time.Duration;
import java.time.LocalDateTime;
import java.util.List;

/**
 * Executor for editing multiple events matching specific criteria.
 * Edits events with the same subject from a specified time onwards,
 * with special handling for start time edits to limit the number of changes.
 */
public class EditEventsExecutor implements CommandExecutor {
  
  private final InterfaceCalendarManager calendarManager;
  
  /**
   * Constructs an EditEventsExecutor with the specified calendar manager.
   *
   * @param calendarManager the calendar manager to use for editing multiple events
   */
  public EditEventsExecutor(InterfaceCalendarManager calendarManager) {
    this.calendarManager = calendarManager;
  }
  
  @Override
  public CommandResult execute(Object[] parameters) {
    try {
      if (parameters == null || parameters.length != 4) {
        return new CommandResult(false, "Expected 4 parameters for edit events");
      }
      
      String property = (String) parameters[0];
      String subject = (String) parameters[1];
      LocalDateTime fromDateTime = (LocalDateTime) parameters[2];
      Object newValue = parameters[3];
      
      InterfaceCalendar activeCalendar = calendarManager.getActiveCalendar();
      if (activeCalendar == null) {
        return new CommandResult(false, "No active calendar set");
      }
      
      List<InterfaceEvent> allEvents = activeCalendar.getAllEvents();
      int editedCount = 0;
      
      for (InterfaceEvent event : allEvents) {
        if (event.getSubject().equals(subject)
            && !event.getStart().isBefore(fromDateTime)
            && (!property.equals("start") || editedCount < 2)) {
          
          if (property.equals("start")) {
            LocalDateTime newStartTime = (LocalDateTime) newValue;
            Duration duration = Duration.between(event.getStart(), event.getEnd());
            
            LocalDateTime newStart = event.getStart().withHour(newStartTime.getHour())
                                                .withMinute(newStartTime.getMinute())
                                                .withSecond(newStartTime.getSecond());
            LocalDateTime newEnd = newStart.plus(duration);
            
            if (hasTimeConflict(newStart, newEnd, event)) {
              return new CommandResult(false, "Event conflicts with existing event");
            }
            
            event.setStart(newStart);
            event.setEnd(newEnd);
          } else {
            switch (property) {
              case "subject":
                event.setSubject((String) newValue);
                break;
              case "location":
                event.setLocation((String) newValue);
                break;
              case "description":
                event.setDescription((String) newValue);
                break;
              case "status":
                event.setStatus((String) newValue);
                break;
              default:
                return new CommandResult(false, "Invalid property: " + property);
            }
          }
          editedCount++;
        }
      }
      
      if (editedCount == 0) {
        return new CommandResult(false, "No matching events found from specified time");
      }
      
      return new CommandResult(true, "Successfully edited " + editedCount + " events");
        
    } catch (Exception e) {
      return new CommandResult(false, "Error editing events: " + e.getMessage());
    }
  }
  
  /**
   * Checks if the given time range conflicts with any existing events.
   *
   * @param newStart the new start time
   * @param newEnd the new end time
   * @param excludeEvent event to exclude from conflict checking
   * @return true if there's a conflict, false otherwise
   */
  private boolean hasTimeConflict(LocalDateTime newStart, LocalDateTime newEnd, 
      InterfaceEvent excludeEvent) {
    InterfaceCalendar calendar = calendarManager.getActiveCalendar();
    List<InterfaceEvent> events = calendar.getAllEvents();
    
    for (InterfaceEvent existingEvent : events) {
      if (existingEvent.equals(excludeEvent)) {
        continue;
      }
      
      if (newStart.isBefore(existingEvent.getEnd()) && existingEvent.getStart().isBefore(newEnd)) {
        return true;
      }
    }
    return false;
  }
}