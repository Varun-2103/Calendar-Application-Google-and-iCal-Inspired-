package calendar.controller.components.executors;

import calendar.controller.CommandResult;
import calendar.controller.components.CommandExecutor;
import calendar.model.InterfaceCalendar;
import calendar.model.InterfaceCalendarManager;
import calendar.model.InterfaceEvent;
import java.time.LocalDateTime;
import java.util.List;

/**
 * Executor for editing individual event properties.
 * Supports editing subject, location, description, start/end times, and status
 * with conflict detection for time changes.
 */
public class EditEventExecutor implements CommandExecutor {

  private final InterfaceCalendarManager calendarManager;

  /**
   * Constructs an EditEventExecutor with the specified calendar manager.
   *
   * @param calendarManager the calendar manager to use for event editing
   */
  public EditEventExecutor(InterfaceCalendarManager calendarManager) {
    this.calendarManager = calendarManager;
  }

  @Override
  public CommandResult execute(Object[] parameters) {
    try {
      InterfaceCalendar calendar = calendarManager.getActiveCalendar();
      if (calendar == null) {
        return new CommandResult(false, 
            "No calendar is currently in use. Use 'use calendar' command first.");
      }

      String property = (String) parameters[0];
      String subject = (String) parameters[1];
      LocalDateTime start = (LocalDateTime) parameters[2];
      LocalDateTime end = (LocalDateTime) parameters[3];
      Object newValue = parameters[4];

      List<InterfaceEvent> events = calendar.getAllEvents();
      InterfaceEvent targetEvent = null;

      for (InterfaceEvent event : events) {
        if (event.getSubject().equals(subject)
            && event.getStart().equals(start)
            && event.getEnd().equals(end)) {
          targetEvent = event;
          break;
        }
      }

      if (targetEvent == null) {
        return new CommandResult(false, "Event not found: " + subject
            + " from " + start + " to " + end);
      }

      try {
        editEventProperty(targetEvent, property, newValue);
      } catch (IllegalArgumentException e) {
        return new CommandResult(false, e.getMessage());
      }

      return new CommandResult(true, "Event " + property + " updated successfully");

    } catch (IllegalArgumentException e) {
      return new CommandResult(false, e.getMessage());
    } catch (Exception e) {
      return new CommandResult(false, "Failed to edit event: " + e.getMessage());
    }
  }

  private void editEventProperty(InterfaceEvent event, String property, Object newValue) {
    switch (property) {
      case "subject":
        String newSubject = (String) newValue;
        if (newSubject == null || newSubject.trim().isEmpty()) {
          throw new IllegalArgumentException("Event subject cannot be empty");
        }
        event.setSubject(newSubject);
        break;
      case "location":
        event.setLocation((String) newValue);
        break;
      case "description":
        event.setDescription((String) newValue);
        break;
      case "start":
        LocalDateTime newStart = (LocalDateTime) newValue;
        java.time.Duration duration = java.time.Duration.between(event.getStart(), event.getEnd());
        LocalDateTime newEnd = newStart.plus(duration);
        
        if (hasTimeConflict(newStart, newEnd, event)) {
          throw new IllegalArgumentException("Event conflicts with existing event");
        }
        event.setStart(newStart);
        event.setEnd(newEnd);
        break;
      case "end":
        LocalDateTime newEndTime = (LocalDateTime) newValue;
        if (newEndTime.isBefore(event.getStart())) {
          throw new IllegalArgumentException("Event end time cannot be before start time");
        }
        if (hasTimeConflict(event.getStart(), newEndTime, event)) {
          throw new IllegalArgumentException("Event conflicts with existing event");
        }
        event.setEnd(newEndTime);
        break;
      case "status":
        String statusStr = ((String) newValue).toLowerCase();
        if (!isValidStatus(statusStr)) {
          throw new IllegalArgumentException("Invalid status: " + statusStr);
        }
        event.setStatus(statusStr);
        break;
      default:
        throw new IllegalArgumentException("Unknown property: " + property);
    }
  }

  private boolean isValidStatus(String status) {
    return status.equals("public")
        || status.equals("private")
        || status.equals("tentative")
        || status.equals("confirmed");
  }

  /**
   * Checks if the given time range conflicts with any existing events.
   *
   * @param newStart the new start time
   * @param newEnd the new end time
   * @param excludeEvent event to exclude from conflict checking
   * @return true if there's a conflict, false otherwise
   */
  private boolean hasTimeConflict(LocalDateTime newStart, LocalDateTime newEnd, 
      InterfaceEvent excludeEvent) {
    InterfaceCalendar calendar = calendarManager.getActiveCalendar();
    List<InterfaceEvent> events = calendar.getAllEvents();
    
    for (InterfaceEvent existingEvent : events) {
      if (existingEvent.equals(excludeEvent)) {
        continue;
      }
      
      if (newStart.isBefore(existingEvent.getEnd()) && existingEvent.getStart().isBefore(newEnd)) {
        return true;
      }
    }
    return false;
  }
}