package calendar.controller.components;

import java.util.List;

/**
 * Interface for parsing command tokens into parameters.
 */
public interface CommandParser {
  /**
   * Parses the provided command tokens into an array of parameters.
   *
   * @param tokens the command tokens to parse
   * @return an array of parsed parameters
   */
  Object[] parse(List<String> tokens);
}