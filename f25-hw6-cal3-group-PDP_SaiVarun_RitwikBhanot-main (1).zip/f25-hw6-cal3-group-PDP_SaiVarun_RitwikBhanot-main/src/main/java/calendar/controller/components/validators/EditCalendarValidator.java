package calendar.controller.components.validators;

import calendar.controller.components.CommandValidator;
import java.util.List;

/**
 * Validator for edit calendar commands.
 */
public class EditCalendarValidator implements CommandValidator {

  @Override
  public void validate(List<String> tokens) {
    if (tokens.size() < 7) {
      throw new IllegalArgumentException(
          "edit calendar requires format: edit calendar --name <name> --property <property> "
              + "<value>");
    }
    
    if (!tokens.get(2).equals("--name")) {
      throw new IllegalArgumentException("edit calendar requires --name flag");
    }
    
    if (!tokens.get(4).equals("--property")) {
      throw new IllegalArgumentException("edit calendar requires --property flag");
    }
  }
}