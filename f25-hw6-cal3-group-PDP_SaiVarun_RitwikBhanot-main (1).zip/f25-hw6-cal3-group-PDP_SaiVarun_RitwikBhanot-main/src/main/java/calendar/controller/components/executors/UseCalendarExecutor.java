package calendar.controller.components.executors;

import calendar.controller.CommandResult;
import calendar.controller.components.CommandExecutor;
import calendar.model.InterfaceCalendarManager;

/**
 * Executor for setting the active calendar for operations.
 * Switches the current working calendar to the specified calendar name.
 */
public class UseCalendarExecutor implements CommandExecutor {

  private final InterfaceCalendarManager calendarManager;

  /**
   * Constructs a UseCalendarExecutor with the specified calendar manager.
   *
   * @param calendarManager the calendar manager to use for setting active calendar
   */
  public UseCalendarExecutor(InterfaceCalendarManager calendarManager) {
    this.calendarManager = calendarManager;
  }

  @Override
  public CommandResult execute(Object[] parameters) {
    try {
      String name = (String) parameters[0];
      
      calendarManager.useCalendar(name);
      return new CommandResult(true, "Now using calendar: " + name);
    } catch (IllegalArgumentException e) {
      return new CommandResult(false, e.getMessage());
    } catch (Exception e) {
      return new CommandResult(false, "Failed to use calendar: " + e.getMessage());
    }
  }
}