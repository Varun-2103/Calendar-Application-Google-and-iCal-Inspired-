package calendar.controller.components.validators;

import calendar.controller.components.CommandValidator;
import java.util.List;

/**
 * Validator for create calendar commands.
 */
public class CreateCalendarValidator implements CommandValidator {

  @Override
  public void validate(List<String> tokens) {
    if (tokens.size() < 6) {
      throw new IllegalArgumentException(
          "create calendar requires format: create calendar --name <calName> --timezone "
          + "area/location");
    }
    
    if (!tokens.get(2).equals("--name")) {
      throw new IllegalArgumentException("create calendar requires --name flag");
    }
    
    if (!tokens.get(4).equals("--timezone")) {
      throw new IllegalArgumentException("create calendar requires --timezone flag");
    }
  }
}