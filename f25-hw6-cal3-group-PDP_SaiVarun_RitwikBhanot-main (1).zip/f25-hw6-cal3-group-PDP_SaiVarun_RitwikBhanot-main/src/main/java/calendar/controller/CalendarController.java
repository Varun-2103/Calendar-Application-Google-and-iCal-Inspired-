package calendar.controller;

import calendar.controller.strategies.CommandStrategy;
import calendar.controller.strategies.CommandStrategyFactory;
import calendar.model.CalendarManager;
import calendar.model.InterfaceCalendarManager;
import calendar.view.InterfaceCalendarView;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Controller for managing calendar commands and coordinating between model and view.
 */
public class CalendarController implements InterfaceCalendarController {

  private final InterfaceCalendarManager calendarManager;
  private final CommandStrategyFactory strategyFactory;

  /**
   * Constructs a CalendarController with default calendar manager.
   */
  public CalendarController() {
    this.calendarManager = new CalendarManager();
    this.strategyFactory = new CommandStrategyFactory();
  }

  /**
   * Constructs a CalendarController with specified calendar manager.
   *
   * @param calendarManager the calendar manager to use, or null for default
   */
  public CalendarController(InterfaceCalendarManager calendarManager) {
    this.calendarManager = calendarManager != null ? calendarManager : new CalendarManager();
    this.strategyFactory = new CommandStrategyFactory();
  }

  @Override
  public void executeCommand(String commandString, InterfaceCalendarView view) {
    try {
      List<String> tokens = tokenize(commandString);
      CommandStrategy strategy = strategyFactory.createStrategy(tokens, calendarManager);
      CommandResult result = strategy.execute(tokens);

      if (result.isSuccess()) {
        if (result.hasEvents()) {
          view.displayEvents(result.getEvents());
        } else {
          if (result.getMessage() != null && !result.getMessage().isEmpty()) {
            view.displaySuccess(result.getMessage());
          }
        }
      } else {
        view.displayError(result.getMessage());
      }

    } catch (IllegalArgumentException e) {
      view.displayError("Invalid command: " + e.getMessage());
    } catch (Exception e) {
      view.displayError("Error executing command: " + e.getMessage());
    }
  }

  private List<String> tokenize(String command) {
    List<String> tokens = new ArrayList<>();
    Pattern pattern = Pattern.compile("\"([^\"]*)\"|([^\\s]+)");
    Matcher matcher = pattern.matcher(command);

    while (matcher.find()) {
      if (matcher.group(1) != null) {
        tokens.add("\"" + matcher.group(1) + "\"");
      } else {
        tokens.add(matcher.group(2));
      }
    }

    return tokens;
  }
}