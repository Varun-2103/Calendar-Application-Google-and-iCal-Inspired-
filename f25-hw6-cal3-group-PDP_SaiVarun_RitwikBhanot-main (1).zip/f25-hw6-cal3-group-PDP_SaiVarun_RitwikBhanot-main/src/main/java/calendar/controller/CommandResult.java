package calendar.controller;

import calendar.model.InterfaceEvent;
import java.util.ArrayList;
import java.util.List;

/**
 * Represents the result of executing a command.
 * Contains success status, a message, and optionally a list of events.
 */
public class CommandResult {

  private final boolean success;
  private final String message;
  private final List<InterfaceEvent> events;

  /**
   * Creates a command result with a success flag and message.
   *
   * @param success whether the command succeeded
   * @param message the result message
   */
  public CommandResult(boolean success, String message) {
    this.success = success;
    this.message = message;
    this.events = new ArrayList<>();
  }

  /**
   * Creates a command result with events (for query commands).
   *
   * @param success whether the command succeeded
   * @param message the result message
   * @param events  the events to include in the result
   */
  public CommandResult(boolean success, String message, List<InterfaceEvent> events) {
    this.success = success;
    this.message = message;
    this.events = events != null ? new ArrayList<>(events) : new ArrayList<>();
  }

  /**
   * Checks if the command execution was successful.
   *
   * @return true if successful, false otherwise
   */
  public boolean isSuccess() {
    return success;
  }

  /**
   * Gets the result message.
   *
   * @return the message describing the result
   */
  public String getMessage() {
    return message;
  }

  /**
   * Gets the list of events from the command result.
   *
   * @return a copy of the events list (empty if no events)
   */
  public List<InterfaceEvent> getEvents() {
    return new ArrayList<>(events);
  }

  /**
   * Checks if this result contains any events.
   *
   * @return true if events list is not empty, false otherwise
   */
  public boolean hasEvents() {
    return !events.isEmpty();
  }
}