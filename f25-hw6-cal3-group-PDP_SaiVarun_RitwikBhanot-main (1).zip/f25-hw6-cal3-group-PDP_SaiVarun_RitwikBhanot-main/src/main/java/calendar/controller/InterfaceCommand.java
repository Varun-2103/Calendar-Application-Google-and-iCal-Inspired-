package calendar.controller;

/**
 * Interface representing a command that can be executed on a calendar or calendar manager.
 * Follows Command design pattern.
 */
public interface InterfaceCommand {

  /**
   * Executes this command on the given target (calendar or calendar manager).
   *
   * @param target the target to operate on (InterfaceCalendar or InterfaceCalendarManager)
   * @return result of executing the command
   */
  CommandResult execute(Object target);
}