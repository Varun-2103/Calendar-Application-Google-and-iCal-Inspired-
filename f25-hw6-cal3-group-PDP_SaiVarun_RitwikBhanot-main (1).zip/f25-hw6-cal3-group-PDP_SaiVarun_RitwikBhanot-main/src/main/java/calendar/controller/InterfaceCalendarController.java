package calendar.controller;

import calendar.view.InterfaceCalendarView;

/**
 * Interface for the calendar controller.
 * Handles parsing and executing commands from user input.
 */
public interface InterfaceCalendarController {

  /**
   * Executes a command string and displays results using the view.
   *
   * @param commandString the command to execute
   * @param view          the view to display results
   */
  void executeCommand(String commandString, InterfaceCalendarView view);
}