package calendar.controller;

import calendar.controller.strategies.CommandStrategy;
import calendar.controller.strategies.CommandStrategyFactory;
import calendar.model.InterfaceCalendarManager;
import calendar.view.CalendarTextView;
import calendar.view.InterfaceCalendarView;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Adapter class to provide backward compatibility for integration tests
 * that expect the old CommandParser interface.
 */
public class CommandParser {

  private final CommandStrategyFactory factory;

  /**
   * Constructs a CommandParser with default strategy factory.
   */
  public CommandParser() {
    this.factory = new CommandStrategyFactory();
  }

  /**
   * Parses a command string and returns an InterfaceCommand adapter.
   *
   * @param commandString command string to parse
   * @return an InterfaceCommand adapter that wraps CommandStrategy
   */
  public InterfaceCommand parse(String commandString) {
    List<String> tokens = tokenize(commandString);
    return new CommandAdapter(commandString, tokens);
  }

  private List<String> tokenize(String command) {
    if (command == null) {
      return new ArrayList<>();
    }

    if (command.trim().isEmpty()) {
      return new ArrayList<>();
    }

    List<String> tokens = new ArrayList<>();
    Pattern pattern = Pattern.compile("\"([^\"]*)\"|([^\\s]+)");
    Matcher matcher = pattern.matcher(command);

    while (matcher.find()) {
      if (matcher.group(1) != null) {
        tokens.add("\"" + matcher.group(1) + "\"");
      } else {
        tokens.add(matcher.group(2));
      }
    }

    return tokens;
  }

  /**
   * Adapter class that implements InterfaceCommand using CommandStrategy.
   */
  private static class CommandAdapter implements InterfaceCommand {
    private final String commandString;
    private final List<String> tokens;

    public CommandAdapter(String commandString, List<String> tokens) {
      this.commandString = commandString;
      this.tokens = tokens;
    }

    @Override
    public CommandResult execute(Object target) {
      try {
        if (tokens.isEmpty()) {
          if (commandString == null) {
            return new CommandResult(false, "Invalid command: null command");
          } else {
            return new CommandResult(false, "Invalid command: empty command");
          }
        }

        InterfaceCalendarManager calendarManager = (InterfaceCalendarManager) target;
        CommandStrategyFactory factory = new CommandStrategyFactory();
        CommandStrategy strategy = factory.createStrategy(tokens, calendarManager);
        CommandResult result = strategy.execute(tokens);


        InterfaceCalendarView view = new CalendarTextView();

        if (result.isSuccess()) {
          if (result.hasEvents()) {
            view.displayEvents(result.getEvents());
          } else if (result.getMessage() != null && !result.getMessage().isEmpty()) {
            if (result.getMessage().equals("Busy") || result.getMessage().equals("Available")) {
              view.displayMessage(result.getMessage());
            } else if (!result.getMessage().contains("created")
                && !result.getMessage().contains("updated")
                && !result.getMessage().contains("copied")
                && !result.getMessage().contains("exported")) {
              view.displayMessage(result.getMessage());
            }
          }
        }

        return result;
      } catch (Exception e) {
        return new CommandResult(false, e.getMessage());
      }
    }
  }
}