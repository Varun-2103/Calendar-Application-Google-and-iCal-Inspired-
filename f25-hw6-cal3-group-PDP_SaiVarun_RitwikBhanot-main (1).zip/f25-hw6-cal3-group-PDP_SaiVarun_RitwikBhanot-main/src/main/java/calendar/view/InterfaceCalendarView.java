package calendar.view;

import calendar.model.InterfaceEvent;
import java.util.List;

/**
 * Interface for the calendar view.
 * Handles all output to the user.
 */
public interface InterfaceCalendarView {

  /**
   * Displays a general message to the user.
   *
   * @param message the message to display
   */
  void displayMessage(String message);

  /**
   * Displays a list of events.
   *
   * @param events the events to display
   */
  void displayEvents(List<InterfaceEvent> events);

  /**
   * Displays an error message.
   *
   * @param error the error message to display
   */
  void displayError(String error);

  /**
   * Displays a success message.
   *
   * @param message the success message to display
   */
  void displaySuccess(String message);
}