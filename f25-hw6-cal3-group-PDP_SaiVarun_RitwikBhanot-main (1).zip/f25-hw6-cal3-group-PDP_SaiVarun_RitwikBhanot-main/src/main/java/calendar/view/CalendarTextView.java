package calendar.view;

import calendar.model.InterfaceEvent;
import java.time.format.DateTimeFormatter;
import java.util.List;

/**
 * Text-based view for the calendar application.
 * Handles all console output.
 */
public class CalendarTextView implements InterfaceCalendarView {

  private static final DateTimeFormatter DATE_FORMATTER =
      DateTimeFormatter.ofPattern("yyyy-MM-dd");
  private static final DateTimeFormatter TIME_FORMATTER =
      DateTimeFormatter.ofPattern("HH:mm");
  private static final DateTimeFormatter DATETIME_FORMATTER =
      DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");

  @Override
  public void displayMessage(String message) {
    System.out.println(message);
  }

  @Override
  public void displayEvents(List<InterfaceEvent> events) {
    if (events == null || events.isEmpty()) {
      System.out.println("No events found.");
      return;
    }

    for (InterfaceEvent event : events) {
      System.out.println(formatEvent(event));
    }
  }

  @Override
  public void displayError(String error) {
    System.err.println("Error: " + error);
  }

  @Override
  public void displaySuccess(String message) {
    System.out.println("Success: " + message);
  }

  /**
   * Formats an event for display.
   *
   * @param event the event to format
   * @return formatted event string
   */
  private String formatEvent(InterfaceEvent event) {
    StringBuilder sb = new StringBuilder();
    sb.append("- ").append(event.getSubject());

    sb.append(" starting on ")
        .append(event.getStart() != null ? event.getStart().format(DATE_FORMATTER) : "null")
        .append(" at ")
        .append(event.getStart() != null ? event.getStart().format(TIME_FORMATTER) : "null");

    sb.append(", ending on ")
        .append(event.getEnd() != null ? event.getEnd().format(DATE_FORMATTER) : "null")
        .append(" at ")
        .append(event.getEnd() != null ? event.getEnd().format(TIME_FORMATTER) : "null");

    if (event.getLocation() != null && !event.getLocation().isEmpty()) {
      sb.append(" (Location: ").append(event.getLocation()).append(")");
    }

    return sb.toString();
  }
}