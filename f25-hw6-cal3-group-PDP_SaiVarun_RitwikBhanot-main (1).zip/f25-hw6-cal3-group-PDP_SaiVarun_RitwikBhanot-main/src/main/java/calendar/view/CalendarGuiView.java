package calendar.view;

import calendar.controller.InterfaceCalendarController;
import calendar.model.InterfaceCalendar;
import calendar.model.InterfaceCalendarManager;
import calendar.model.InterfaceEvent;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Insets;
import java.time.LocalDate;
import java.time.YearMonth;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import javax.swing.BorderFactory;
import javax.swing.ButtonGroup;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

/**
 * Graphical calendar view using Java Swing.
 */
public class CalendarGuiView extends JFrame implements InterfaceCalendarView {

  private InterfaceCalendarController controller;
  private YearMonth currentMonth;
  private JPanel calendarPanel;
  private JLabel monthLabel;
  private JTextArea eventDisplayArea;
  private JComboBox<String> calendarSelector;
  private DefaultComboBoxModel<String> calendarModel;
  private InterfaceCalendarManager calendarManager;
  private LocalDate selectedDate;
  private JLabel selectedDateLabel;
  private Map<LocalDate, JButton> dateButtons;
  private boolean isUpdating = false;

  /**
   * Constructs a new CalendarGuiView with the specified calendar manager.
   *
   * @param calendarManager the calendar manager to use
   */
  public CalendarGuiView(InterfaceCalendarManager calendarManager) {
    super("Calendar Application");
    this.calendarManager = calendarManager;
    this.selectedDate = null;
    this.currentMonth = YearMonth.now();
    this.dateButtons = new HashMap<>();
    initializeGui();
  }

  /**
   * Initializes the default calendar.
   */
  public void initialize() {
    initializeDefaultCalendar();
  }

  public void setController(InterfaceCalendarController controller) {
    this.controller = controller;
  }

  @Override
  public void displayMessage(String message) {
    if (!isUpdating && eventDisplayArea != null) {
      eventDisplayArea.setText(message);
    }
  }

  @Override
  public void displayEvents(List<InterfaceEvent> events) {
    if (isUpdating) {
      return;
    }

    isUpdating = true;
    try {
      StringBuilder sb = new StringBuilder();

      if (selectedDate != null) {
        sb.append("Events on ").append(selectedDate).append(":\n\n");
      }

      if (events.isEmpty()) {
        sb.append("No events scheduled.");
      } else {
        DateTimeFormatter timeFormatter = DateTimeFormatter.ofPattern("HH:mm");
        for (InterfaceEvent event : events) {
          sb.append("- ").append(event.getSubject())
              .append(" starting on ").append(event.getStart().toLocalDate())
              .append(" at ").append(event.getStart().format(timeFormatter))
              .append(", ending on ").append(event.getEnd().toLocalDate())
              .append(" at ").append(event.getEnd().format(timeFormatter));

          if (event.getLocation() != null && !event.getLocation().isEmpty()) {
            sb.append("\n  Location: ").append(event.getLocation());
          }
          if (event.getDescription() != null && !event.getDescription().isEmpty()) {
            sb.append("\n  Description: ").append(event.getDescription());
          }
          sb.append("\n\n");
        }
      }

      eventDisplayArea.setText(sb.toString());
      eventDisplayArea.setCaretPosition(0);
    } finally {
      isUpdating = false;
    }
  }

  @Override
  public void displayError(String error) {
    JOptionPane.showMessageDialog(this, error, "Error", JOptionPane.ERROR_MESSAGE);
  }

  @Override
  public void displaySuccess(String message) {
    if (!isUpdating && !message.contains("Print events completed")
        && !message.contains("Status checked")
        && !message.contains("Now using calendar")
        && !message.contains("using calendar")) {
      JOptionPane.showMessageDialog(this, message, "Success",
          JOptionPane.INFORMATION_MESSAGE);
      updateCalendarGrid();
    }
  }

  private void initializeDefaultCalendar() {
    try {
      if (!calendarManager.hasCalendars()) {
        ZoneId systemZone = ZoneId.systemDefault();
        calendarManager.createCalendar("My Calendar", systemZone);
        calendarManager.useCalendar("My Calendar");
      } else if (!calendarManager.hasActiveCalendar()) {
        Set<String> names = calendarManager.getAllCalendarNames();
        String firstName = names.iterator().next();
        calendarManager.useCalendar(firstName);
      }

      refreshCalendarList();

      if (calendarManager.hasActiveCalendar()) {
        String activeName = calendarManager.getActiveCalendarName();
        if (calendarSelector != null) {
          calendarSelector.setSelectedItem(activeName);
        }
      }
    } catch (Exception e) {
      e.printStackTrace();
    }
  }

  private void initializeGui() {
    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    setSize(1300, 800);
    setLayout(new BorderLayout());
    setLocationRelativeTo(null);

    final JPanel mainPanel = new JPanel(new BorderLayout());

    final JPanel topPanel = new JPanel(new BorderLayout());
    final JPanel calendarSelectorPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
    calendarModel = new DefaultComboBoxModel<>();
    calendarSelector = new JComboBox<>(calendarModel);
    calendarSelector.setPreferredSize(new Dimension(150, 25));
    final JButton newCalendarButton = new JButton("New Calendar");
    final JButton editCalendarButton = new JButton("Edit Calendar");

    calendarSelectorPanel.add(new JLabel("Calendar:"));
    calendarSelectorPanel.add(calendarSelector);
    calendarSelectorPanel.add(newCalendarButton);
    calendarSelectorPanel.add(editCalendarButton);

    final JPanel navPanel = new JPanel(new FlowLayout());
    final JButton prevButton = new JButton("<");
    final JButton todayButton = new JButton("Today");
    monthLabel = new JLabel(currentMonth.getMonth() + " " + currentMonth.getYear(),
        SwingConstants.CENTER);
    monthLabel.setFont(monthLabel.getFont().deriveFont(Font.BOLD, 18f));
    monthLabel.setPreferredSize(new Dimension(200, 30));
    final JButton nextButton = new JButton(">");

    navPanel.add(prevButton);
    navPanel.add(todayButton);
    navPanel.add(monthLabel);
    navPanel.add(nextButton);

    topPanel.add(calendarSelectorPanel, BorderLayout.NORTH);
    topPanel.add(navPanel, BorderLayout.CENTER);

    calendarPanel = new JPanel(new GridLayout(0, 7, 5, 5));
    calendarPanel.setBackground(Color.WHITE);
    calendarPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

    final JPanel rightPanel = new JPanel(new BorderLayout());
    rightPanel.setPreferredSize(new Dimension(400, 600));
    rightPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

    selectedDateLabel = new JLabel("Selected Date:");
    selectedDateLabel.setFont(selectedDateLabel.getFont().deriveFont(Font.BOLD, 14f));
    selectedDateLabel.setBorder(BorderFactory.createEmptyBorder(5, 5, 10, 5));

    eventDisplayArea = new JTextArea();
    eventDisplayArea.setEditable(false);
    eventDisplayArea.setFont(new Font("Monospaced", Font.PLAIN, 12));
    eventDisplayArea.setLineWrap(true);
    eventDisplayArea.setWrapStyleWord(true);
    final JScrollPane eventScroll = new JScrollPane(eventDisplayArea);
    eventScroll.setPreferredSize(new Dimension(380, 400));

    final JPanel buttonPanel = new JPanel();
    buttonPanel.setLayout(new GridLayout(0, 1, 5, 5));
    buttonPanel.setBorder(BorderFactory.createEmptyBorder(10, 5, 5, 5));

    final JButton createEventButton = new JButton("Create Event");
    final JButton createSeriesButton = new JButton("Create Series");
    final JButton editEventButton = new JButton("Edit Event");
    final JButton editEventsButton = new JButton("Edit Events");
    final JButton editSeriesButton = new JButton("Edit Series");
    final JButton copyEventButton = new JButton("Copy Event");
    final JButton copyEventsButton = new JButton("Copy Events");
    final JButton copyEventsOnButton = new JButton("Copy Events On");
    final JButton exportButton = new JButton("Export Calendar");
    final JButton showStatusButton = new JButton("Show Status");

    buttonPanel.add(createEventButton);
    buttonPanel.add(createSeriesButton);
    buttonPanel.add(editEventButton);
    buttonPanel.add(editEventsButton);
    buttonPanel.add(editSeriesButton);
    buttonPanel.add(copyEventButton);
    buttonPanel.add(copyEventsButton);
    buttonPanel.add(copyEventsOnButton);
    buttonPanel.add(exportButton);
    buttonPanel.add(showStatusButton);

    rightPanel.add(selectedDateLabel, BorderLayout.NORTH);
    rightPanel.add(eventScroll, BorderLayout.CENTER);
    rightPanel.add(buttonPanel, BorderLayout.SOUTH);

    mainPanel.add(topPanel, BorderLayout.NORTH);
    mainPanel.add(calendarPanel, BorderLayout.CENTER);

    add(mainPanel, BorderLayout.CENTER);
    add(rightPanel, BorderLayout.EAST);

    prevButton.addActionListener(e -> navigateMonth(-1));
    nextButton.addActionListener(e -> navigateMonth(1));
    todayButton.addActionListener(e -> navigateToToday());
    newCalendarButton.addActionListener(e -> showNewCalendarDialog());
    editCalendarButton.addActionListener(e -> showEditCalendarDialog());
    createEventButton.addActionListener(e -> showCreateEventDialog());
    createSeriesButton.addActionListener(e -> showCreateSeriesDialog());
    editEventButton.addActionListener(e -> showEditEventDialog());
    editEventsButton.addActionListener(e -> showEditEventsDialog());
    editSeriesButton.addActionListener(e -> showEditSeriesDialog());
    copyEventButton.addActionListener(e -> showCopyEventDialog());
    copyEventsButton.addActionListener(e -> showCopyEventsDialog());
    copyEventsOnButton.addActionListener(e -> showCopyEventsOnDialog());
    exportButton.addActionListener(e -> showExportDialog());
    showStatusButton.addActionListener(e -> showStatusDialog());
    calendarSelector.addActionListener(e -> selectCalendar());

    updateCalendarGrid();
  }

  private void refreshCalendarList() {
    String currentSelection = (String) calendarSelector.getSelectedItem();
    calendarModel.removeAllElements();

    Set<String> calendarNames = calendarManager.getAllCalendarNames();
    for (String name : calendarNames) {
      calendarModel.addElement(name);
    }

    if (currentSelection != null && calendarNames.contains(currentSelection)) {
      calendarSelector.setSelectedItem(currentSelection);
    } else if (calendarModel.getSize() > 0) {
      calendarSelector.setSelectedIndex(0);
    }
  }

  private void navigateToToday() {
    currentMonth = YearMonth.now();
    selectedDate = LocalDate.now();
    monthLabel.setText(currentMonth.getMonth() + " " + currentMonth.getYear());
    updateCalendarGrid();
    selectDate(selectedDate);
  }

  private void navigateMonth(int direction) {
    currentMonth = currentMonth.plusMonths(direction);
    monthLabel.setText(currentMonth.getMonth() + " " + currentMonth.getYear());
    updateCalendarGrid();
  }

  private void updateCalendarGrid() {
    if (calendarPanel == null || isUpdating) {
      return;
    }

    calendarPanel.removeAll();
    dateButtons.clear();

    String[] dayHeaders = {"Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"};
    for (String header : dayHeaders) {
      JLabel headerLabel = new JLabel(header, SwingConstants.CENTER);
      headerLabel.setFont(headerLabel.getFont().deriveFont(Font.BOLD, 14f));
      headerLabel.setOpaque(true);
      headerLabel.setBackground(new Color(220, 220, 220));
      headerLabel.setBorder(BorderFactory.createLineBorder(Color.GRAY));
      calendarPanel.add(headerLabel);
    }

    LocalDate firstOfMonth = currentMonth.atDay(1);
    int daysInMonth = currentMonth.lengthOfMonth();
    int firstDayOfWeek = firstOfMonth.getDayOfWeek().getValue() % 7;

    for (int i = 0; i < firstDayOfWeek; i++) {
      JPanel emptyPanel = new JPanel();
      emptyPanel.setBackground(Color.WHITE);
      calendarPanel.add(emptyPanel);
    }

    for (int day = 1; day <= daysInMonth; day++) {
      LocalDate date = currentMonth.atDay(day);
      JButton dayButton = createDayButton(date);
      dateButtons.put(date, dayButton);
      calendarPanel.add(dayButton);
    }

    calendarPanel.revalidate();
    calendarPanel.repaint();
  }

  private JButton createDayButton(LocalDate date) {
    int eventCount = 0;
    if (calendarManager.hasActiveCalendar()) {
      InterfaceCalendar calendar = calendarManager.getActiveCalendar();
      List<InterfaceEvent> events = calendar.getEventsOn(date);
      eventCount = events.size();
    }

    JButton dayButton = new JButton();
    dayButton.setLayout(new BorderLayout());
    dayButton.setPreferredSize(new Dimension(80, 80));

    JLabel dayLabel = new JLabel(String.valueOf(date.getDayOfMonth()), SwingConstants.CENTER);
    dayLabel.setFont(dayLabel.getFont().deriveFont(Font.BOLD, 16f));

    JLabel eventLabel = new JLabel("", SwingConstants.CENTER);
    if (eventCount > 0) {
      eventLabel.setText(eventCount + " event" + (eventCount > 1 ? "s" : ""));
      eventLabel.setFont(eventLabel.getFont().deriveFont(Font.PLAIN, 10f));
    }

    dayButton.add(dayLabel, BorderLayout.CENTER);
    dayButton.add(eventLabel, BorderLayout.SOUTH);

    dayButton.setBackground(Color.WHITE);
    dayButton.setBorder(BorderFactory.createLineBorder(Color.LIGHT_GRAY));

    if (date.equals(LocalDate.now())) {
      dayButton.setBorder(BorderFactory.createLineBorder(Color.BLUE, 2));
    }

    if (date.equals(selectedDate)) {
      dayButton.setBackground(new Color(144, 238, 144));
    }

    dayButton.addActionListener(e -> selectDate(date));

    return dayButton;
  }

  private void selectDate(LocalDate date) {
    selectedDate = date;
    selectedDateLabel.setText("Selected Date: " + date);
    updateCalendarGrid();

    if (controller != null && calendarManager.hasActiveCalendar()) {
      controller.executeCommand("print events on " + date.toString(), this);
    } else {
      displayError("No active calendar. Please create or select a calendar.");
    }
  }

  private void selectCalendar() {
    if (isUpdating) {
      return;
    }

    String selectedName = (String) calendarSelector.getSelectedItem();
    if (selectedName != null && !selectedName.isEmpty() && controller != null) {
      isUpdating = true;
      try {
        controller.executeCommand("use calendar --name \"" + selectedName + "\"", this);
        updateCalendarGrid();
        if (selectedDate != null) {
          selectDate(selectedDate);
        }
      } finally {
        isUpdating = false;
      }
    }
  }

  private void showNewCalendarDialog() {
    if (controller == null) {
      displayError("Controller not initialized");
      return;
    }

    JTextField nameField = new JTextField();
    String[] timezones = ZoneId.getAvailableZoneIds().stream().sorted().toArray(String[]::new);
    JComboBox<String> timezoneCombo = new JComboBox<>(timezones);
    timezoneCombo.setSelectedItem(ZoneId.systemDefault().toString());

    JPanel panel = new JPanel(new GridLayout(2, 2, 5, 5));
    panel.add(new JLabel("Calendar Name:"));
    panel.add(nameField);
    panel.add(new JLabel("Timezone:"));
    panel.add(timezoneCombo);

    int result = JOptionPane.showConfirmDialog(this, panel, "Create New Calendar",
        JOptionPane.OK_CANCEL_OPTION);

    if (result == JOptionPane.OK_OPTION) {
      String name = nameField.getText().trim();
      String timezone = (String) timezoneCombo.getSelectedItem();

      if (!name.isEmpty()) {
        controller.executeCommand("create calendar --name \"" + name
            + "\" --timezone " + timezone, this);
        refreshCalendarList();
        calendarSelector.setSelectedItem(name);
      } else {
        displayError("Calendar name cannot be empty");
      }
    }
  }

  private void showEditCalendarDialog() {
    if (controller == null) {
      displayError("Controller not initialized");
      return;
    }

    if (!calendarManager.hasActiveCalendar()) {
      displayError("Please select a calendar first");
      return;
    }

    String currentName = calendarManager.getActiveCalendarName();
    ZoneId currentTimezone = calendarManager.getActiveCalendarTimezone();

    JTextField nameField = new JTextField(currentName);
    String[] timezones = ZoneId.getAvailableZoneIds().stream().sorted().toArray(String[]::new);
    JComboBox<String> timezoneCombo = new JComboBox<>(timezones);
    timezoneCombo.setSelectedItem(currentTimezone.toString());

    JPanel panel = new JPanel(new GridLayout(2, 2, 5, 5));
    panel.add(new JLabel("New Name:"));
    panel.add(nameField);
    panel.add(new JLabel("New Timezone:"));
    panel.add(timezoneCombo);

    int result = JOptionPane.showConfirmDialog(this, panel, "Edit Calendar",
        JOptionPane.OK_CANCEL_OPTION);

    if (result == JOptionPane.OK_OPTION) {
      String newName = nameField.getText().trim();
      String newTimezone = (String) timezoneCombo.getSelectedItem();

      if (!newName.equals(currentName) && !newName.isEmpty()) {
        controller.executeCommand("edit calendar --name \"" + currentName
            + "\" --property name \"" + newName + "\"", this);
      }

      if (!newTimezone.equals(currentTimezone.toString())) {
        String calName = newName.isEmpty() ? currentName : newName;
        controller.executeCommand("edit calendar --name \"" + calName
            + "\" --property timezone \"" + newTimezone + "\"", this);
      }

      refreshCalendarList();
    }
  }

  private void showCreateEventDialog() {
    if (controller == null) {
      displayError("Controller not initialized");
      return;
    }

    if (!calendarManager.hasActiveCalendar()) {
      displayError("Please create or select a calendar first");
      return;
    }

    JTextField nameField = new JTextField();
    JTextField dateField = new JTextField(
        selectedDate != null ? selectedDate.toString() : LocalDate.now().toString());
    JTextField startField = new JTextField("09:00");
    JTextField endField = new JTextField("10:00");

    JPanel panel = new JPanel(new GridLayout(0, 2, 5, 5));
    panel.add(new JLabel("Event Name:"));
    panel.add(nameField);
    panel.add(new JLabel("Date (YYYY-MM-DD):"));
    panel.add(dateField);
    panel.add(new JLabel("Start Time (HH:MM):"));
    panel.add(startField);
    panel.add(new JLabel("End Time (HH:MM):"));
    panel.add(endField);

    int result = JOptionPane.showConfirmDialog(this, panel, "Create Event",
        JOptionPane.OK_CANCEL_OPTION);

    if (result == JOptionPane.OK_OPTION) {
      String name = nameField.getText().trim();
      String date = dateField.getText().trim();
      String start = startField.getText().trim();
      String end = endField.getText().trim();

      if (!name.isEmpty() && !date.isEmpty()) {
        controller.executeCommand("create event \"" + name + "\" from "
            + date + "T" + start + " to " + date + "T" + end, this);
      } else {
        displayError("Event name and date cannot be empty");
      }
    }
  }

  private void showEditEventDialog() {
    if (controller == null) {
      displayError("Controller not initialized");
      return;
    }

    if (!calendarManager.hasActiveCalendar()) {
      displayError("Please select a calendar first");
      return;
    }

    JTextField subjectField = new JTextField();
    JTextField dateField = new JTextField(LocalDate.now().toString());
    JTextField startTimeField = new JTextField("09:00");
    JTextField endTimeField = new JTextField("10:00");

    JPanel findPanel = new JPanel(new GridLayout(4, 2, 5, 5));
    findPanel.add(new JLabel("Event Name:"));
    findPanel.add(subjectField);
    findPanel.add(new JLabel("Date (YYYY-MM-DD):"));
    findPanel.add(dateField);
    findPanel.add(new JLabel("Start Time (HH:MM):"));
    findPanel.add(startTimeField);
    findPanel.add(new JLabel("End Time (HH:MM):"));
    findPanel.add(endTimeField);

    int findResult = JOptionPane.showConfirmDialog(this, findPanel,
        "Find Event to Edit", JOptionPane.OK_CANCEL_OPTION);

    if (findResult != JOptionPane.OK_OPTION) {
      return;
    }

    final String subject = subjectField.getText().trim();
    final String date = dateField.getText().trim();
    final String startTime = startTimeField.getText().trim();
    final String endTime = endTimeField.getText().trim();

    if (subject.isEmpty()) {
      displayError("Event name cannot be empty");
      return;
    }

    String[] properties = {"Subject", "Location", "Description", "Start", "End", "Status"};
    String property = (String) JOptionPane.showInputDialog(
        this,
        "Select property to edit:",
        "Edit Property",
        JOptionPane.QUESTION_MESSAGE,
        null,
        properties,
        properties[0]
    );

    if (property == null) {
      return;
    }

    String newValue;
    if (property.equals("Status")) {
      String[] statuses = {"public", "private", "tentative", "confirmed"};
      newValue = (String) JOptionPane.showInputDialog(
          this,
          "Select new status:",
          "Edit Status",
          JOptionPane.QUESTION_MESSAGE,
          null,
          statuses,
          statuses[0]
      );
    } else if (property.equals("Start") || property.equals("End")) {
      newValue = JOptionPane.showInputDialog(this, "Enter new " + property.toLowerCase()
          + " time (HH:MM):");
      if (newValue != null && !newValue.trim().isEmpty()) {
        newValue = date + "T" + newValue.trim();
      }
    } else {
      newValue = JOptionPane.showInputDialog(this, "Enter new " + property.toLowerCase() + ":");
    }

    if (newValue != null && !newValue.trim().isEmpty()) {
      String propName = property.toLowerCase();

      String command = "edit event " + propName + " \"" + subject + "\" from "
          + date + "T" + startTime + " to " + date + "T" + endTime
          + " with \"" + newValue.trim() + "\"";

      controller.executeCommand(command, this);
    }
  }

  private void showCreateSeriesDialog() {
    if (controller == null) {
      displayError("Controller not initialized");
      return;
    }

    if (!calendarManager.hasActiveCalendar()) {
      displayError("Please create or select a calendar first");
      return;
    }

    final JTextField nameField = new JTextField();
    final JTextField dateField = new JTextField(
        selectedDate != null ? selectedDate.toString() : LocalDate.now().toString());
    final JTextField startField = new JTextField("09:00");
    final JTextField endField = new JTextField("10:00");

    final JCheckBox monCheck = new JCheckBox("Monday (M)");
    final JCheckBox tueCheck = new JCheckBox("Tuesday (T)");
    final JCheckBox wedCheck = new JCheckBox("Wednesday (W)");
    final JCheckBox thuCheck = new JCheckBox("Thursday (R)");
    final JCheckBox friCheck = new JCheckBox("Friday (F)");
    final JCheckBox satCheck = new JCheckBox("Saturday (S)");
    final JCheckBox sunCheck = new JCheckBox("Sunday (U)");

    JRadioButton forTimesRadio = new JRadioButton("For N times");
    JRadioButton untilDateRadio = new JRadioButton("Until date");
    ButtonGroup group = new ButtonGroup();
    group.add(forTimesRadio);
    group.add(untilDateRadio);
    forTimesRadio.setSelected(true);

    JTextField occurrencesField = new JTextField("5");
    JTextField untilField = new JTextField(LocalDate.now().plusMonths(1).toString());
    untilField.setEnabled(false);

    forTimesRadio.addActionListener(e -> {
      occurrencesField.setEnabled(true);
      untilField.setEnabled(false);
    });

    untilDateRadio.addActionListener(e -> {
      occurrencesField.setEnabled(false);
      untilField.setEnabled(true);
    });

    final JPanel panel = new JPanel(new GridBagLayout());
    final GridBagConstraints gbc = new GridBagConstraints();
    gbc.fill = GridBagConstraints.HORIZONTAL;
    gbc.insets = new Insets(5, 5, 5, 5);

    gbc.gridx = 0;
    gbc.gridy = 0;
    panel.add(new JLabel("Event Name:"), gbc);
    gbc.gridx = 1;
    panel.add(nameField, gbc);

    gbc.gridx = 0;
    gbc.gridy = 1;
    panel.add(new JLabel("Start Date:"), gbc);
    gbc.gridx = 1;
    panel.add(dateField, gbc);

    gbc.gridx = 0;
    gbc.gridy = 2;
    panel.add(new JLabel("Start Time:"), gbc);
    gbc.gridx = 1;
    panel.add(startField, gbc);

    gbc.gridx = 0;
    gbc.gridy = 3;
    panel.add(new JLabel("End Time:"), gbc);
    gbc.gridx = 1;
    panel.add(endField, gbc);

    gbc.gridx = 0;
    gbc.gridy = 4;
    gbc.gridwidth = 2;
    panel.add(new JLabel("Repeat on:"), gbc);

    gbc.gridy = 5;
    final JPanel daysPanel = new JPanel(new GridLayout(2, 4, 5, 5));
    daysPanel.add(monCheck);
    daysPanel.add(tueCheck);
    daysPanel.add(wedCheck);
    daysPanel.add(thuCheck);
    daysPanel.add(friCheck);
    daysPanel.add(satCheck);
    daysPanel.add(sunCheck);
    panel.add(daysPanel, gbc);

    gbc.gridy = 6;
    gbc.gridwidth = 1;
    gbc.gridx = 0;
    panel.add(forTimesRadio, gbc);
    gbc.gridx = 1;
    panel.add(occurrencesField, gbc);

    gbc.gridy = 7;
    gbc.gridx = 0;
    panel.add(untilDateRadio, gbc);
    gbc.gridx = 1;
    panel.add(untilField, gbc);

    int result = JOptionPane.showConfirmDialog(this, panel, "Create Recurring Event Series",
        JOptionPane.OK_CANCEL_OPTION);

    if (result == JOptionPane.OK_OPTION) {
      final String name = nameField.getText().trim();
      final String date = dateField.getText().trim();
      final String start = startField.getText().trim();
      final String end = endField.getText().trim();

      final StringBuilder weekdays = new StringBuilder();
      if (monCheck.isSelected()) {
        weekdays.append("M");
      }
      if (tueCheck.isSelected()) {
        weekdays.append("T");
      }
      if (wedCheck.isSelected()) {
        weekdays.append("W");
      }
      if (thuCheck.isSelected()) {
        weekdays.append("R");
      }
      if (friCheck.isSelected()) {
        weekdays.append("F");
      }
      if (satCheck.isSelected()) {
        weekdays.append("S");
      }
      if (sunCheck.isSelected()) {
        weekdays.append("U");
      }

      if (name.isEmpty() || date.isEmpty() || weekdays.length() == 0) {
        displayError("Please fill in all required fields and select at least one weekday");
        return;
      }

      String command;
      if (forTimesRadio.isSelected()) {
        String occurrences = occurrencesField.getText().trim();
        command = "create event \"" + name + "\" from " + date + "T" + start
            + " to " + date + "T" + end + " repeats " + weekdays
            + " for " + occurrences + " times";
      } else {
        String until = untilField.getText().trim();
        command = "create event \"" + name + "\" from " + date + "T" + start
            + " to " + date + "T" + end + " repeats " + weekdays
            + " until " + until;
      }

      controller.executeCommand(command, this);
    }
  }

  private void showEditEventsDialog() {
    if (controller == null) {
      displayError("Controller not initialized");
      return;
    }

    if (!calendarManager.hasActiveCalendar()) {
      displayError("Please select a calendar first");
      return;
    }

    JTextField subjectField = new JTextField();
    JTextField fromDateTimeField = new JTextField(LocalDate.now().toString() + "T09:00");

    JPanel findPanel = new JPanel(new GridLayout(2, 2, 5, 5));
    findPanel.add(new JLabel("Event Name:"));
    findPanel.add(subjectField);
    findPanel.add(new JLabel("From DateTime (YYYY-MM-DDTHH:MM):"));
    findPanel.add(fromDateTimeField);

    int findResult = JOptionPane.showConfirmDialog(this, findPanel,
        "Find Events to Edit", JOptionPane.OK_CANCEL_OPTION);

    if (findResult != JOptionPane.OK_OPTION) {
      return;
    }

    String subject = subjectField.getText().trim();
    String fromDateTime = fromDateTimeField.getText().trim();

    if (subject.isEmpty() || fromDateTime.isEmpty()) {
      displayError("Event name and from date-time cannot be empty");
      return;
    }

    String[] properties = {"Subject", "Location", "Description", "Status", "Start"};
    String property = (String) JOptionPane.showInputDialog(
        this,
        "Select property to edit (will affect all matching events from specified time):",
        "Edit Property",
        JOptionPane.QUESTION_MESSAGE,
        null,
        properties,
        properties[0]
    );

    if (property == null) {
      return;
    }

    String newValue;
    if (property.equals("Status")) {
      String[] statuses = {"public", "private", "tentative", "confirmed"};
      newValue = (String) JOptionPane.showInputDialog(
          this,
          "Select new status:",
          "Edit Status",
          JOptionPane.QUESTION_MESSAGE,
          null,
          statuses,
          statuses[0]
      );
    } else if (property.equals("Start")) {
      newValue = JOptionPane.showInputDialog(this, "Enter new start time (HH:MM):");
      if (newValue != null && !newValue.trim().isEmpty()) {
        newValue = fromDateTime.substring(0, 10) + "T" + newValue.trim();
      }
    } else {
      newValue = JOptionPane.showInputDialog(this, "Enter new " + property.toLowerCase() + ":");
    }

    if (newValue != null && !newValue.trim().isEmpty()) {
      String propName = property.toLowerCase();
      String command = "edit events " + propName + " \"" + subject + "\" from "
          + fromDateTime + " with \"" + newValue.trim() + "\"";

      controller.executeCommand(command, this);
    }
  }

  private void showEditSeriesDialog() {
    if (controller == null) {
      displayError("Controller not initialized");
      return;
    }

    if (!calendarManager.hasActiveCalendar()) {
      displayError("Please select a calendar first");
      return;
    }

    JTextField subjectField = new JTextField();
    JTextField fromDateTimeField = new JTextField(LocalDate.now().toString() + "T09:00");

    JPanel findPanel = new JPanel(new GridLayout(2, 2, 5, 5));
    findPanel.add(new JLabel("Event Name:"));
    findPanel.add(subjectField);
    findPanel.add(new JLabel("Any Event DateTime (YYYY-MM-DDTHH:MM):"));
    findPanel.add(fromDateTimeField);

    int findResult = JOptionPane.showConfirmDialog(this, findPanel,
        "Find Series to Edit", JOptionPane.OK_CANCEL_OPTION);

    if (findResult != JOptionPane.OK_OPTION) {
      return;
    }

    String subject = subjectField.getText().trim();
    String fromDateTime = fromDateTimeField.getText().trim();

    if (subject.isEmpty() || fromDateTime.isEmpty()) {
      displayError("Event name and date-time cannot be empty");
      return;
    }

    String[] properties = {"Subject", "Location", "Description", "Status", "Start", "End"};
    String property = (String) JOptionPane.showInputDialog(
        this,
        "Select property to edit (will affect ALL events in series):",
        "Edit Property",
        JOptionPane.QUESTION_MESSAGE,
        null,
        properties,
        properties[0]
    );

    if (property == null) {
      return;
    }

    String newValue;
    if (property.equals("Status")) {
      String[] statuses = {"public", "private", "tentative", "confirmed"};
      newValue = (String) JOptionPane.showInputDialog(
          this,
          "Select new status:",
          "Edit Status",
          JOptionPane.QUESTION_MESSAGE,
          null,
          statuses,
          statuses[0]
      );
    } else if (property.equals("Start") || property.equals("End")) {
      newValue = JOptionPane.showInputDialog(this, "Enter new " + property.toLowerCase()
          + " time (HH:MM):");
      if (newValue != null && !newValue.trim().isEmpty()) {
        newValue = fromDateTime.substring(0, 10) + "T" + newValue.trim();
      }
    } else {
      newValue = JOptionPane.showInputDialog(this, "Enter new " + property.toLowerCase() + ":");
    }

    if (newValue != null && !newValue.trim().isEmpty()) {
      String propName = property.toLowerCase();
      String command = "edit series " + propName + " \"" + subject + "\" from "
          + fromDateTime + " with \"" + newValue.trim() + "\"";

      controller.executeCommand(command, this);
    }
  }

  private void showCopyEventDialog() {
    if (controller == null) {
      displayError("Controller not initialized");
      return;
    }

    if (!calendarManager.hasActiveCalendar()) {
      displayError("Please select a calendar first");
      return;
    }

    Set<String> allCalendars = calendarManager.getAllCalendarNames();
    if (allCalendars.size() < 2) {
      displayError("You need at least 2 calendars to copy events between them");
      return;
    }

    final JTextField eventNameField = new JTextField();
    final JTextField onDateTimeField = new JTextField(LocalDate.now().toString() + "T09:00");

    String[] calendarArray = allCalendars.toArray(new String[0]);
    JComboBox<String> targetCalendarCombo = new JComboBox<>(calendarArray);
    String currentCal = calendarManager.getActiveCalendarName();
    for (int i = 0; i < calendarArray.length; i++) {
      if (!calendarArray[i].equals(currentCal)) {
        targetCalendarCombo.setSelectedIndex(i);
        break;
      }
    }

    JTextField toDateTimeField = new JTextField(LocalDate.now().toString() + "T10:00");

    JPanel panel = new JPanel(new GridLayout(4, 2, 5, 5));
    panel.add(new JLabel("Event Name:"));
    panel.add(eventNameField);
    panel.add(new JLabel("On DateTime (YYYY-MM-DDTHH:MM):"));
    panel.add(onDateTimeField);
    panel.add(new JLabel("Target Calendar:"));
    panel.add(targetCalendarCombo);
    panel.add(new JLabel("To DateTime (YYYY-MM-DDTHH:MM):"));
    panel.add(toDateTimeField);

    int result = JOptionPane.showConfirmDialog(this, panel, "Copy Event",
        JOptionPane.OK_CANCEL_OPTION);

    if (result == JOptionPane.OK_OPTION) {
      String eventName = eventNameField.getText().trim();
      String onDateTime = onDateTimeField.getText().trim();
      String targetCalendar = (String) targetCalendarCombo.getSelectedItem();
      String toDateTime = toDateTimeField.getText().trim();

      if (eventName.isEmpty() || onDateTime.isEmpty() || toDateTime.isEmpty()) {
        displayError("All fields are required");
        return;
      }

      String command = "copy event \"" + eventName + "\" on " + onDateTime
          + " --target " + targetCalendar + " to " + toDateTime;

      controller.executeCommand(command, this);
    }
  }

  private void showCopyEventsDialog() {
    if (controller == null) {
      displayError("Controller not initialized");
      return;
    }

    if (!calendarManager.hasActiveCalendar()) {
      displayError("Please select a calendar first");
      return;
    }

    Set<String> allCalendars = calendarManager.getAllCalendarNames();
    if (allCalendars.size() < 2) {
      displayError("You need at least 2 calendars to copy events between them");
      return;
    }

    final JTextField startDateField = new JTextField(LocalDate.now().toString());
    final JTextField endDateField = new JTextField(LocalDate.now().plusDays(7).toString());

    String[] calendarArray = allCalendars.toArray(new String[0]);
    JComboBox<String> targetCalendarCombo = new JComboBox<>(calendarArray);
    String currentCal = calendarManager.getActiveCalendarName();
    for (int i = 0; i < calendarArray.length; i++) {
      if (!calendarArray[i].equals(currentCal)) {
        targetCalendarCombo.setSelectedIndex(i);
        break;
      }
    }

    JTextField targetDateField = new JTextField(LocalDate.now().plusMonths(1).toString());

    JPanel panel = new JPanel(new GridLayout(4, 2, 5, 5));
    panel.add(new JLabel("Start Date (YYYY-MM-DD):"));
    panel.add(startDateField);
    panel.add(new JLabel("End Date (YYYY-MM-DD):"));
    panel.add(endDateField);
    panel.add(new JLabel("Target Calendar:"));
    panel.add(targetCalendarCombo);
    panel.add(new JLabel("To Date (YYYY-MM-DD):"));
    panel.add(targetDateField);

    int result = JOptionPane.showConfirmDialog(this, panel, "Copy Events in Date Range",
        JOptionPane.OK_CANCEL_OPTION);

    if (result == JOptionPane.OK_OPTION) {
      String startDate = startDateField.getText().trim();
      String endDate = endDateField.getText().trim();
      String targetCalendar = (String) targetCalendarCombo.getSelectedItem();
      String targetDate = targetDateField.getText().trim();

      if (startDate.isEmpty() || endDate.isEmpty() || targetDate.isEmpty()) {
        displayError("All fields are required");
        return;
      }

      String command = "copy events between " + startDate + " and " + endDate
          + " --target " + targetCalendar + " to " + targetDate;

      controller.executeCommand(command, this);
    }
  }

  private void showCopyEventsOnDialog() {
    if (controller == null) {
      displayError("Controller not initialized");
      return;
    }

    if (!calendarManager.hasActiveCalendar()) {
      displayError("Please select a calendar first");
      return;
    }

    Set<String> allCalendars = calendarManager.getAllCalendarNames();
    if (allCalendars.size() < 2) {
      displayError("You need at least 2 calendars to copy events between them");
      return;
    }

    final JTextField onDateField = new JTextField(
        selectedDate != null ? selectedDate.toString() : LocalDate.now().toString());

    String[] calendarArray = allCalendars.toArray(new String[0]);
    JComboBox<String> targetCalendarCombo = new JComboBox<>(calendarArray);
    String currentCal = calendarManager.getActiveCalendarName();
    for (int i = 0; i < calendarArray.length; i++) {
      if (!calendarArray[i].equals(currentCal)) {
        targetCalendarCombo.setSelectedIndex(i);
        break;
      }
    }

    JTextField targetDateField = new JTextField(LocalDate.now().plusDays(1).toString());

    JPanel panel = new JPanel(new GridLayout(3, 2, 5, 5));
    panel.add(new JLabel("On Date (YYYY-MM-DD):"));
    panel.add(onDateField);
    panel.add(new JLabel("Target Calendar:"));
    panel.add(targetCalendarCombo);
    panel.add(new JLabel("To Date (YYYY-MM-DD):"));
    panel.add(targetDateField);

    int result = JOptionPane.showConfirmDialog(this, panel, "Copy Events On Specific Date",
        JOptionPane.OK_CANCEL_OPTION);

    if (result == JOptionPane.OK_OPTION) {
      String onDate = onDateField.getText().trim();
      String targetCalendar = (String) targetCalendarCombo.getSelectedItem();
      String targetDate = targetDateField.getText().trim();

      if (onDate.isEmpty() || targetDate.isEmpty()) {
        displayError("All fields are required");
        return;
      }

      String command = "copy events on " + onDate
          + " --target " + targetCalendar + " to " + targetDate;

      controller.executeCommand(command, this);
    }
  }

  private void showExportDialog() {
    if (controller == null) {
      displayError("Controller not initialized");
      return;
    }

    if (!calendarManager.hasActiveCalendar()) {
      displayError("Please select a calendar first");
      return;
    }

    String[] formats = {"CSV (.csv)", "iCal (.ical)"};
    String format = (String) JOptionPane.showInputDialog(
        this,
        "Select export format:",
        "Export Calendar",
        JOptionPane.QUESTION_MESSAGE,
        null,
        formats,
        formats[0]
    );

    if (format != null) {
      String extension = format.contains("CSV") ? ".csv" : ".ical";
      String defaultName = calendarManager.getActiveCalendarName().replace(" ", "_") + extension;

      String fileName = JOptionPane.showInputDialog(this, "Enter filename:", defaultName);

      if (fileName != null && !fileName.trim().isEmpty()) {
        if (!fileName.endsWith(extension)) {
          fileName += extension;
        }
        controller.executeCommand("export cal " + fileName, this);
      }
    }
  }

  private void showStatusDialog() {
    if (controller == null) {
      displayError("Controller not initialized");
      return;
    }

    if (!calendarManager.hasActiveCalendar()) {
      displayError("Please select a calendar first");
      return;
    }

    JTextField dateField = new JTextField(
        selectedDate != null ? selectedDate.toString() : LocalDate.now().toString());
    JTextField timeField = new JTextField("09:00");

    JPanel panel = new JPanel(new GridLayout(2, 2, 5, 5));
    panel.add(new JLabel("Date (YYYY-MM-DD):"));
    panel.add(dateField);
    panel.add(new JLabel("Time (HH:MM):"));
    panel.add(timeField);

    int result = JOptionPane.showConfirmDialog(this, panel, "Check Availability Status",
        JOptionPane.OK_CANCEL_OPTION);

    if (result == JOptionPane.OK_OPTION) {
      String date = dateField.getText().trim();
      String time = timeField.getText().trim();

      if (!date.isEmpty() && !time.isEmpty()) {
        controller.executeCommand("show status on " + date + "T" + time, this);
      } else {
        displayError("Date and time cannot be empty");
      }
    }
  }
}