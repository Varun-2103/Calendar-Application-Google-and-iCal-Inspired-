package calendar.export;

import calendar.model.InterfaceEvent;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

/**
 * Exports calendar events to iCal format compatible with Google Calendar.
 * Follows RFC 5545 iCalendar specification.
 */
public class IcalExporter implements InterfaceCalendarExporter {

  private static final DateTimeFormatter ICAL_DATETIME_FORMATTER = 
      DateTimeFormatter.ofPattern("yyyyMMdd'T'HHmmss");
  private static final DateTimeFormatter ICAL_DATE_FORMATTER = 
      DateTimeFormatter.ofPattern("yyyyMMdd");

  @Override
  public String export(List<InterfaceEvent> events, String fileName) throws IOException {
    Path path = Paths.get(fileName);

    try (BufferedWriter writer = new BufferedWriter(new FileWriter(path.toFile()))) {
      writer.write("BEGIN:VCALENDAR\r\n");
      writer.write("VERSION:2.0\r\n");
      writer.write("PRODID:-//Calendar App//Calendar App Events//EN\r\n");
      writer.write("CALSCALE:GREGORIAN\r\n");

      for (InterfaceEvent event : events) {
        writer.write(formatEventForIcal(event));
      }

      writer.write("END:VCALENDAR\r\n");
    }

    return path.toAbsolutePath().toString();
  }

  /**
   * Formats an event as an iCal VEVENT component.
   *
   * @param event the event to format
   * @return iCal formatted event string
   */
  private String formatEventForIcal(InterfaceEvent event) {
    StringBuilder ical = new StringBuilder();
    
    ical.append("BEGIN:VEVENT\r\n");
    
    ical.append("UID:").append(event.getSubject().hashCode()).append("@calendarapp\r\n");
    
    LocalDateTime now = LocalDateTime.now();
    ical.append("DTSTAMP:").append(formatDateTime(now)).append("\r\n");
    
    if (isAllDayEvent(event)) {
      ical.append("DTSTART:").append(formatDate(event.getStart())).append("\r\n");
    } else {
      ical.append("DTSTART:").append(formatDateTime(event.getStart())).append("\r\n");
    }
    
    if (isAllDayEvent(event)) {
      ical.append("DTEND:").append(formatDate(event.getEnd())).append("\r\n");
      ical.append("X-MICROSOFT-CDO-ALLDAYEVENT:TRUE\r\n");
    } else {
      ical.append("DTEND:").append(formatDateTime(event.getEnd())).append("\r\n");
    }
    
    ical.append("SUMMARY:").append(escapeIcalText(event.getSubject())).append("\r\n");
    
    if (event.getDescription() != null && !event.getDescription().trim().isEmpty()) {
      ical.append("DESCRIPTION:").append(escapeIcalText(event.getDescription())).append("\r\n");
    }
    
    if (event.getLocation() != null && !event.getLocation().trim().isEmpty()) {
      ical.append("LOCATION:").append(escapeIcalText(event.getLocation())).append("\r\n");
    }
    
    if (event.getStatus() != null && !event.getStatus().trim().isEmpty()) {
      String status = event.getStatus().toLowerCase();
      if ("confirmed".equals(status) || "tentative".equals(status) || "cancelled".equals(status)) {
        ical.append("STATUS:").append(status.toUpperCase()).append("\r\n");
      }
    }
    
    ical.append("END:VEVENT\r\n");
    
    return ical.toString();
  }

  /**
   * Formats a LocalDateTime for iCal format.
   * Uses UTC timezone as required by iCal standard.
   *
   * @param dateTime the date/time to format
   * @return formatted date/time string
   */
  private String formatDateTime(LocalDateTime dateTime) {
    ZonedDateTime utc = dateTime.atZone(ZoneId.of("UTC"));
    return ICAL_DATETIME_FORMATTER.format(utc);
  }

  /**
   * Escapes special characters in iCal text values.
   * Handles backslashes, newlines, commas, and semicolons.
   *
   * @param text text to escape
   * @return escaped text
    */
  private String escapeIcalText(String text) {
    if (text == null) {
      return "";
    }
    
    text = text.replace("\\", "\\\\");
    text = text.replace("\"", "\\\"");
    text = text.replace("\r\n", "\\n");
    text = text.replace("\n", "\\n");
    text = text.replace(",", "\\,");
    text = text.replace(";", "\\;");
    
    return text;
  }

  /**
   * Formats a LocalDateTime for iCal DATE format (for all-day events).
   *
   * @param dateTime the date/time to format
   * @return formatted date string
   */
  private String formatDate(LocalDateTime dateTime) {
    return ICAL_DATE_FORMATTER.format(dateTime);
  }

  /**
   * Checks if an event is an all-day event.
   *
   * @param event the event to check
   * @return true if all-day event
   */
  private boolean isAllDayEvent(InterfaceEvent event) {
    LocalDateTime start = event.getStart();
    LocalDateTime end = event.getEnd();
    return start.getHour() == 8 && start.getMinute() == 0
        && end.getHour() == 17
        && end.getMinute() == 0
        && start.toLocalDate().equals(end.toLocalDate());
  }
}