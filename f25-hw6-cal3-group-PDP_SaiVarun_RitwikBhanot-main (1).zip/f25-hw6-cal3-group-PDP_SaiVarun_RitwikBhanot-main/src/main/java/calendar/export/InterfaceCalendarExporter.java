package calendar.export;

import calendar.model.InterfaceEvent;
import java.io.IOException;
import java.util.List;

/**
 * Interface for exporting calendar events to different formats.
 */
public interface InterfaceCalendarExporter {

  /**
   * Exports events to a file.
   *
   * @param events   the events to export
   * @param fileName the name of the file to create
   * @return the absolute path of the created file
   * @throws IOException if there's an error writing the file
   */
  String export(List<InterfaceEvent> events, String fileName) throws IOException;
}