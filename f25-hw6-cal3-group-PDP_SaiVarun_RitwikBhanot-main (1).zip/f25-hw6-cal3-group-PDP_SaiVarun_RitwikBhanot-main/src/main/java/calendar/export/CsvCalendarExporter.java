package calendar.export;

import calendar.model.InterfaceEvent;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeFormatterBuilder;
import java.util.List;
import java.util.Locale;

/**
 * Exports calendar events to CSV format compatible with Google Calendar.
 */
public class CsvCalendarExporter implements InterfaceCalendarExporter {
  private static final DateTimeFormatter DATE_FORMATTER =
      DateTimeFormatter.ofPattern("MM/dd/yyyy");
  private static final DateTimeFormatter TIME_FORMATTER =
      new DateTimeFormatterBuilder()
          .appendPattern("hh:mm ")
          .appendText(java.time.temporal.ChronoField.AMPM_OF_DAY,
              java.util.Map.of(0L, "am", 1L, "pm"))
          .toFormatter(Locale.US);

  @Override
  public String export(List<InterfaceEvent> events, String fileName) throws IOException {
    Path path = Paths.get(fileName);

    try (BufferedWriter writer = new BufferedWriter(new FileWriter(path.toFile()))) {
      writer.write(
          "Subject,Start Date,Start Time,End Date,End Time,All Day Event,Description,Location,"
              + "Private\n");

      for (InterfaceEvent event : events) {
        writer.write(formatEventForCsv(event));
        writer.write("\n");
      }
    }

    return path.toAbsolutePath().toString();
  }

  /**
   * Formats an event as a CSV row.
   *
   * @param event the event to format
   * @return CSV-formatted string
   */
  private String formatEventForCsv(InterfaceEvent event) {
    boolean allDay = isAllDayEvent(event);
    StringBuilder csv = new StringBuilder();

    csv.append(escapeCsv(event.getSubject())).append(",");

    LocalDateTime start = event.getStart();
    LocalDateTime end = event.getEnd();

    csv.append(start.format(DATE_FORMATTER)).append(",");

    if (allDay) {
      csv.append(",");
    } else {
      csv.append(start.format(TIME_FORMATTER)).append(",");
    }

    csv.append(end.format(DATE_FORMATTER)).append(",");

    if (allDay) {
      csv.append(",");
    } else {
      csv.append(end.format(TIME_FORMATTER)).append(",");
    }

    csv.append(allDay ? "True" : "False").append(",");

    String description = event.getDescription();
    csv.append(description != null ? escapeCsv(description) : "").append(",");

    String location = event.getLocation();
    csv.append(location != null ? escapeCsv(location) : "").append(",");

    String status = event.getStatus();
    boolean isPrivate = status != null && status.equalsIgnoreCase("private");
    csv.append(isPrivate ? "True" : "False");

    return csv.toString();
  }

  /**
   * Escapes special characters for CSV format.
   *
   * @param value the value to escape
   * @return escaped value
   */
  private String escapeCsv(String value) {
    if (value == null || value.isEmpty()) {
      return "";
    }
    if (value.contains(",") || value.contains("\"") || value.contains("\n")
        || value.contains("\r")) {
      String escapedValue = value.replace("\"", "\"\"");
      return "\"" + escapedValue + "\"";
    }
    return value;
  }

  /**
   * Checks if an event is an all-day event.
   *
   * @param event the event to check
   * @return true if all-day event
   */
  private boolean isAllDayEvent(InterfaceEvent event) {
    LocalDateTime start = event.getStart();
    LocalDateTime end = event.getEnd();
    return start.getHour() == 8 && start.getMinute() == 0
        && end.getHour() == 17
        && end.getMinute() == 0
        && start.toLocalDate().equals(end.toLocalDate());
  }
}