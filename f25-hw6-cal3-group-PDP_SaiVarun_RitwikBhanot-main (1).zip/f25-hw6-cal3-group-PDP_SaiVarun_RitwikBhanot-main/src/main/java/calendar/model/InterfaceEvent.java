package calendar.model;

import java.time.LocalDateTime;

/**
 * Interface representing a calendar event.
 * An event has a subject, start/end times, and optional location, description, and status.
 */
public interface InterfaceEvent {

  /**
   * Gets the subject of the event.
   *
   * @return the subject
   */
  String getSubject();

  /**
   * Gets the start date and time of the event.
   *
   * @return the start date/time
   */
  LocalDateTime getStart();

  /**
   * Gets the end date and time of the event.
   *
   * @return the end date/time
   */
  LocalDateTime getEnd();

  /**
   * Gets the location of the event.
   *
   * @return the location, or null if not set
   */
  String getLocation();

  /**
   * Gets the description of the event.
   *
   * @return the description, or null if not set
   */
  String getDescription();

  /**
   * Gets the status of the event (public or private).
   *
   * @return the status, or null if not set
   */
  String getStatus();

  /**
   * Sets the subject of the event.
   *
   * @param subject the new subject
   */
  void setSubject(String subject);

  /**
   * Sets the start date and time of the event.
   *
   * @param start the new start date/time
   */
  void setStart(LocalDateTime start);

  /**
   * Sets the end date and time of the event.
   *
   * @param end the new end date/time
   */
  void setEnd(LocalDateTime end);

  /**
   * Sets the location of the event.
   *
   * @param location the new location
   */
  void setLocation(String location);

  /**
   * Sets the description of the event.
   *
   * @param description the new description
   */
  void setDescription(String description);

  /**
   * Sets the status of the event.
   *
   * @param status the new status (public or private)
   */
  void setStatus(String status);
}