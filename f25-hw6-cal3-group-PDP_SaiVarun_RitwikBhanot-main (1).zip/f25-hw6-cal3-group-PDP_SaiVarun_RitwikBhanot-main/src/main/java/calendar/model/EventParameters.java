package calendar.model;

import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.Set;

/**
 * Parameter object for event creation operations.
 */
public class EventParameters {
  private final String subject;
  private final LocalDateTime start;
  private final LocalDateTime end;
  private final String weekdays;
  private final int occurrences;
  private final LocalDateTime until;

  private EventParameters(Builder builder) {
    this.subject = builder.subject;
    this.start = builder.start;
    this.end = builder.end;
    this.weekdays = builder.weekdays;
    this.occurrences = builder.occurrences;
    this.until = builder.until;
  }

  public String getSubject() {
    return subject;
  }

  public LocalDateTime getStart() {
    return start;
  }

  public LocalDateTime getEnd() {
    return end;
  }

  public String getWeekdays() {
    return weekdays;
  }

  public int getOccurrences() {
    return occurrences;
  }

  public LocalDateTime getUntil() {
    return until;
  }

  public boolean isSeries() {
    return weekdays != null;
  }

  public boolean isSeriesWithOccurrences() {
    return isSeries() && occurrences > 0;
  }

  public boolean isSeriesWithUntil() {
    return isSeries() && until != null;
  }

  public LocalTime getStartTime() {
    return start.toLocalTime();
  }

  public LocalTime getEndTime() {
    return end.toLocalTime();
  }

  /**
   * Builder for EventParameters.
   */
  public static class Builder {
    private String subject;
    private LocalDateTime start;
    private LocalDateTime end;
    private String weekdays;
    private int occurrences;
    private LocalDateTime until;

    /**
     * Sets the subject.
     *
     * @param subject the subject
     * @return this builder
     */
    public Builder subject(String subject) {
      this.subject = subject;
      return this;
    }

    /**
     * Sets the start time.
     *
     * @param start the start time
     * @return this builder
     */
    public Builder start(LocalDateTime start) {
      this.start = start;
      return this;
    }

    /**
     * Sets the end time.
     *
     * @param end the end time
     * @return this builder
     */
    public Builder end(LocalDateTime end) {
      this.end = end;
      return this;
    }

    /**
     * Sets the weekdays.
     *
     * @param weekdays the weekdays
     * @return this builder
     */
    public Builder weekdays(String weekdays) {
      this.weekdays = weekdays;
      return this;
    }

    /**
     * Sets the occurrences.
     *
     * @param occurrences the occurrences
     * @return this builder
     */
    public Builder occurrences(int occurrences) {
      this.occurrences = occurrences;
      return this;
    }

    /**
     * Sets the until date.
     *
     * @param until the until date
     * @return this builder
     */
    public Builder until(LocalDateTime until) {
      this.until = until;
      return this;
    }

    /**
     * Builds the EventParameters.
     *
     * @return the EventParameters
     */
    public EventParameters build() {
      return new EventParameters(this);
    }
  }

  /**
   * Creates a new builder.
   *
   * @return new builder
   */
  public static Builder builder() {
    return new Builder();
  }
}