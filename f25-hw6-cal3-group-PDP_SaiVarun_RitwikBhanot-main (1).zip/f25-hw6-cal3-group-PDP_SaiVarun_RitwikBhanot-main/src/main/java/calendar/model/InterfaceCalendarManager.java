package calendar.model;

import java.time.ZoneId;
import java.util.List;
import java.util.Set;

/**
 * Interface for managing multiple calendars with unique names and timezones.
 * Supports creating, editing, switching between calendars, and querying calendar information.
 */
public interface InterfaceCalendarManager {

  /**
   * Creates a new calendar with the specified name and timezone.
   *
   * @param name     the unique name of the calendar
   * @param timezone the timezone for the calendar (IANA format)
   * @throws IllegalArgumentException if calendar name already exists or timezone is invalid
   */
  void createCalendar(String name, ZoneId timezone);

  /**
   * Edits a property of an existing calendar.
   *
   * @param name     the name of the calendar to edit
   * @param property the property to edit ("name" or "timezone")
   * @param newValue the new value for the property
   * @throws IllegalArgumentException if calendar not found, property invalid, or new value invalid
   */
  void editCalendar(String name, String property, String newValue);

  /**
   * Sets the active calendar context for subsequent operations.
   *
   * @param name the name of the calendar to set as active
   * @throws IllegalArgumentException if calendar not found
   */
  void useCalendar(String name);

  /**
   * Gets the currently active calendar.
   *
   * @return the active calendar
   * @throws IllegalStateException if no calendar is currently active
   */
  InterfaceCalendar getActiveCalendar();

  /**
   * Gets the name of the currently active calendar.
   *
   * @return the active calendar name
   * @throws IllegalStateException if no calendar is currently active
   */
  String getActiveCalendarName();

  /**
   * Gets the timezone of the currently active calendar.
   *
   * @return the active calendar timezone
   * @throws IllegalStateException if no calendar is currently active
   */
  ZoneId getActiveCalendarTimezone();

  /**
   * Gets a calendar by name.
   *
   * @param name the name of the calendar
   * @return the calendar, or null if not found
   */
  InterfaceCalendar getCalendar(String name);

  /**
   * Gets the timezone of a specific calendar.
   *
   * @param name the name of the calendar
   * @return the timezone, or null if calendar not found
   */
  ZoneId getCalendarTimezone(String name);

  /**
   * Gets all calendar names.
   *
   * @return set of all calendar names
   */
  Set<String> getAllCalendarNames();

  /**
   * Checks if a calendar with the given name exists.
   *
   * @param name the calendar name to check
   * @return true if calendar exists, false otherwise
   */
  boolean calendarExists(String name);

  /**
   * Gets all calendars.
   *
   * @return list of all calendars
   */
  List<InterfaceCalendar> getAllCalendars();

  /**
   * Checks if any calendar exists.
   *
   * @return true if at least one calendar exists, false otherwise
   */
  boolean hasCalendars();

  /**
   * Checks if a calendar is currently active.
   *
   * @return true if a calendar is active, false otherwise
   */
  boolean hasActiveCalendar();
}