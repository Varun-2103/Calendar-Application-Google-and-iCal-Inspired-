package calendar.model;

import java.time.ZoneId;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Manages multiple calendars with unique names and timezones.
 * Maintains an active calendar context for operations.
 */
public class CalendarManager implements InterfaceCalendarManager {

  private final Map<String, InterfaceCalendar> calendars;
  private final Map<String, ZoneId> calendarTimezones;
  private String activeCalendarName;

  /**
   * Creates a new calendar manager.
   */
  public CalendarManager() {
    this.calendars = new HashMap<>();
    this.calendarTimezones = new HashMap<>();
    this.activeCalendarName = null;
  }

  @Override
  public void createCalendar(String name, ZoneId timezone) {
    if (name == null || name.trim().isEmpty()) {
      throw new IllegalArgumentException("Calendar name cannot be null or empty");
    }
    if (timezone == null) {
      throw new IllegalArgumentException("Timezone cannot be null");
    }
    if (calendars.containsKey(name)) {
      throw new IllegalArgumentException("Calendar with name '" + name + "' already exists");
    }

    InterfaceCalendar calendar = new Calendar(timezone);
    calendars.put(name, calendar);
    calendarTimezones.put(name, timezone);
  }

  @Override
  public void editCalendar(String name, String property, String newValue) {
    if (!calendars.containsKey(name)) {
      throw new IllegalArgumentException("Calendar '" + name + "' not found");
    }
    if (property == null || property.trim().isEmpty()) {
      throw new IllegalArgumentException("Property cannot be null or empty");
    }
    if (newValue == null || newValue.trim().isEmpty()) {
      throw new IllegalArgumentException("New value cannot be null or empty");
    }

    switch (property.toLowerCase()) {
      case "name":
        editCalendarName(name, newValue);
        break;
      case "timezone":
        editCalendarTimezone(name, newValue);
        break;
      default:
        throw new IllegalArgumentException("Invalid property: " + property
            + ". Valid properties are: name, timezone");
    }
  }

  @Override
  public void useCalendar(String name) {
    if (!calendars.containsKey(name)) {
      throw new IllegalArgumentException("Calendar '" + name + "' not found");
    }
    activeCalendarName = name;
  }

  @Override
  public InterfaceCalendar getActiveCalendar() {
    if (activeCalendarName == null) {
      throw new IllegalStateException("No calendar is currently active. Use 'use calendar' command "
          + "first.");
    }
    return calendars.get(activeCalendarName);
  }

  @Override
  public String getActiveCalendarName() {
    if (activeCalendarName == null) {
      throw new IllegalStateException("No calendar is currently active");
    }
    return activeCalendarName;
  }

  @Override
  public ZoneId getActiveCalendarTimezone() {
    if (activeCalendarName == null) {
      throw new IllegalStateException("No calendar is currently active");
    }
    return calendarTimezones.get(activeCalendarName);
  }

  @Override
  public InterfaceCalendar getCalendar(String name) {
    return calendars.get(name);
  }

  @Override
  public ZoneId getCalendarTimezone(String name) {
    return calendarTimezones.get(name);
  }

  @Override
  public Set<String> getAllCalendarNames() {
    return new HashSet<>(calendars.keySet());
  }

  @Override
  public boolean calendarExists(String name) {
    return calendars.containsKey(name);
  }

  @Override
  public List<InterfaceCalendar> getAllCalendars() {
    return new ArrayList<>(calendars.values());
  }

  @Override
  public boolean hasCalendars() {
    return !calendars.isEmpty();
  }

  @Override
  public boolean hasActiveCalendar() {
    return activeCalendarName != null;
  }

  /**
   * Edits the name of a calendar.
   *
   * @param oldName the current name of the calendar
   * @param newName the new name for the calendar
   * @throws IllegalArgumentException if new name already exists or is invalid
   */
  private void editCalendarName(String oldName, String newName) {
    if (newName.trim().isEmpty()) {
      throw new IllegalArgumentException("Calendar name cannot be empty");
    }
    if (calendars.containsKey(newName) && !newName.equals(oldName)) {
      throw new IllegalArgumentException("Calendar with name '" + newName + "' already exists");
    }

    InterfaceCalendar calendar = calendars.get(oldName);
    calendars.remove(oldName);
    ZoneId timezone = calendarTimezones.get(oldName);
    calendarTimezones.remove(oldName);

    calendars.put(newName, calendar);
    calendarTimezones.put(newName, timezone);

    if (oldName.equals(activeCalendarName)) {
      activeCalendarName = newName;
    }
  }

  /**
   * Edits the timezone of a calendar.
   *
   * @param name       the name of the calendar
   * @param timezoneId the new timezone ID (IANA format)
   * @throws IllegalArgumentException if timezone is invalid
   */
  private void editCalendarTimezone(String name, String timezoneId) {
    try {
      ZoneId newTimezone = ZoneId.of(timezoneId);
      calendarTimezones.put(name, newTimezone);
    } catch (Exception e) {
      throw new IllegalArgumentException("Invalid timezone: " + timezoneId
          + ". Expected format: Area/Location (e.g., America/New_York)");
    }
  }
}