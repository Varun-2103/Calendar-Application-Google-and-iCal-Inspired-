package calendar.model;

import calendar.util.DateTimeParser;
import calendar.util.EventValidator;
import calendar.util.WeekdayParser;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.ZoneId;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * Implementation of a calendar that manages events and event series.
 */
public class Calendar implements InterfaceCalendar {

  private Set<InterfaceEvent> events;
  private List<InterfaceEventSeries> eventSeries;
  private Map<InterfaceEvent, InterfaceEventSeries> eventToSeriesMap;
  private ZoneId timezone;

  /**
   * Creates a new empty calendar with default timezone (UTC).
   */
  public Calendar() {
    this(ZoneId.of("UTC"));
  }

  /**
   * Creates a new empty calendar with specified timezone.
   *
   * @param timezone the timezone for this calendar
   */
  public Calendar(ZoneId timezone) {
    this.events = new LinkedHashSet<>();
    this.eventSeries = new ArrayList<>();
    this.eventToSeriesMap = new HashMap<>();
    this.timezone = timezone != null ? timezone : ZoneId.of("UTC");
  }

  @Override
  public void createEvent(String subject, LocalDateTime start, LocalDateTime end) {
    EventParameters params = EventParameters.builder()
        .subject(subject)
        .start(start)
        .end(end)
        .build();
    
    createEventWithParameters(params);
  }

  /**
   * Creates an event using parameter object.
   *
   * @param params the event parameters
   */
  private void createEventWithParameters(EventParameters params) {
    InterfaceEvent newEvent = new Event(params.getSubject(), params.getStart(), params.getEnd());

    if (!events.add(newEvent)) {
      throw new IllegalArgumentException(
          "An event with the same subject, start time, and end time already exists");
    }
  }

  /**
   * Creates an event series using parameter object.
   *
   * @param params the event parameters
   */
  private void createEventSeriesWithParameters(EventParameters params) {
    Set<DayOfWeek> weekdaySet = WeekdayParser.parse(params.getWeekdays());
    InterfaceEventSeries series = new EventSeries(
        params.getSubject(), params.getStartTime(), params.getEndTime(), weekdaySet);

    List<LocalDate> dates;
    if (params.isSeriesWithOccurrences()) {
      dates = generateSeriesDates(
          params.getStart().toLocalDate(), weekdaySet, params.getOccurrences());
    } else {
      dates = generateSeriesDatesUntil(
          params.getStart().toLocalDate(), weekdaySet, params.getUntil().toLocalDate());
    }

    for (LocalDate date : dates) {
      LocalDateTime eventStart = date.atTime(params.getStart().toLocalTime());
      LocalDateTime eventEnd = date.atTime(params.getEnd().toLocalTime());

      InterfaceEvent event = new Event(params.getSubject(), eventStart, eventEnd);

      if (!events.add(event)) {
        throw new IllegalArgumentException(
            "Event series would create duplicate event on " + date);
      }

      addEventToSeries(event, series);
    }

    eventSeries.add(series);
  }

  @Override
  public void createAllDayEvent(String subject, LocalDate date) {
    if (date == null) {
      throw new IllegalArgumentException("Date cannot be null");
    }

    LocalDateTime start = date.atTime(8, 0);
    LocalDateTime end = date.atTime(17, 0);
    createEvent(subject, start, end);
  }

  @Override
  public void createEventSeries(String subject, LocalDateTime start, LocalDateTime end,
                                String weekdays, int occurrences) {
    EventValidator.validateSubject(subject);
    EventValidator.validateTimes(start, end);
    EventValidator.validateSameDay(start, end);
    EventValidator.validateWeekdays(weekdays);
    EventValidator.validateOccurrences(occurrences);
    
    EventParameters params = EventParameters.builder()
        .subject(subject)
        .start(start)
        .end(end)
        .weekdays(weekdays)
        .occurrences(occurrences)
        .build();
    
    createEventSeriesWithParameters(params);
  }

  @Override
  public void createEventSeriesUntil(String subject, LocalDateTime start, LocalDateTime end,
                                     String weekdays, LocalDate until) {
    EventValidator.validateSubject(subject);
    EventValidator.validateTimes(start, end);
    EventValidator.validateSameDay(start, end);
    EventValidator.validateWeekdays(weekdays);
    EventValidator.validateUntilDate(start.toLocalDate(), until);
    
    EventParameters params = EventParameters.builder()
        .subject(subject)
        .start(start)
        .end(end)
        .weekdays(weekdays)
        .until(until.atStartOfDay())
        .build();
    
    createEventSeriesWithParameters(params);
  }

  @Override
  public void editEvent(String subject, LocalDateTime start, String property, String newValue) {
    EventValidator.validateSubject(subject);
    if (start == null) {
      throw new IllegalArgumentException("Start time cannot be null");
    }
    EventValidator.validateEditParameters(property, newValue);

    InterfaceEvent event = findEvent(subject, start);

    if (event == null) {
      throw new IllegalArgumentException("Event not found with subject '" + subject
          + "' starting at " + start);
    }

    if (property.equalsIgnoreCase("start") && isPartOfSeries(event)) {
      removeEventFromSeries(event);
    }

    String oldSubject = event.getSubject();
    LocalDateTime oldStart = event.getStart();
    LocalDateTime oldEnd = event.getEnd();

    updateEventProperty(event, property, newValue);

    if (!validateNoDuplicateExcept(event, oldSubject, oldStart, oldEnd)) {
      event.setSubject(oldSubject);
      event.setStart(oldStart);
      event.setEnd(oldEnd);
      throw new IllegalArgumentException("Edit would create a duplicate event");
    }
  }

  @Override
  public void editEventsFrom(String subject, LocalDateTime start, String property,
                             String newValue) {
    EventValidator.validateSubject(subject);
    if (start == null) {
      throw new IllegalArgumentException("Start time cannot be null");
    }
    EventValidator.validateEditParameters(property, newValue);

    InterfaceEvent event = findEvent(subject, start);

    if (event == null) {
      throw new IllegalArgumentException("Event not found with subject '" + subject
          + "' starting at " + start);
    }

    if (isPartOfSeries(event)) {
      if (property.equalsIgnoreCase("start")) {
        splitSeriesAndUpdateFrom(event, start, property, newValue);
      } else {
        InterfaceEventSeries series = getSeriesForEvent(event);
        series.updatePropertyFrom(start, property, newValue);
      }
    } else {
      editEvent(subject, start, property, newValue);
    }
  }

  @Override
  public void editSeries(String subject, LocalDateTime start, String property, String newValue) {
    EventValidator.validateSubject(subject);
    if (start == null) {
      throw new IllegalArgumentException("Start time cannot be null");
    }
    EventValidator.validateEditParameters(property, newValue);

    InterfaceEvent event = findEvent(subject, start);

    if (event == null) {
      throw new IllegalArgumentException("Event not found with subject '" + subject
          + "' starting at " + start);
    }

    if (isPartOfSeries(event)) {
      InterfaceEventSeries series = getSeriesForEvent(event);
      series.updateProperty(property, newValue);
    } else {
      editEvent(subject, start, property, newValue);
    }
  }

  @Override
  public List<InterfaceEvent> getEventsOn(LocalDate date) {
    if (date == null) {
      throw new IllegalArgumentException("Date cannot be null");
    }

    return events.stream()
        .filter(event -> {
          LocalDate eventStart = event.getStart().toLocalDate();
          LocalDate eventEnd = event.getEnd().toLocalDate();
          return !date.isBefore(eventStart) && !date.isAfter(eventEnd);
        })
        .sorted((e1, e2) -> e1.getStart().compareTo(e2.getStart()))
        .collect(Collectors.toList());
  }

  @Override
  public List<InterfaceEvent> getEventsBetween(LocalDateTime start, LocalDateTime end) {
    if (start == null) {
      throw new IllegalArgumentException("Start time cannot be null");
    }
    if (end == null) {
      throw new IllegalArgumentException("End time cannot be null");
    }

    return events.stream()
        .filter(event -> event.getStart().isBefore(end) && event.getEnd().isAfter(start))
        .sorted((e1, e2) -> e1.getStart().compareTo(e2.getStart()))
        .collect(Collectors.toList());
  }

  @Override
  public boolean isBusy(LocalDateTime dateTime) {
    if (dateTime == null) {
      throw new IllegalArgumentException("DateTime cannot be null");
    }

    return events.stream()
        .anyMatch(event -> !dateTime.isBefore(event.getStart())
            && dateTime.isBefore(event.getEnd()));
  }

  @Override
  public List<InterfaceEvent> getAllEvents() {
    return new ArrayList<>(events);
  }

  /**
   * Gets the timezone of this calendar.
   *
   * @return the timezone
   */
  public ZoneId getTimezone() {
    return timezone;
  }

  /**
   * Sets the timezone of this calendar.
   *
   * @param timezone the new timezone
   */
  public void setTimezone(ZoneId timezone) {
    this.timezone = timezone != null ? timezone : ZoneId.of("UTC");
  }

  /**
   * Checks if an event is part of a series.
   *
   * @param event the event to check
   * @return true if the event belongs to a series
   */
  private boolean isPartOfSeries(InterfaceEvent event) {
    return eventToSeriesMap.containsKey(event);
  }

  /**
   * Gets the series that an event belongs to.
   *
   * @param event the event
   * @return the series, or null if not part of a series
   */
  private InterfaceEventSeries getSeriesForEvent(InterfaceEvent event) {
    return eventToSeriesMap.get(event);
  }

  /**
   * Removes an event from its series.
   *
   * @param event the event to remove
   */
  private void removeEventFromSeries(InterfaceEvent event) {
    InterfaceEventSeries series = eventToSeriesMap.get(event);
    if (series != null) {
      series.removeEvent(event);
      eventToSeriesMap.remove(event);
    }
  }

  /**
   * Adds an event to a series.
   *
   * @param event  the event to add
   * @param series the series to add to
   */
  private void addEventToSeries(InterfaceEvent event, InterfaceEventSeries series) {
    series.addEvent(event);
    eventToSeriesMap.put(event, series);
  }

  /**
   * Validates no duplicate except for the specified event with old values.
   *
   * @param currentEvent the event being edited
   * @param oldSubject   the old subject
   * @param oldStart     the old start time
   * @param oldEnd       the old end time
   * @return true if valid, false if duplicate found
   */
  private boolean validateNoDuplicateExcept(InterfaceEvent currentEvent, String oldSubject,
                                            LocalDateTime oldStart, LocalDateTime oldEnd) {
    return events.stream()
        .filter(event -> !isSameEvent(event, currentEvent))
        .noneMatch(event -> hasSameIdentity(event, currentEvent));
  }

  /**
   * Checks if two events are the same instance.
   *
   * @param event1 the first event
   * @param event2 the second event
   * @return true if they are the same instance
   */
  private boolean isSameEvent(InterfaceEvent event1, InterfaceEvent event2) {
    return event1 == event2;
  }

  /**
   * Checks if two events have the same identity (subject, start, end).
   *
   * @param event1 the first event
   * @param event2 the second event
   * @return true if they have the same identity
   */
  private boolean hasSameIdentity(InterfaceEvent event1, InterfaceEvent event2) {
    return event1.getSubject().equals(event2.getSubject())
        && event1.getStart().equals(event2.getStart())
        && event1.getEnd().equals(event2.getEnd());
  }

  /**
   * Finds an event by subject and start time.
   *
   * @param subject the subject to search for
   * @param start   the start time to search for
   * @return the found event, or null if not found
   */
  private InterfaceEvent findEvent(String subject, LocalDateTime start) {
    for (InterfaceEvent event : events) {
      if (event.getSubject().equals(subject) && event.getStart().equals(start)) {
        return event;
      }
    }
    return null;
  }

  /**
   * Updates a single property of an event.
   *
   * @param event    the event to update
   * @param property the property name
   * @param newValue the new value
   */
  private void updateEventProperty(InterfaceEvent event, String property, String newValue) {
    if (isIdentityProperty(property)) {
      updateIdentityProperty(event, property, newValue);
    } else {
      updateSimpleProperty(event, property, newValue);
    }
  }

  /**
   * Checks if the property affects event identity.
   *
   * @param property the property name
   * @return true if it's an identity property
   */
  private boolean isIdentityProperty(String property) {
    String prop = property.toLowerCase();
    return prop.equals("subject") || prop.equals("start") || prop.equals("end");
  }

  /**
   * Updates identity properties (subject, start, end) that require re-adding to collections.
   *
   * @param event    the event to update
   * @param property the property name
   * @param newValue the new value
   */
  private void updateIdentityProperty(InterfaceEvent event, String property, String newValue) {
    temporarilyRemoveFromCollections(event);
    
    try {
      switch (property.toLowerCase()) {
        case "subject":
          event.setSubject(newValue);
          break;
        case "start":
          updateEventStartTime(event, newValue);
          break;
        case "end":
          event.setEnd(DateTimeParser.parseDateTime(newValue));
          break;
        default:
          throw new IllegalArgumentException("Unknown identity property: " + property);
      }
    } finally {
      addToCollections(event);
    }
  }

  /**
   * Updates simple properties that don't affect event identity.
   *
   * @param event    the event to update
   * @param property the property name
   * @param newValue the new value
   */
  private void updateSimpleProperty(InterfaceEvent event, String property, String newValue) {
    switch (property.toLowerCase()) {
      case "location":
        event.setLocation(newValue);
        break;
      case "description":
        event.setDescription(newValue);
        break;
      case "status":
        event.setStatus(newValue);
        break;
      default:
        throw new IllegalArgumentException("Unknown property: " + property);
    }
  }

  /**
   * Updates event start time while maintaining duration.
   *
   * @param event    the event to update
   * @param newValue the new start time as string
   */
  private void updateEventStartTime(InterfaceEvent event, String newValue) {
    LocalDateTime newStart = DateTimeParser.parseDateTime(newValue);
    if (event instanceof Event) {
      ((Event) event).updateStartTime(newStart);
    } else {
      // Fallback for interface implementations
      LocalDateTime oldStart = event.getStart();
      LocalDateTime oldEnd = event.getEnd();
      long durationMinutes = java.time.Duration.between(oldStart, oldEnd).toMinutes();
      event.setStart(newStart);
      event.setEnd(newStart.plusMinutes(durationMinutes));
    }
  }

  /**
   * Temporarily removes event from collections for identity updates.
   *
   * @param event the event to remove
   */
  private void temporarilyRemoveFromCollections(InterfaceEvent event) {
    events.remove(event);
  }

  /**
   * Adds event back to collections after identity updates.
   *
   * @param event the event to add
   */
  private void addToCollections(InterfaceEvent event) {
    events.add(event);
  }

  /**
   * Splits a series when editing start time from a specific date.
   *
   * @param event    the event to start the split from
   * @param start    the start datetime
   * @param property the property being edited
   * @param newValue the new value
   */
  private void splitSeriesAndUpdateFrom(InterfaceEvent event, LocalDateTime start,
                                        String property, String newValue) {
    InterfaceEventSeries oldSeries = getSeriesForEvent(event);
    List<InterfaceEvent> eventsToUpdate = new ArrayList<>();

    for (InterfaceEvent e : oldSeries.getAllEvents()) {
      if (!e.getStart().isBefore(start)) {
        eventsToUpdate.add(e);
      }
    }

    for (InterfaceEvent e : eventsToUpdate) {
      removeEventFromSeries(e);
    }

    if (property.equalsIgnoreCase("start")) {
      LocalDateTime referenceTime = DateTimeParser.parseDateTime(newValue);
      LocalTime newTime = referenceTime.toLocalTime();

      for (InterfaceEvent e : eventsToUpdate) {
        LocalDate eventDate = e.getStart().toLocalDate();
        LocalDateTime newStart = eventDate.atTime(newTime);

        temporarilyRemoveFromCollections(e);

        if (e instanceof Event) {
          ((Event) e).updateStartTime(newStart);
        } else {
          // Fallback for interface implementations
          long durationMinutes = java.time.Duration.between(
              e.getStart(), e.getEnd()).toMinutes();
          e.setStart(newStart);
          e.setEnd(newStart.plusMinutes(durationMinutes));
        }

        addToCollections(e);
      }
    } else {
      for (InterfaceEvent e : eventsToUpdate) {
        updateEventProperty(e, property, newValue);
      }
    }

    if (eventsToUpdate.size() > 1) {
      LocalTime newStartTime = eventsToUpdate.get(0).getStart().toLocalTime();
      LocalTime newEndTime = eventsToUpdate.get(0).getEnd().toLocalTime();
      String subject = eventsToUpdate.get(0).getSubject();

      InterfaceEventSeries newSeries = new EventSeries(
          subject, newStartTime, newEndTime, oldSeries.getWeekdays());

      for (InterfaceEvent e : eventsToUpdate) {
        addEventToSeries(e, newSeries);
      }

      eventSeries.add(newSeries);
    }
  }

  /**
   * Generates dates for a series with specific number of occurrences.
   *
   * @param startDate   the start date
   * @param weekdays    the set of weekdays
   * @param occurrences the number of occurrences
   * @return list of dates
   */
  private List<LocalDate> generateSeriesDates(LocalDate startDate, Set<DayOfWeek> weekdays,
                                              int occurrences) {
    return generateSeriesDates(startDate, weekdays, occurrences, null);
  }

  /**
   * Generates dates for a series with either occurrences limit or until date.
   *
   * @param startDate   the start date
   * @param weekdays    the set of weekdays
   * @param occurrences the number of occurrences (-1 if using until date)
   * @param until       the end date (null if using occurrences)
   * @return list of dates
   */
  private List<LocalDate> generateSeriesDates(LocalDate startDate, Set<DayOfWeek> weekdays,
                                              int occurrences, LocalDate until) {
    List<LocalDate> dates = new ArrayList<>();
    LocalDate currentDate = startDate;
    int count = 0;

    while (shouldContinueGenerating(currentDate, count, occurrences, until)) {
      if (weekdays.contains(currentDate.getDayOfWeek())) {
        dates.add(currentDate);
        count++;
      }
      currentDate = currentDate.plusDays(1);
    }

    return dates;
  }

  /**
   * Generates dates for a series until a specific date.
   *
   * @param startDate the start date
   * @param weekdays  the set of weekdays
   * @param until     the end date (inclusive)
   * @return list of dates
   */
  private List<LocalDate> generateSeriesDatesUntil(LocalDate startDate, Set<DayOfWeek> weekdays,
                                                   LocalDate until) {
    return generateSeriesDates(startDate, weekdays, -1, until);
  }

  /**
   * Determines if date generation should continue.
   *
   * @param currentDate the current date being processed
   * @param count       the current count of generated dates
   * @param occurrences the target number of occurrences (-1 if using until date)
   * @param until       the until date (null if using occurrences)
   * @return true if generation should continue
   */
  private boolean shouldContinueGenerating(LocalDate currentDate, int count, 
                                           int occurrences, LocalDate until) {
    if (occurrences > 0) {
      return count < occurrences;
    } else {
      return !currentDate.isAfter(until);
    }
  }
}