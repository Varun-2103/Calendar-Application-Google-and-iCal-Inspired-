package calendar.model;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.List;

/**
 * Interface representing a calendar that manages events and event series.
 * Supports creating, editing, querying, and exporting calendar events.
 */
public interface InterfaceCalendar {

  /**
   * Creates a single event in the calendar.
   *
   * @param subject the subject of the event
   * @param start   the start date and time
   * @param end     the end date and time
   * @throws IllegalArgumentException if event would create a duplicate
   */
  void createEvent(String subject, LocalDateTime start, LocalDateTime end);

  /**
   * Creates an all-day event (8am to 5pm) on the specified date.
   *
   * @param subject the subject of the event
   * @param date    the date of the event
   * @throws IllegalArgumentException if event would create a duplicate
   */
  void createAllDayEvent(String subject, LocalDate date);

  /**
   * Creates a recurring event series that repeats for a specified number of occurrences.
   *
   * @param subject     the subject of the events
   * @param start       the start date and time of the first event
   * @param end         the end date and time of the first event
   * @param weekdays    string representing days of the week (e.g., "MWF")
   * @param occurrences the number of times to repeat
   * @throws IllegalArgumentException if any event would create a duplicate
   */
  void createEventSeries(String subject, LocalDateTime start, LocalDateTime end,
                         String weekdays, int occurrences);

  /**
   * Creates a recurring event series that repeats until a specified date (inclusive).
   *
   * @param subject  the subject of the events
   * @param start    the start date and time of the first event
   * @param end      the end date and time of the first event
   * @param weekdays string representing days of the week
   * @param until    the end date (inclusive)
   * @throws IllegalArgumentException if any event would create a duplicate
   */
  void createEventSeriesUntil(String subject, LocalDateTime start, LocalDateTime end,
                              String weekdays, LocalDate until);

  /**
   * Edits a single event's property.
   *
   * @param subject  the subject of the event to edit
   * @param start    the start date and time of the event to edit
   * @param property the property to edit (subject, start, end, location, description, status)
   * @param newValue the new value for the property
   * @throws IllegalArgumentException if event not found or edit would create duplicate
   */
  void editEvent(String subject, LocalDateTime start, String property, String newValue);

  /**
   * Edits all events in a series starting from the specified event.
   *
   * @param subject  the subject of the event to edit
   * @param start    the start date and time of the event
   * @param property the property to edit
   * @param newValue the new value for the property
   * @throws IllegalArgumentException if event not found or edit would create duplicate
   */
  void editEventsFrom(String subject, LocalDateTime start, String property, String newValue);

  /**
   * Edits all events in a series (before and after the specified event).
   *
   * @param subject  the subject of the event
   * @param start    the start date and time of the event
   * @param property the property to edit
   * @param newValue the new value for the property
   * @throws IllegalArgumentException if event not found or edit would create duplicate
   */
  void editSeries(String subject, LocalDateTime start, String property, String newValue);

  /**
   * Gets all events scheduled on a specific date.
   *
   * @param date the date to query
   * @return list of events on that date
   */
  List<InterfaceEvent> getEventsOn(LocalDate date);

  /**
   * Gets all events that partly or completely overlap with the given time range.
   *
   * @param start the start of the range
   * @param end   the end of the range
   * @return list of events in the range
   */
  List<InterfaceEvent> getEventsBetween(LocalDateTime start, LocalDateTime end);

  /**
   * Checks if the user is busy at the specified date and time.
   *
   * @param dateTime the date and time to check
   * @return true if busy, false if available
   */
  boolean isBusy(LocalDateTime dateTime);

  /**
   * Gets all events in the calendar.
   *
   * @return list of all events
   */
  List<InterfaceEvent> getAllEvents();

  /**
   * Gets the timezone of this calendar.
   *
   * @return the timezone
   */
  ZoneId getTimezone();

  /**
   * Sets the timezone of this calendar.
   *
   * @param timezone the new timezone
   */
  void setTimezone(ZoneId timezone);
}