package calendar.model;

import calendar.util.EventValidator;
import java.time.LocalDateTime;
import java.util.Objects;

/**
 * Represents a single calendar event.
 */
public class Event implements InterfaceEvent {

  private String subject;
  private LocalDateTime start;
  private LocalDateTime end;
  private String location;
  private String description;
  private String status;

  /**
   * Creates a new event with the specified subject, start, and end times.
   *
   * @param subject the subject of the event
   * @param start   the start date/time
   * @param end     the end date/time
   */
  public Event(String subject, LocalDateTime start, LocalDateTime end) {
    this(subject, start, end, true);
  }

  /**
   * Creates a new event with optional validation.
   *
   * @param subject   the subject of the event
   * @param start     the start date/time
   * @param end       the end date/time
   * @param validate  whether to validate parameters
   */
  Event(String subject, LocalDateTime start, LocalDateTime end, boolean validate) {
    if (validate) {
      validateEventParameters(subject, start, end);
    }
    this.subject = subject;
    this.start = start;
    this.end = end;
    this.location = null;
    this.description = null;
    this.status = null;
  }

  /**
   * Validates event parameters.
   *
   * @param subject the subject
   * @param start   the start time
   * @param end     the end time
   */
  private void validateEventParameters(String subject, LocalDateTime start, LocalDateTime end) {
    EventValidator.validateSubject(subject);
    EventValidator.validateTimes(start, end);
  }

  @Override
  public String getSubject() {
    return subject;
  }

  @Override
  public LocalDateTime getStart() {
    return start;
  }

  @Override
  public LocalDateTime getEnd() {
    return end;
  }

  @Override
  public String getLocation() {
    return location;
  }

  @Override
  public String getDescription() {
    return description;
  }

  @Override
  public String getStatus() {
    return status;
  }

  @Override
  public void setSubject(String subject) {
    this.subject = subject;
  }

  @Override
  public void setStart(LocalDateTime start) {
    this.start = start;
  }

  @Override
  public void setEnd(LocalDateTime end) {
    this.end = end;
  }

  @Override
  public void setLocation(String location) {
    this.location = location;
  }

  @Override
  public void setDescription(String description) {
    this.description = description;
  }

  @Override
  public void setStatus(String status) {
    this.status = status;
  }

  @Override
  public boolean equals(Object obj) {
    if (this == obj) {
      return true;
    }
    if (!(obj instanceof InterfaceEvent)) {
      return false;
    }
    InterfaceEvent other = (InterfaceEvent) obj;
    return subject.equals(other.getSubject())
        && start.equals(other.getStart())
        && end.equals(other.getEnd());
  }

  @Override
  public int hashCode() {
    return Objects.hash(subject, start, end);
  }

  @Override
  public String toString() {
    return subject + " from " + start + " to " + end;
  }

  /**
   * Updates the event with a new start time while maintaining duration.
   *
   * @param newStart the new start time
   */
  public void updateStartTime(LocalDateTime newStart) {
    long durationMinutes = java.time.Duration.between(this.start, this.end).toMinutes();
    this.start = newStart;
    this.end = newStart.plusMinutes(durationMinutes);
  }

  /**
   * Creates a copy of this event with updated properties.
   *
   * @param newSubject the new subject (null to keep current)
   * @param newStart   the new start time (null to keep current)
   * @param newEnd     the new end time (null to keep current)
   * @return a new event with updated properties
   */
  public Event withUpdates(String newSubject, LocalDateTime newStart, LocalDateTime newEnd) {
    String subject = newSubject != null ? newSubject : this.subject;
    LocalDateTime start = newStart != null ? newStart : this.start;
    LocalDateTime end = newEnd != null ? newEnd : this.end;
    return new Event(subject, start, end);
  }
}