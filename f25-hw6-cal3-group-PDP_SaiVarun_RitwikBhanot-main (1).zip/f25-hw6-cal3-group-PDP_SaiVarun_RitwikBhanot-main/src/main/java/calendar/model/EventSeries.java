package calendar.model;

import calendar.util.DateTimeParser;
import calendar.util.EventValidator;
import java.time.DayOfWeek;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

/**
 * Represents a series of recurring events.
 * All events in a series share the same start and end times.
 */
public class EventSeries implements InterfaceEventSeries {

  private String subject;
  private LocalTime startTime;
  private LocalTime endTime;
  private Set<DayOfWeek> weekdays;
  private List<InterfaceEvent> events;

  /**
   * Creates a new event series.
   *
   * @param subject   the subject of the series
   * @param startTime the start time for events
   * @param endTime   the end time for events
   * @param weekdays  the set of weekdays
   */
  public EventSeries(String subject, LocalTime startTime, LocalTime endTime,
                     Set<DayOfWeek> weekdays) {
    EventValidator.validateSubject(subject);
    if (startTime == null) {
      throw new IllegalArgumentException("Start time cannot be null");
    }
    if (endTime == null) {
      throw new IllegalArgumentException("End time cannot be null");
    }
    if (weekdays == null || weekdays.isEmpty()) {
      throw new IllegalArgumentException("Weekdays cannot be null or empty");
    }

    this.subject = subject;
    this.startTime = startTime;
    this.endTime = endTime;
    this.weekdays = weekdays;
    this.events = new ArrayList<>();
  }

  @Override
  public String getSubject() {
    return subject;
  }

  @Override
  public LocalTime getStartTime() {
    return startTime;
  }

  @Override
  public LocalTime getEndTime() {
    return endTime;
  }

  @Override
  public Set<DayOfWeek> getWeekdays() {
    return weekdays;
  }

  @Override
  public List<InterfaceEvent> getAllEvents() {
    return new ArrayList<>(events);
  }

  @Override
  public void addEvent(InterfaceEvent event) {
    if (event == null) {
      throw new IllegalArgumentException("Event cannot be null");
    }

    validateEventCompatibility(event);

    if (events.contains(event)) {
      throw new IllegalArgumentException("Event already exists in series");
    }

    events.add(event);
  }

  /**
   * Validates that an event is compatible with this series.
   *
   * @param event the event to validate
   */
  private void validateEventCompatibility(InterfaceEvent event) {
    if (!hasMatchingTime(event)) {
      throw new IllegalArgumentException(
          "Event times do not match series times");
    }

    if (!hasMatchingSubject(event)) {
      throw new IllegalArgumentException(
          "Event subject does not match series subject");
    }
  }

  /**
   * Checks if event times match series times.
   *
   * @param event the event to check
   * @return true if times match
   */
  private boolean hasMatchingTime(InterfaceEvent event) {
    return event.getStart().toLocalTime().equals(this.startTime)
        && event.getEnd().toLocalTime().equals(this.endTime);
  }

  /**
   * Checks if event subject matches series subject.
   *
   * @param event the event to check
   * @return true if subjects match
   */
  private boolean hasMatchingSubject(InterfaceEvent event) {
    return event.getSubject().equals(this.subject);
  }

  @Override
  public void removeEvent(InterfaceEvent event) {
    if (event == null) {
      throw new IllegalArgumentException("Event cannot be null");
    }

    if (!events.contains(event)) {
      throw new IllegalArgumentException("Event does not exist in series");
    }

    events.remove(event);
  }

  @Override
  public void updateProperty(String property, String value) {
    EventValidator.validateEditParameters(property, value);

    for (InterfaceEvent event : events) {
      updateEventProperty(event, property, value);
    }

    if (property.equalsIgnoreCase("subject")) {
      this.subject = value;
    }
  }

  @Override
  public void updatePropertyFrom(LocalDateTime startDate, String property, String value) {
    if (startDate == null) {
      throw new IllegalArgumentException("Start date cannot be null");
    }
    EventValidator.validateEditParameters(property, value);

    for (InterfaceEvent event : events) {
      if (!event.getStart().isBefore(startDate)) {
        updateEventProperty(event, property, value);
      }
    }
  }

  /**
   * Updates a single property of an event.
   *
   * @param event    the event to update
   * @param property the property name
   * @param value    the new value
   */
  private void updateEventProperty(InterfaceEvent event, String property, String value) {
    switch (property.toLowerCase()) {
      case "subject":
        event.setSubject(value);
        break;
      case "location":
        event.setLocation(value);
        break;
      case "description":
        event.setDescription(value);
        break;
      case "status":
        event.setStatus(value);
        break;
      case "start":
        event.setStart(DateTimeParser.parseDateTime(value));
        break;
      case "end":
        event.setEnd(DateTimeParser.parseDateTime(value));
        break;
      default:
        throw new IllegalArgumentException("Unknown property: " + property);
    }
  }
}