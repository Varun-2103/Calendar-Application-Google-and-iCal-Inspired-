package calendar.model;

import java.time.DayOfWeek;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.List;
import java.util.Set;

/**
 * Interface representing a series of recurring events.
 * All events in a series share the same start and end times.
 */
public interface InterfaceEventSeries {

  /**
   * Gets the subject of the event series.
   *
   * @return the subject
   */
  String getSubject();

  /**
   * Gets the start time for all events in the series.
   *
   * @return the start time
   */
  LocalTime getStartTime();

  /**
   * Gets the end time for all events in the series.
   *
   * @return the end time
   */
  LocalTime getEndTime();

  /**
   * Gets the set of weekdays on which events occur.
   *
   * @return set of DayOfWeek values
   */
  Set<DayOfWeek> getWeekdays();

  /**
   * Gets all events in this series.
   *
   * @return list of all events in the series
   */
  List<InterfaceEvent> getAllEvents();

  /**
   * Adds an event to this series.
   * Does not modify the event itself.
   *
   * @param event the event to add
   */
  void addEvent(InterfaceEvent event);

  /**
   * Removes an event from this series.
   * Does not modify the event itself.
   *
   * @param event the event to remove
   */
  void removeEvent(InterfaceEvent event);

  /**
   * Updates a property for all events in the series.
   *
   * @param property the property to update
   * @param value    the new value
   */
  void updateProperty(String property, String value);

  /**
   * Updates a property for all events starting from a specific date/time.
   *
   * @param startDate the date/time to start updating from
   * @param property  the property to update
   * @param value     the new value
   */
  void updatePropertyFrom(LocalDateTime startDate, String property, String value);
}