import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import calendar.controller.CalendarController;
import calendar.controller.InterfaceCalendarController;
import calendar.view.CalendarTextView;
import calendar.view.InterfaceCalendarView;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintStream;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import org.junit.After;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TemporaryFolder;

/**
 * Test class for CalendarRunner main application entry point.
 */
public class CalendarRunnerTest {

  @Rule
  public TemporaryFolder tempFolder = new TemporaryFolder();

  private ByteArrayOutputStream errContent;
  private PrintStream originalErr;

  /** Sets up error streams for testing. */
  @Before
  public void setUpStreams() {
    errContent = new ByteArrayOutputStream();
    originalErr = System.err;
    System.setErr(new PrintStream(errContent));
  }

  /** Restores original error streams after testing. */
  @After
  public void restoreStreams() {
    System.setErr(originalErr);
  }

  @Test
  public void testConstants() throws Exception {
    // Test that constants have expected values
    Field interactiveMode = CalendarRunner.class.getDeclaredField("INTERACTIVE_MODE");
    Field headlessMode = CalendarRunner.class.getDeclaredField("HEADLESS_MODE");
    Field modeFlag = CalendarRunner.class.getDeclaredField("MODE_FLAG");
    final Field exitCommand = CalendarRunner.class.getDeclaredField("EXIT_COMMAND");

    interactiveMode.setAccessible(true);
    headlessMode.setAccessible(true);
    modeFlag.setAccessible(true);
    exitCommand.setAccessible(true);

    assertEquals("interactive", interactiveMode.get(null));
    assertEquals("headless", headlessMode.get(null));
    assertEquals("--mode", modeFlag.get(null));
    assertEquals("exit", exitCommand.get(null));
  }

  @Test
  public void testPrintUsageMethod() throws Exception {
    // Use reflection to test private method
    Method printUsage = CalendarRunner.class.getDeclaredMethod("printUsage");
    printUsage.setAccessible(true);

    // Should not throw an exception
    printUsage.invoke(null);
    
    // Check that something was printed to stderr
    String output = errContent.toString();
    assertFalse("Usage should be printed", output.isEmpty());
    assertTrue("Should contain usage information", output.contains("Usage:"));
  }

  @Test
  public void testRunInteractiveModeMethod() throws Exception {
    // Use reflection to test private method
    Method runInteractiveMode = CalendarRunner.class.getDeclaredMethod(
        "runInteractiveMode", InterfaceCalendarController.class, InterfaceCalendarView.class);
    runInteractiveMode.setAccessible(true);

    InterfaceCalendarController controller = new CalendarController();
    InterfaceCalendarView view = new CalendarTextView();

    // Test with mock input that exits immediately
    String input = "exit\n";
    ByteArrayInputStream inContent = new ByteArrayInputStream(input.getBytes());
    System.setIn(inContent);

    // This should not throw an exception
    runInteractiveMode.invoke(null, controller, view);
  }

  @Test
  public void testRunInteractiveModeMethodWithEmptyCommands() throws Exception {
    // Use reflection to test private method
    Method runInteractiveMode = CalendarRunner.class.getDeclaredMethod(
        "runInteractiveMode", InterfaceCalendarController.class, InterfaceCalendarView.class);
    runInteractiveMode.setAccessible(true);

    InterfaceCalendarController controller = new CalendarController();
    InterfaceCalendarView view = new CalendarTextView();

    // Test with empty commands and then exit
    String input = "\n   \nexit\n";
    ByteArrayInputStream inContent = new ByteArrayInputStream(input.getBytes());
    System.setIn(inContent);

    // This should not throw an exception
    runInteractiveMode.invoke(null, controller, view);
  }

  @Test
  public void testRunHeadlessModeMethodValidFile() throws Exception {
    // Use reflection to test private method
    Method runHeadlessMode = CalendarRunner.class.getDeclaredMethod(
        "runHeadlessMode", InterfaceCalendarController.class, 
        InterfaceCalendarView.class, String.class);
    runHeadlessMode.setAccessible(true);

    File commandFile = tempFolder.newFile("commands.txt");
    try (FileWriter writer = new FileWriter(commandFile)) {
      writer.write("create calendar Test\n");
      writer.write("exit\n");
    }

    InterfaceCalendarController controller = new CalendarController();
    InterfaceCalendarView view = new CalendarTextView();

    // This should not throw an exception
    runHeadlessMode.invoke(null, controller, view, commandFile.getAbsolutePath());
  }

  @Test
  public void testRunHeadlessModeMethodWithCommentsAndEmptyLines() throws Exception {
    // Use reflection to test private method
    Method runHeadlessMode = CalendarRunner.class.getDeclaredMethod(
        "runHeadlessMode", InterfaceCalendarController.class, 
        InterfaceCalendarView.class, String.class);
    runHeadlessMode.setAccessible(true);

    File commandFile = tempFolder.newFile("commands.txt");
    try (FileWriter writer = new FileWriter(commandFile)) {
      writer.write("# This is a comment\n");
      writer.write("\n");
      writer.write("create calendar Test\n");
      writer.write("  \n");
      writer.write("exit\n");
    }

    InterfaceCalendarController controller = new CalendarController();
    InterfaceCalendarView view = new CalendarTextView();

    // This should not throw an exception
    runHeadlessMode.invoke(null, controller, view, commandFile.getAbsolutePath());
  }



  @Test
  public void testRunHeadlessModeMethodNonExistentFile() throws Exception {
    // Use reflection to test private method
    Method runHeadlessMode = CalendarRunner.class.getDeclaredMethod(
        "runHeadlessMode", InterfaceCalendarController.class, 
        InterfaceCalendarView.class, String.class);
    runHeadlessMode.setAccessible(true);

    InterfaceCalendarController controller = new CalendarController();
    InterfaceCalendarView view = new CalendarTextView();

    try {
      runHeadlessMode.invoke(null, controller, view, "nonexistent.txt");
      fail("Should throw IOException for non-existent file");
    } catch (Exception e) {
      assertTrue("Should be caused by IOException", 
          e.getCause() instanceof IOException);
    }
  }

  @Test
  public void testRunHeadlessModeMethodInvalidCommands() throws Exception {
    // Use reflection to test private method
    Method runHeadlessMode = CalendarRunner.class.getDeclaredMethod(
        "runHeadlessMode", InterfaceCalendarController.class, 
        InterfaceCalendarView.class, String.class);
    runHeadlessMode.setAccessible(true);

    File commandFile = tempFolder.newFile("commands.txt");
    try (FileWriter writer = new FileWriter(commandFile)) {
      writer.write("invalid command\n");
      writer.write("another invalid command\n");
      writer.write("exit\n");
    }

    InterfaceCalendarController controller = new CalendarController();
    InterfaceCalendarView view = new CalendarTextView();

    // Should not throw an exception even with invalid commands
    runHeadlessMode.invoke(null, controller, view, commandFile.getAbsolutePath());
  }

  @Test
  public void testRunInteractiveModeMethodWithInvalidCommand() throws Exception {
    // Use reflection to test private method
    Method runInteractiveMode = CalendarRunner.class.getDeclaredMethod(
        "runInteractiveMode", InterfaceCalendarController.class, InterfaceCalendarView.class);
    runInteractiveMode.setAccessible(true);

    InterfaceCalendarController controller = new CalendarController();
    InterfaceCalendarView view = new CalendarTextView();

    // Test with invalid command and then exit
    String input = "invalid command\nexit\n";
    ByteArrayInputStream inContent = new ByteArrayInputStream(input.getBytes());
    System.setIn(inContent);

    // This should not throw an exception
    runInteractiveMode.invoke(null, controller, view);
  }

  @Test
  public void testRunInteractiveModeMethodScannerHasNoNextLine() throws Exception {
    // Use reflection to test private method
    Method runInteractiveMode = CalendarRunner.class.getDeclaredMethod(
        "runInteractiveMode", InterfaceCalendarController.class, InterfaceCalendarView.class);
    runInteractiveMode.setAccessible(true);

    InterfaceCalendarController controller = new CalendarController();
    InterfaceCalendarView view = new CalendarTextView();

    // Test with empty input to trigger the !scanner.hasNextLine() branch
    String input = "";
    ByteArrayInputStream inContent = new ByteArrayInputStream(input.getBytes());
    System.setIn(inContent);

    // This should not throw an exception
    runInteractiveMode.invoke(null, controller, view);
  }

  @Test
  public void testRunHeadlessModeMethodWithOnlyComments() throws Exception {
    // Use reflection to test private method
    Method runHeadlessMode = CalendarRunner.class.getDeclaredMethod(
        "runHeadlessMode", InterfaceCalendarController.class, 
        InterfaceCalendarView.class, String.class);
    runHeadlessMode.setAccessible(true);

    File commandFile = tempFolder.newFile("commands.txt");
    try (FileWriter writer = new FileWriter(commandFile)) {
      writer.write("# This is a comment\n");
      writer.write("# Another comment\n");
      writer.write("exit\n");
    }

    InterfaceCalendarController controller = new CalendarController();
    InterfaceCalendarView view = new CalendarTextView();

    // Should not throw an exception
    runHeadlessMode.invoke(null, controller, view, commandFile.getAbsolutePath());
  }

  @Test
  public void testRunHeadlessModeMethodWithExceptionInCommand() throws Exception {
    // Use reflection to test private method
    Method runHeadlessMode = CalendarRunner.class.getDeclaredMethod(
        "runHeadlessMode", InterfaceCalendarController.class, 
        InterfaceCalendarView.class, String.class);
    runHeadlessMode.setAccessible(true);

    File commandFile = tempFolder.newFile("commands.txt");
    try (FileWriter writer = new FileWriter(commandFile)) {
      writer.write("invalid command that causes exception\n");
      writer.write("exit\n");
    }

    InterfaceCalendarController controller = new CalendarController();
    InterfaceCalendarView view = new CalendarTextView();

    // Should not throw an exception - should handle the exception gracefully
    runHeadlessMode.invoke(null, controller, view, commandFile.getAbsolutePath());
  }

  @Test
  public void testRunHeadlessModeMethodWithEmptyLines() throws Exception {
    // Use reflection to test private method
    Method runHeadlessMode = CalendarRunner.class.getDeclaredMethod(
        "runHeadlessMode", InterfaceCalendarController.class, 
        InterfaceCalendarView.class, String.class);
    runHeadlessMode.setAccessible(true);

    File commandFile = tempFolder.newFile("commands.txt");
    try (FileWriter writer = new FileWriter(commandFile)) {
      writer.write("\n");
      writer.write("   \n");
      writer.write("create calendar Test\n");
      writer.write("\n");
      writer.write("exit\n");
    }

    InterfaceCalendarController controller = new CalendarController();
    InterfaceCalendarView view = new CalendarTextView();

    // Should not throw an exception
    runHeadlessMode.invoke(null, controller, view, commandFile.getAbsolutePath());
  }

  @Test
  public void testRunInteractiveModeMethodWithWhitespaceCommands() throws Exception {
    // Use reflection to test private method
    Method runInteractiveMode = CalendarRunner.class.getDeclaredMethod(
        "runInteractiveMode", InterfaceCalendarController.class, InterfaceCalendarView.class);
    runInteractiveMode.setAccessible(true);

    InterfaceCalendarController controller = new CalendarController();
    InterfaceCalendarView view = new CalendarTextView();

    // Test with various whitespace commands and then exit
    String input = "   \n\t\n  exit  \n";
    ByteArrayInputStream inContent = new ByteArrayInputStream(input.getBytes());
    System.setIn(inContent);

    // This should not throw an exception
    runInteractiveMode.invoke(null, controller, view);
  }

  @Test
  public void testRunInteractiveModeMethodWithMixedCaseExit() throws Exception {
    // Use reflection to test private method
    Method runInteractiveMode = CalendarRunner.class.getDeclaredMethod(
        "runInteractiveMode", InterfaceCalendarController.class, InterfaceCalendarView.class);
    runInteractiveMode.setAccessible(true);

    InterfaceCalendarController controller = new CalendarController();
    InterfaceCalendarView view = new CalendarTextView();

    // Test with mixed case exit command
    String input = "EXIT\n";
    ByteArrayInputStream inContent = new ByteArrayInputStream(input.getBytes());
    System.setIn(inContent);

    // This should not throw an exception
    runInteractiveMode.invoke(null, controller, view);
  }

  @Test
  public void testRunInteractiveModeMethodWithCommandException() throws Exception {
    // Use reflection to test private method
    Method runInteractiveMode = CalendarRunner.class.getDeclaredMethod(
        "runInteractiveMode", InterfaceCalendarController.class, InterfaceCalendarView.class);
    runInteractiveMode.setAccessible(true);

    // Create a mock controller that throws exceptions
    InterfaceCalendarController mockController = new InterfaceCalendarController() {
      @Override
      public void executeCommand(String commandString, InterfaceCalendarView view) {
        if (commandString.contains("invalid")) {
          throw new RuntimeException("Test exception");
        }
      }
    };
    
    InterfaceCalendarView view = new CalendarTextView();

    // Test with command that causes exception to trigger exception handling
    String input = "invalid command\nexit\n";
    ByteArrayInputStream inContent = new ByteArrayInputStream(input.getBytes());
    System.setIn(inContent);

    // This should not throw an exception - should handle the exception gracefully
    runInteractiveMode.invoke(null, mockController, view);
  }

  @Test
  public void testRunHeadlessModeMethodWithMixedCaseExit() throws Exception {
    // Use reflection to test private method
    Method runHeadlessMode = CalendarRunner.class.getDeclaredMethod(
        "runHeadlessMode", InterfaceCalendarController.class, 
        InterfaceCalendarView.class, String.class);
    runHeadlessMode.setAccessible(true);

    File commandFile = tempFolder.newFile("commands.txt");
    try (FileWriter writer = new FileWriter(commandFile)) {
      writer.write("create calendar Test\n");
      writer.write("EXIT\n");
    }

    InterfaceCalendarController controller = new CalendarController();
    InterfaceCalendarView view = new CalendarTextView();

    // Should not throw an exception
    runHeadlessMode.invoke(null, controller, view, commandFile.getAbsolutePath());
  }

  @Test
  public void testRunHeadlessModeMethodWithCommandException() throws Exception {
    // Use reflection to test private method
    Method runHeadlessMode = CalendarRunner.class.getDeclaredMethod(
        "runHeadlessMode", InterfaceCalendarController.class, 
        InterfaceCalendarView.class, String.class);
    runHeadlessMode.setAccessible(true);

    // Create a mock controller that throws exceptions
    InterfaceCalendarController mockController = new InterfaceCalendarController() {
      @Override
      public void executeCommand(String commandString, InterfaceCalendarView view) {
        if (commandString.contains("invalid")) {
          throw new RuntimeException("Test exception");
        }
      }
    };

    File commandFile = tempFolder.newFile("commands.txt");
    try (FileWriter writer = new FileWriter(commandFile)) {
      writer.write("invalid command\n");
      writer.write("exit\n");
    }

    InterfaceCalendarView view = new CalendarTextView();

    // Should not throw an exception - should handle the exception gracefully
    runHeadlessMode.invoke(null, mockController, view, commandFile.getAbsolutePath());
  }
}