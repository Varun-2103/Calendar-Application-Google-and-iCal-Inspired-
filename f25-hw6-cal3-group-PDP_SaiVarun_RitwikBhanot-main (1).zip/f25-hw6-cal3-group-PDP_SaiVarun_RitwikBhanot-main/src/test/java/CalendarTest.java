import static org.junit.Assert.assertTrue;

import org.junit.Test;

/**
 * A placeholder test class. You must definitely not use this.
 */
public class CalendarTest {
  @Test
  public void testAlwaysPass() {
    assertTrue(true);
  }
}
