package calendar.export;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import calendar.model.Event;
import calendar.model.InterfaceEvent;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * Comprehensive test suite for CsvCalendarExporter class.
 * Tests all functionality including CSV export, formatting, escaping, and edge cases.
 */
public class CsvCalendarExporterTest {

  private CsvCalendarExporter exporter;
  private String testFileName = "testexport.csv";

  /** Sets up test environment before each test. */
  @Before
  public void setUp() {
    exporter = new CsvCalendarExporter();
    cleanupTestFiles();
  }

  /** Cleans up test environment after each test. */
  @After
  public void tearDown() {
    cleanupTestFiles();
  }

  private void cleanupTestFiles() {
    try {
      Files.deleteIfExists(Paths.get(testFileName));
    } catch (IOException e) {
      // Ignore cleanup failures
    }
  }

  @Test
  public void testExportSingleEventExportsCorrectly() throws IOException {
    List<InterfaceEvent> events = Arrays.asList(
        new Event("Team Meeting",
            LocalDateTime.of(2023, 12, 15, 10, 0),
            LocalDateTime.of(2023, 12, 15, 11, 0))
    );

    String filePath = exporter.export(events, testFileName);

    assertNotNull(filePath);
    assertTrue(Files.exists(Paths.get(testFileName)));

    List<String> lines = readFileLines(testFileName);
    assertEquals(2, lines.size());
    assertTrue(lines.get(0).contains("Subject,Start Date,Start Time,End Date,End Time"));
    assertTrue(lines.get(1).contains("Team Meeting"));
  }

  @Test
  public void testExportMultipleEventsExportsCorrectly() throws IOException {
    List<InterfaceEvent> events = Arrays.asList(
        new Event("Meeting 1",
            LocalDateTime.of(2023, 12, 15, 10, 0),
            LocalDateTime.of(2023, 12, 15, 11, 0)),
        new Event("Meeting 2",
            LocalDateTime.of(2023, 12, 16, 14, 0),
            LocalDateTime.of(2023, 12, 16, 15, 0))
    );

    String filePath = exporter.export(events, testFileName);

    assertNotNull(filePath);
    assertTrue(Files.exists(Paths.get(testFileName)));

    List<String> lines = readFileLines(testFileName);
    assertEquals(3, lines.size());
    assertTrue(lines.get(1).contains("Meeting 1"));
    assertTrue(lines.get(2).contains("Meeting 2"));
  }

  @Test
  public void testExportEmptyEventListExportsHeaderOnly() throws IOException {
    List<InterfaceEvent> events = new ArrayList<>();

    String filePath = exporter.export(events, testFileName);

    assertNotNull(filePath);
    assertTrue(Files.exists(Paths.get(testFileName)));

    List<String> lines = readFileLines(testFileName);
    assertEquals(1, lines.size());
    assertTrue(lines.get(0).contains("Subject,Start Date,Start Time,End Date,End Time"));
  }

  @Test
  public void testExportAllDayEventExportsCorrectly() throws IOException {
    List<InterfaceEvent> events = Arrays.asList(
        new Event("All Day Event",
            LocalDateTime.of(2023, 12, 15, 8, 0),
            LocalDateTime.of(2023, 12, 15, 17, 0))
    );

    String filePath = exporter.export(events, testFileName);

    List<String> lines = readFileLines(testFileName);
    assertEquals(2, lines.size());
    String eventLine = lines.get(1);
    assertTrue(eventLine.contains("All Day Event"));
    assertTrue(eventLine.contains("True"));
    assertTrue(eventLine.contains("12/15/2023"));
  }

  @Test
  public void testExportRegularEventExportsCorrectly() throws IOException {
    List<InterfaceEvent> events = Arrays.asList(
        new Event("Regular Meeting",
            LocalDateTime.of(2023, 12, 15, 10, 30),
            LocalDateTime.of(2023, 12, 15, 11, 30))
    );

    String filePath = exporter.export(events, testFileName);

    List<String> lines = readFileLines(testFileName);
    assertEquals(2, lines.size());
    String eventLine = lines.get(1);
    assertTrue(eventLine.contains("Regular Meeting"));
    assertTrue(eventLine.contains("False"));
    assertTrue(eventLine.contains("10:30 am"));
    assertTrue(eventLine.contains("11:30 am"));
  }

  @Test
  public void testExportEventWithDescriptionExportsCorrectly() throws IOException {
    Event event = new Event("Meeting",
        LocalDateTime.of(2023, 12, 15, 10, 0),
        LocalDateTime.of(2023, 12, 15, 11, 0));
    event.setDescription("Weekly team sync");
    List<InterfaceEvent> events = Arrays.asList(event);

    String filePath = exporter.export(events, testFileName);

    List<String> lines = readFileLines(testFileName);
    String eventLine = lines.get(1);
    assertTrue(eventLine.contains("Weekly team sync"));
  }

  @Test
  public void testExportEventWithLocationExportsCorrectly() throws IOException {
    Event event = new Event("Meeting",
        LocalDateTime.of(2023, 12, 15, 10, 0),
        LocalDateTime.of(2023, 12, 15, 11, 0));
    event.setLocation("Conference Room A");
    List<InterfaceEvent> events = Arrays.asList(event);

    String filePath = exporter.export(events, testFileName);

    List<String> lines = readFileLines(testFileName);
    String eventLine = lines.get(1);
    assertTrue(eventLine.contains("Conference Room A"));
  }

  @Test
  public void testExportPrivateEventExportsCorrectly() throws IOException {
    Event event = new Event("Private Meeting",
        LocalDateTime.of(2023, 12, 15, 10, 0),
        LocalDateTime.of(2023, 12, 15, 11, 0));
    event.setStatus("private");
    List<InterfaceEvent> events = Arrays.asList(event);

    String filePath = exporter.export(events, testFileName);

    List<String> lines = readFileLines(testFileName);
    String eventLine = lines.get(1);
    assertTrue(eventLine.contains("True"));
  }

  @Test
  public void testExportPublicEventExportsCorrectly() throws IOException {
    Event event = new Event("Public Meeting",
        LocalDateTime.of(2023, 12, 15, 10, 0),
        LocalDateTime.of(2023, 12, 15, 11, 0));
    event.setStatus("public");
    List<InterfaceEvent> events = Arrays.asList(event);

    String filePath = exporter.export(events, testFileName);

    List<String> lines = readFileLines(testFileName);
    String eventLine = lines.get(1);
    assertTrue(eventLine.contains("False"));
  }

  @Test
  public void testExportEventWithSpecialCharactersEscapesCorrectly() throws IOException {
    Event event = new Event("Meeting, with \"quotes\"",
        LocalDateTime.of(2023, 12, 15, 10, 0),
        LocalDateTime.of(2023, 12, 15, 11, 0));
    event.setDescription("Description with, commas\nand newlines");
    List<InterfaceEvent> events = Arrays.asList(event);

    String filePath = exporter.export(events, testFileName);

    List<String> lines = readFileLines(testFileName);
    String eventLine = lines.get(1);
    assertTrue(eventLine.contains("\"Meeting, with \"\"quotes\"\"\""));
  }

  @Test
  public void testExportEventWithCommasInSubjectEscapesCorrectly() throws IOException {
    Event event = new Event("Meeting, Part 1",
        LocalDateTime.of(2023, 12, 15, 10, 0),
        LocalDateTime.of(2023, 12, 15, 11, 0));
    List<InterfaceEvent> events = Arrays.asList(event);

    String filePath = exporter.export(events, testFileName);

    List<String> lines = readFileLines(testFileName);
    String eventLine = lines.get(1);
    assertTrue(eventLine.contains("\"Meeting, Part 1\""));
  }

  @Test
  public void testExportEventWithQuotesInSubjectEscapesCorrectly() throws IOException {
    Event event = new Event("Meeting \"Important\"",
        LocalDateTime.of(2023, 12, 15, 10, 0),
        LocalDateTime.of(2023, 12, 15, 11, 0));
    List<InterfaceEvent> events = Arrays.asList(event);

    String filePath = exporter.export(events, testFileName);

    List<String> lines = readFileLines(testFileName);
    String eventLine = lines.get(1);
    assertTrue(eventLine.contains("\"Meeting \"\"Important\"\"\""));
  }

  @Test
  public void testExportEventWithNewlinesInDescriptionEscapesCorrectly() throws IOException {
    Event event = new Event("Meeting",
        LocalDateTime.of(2023, 12, 15, 10, 0),
        LocalDateTime.of(2023, 12, 15, 11, 0));
    event.setDescription("Line 1\nLine 2\r\nLine 3");
    List<InterfaceEvent> events = Arrays.asList(event);

    String filePath = exporter.export(events, testFileName);

    String fileContent = readFileContent(testFileName);
    assertTrue(fileContent.contains("\"Line 1\nLine 2\r\nLine 3\""));
  }

  @Test
  public void testExportEventWithNullFieldsHandlesCorrectly() throws IOException {
    Event event = new Event("Meeting",
        LocalDateTime.of(2023, 12, 15, 10, 0),
        LocalDateTime.of(2023, 12, 15, 11, 0));
    event.setDescription(null);
    event.setLocation(null);
    event.setStatus(null);
    List<InterfaceEvent> events = Arrays.asList(event);

    String filePath = exporter.export(events, testFileName);

    List<String> lines = readFileLines(testFileName);
    String eventLine = lines.get(1);
    assertTrue(eventLine.contains("False"));
  }

  @Test
  public void testExportEventWithEmptyFieldsHandlesCorrectly() throws IOException {
    Event event = new Event("Meeting",
        LocalDateTime.of(2023, 12, 15, 10, 0),
        LocalDateTime.of(2023, 12, 15, 11, 0));
    event.setDescription("");
    event.setLocation("");
    event.setStatus("");
    List<InterfaceEvent> events = Arrays.asList(event);

    String filePath = exporter.export(events, testFileName);

    List<String> lines = readFileLines(testFileName);
    String eventLine = lines.get(1);
    assertTrue(eventLine.contains("False"));
  }

  @Test
  public void testExportMultiDayEventHandlesCorrectly() throws IOException {
    List<InterfaceEvent> events = Arrays.asList(
        new Event("Multi Day Event",
            LocalDateTime.of(2023, 12, 15, 10, 0),
            LocalDateTime.of(2023, 12, 16, 15, 0))
    );

    String filePath = exporter.export(events, testFileName);

    List<String> lines = readFileLines(testFileName);
    String eventLine = lines.get(1);
    assertTrue(eventLine.contains("Multi Day Event"));
    assertTrue(eventLine.contains("12/15/2023"));
    assertTrue(eventLine.contains("12/16/2023"));
    assertTrue(eventLine.contains("False"));
  }

  @Test
  public void testExportEventWithVeryLongFieldsHandlesCorrectly() throws IOException {
    String longSubject = "This is a very long subject that contains many words "
        + "and should be handled correctly by the CSV exporter";
    String longDescription = "This is a very long description that contains a lot of detail "
        + "about the event and should be handled correctly without any issues "
        + "or truncation during the export process";
    Event event = new Event(longSubject,
        LocalDateTime.of(2023, 12, 15, 10, 0),
        LocalDateTime.of(2023, 12, 15, 11, 0));
    event.setDescription(longDescription);
    List<InterfaceEvent> events = Arrays.asList(event);

    String filePath = exporter.export(events, testFileName);

    List<String> lines = readFileLines(testFileName);
    String eventLine = lines.get(1);
    assertTrue(eventLine.contains(longSubject));
    assertTrue(eventLine.contains(longDescription));
  }

  @Test
  public void testExportReturnsAbsolutePath() throws IOException {
    List<InterfaceEvent> events = Arrays.asList(
        new Event("Test Event",
            LocalDateTime.of(2023, 12, 15, 10, 0),
            LocalDateTime.of(2023, 12, 15, 11, 0))
    );

    String filePath = exporter.export(events, testFileName);

    assertNotNull(filePath);
    assertTrue(filePath.contains(testFileName));
    File file = new File(filePath);
    assertTrue(file.isAbsolute());
    assertTrue(file.exists());
  }

  @Test
  public void testExportCsvHeaderFormatIsCorrect() throws IOException {
    List<InterfaceEvent> events = new ArrayList<>();

    String filePath = exporter.export(events, testFileName);

    List<String> lines = readFileLines(testFileName);
    String header = lines.get(0);
    assertEquals(
        "Subject,Start Date,Start Time,End Date,End Time,All Day Event,Description,Location,"
            + "Private",
        header);
  }

  @Test
  public void testExportDateFormatIsCorrect() throws IOException {
    List<InterfaceEvent> events = Arrays.asList(
        new Event("Test",
            LocalDateTime.of(2023, 12, 15, 10, 0),
            LocalDateTime.of(2023, 12, 15, 11, 0))
    );

    String filePath = exporter.export(events, testFileName);

    List<String> lines = readFileLines(testFileName);
    String eventLine = lines.get(1);
    assertTrue(eventLine.contains("12/15/2023"));
  }

  @Test
  public void testExportTimeFormatIsCorrect() throws IOException {
    List<InterfaceEvent> events = Arrays.asList(
        new Event("Test",
            LocalDateTime.of(2023, 12, 15, 14, 30),
            LocalDateTime.of(2023, 12, 15, 15, 45))
    );

    String filePath = exporter.export(events, testFileName);

    List<String> lines = readFileLines(testFileName);
    String eventLine = lines.get(1);
    assertTrue(eventLine.contains("2:30 pm"));
    assertTrue(eventLine.contains("3:45 pm"));
  }

  @Test
  public void testExportMorningTimeFormatIsCorrect() throws IOException {
    List<InterfaceEvent> events = Arrays.asList(
        new Event("Test",
            LocalDateTime.of(2023, 12, 15, 9, 15),
            LocalDateTime.of(2023, 12, 15, 10, 30))
    );

    String filePath = exporter.export(events, testFileName);

    List<String> lines = readFileLines(testFileName);
    String eventLine = lines.get(1);
    assertTrue(eventLine.contains("9:15 am"));
    assertTrue(eventLine.contains("10:30 am"));
  }

  @Test
  public void testExportEveningTimeFormatIsCorrect() throws IOException {
    List<InterfaceEvent> events = Arrays.asList(
        new Event("Test",
            LocalDateTime.of(2023, 12, 15, 20, 15),
            LocalDateTime.of(2023, 12, 15, 21, 30))
    );

    String filePath = exporter.export(events, testFileName);

    List<String> lines = readFileLines(testFileName);
    String eventLine = lines.get(1);
    assertTrue(eventLine.contains("8:15 pm"));
    assertTrue(eventLine.contains("9:30 pm"));
  }

  @Test
  public void testExportMidnightTimeFormatIsCorrect() throws IOException {
    List<InterfaceEvent> events = Arrays.asList(
        new Event("Test",
            LocalDateTime.of(2023, 12, 15, 0, 0),
            LocalDateTime.of(2023, 12, 15, 1, 0))
    );

    String filePath = exporter.export(events, testFileName);

    List<String> lines = readFileLines(testFileName);
    String eventLine = lines.get(1);
    assertTrue(eventLine.contains("12:00 am"));
    assertTrue(eventLine.contains("1:00 am"));
  }

  @Test
  public void testExportNoonTimeFormatIsCorrect() throws IOException {
    List<InterfaceEvent> events = Arrays.asList(
        new Event("Test",
            LocalDateTime.of(2023, 12, 15, 12, 0),
            LocalDateTime.of(2023, 12, 15, 13, 0))
    );

    String filePath = exporter.export(events, testFileName);

    List<String> lines = readFileLines(testFileName);
    String eventLine = lines.get(1);
    assertTrue(eventLine.contains("12:00 pm"));
    assertTrue(eventLine.contains("1:00 pm"));
  }

  @Test
  public void testExportCaseInsensitivePrivateStatusHandlesCorrectly() throws IOException {
    Event event1 = new Event("Private 1",
        LocalDateTime.of(2023, 12, 15, 10, 0),
        LocalDateTime.of(2023, 12, 15, 11, 0));
    event1.setStatus("private");

    Event event2 = new Event("Private 2",
        LocalDateTime.of(2023, 12, 15, 12, 0),
        LocalDateTime.of(2023, 12, 15, 13, 0));
    event2.setStatus("PRIVATE");

    Event event3 = new Event("Private 3",
        LocalDateTime.of(2023, 12, 15, 14, 0),
        LocalDateTime.of(2023, 12, 15, 15, 0));
    event3.setStatus("Private");

    List<InterfaceEvent> events = Arrays.asList(event1, event2, event3);

    String filePath = exporter.export(events, testFileName);

    List<String> lines = readFileLines(testFileName);
    for (int i = 1; i < lines.size(); i++) {
      String eventLine = lines.get(i);
      assertTrue(eventLine.contains("True"));
    }
  }

  @Test
  public void testExportEdgeCaseEventsHandlesCorrectly() throws IOException {
    Event event1 = new Event("Edge Case 1",
        LocalDateTime.of(2023, 1, 1, 0, 0),
        LocalDateTime.of(2023, 1, 1, 0, 1));

    Event event2 = new Event("Edge Case 2",
        LocalDateTime.of(2023, 12, 31, 23, 59),
        LocalDateTime.of(2024, 1, 1, 0, 0));

    List<InterfaceEvent> events = Arrays.asList(event1, event2);

    String filePath = exporter.export(events, testFileName);

    List<String> lines = readFileLines(testFileName);
    assertEquals(3, lines.size());
    assertTrue(lines.get(1).contains("Edge Case 1"));
    assertTrue(lines.get(2).contains("Edge Case 2"));
  }

  private List<String> readFileLines(String fileName) throws IOException {
    List<String> lines = new ArrayList<>();
    try (BufferedReader reader = new BufferedReader(new FileReader(fileName))) {
      String line;
      while ((line = reader.readLine()) != null) {
        lines.add(line);
      }
    }
    return lines;
  }

  private String readFileContent(String fileName) throws IOException {
    return new String(Files.readAllBytes(Paths.get(fileName)));
  }

  @Test
  public void testEscapeCsvNullValue() throws IOException {
    Event event = new Event("Meeting",
        LocalDateTime.of(2023, 12, 15, 10, 0),
        LocalDateTime.of(2023, 12, 15, 11, 0));
    event.setDescription(null);
    event.setLocation(null);
    List<InterfaceEvent> events = Arrays.asList(event);

    String filePath = exporter.export(events, testFileName);

    List<String> lines = readFileLines(testFileName);
    String eventLine = lines.get(1);
    assertTrue(eventLine.contains("Meeting"));
  }

  @Test
  public void testEscapeCsvEmptyValue() throws IOException {
    Event event = new Event("Meeting",
        LocalDateTime.of(2023, 12, 15, 10, 0),
        LocalDateTime.of(2023, 12, 15, 11, 0));
    event.setDescription("");
    List<InterfaceEvent> events = Arrays.asList(event);

    String filePath = exporter.export(events, testFileName);

    List<String> lines = readFileLines(testFileName);
    assertTrue(lines.size() > 1);
  }

  @Test
  public void testIsAllDayEventTrue() throws IOException {
    List<InterfaceEvent> events = Arrays.asList(
        new Event("All Day",
            LocalDateTime.of(2023, 12, 15, 8, 0),
            LocalDateTime.of(2023, 12, 15, 17, 0))
    );

    String filePath = exporter.export(events, testFileName);

    List<String> lines = readFileLines(testFileName);
    String eventLine = lines.get(1);
    assertTrue(eventLine.contains("True"));
  }

  @Test
  public void testIsAllDayEventFalseDifferentHour() throws IOException {
    List<InterfaceEvent> events = Arrays.asList(
        new Event("Not All Day",
            LocalDateTime.of(2023, 12, 15, 9, 0),
            LocalDateTime.of(2023, 12, 15, 17, 0))
    );

    String filePath = exporter.export(events, testFileName);

    List<String> lines = readFileLines(testFileName);
    String eventLine = lines.get(1);
    assertTrue(eventLine.contains("False"));
  }

  @Test
  public void testIsAllDayEventFalseDifferentMinute() throws IOException {
    List<InterfaceEvent> events = Arrays.asList(
        new Event("Not All Day",
            LocalDateTime.of(2023, 12, 15, 8, 30),
            LocalDateTime.of(2023, 12, 15, 17, 0))
    );

    String filePath = exporter.export(events, testFileName);

    List<String> lines = readFileLines(testFileName);
    String eventLine = lines.get(1);
    assertTrue(eventLine.contains("False"));
  }

  @Test
  public void testIsAllDayEventFalseDifferentEndHour() throws IOException {
    List<InterfaceEvent> events = Arrays.asList(
        new Event("Not All Day",
            LocalDateTime.of(2023, 12, 15, 8, 0),
            LocalDateTime.of(2023, 12, 15, 16, 0))
    );

    String filePath = exporter.export(events, testFileName);

    List<String> lines = readFileLines(testFileName);
    String eventLine = lines.get(1);
    assertTrue(eventLine.contains("False"));
  }

  @Test
  public void testIsAllDayEventFalseDifferentEndMinute() throws IOException {
    List<InterfaceEvent> events = Arrays.asList(
        new Event("Not All Day",
            LocalDateTime.of(2023, 12, 15, 8, 0),
            LocalDateTime.of(2023, 12, 15, 17, 30))
    );

    String filePath = exporter.export(events, testFileName);

    List<String> lines = readFileLines(testFileName);
    String eventLine = lines.get(1);
    assertTrue(eventLine.contains("False"));
  }

  @Test
  public void testIsAllDayEventFalseDifferentDate() throws IOException {
    List<InterfaceEvent> events = Arrays.asList(
        new Event("Multi Day",
            LocalDateTime.of(2023, 12, 15, 8, 0),
            LocalDateTime.of(2023, 12, 16, 17, 0))
    );

    String filePath = exporter.export(events, testFileName);

    List<String> lines = readFileLines(testFileName);
    String eventLine = lines.get(1);
    assertTrue(eventLine.contains("False"));
  }
}