package calendar.export;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import calendar.model.Event;
import calendar.model.InterfaceEvent;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * Comprehensive test suite for IcalExporter class.
 * Tests all functionality including iCal export, formatting, escaping, and RFC 5545 compliance.
 */
public class IcalExporterTest {

  private IcalExporter exporter;
  private String testFileName = "testexport.ics";

  /** Sets up test environment before each test. */
  @Before
  public void setUp() {
    exporter = new IcalExporter();
    cleanupTestFiles();
  }

  /** Cleans up test environment after each test. */
  @After
  public void tearDown() {
    cleanupTestFiles();
  }

  private void cleanupTestFiles() {
    try {
      Files.deleteIfExists(Paths.get(testFileName));
    } catch (IOException e) {
      // Ignore cleanup failures
    }
  }

  @Test
  public void testExportSingleEventExportsCorrectly() throws IOException {
    List<InterfaceEvent> events = Arrays.asList(
        new Event("Team Meeting",
            LocalDateTime.of(2023, 12, 15, 10, 0),
            LocalDateTime.of(2023, 12, 15, 11, 0))
    );

    String filePath = exporter.export(events, testFileName);

    assertNotNull(filePath);
    assertTrue(Files.exists(Paths.get(testFileName)));

    String content = readFileContent(testFileName);
    assertTrue(content.contains("BEGIN:VCALENDAR"));
    assertTrue(content.contains("VERSION:2.0"));
    assertTrue(content.contains("PRODID"));
    assertTrue(content.contains("CALSCALE:GREGORIAN"));
    assertTrue(content.contains("BEGIN:VEVENT"));
    assertTrue(content.contains("END:VEVENT"));
    assertTrue(content.contains("END:VCALENDAR"));
    assertTrue(content.contains("SUMMARY:Team Meeting"));
  }

  @Test
  public void testExportMultipleEventsExportsCorrectly() throws IOException {
    List<InterfaceEvent> events = Arrays.asList(
        new Event("Meeting 1",
            LocalDateTime.of(2023, 12, 15, 10, 0),
            LocalDateTime.of(2023, 12, 15, 11, 0)),
        new Event("Meeting 2",
            LocalDateTime.of(2023, 12, 16, 14, 0),
            LocalDateTime.of(2023, 12, 16, 15, 0))
    );

    String filePath = exporter.export(events, testFileName);

    String content = readFileContent(testFileName);
    int eventBeginCount = countOccurrences(content, "BEGIN:VEVENT");
    int eventEndCount = countOccurrences(content, "END:VEVENT");
    assertEquals(2, eventBeginCount);
    assertEquals(2, eventEndCount);
    assertTrue(content.contains("SUMMARY:Meeting 1"));
    assertTrue(content.contains("SUMMARY:Meeting 2"));
  }

  @Test
  public void testExportEmptyEventListExportsHeaderOnly() throws IOException {
    List<InterfaceEvent> events = new ArrayList<>();

    String filePath = exporter.export(events, testFileName);

    assertNotNull(filePath);
    assertTrue(Files.exists(Paths.get(testFileName)));

    String content = readFileContent(testFileName);
    assertTrue(content.contains("BEGIN:VCALENDAR"));
    assertTrue(content.contains("VERSION:2.0"));
    assertTrue(content.contains("PRODID"));
    assertTrue(content.contains("CALSCALE:GREGORIAN"));
    assertTrue(content.contains("END:VCALENDAR"));
    assertEquals(0, countOccurrences(content, "BEGIN:VEVENT"));
  }

  @Test
  public void testExportEventWithDescriptionExportsCorrectly() throws IOException {
    Event event = new Event("Meeting",
        LocalDateTime.of(2023, 12, 15, 10, 0),
        LocalDateTime.of(2023, 12, 15, 11, 0));
    event.setDescription("Weekly team sync");
    List<InterfaceEvent> events = Arrays.asList(event);

    String filePath = exporter.export(events, testFileName);

    String content = readFileContent(testFileName);
    assertTrue(content.contains("DESCRIPTION:Weekly team sync"));
  }

  @Test
  public void testExportEventWithLocationExportsCorrectly() throws IOException {
    Event event = new Event("Meeting",
        LocalDateTime.of(2023, 12, 15, 10, 0),
        LocalDateTime.of(2023, 12, 15, 11, 0));
    event.setLocation("Conference Room A");
    List<InterfaceEvent> events = Arrays.asList(event);

    String filePath = exporter.export(events, testFileName);

    String content = readFileContent(testFileName);
    assertTrue(content.contains("LOCATION:Conference Room A"));
  }

  @Test
  public void testExportEventWithValidStatusExportsCorrectly() throws IOException {
    Event event1 = new Event("Confirmed Meeting",
        LocalDateTime.of(2023, 12, 15, 10, 0),
        LocalDateTime.of(2023, 12, 15, 11, 0));
    event1.setStatus("confirmed");

    Event event2 = new Event("Tentative Meeting",
        LocalDateTime.of(2023, 12, 16, 10, 0),
        LocalDateTime.of(2023, 12, 16, 11, 0));
    event2.setStatus("tentative");

    Event event3 = new Event("Cancelled Meeting",
        LocalDateTime.of(2023, 12, 17, 10, 0),
        LocalDateTime.of(2023, 12, 17, 11, 0));
    event3.setStatus("cancelled");

    List<InterfaceEvent> events = Arrays.asList(event1, event2, event3);

    String filePath = exporter.export(events, testFileName);

    String content = readFileContent(testFileName);
    assertTrue(content.contains("STATUS:CONFIRMED"));
    assertTrue(content.contains("STATUS:TENTATIVE"));
    assertTrue(content.contains("STATUS:CANCELLED"));
  }

  @Test
  public void testExportEventWithInvalidStatusIgnoresStatus() throws IOException {
    Event event = new Event("Meeting",
        LocalDateTime.of(2023, 12, 15, 10, 0),
        LocalDateTime.of(2023, 12, 15, 11, 0));
    event.setStatus("invalid");
    List<InterfaceEvent> events = Arrays.asList(event);

    String filePath = exporter.export(events, testFileName);

    String content = readFileContent(testFileName);
    assertFalse(content.contains("STATUS:"));
  }

  @Test
  public void testExportEventWithSpecialCharactersEscapesCorrectly() throws IOException {
    Event event = new Event("Meeting, with; semicolons\\and backslashes",
        LocalDateTime.of(2023, 12, 15, 10, 0),
        LocalDateTime.of(2023, 12, 15, 11, 0));
    event.setDescription("Description with, commas; semicolons\\and backslashes");
    event.setLocation("Location, with; special\\chars");
    List<InterfaceEvent> events = Arrays.asList(event);

    String filePath = exporter.export(events, testFileName);

    String content = readFileContent(testFileName);
    assertTrue(content.contains("SUMMARY:Meeting\\, with\\; semicolons\\\\and backslashes"));
    assertTrue(content.contains(
        "DESCRIPTION:Description with\\, commas\\; semicolons\\\\and backslashes"));
    assertTrue(content.contains("LOCATION:Location\\, with\\; special\\\\chars"));
  }

  @Test
  public void testExportEventWithNewlinesEscapesCorrectly() throws IOException {
    Event event = new Event("Meeting",
        LocalDateTime.of(2023, 12, 15, 10, 0),
        LocalDateTime.of(2023, 12, 15, 11, 0));
    event.setDescription("Line 1\nLine 2\r\nLine 3");
    List<InterfaceEvent> events = Arrays.asList(event);

    String filePath = exporter.export(events, testFileName);

    String content = readFileContent(testFileName);
    assertTrue(content.contains("DESCRIPTION:Line 1\\nLine 2\\nLine 3"));
  }

  @Test
  public void testExportEventWithQuotesEscapesCorrectly() throws IOException {
    Event event = new Event("Meeting \"Important\"",
        LocalDateTime.of(2023, 12, 15, 10, 0),
        LocalDateTime.of(2023, 12, 15, 11, 0));
    event.setDescription("Description with \"quotes\"");
    List<InterfaceEvent> events = Arrays.asList(event);

    String filePath = exporter.export(events, testFileName);

    String content = readFileContent(testFileName);
    assertTrue(content.contains("SUMMARY:Meeting \\\"Important\\\""));
    assertTrue(content.contains("DESCRIPTION:Description with \\\"quotes\\\""));
  }

  @Test
  public void testExportEventWithNullFieldsHandlesCorrectly() throws IOException {
    Event event = new Event("Meeting",
        LocalDateTime.of(2023, 12, 15, 10, 0),
        LocalDateTime.of(2023, 12, 15, 11, 0));
    event.setDescription(null);
    event.setLocation(null);
    event.setStatus(null);
    List<InterfaceEvent> events = Arrays.asList(event);

    String filePath = exporter.export(events, testFileName);

    String content = readFileContent(testFileName);
    assertFalse(content.contains("DESCRIPTION:"));
    assertFalse(content.contains("LOCATION:"));
    assertFalse(content.contains("STATUS:"));
  }

  @Test
  public void testExportEventWithEmptyFieldsHandlesCorrectly() throws IOException {
    Event event = new Event("Meeting",
        LocalDateTime.of(2023, 12, 15, 10, 0),
        LocalDateTime.of(2023, 12, 15, 11, 0));
    event.setDescription("");
    event.setLocation("");
    event.setStatus("");
    List<InterfaceEvent> events = Arrays.asList(event);

    String filePath = exporter.export(events, testFileName);

    String content = readFileContent(testFileName);
    assertFalse(content.contains("DESCRIPTION:"));
    assertFalse(content.contains("LOCATION:"));
    assertFalse(content.contains("STATUS:"));
  }

  @Test
  public void testExportDateTimeFormatIsCorrect() throws IOException {
    List<InterfaceEvent> events = Arrays.asList(
        new Event("Test Event",
            LocalDateTime.of(2023, 12, 15, 10, 30, 45),
            LocalDateTime.of(2023, 12, 15, 11, 45, 30))
    );

    String filePath = exporter.export(events, testFileName);

    String content = readFileContent(testFileName);
    assertTrue(content.contains("DTSTART:20231215T103045"));
    assertTrue(content.contains("DTEND:20231215T114530"));
  }

  @Test
  public void testExportUidGenerationIsUnique() throws IOException {
    Event event1 = new Event("Meeting 1",
        LocalDateTime.of(2023, 12, 15, 10, 0),
        LocalDateTime.of(2023, 12, 15, 11, 0));
    Event event2 = new Event("Meeting 2",
        LocalDateTime.of(2023, 12, 15, 12, 0),
        LocalDateTime.of(2023, 12, 15, 13, 0));
    List<InterfaceEvent> events = Arrays.asList(event1, event2);

    String filePath = exporter.export(events, testFileName);

    String content = readFileContent(testFileName);
    int uid1 = event1.getSubject().hashCode();
    int uid2 = event2.getSubject().hashCode();
    assertTrue(content.contains("UID:" + uid1 + "@calendarapp"));
    assertTrue(content.contains("UID:" + uid2 + "@calendarapp"));
  }

  @Test
  public void testExportDstampGenerationIsPresent() throws IOException {
    List<InterfaceEvent> events = Arrays.asList(
        new Event("Test Event",
            LocalDateTime.of(2023, 12, 15, 10, 0),
            LocalDateTime.of(2023, 12, 15, 11, 0))
    );

    String filePath = exporter.export(events, testFileName);

    String content = readFileContent(testFileName);
    assertTrue(content.contains("DTSTAMP:"));
  }

  @Test
  public void testExportLineEndingsIsCorrect() throws IOException {
    List<InterfaceEvent> events = Arrays.asList(
        new Event("Test Event",
            LocalDateTime.of(2023, 12, 15, 10, 0),
            LocalDateTime.of(2023, 12, 15, 11, 0))
    );

    String filePath = exporter.export(events, testFileName);

    String content = readFileContent(testFileName);
    assertTrue(content.contains("\r\n"));
    assertFalse(content.contains("\n\r"));
  }

  @Test
  public void testExportEventWithVeryLongFieldsHandlesCorrectly() throws IOException {
    String longSubject = "This is a very long subject that contains many words "
        + "and should be handled correctly by the iCal exporter";
    String longDescription = "This is a very long description that contains a lot of detail "
        + "about the event and should be handled correctly without any issues "
        + "or truncation during the export process";
    Event event = new Event(longSubject,
        LocalDateTime.of(2023, 12, 15, 10, 0),
        LocalDateTime.of(2023, 12, 15, 11, 0));
    event.setDescription(longDescription);
    List<InterfaceEvent> events = Arrays.asList(event);

    String filePath = exporter.export(events, testFileName);

    String content = readFileContent(testFileName);
    assertTrue(content.contains("SUMMARY:" + longSubject));
    assertTrue(content.contains("DESCRIPTION:" + longDescription));
  }

  @Test
  public void testExportReturnsAbsolutePath() throws IOException {
    List<InterfaceEvent> events = Arrays.asList(
        new Event("Test Event",
            LocalDateTime.of(2023, 12, 15, 10, 0),
            LocalDateTime.of(2023, 12, 15, 11, 0))
    );

    String filePath = exporter.export(events, testFileName);

    assertNotNull(filePath);
    assertTrue(filePath.contains(testFileName));
    File file = new File(filePath);
    assertTrue(file.isAbsolute());
    assertTrue(file.exists());
  }

  @Test
  public void testExportCalendarHeaderFormatIsCorrect() throws IOException {
    List<InterfaceEvent> events = new ArrayList<>();

    String filePath = exporter.export(events, testFileName);

    String content = readFileContent(testFileName);
    String[] lines = content.split("\r\n");
    assertEquals("BEGIN:VCALENDAR", lines[0]);
    assertEquals("VERSION:2.0", lines[1]);
    assertTrue(lines[2].startsWith("PRODID:-//Calendar App//Calendar App Events//EN"));
    assertEquals("CALSCALE:GREGORIAN", lines[3]);
    assertEquals("END:VCALENDAR", lines[4]);
  }

  @Test
  public void testExportEventStructureIsCorrect() throws IOException {
    List<InterfaceEvent> events = Arrays.asList(
        new Event("Test Event",
            LocalDateTime.of(2023, 12, 15, 10, 0),
            LocalDateTime.of(2023, 12, 15, 11, 0))
    );

    String filePath = exporter.export(events, testFileName);

    String content = readFileContent(testFileName);
    String[] lines = content.split("\r\n");

    boolean foundEventBegin = false;
    boolean foundEventEnd = false;
    boolean foundUid = false;
    boolean foundDtstamp = false;
    boolean foundDtstart = false;
    boolean foundDtend = false;
    boolean foundSummary = false;

    for (String line : lines) {
      if (line.equals("BEGIN:VEVENT")) {
        foundEventBegin = true;
      }
      if (line.equals("END:VEVENT")) {
        foundEventEnd = true;
      }
      if (line.startsWith("UID:")) {
        foundUid = true;
      }
      if (line.startsWith("DTSTAMP:")) {
        foundDtstamp = true;
      }
      if (line.startsWith("DTSTART:")) {
        foundDtstart = true;
      }
      if (line.startsWith("DTEND:")) {
        foundDtend = true;
      }
      if (line.startsWith("SUMMARY:")) {
        foundSummary = true;
      }
    }

    assertTrue(foundEventBegin);
    assertTrue(foundEventEnd);
    assertTrue(foundUid);
    assertTrue(foundDtstamp);
    assertTrue(foundDtstart);
    assertTrue(foundDtend);
    assertTrue(foundSummary);
  }

  @Test
  public void testExportEdgeCaseEventsHandlesCorrectly() throws IOException {
    Event event1 = new Event("Edge Case 1",
        LocalDateTime.of(2023, 1, 1, 0, 0),
        LocalDateTime.of(2023, 1, 1, 0, 1));

    Event event2 = new Event("Edge Case 2",
        LocalDateTime.of(2023, 12, 31, 23, 59),
        LocalDateTime.of(2024, 1, 1, 0, 0));

    List<InterfaceEvent> events = Arrays.asList(event1, event2);

    String filePath = exporter.export(events, testFileName);

    String content = readFileContent(testFileName);
    assertTrue(content.contains("DTSTART:20230101T000000"));
    assertTrue(content.contains("DTEND:20230101T000100"));
    assertTrue(content.contains("DTSTART:20231231T235900"));
    assertTrue(content.contains("DTEND:20240101T000000"));
  }

  @Test
  public void testExportCaseInsensitiveStatusHandlesCorrectly() throws IOException {
    Event event1 = new Event("Test 1",
        LocalDateTime.of(2023, 12, 15, 10, 0),
        LocalDateTime.of(2023, 12, 15, 11, 0));
    event1.setStatus("CONFIRMED");

    Event event2 = new Event("Test 2",
        LocalDateTime.of(2023, 12, 15, 12, 0),
        LocalDateTime.of(2023, 12, 15, 13, 0));
    event2.setStatus("TENTATIVE");

    Event event3 = new Event("Test 3",
        LocalDateTime.of(2023, 12, 15, 14, 0),
        LocalDateTime.of(2023, 12, 15, 15, 0));
    event3.setStatus("CANCELLED");

    List<InterfaceEvent> events = Arrays.asList(event1, event2, event3);

    String filePath = exporter.export(events, testFileName);

    String content = readFileContent(testFileName);
    assertTrue(content.contains("STATUS:CONFIRMED"));
    assertTrue(content.contains("STATUS:TENTATIVE"));
    assertTrue(content.contains("STATUS:CANCELLED"));
  }

  @Test
  public void testExportMultiDayEventHandlesCorrectly() throws IOException {
    List<InterfaceEvent> events = Arrays.asList(
        new Event("Multi Day Event",
            LocalDateTime.of(2023, 12, 15, 10, 0),
            LocalDateTime.of(2023, 12, 16, 15, 0))
    );

    String filePath = exporter.export(events, testFileName);

    String content = readFileContent(testFileName);
    assertTrue(content.contains("DTSTART:20231215T100000"));
    assertTrue(content.contains("DTEND:20231216T150000"));
  }

  @Test
  public void testExportEventWithSecondsPreservesSeconds() throws IOException {
    List<InterfaceEvent> events = Arrays.asList(
        new Event("Test Event",
            LocalDateTime.of(2023, 12, 15, 10, 30, 45),
            LocalDateTime.of(2023, 12, 15, 11, 45, 30))
    );

    String filePath = exporter.export(events, testFileName);

    String content = readFileContent(testFileName);
    assertTrue(content.contains("DTSTART:20231215T103045"));
    assertTrue(content.contains("DTEND:20231215T114530"));
  }

  private String readFileContent(String fileName) throws IOException {
    return new String(Files.readAllBytes(Paths.get(fileName)));
  }

  private int countOccurrences(String content, String substring) {
    int count = 0;
    int index = 0;
    while ((index = content.indexOf(substring, index)) != -1) {
      count++;
      index += substring.length();
    }
    return count;
  }
}