package calendar.model;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import java.time.LocalDateTime;
import org.junit.Test;

/**
 * Comprehensive test suite for the Event class.
 * Tests all functionality including creation, properties, equality, and edge cases.
 */
public class EventTest {

  private static final String SUBJECT = "Team Meeting";
  private static final LocalDateTime START = LocalDateTime.of(2023, 12, 15, 10, 0);
  private static final LocalDateTime END = LocalDateTime.of(2023, 12, 15, 11, 0);
  private static final String LOCATION = "Conference Room A";
  private static final String DESCRIPTION = "Weekly team sync";
  private static final String STATUS = "public";

  @Test
  public void testEventCreationValidParametersCreatesEvent() {
    Event event = new Event(SUBJECT, START, END);

    assertNotNull(event);
    assertEquals(SUBJECT, event.getSubject());
    assertEquals(START, event.getStart());
    assertEquals(END, event.getEnd());
    assertNull(event.getLocation());
    assertNull(event.getDescription());
    assertNull(event.getStatus());
  }

  @Test(expected = IllegalArgumentException.class)
  public void testEventCreationNullSubjectThrowsException() {
    new Event(null, START, END);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testEventCreationEmptySubjectThrowsException() {
    new Event("", START, END);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testEventCreationNullStartThrowsException() {
    new Event(SUBJECT, null, END);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testEventCreationNullEndThrowsException() {
    new Event(SUBJECT, START, null);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testEventCreationEndBeforeStartThrowsException() {
    LocalDateTime invalidEnd = START.minusHours(1);
    new Event(SUBJECT, START, invalidEnd);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testEventCreationEndEqualsStartThrowsException() {
    new Event(SUBJECT, START, START);
  }

  @Test
  public void testSetSubjectValidSubjectUpdatesSubject() {
    Event event = new Event(SUBJECT, START, END);
    String newSubject = "Updated Meeting";

    event.setSubject(newSubject);

    assertEquals(newSubject, event.getSubject());
  }

  @Test
  public void testSetStartValidStartUpdatesStart() {
    Event event = new Event(SUBJECT, START, END);
    LocalDateTime newStart = START.plusHours(1);

    event.setStart(newStart);

    assertEquals(newStart, event.getStart());
  }

  @Test
  public void testSetEndValidEndUpdatesEnd() {
    Event event = new Event(SUBJECT, START, END);
    LocalDateTime newEnd = END.plusHours(1);

    event.setEnd(newEnd);

    assertEquals(newEnd, event.getEnd());
  }

  @Test
  public void testSetLocationValidLocationUpdatesLocation() {
    Event event = new Event(SUBJECT, START, END);

    event.setLocation(LOCATION);

    assertEquals(LOCATION, event.getLocation());
  }

  @Test
  public void testSetDescriptionValidDescriptionUpdatesDescription() {
    Event event = new Event(SUBJECT, START, END);

    event.setDescription(DESCRIPTION);

    assertEquals(DESCRIPTION, event.getDescription());
  }

  @Test
  public void testSetStatusValidStatusUpdatesStatus() {
    Event event = new Event(SUBJECT, START, END);

    event.setStatus(STATUS);

    assertEquals(STATUS, event.getStatus());
  }

  @Test
  public void testEqualsSameEventReturnsTrue() {
    Event event1 = new Event(SUBJECT, START, END);
    Event event2 = new Event(SUBJECT, START, END);

    assertTrue(event1.equals(event2));
    assertTrue(event2.equals(event1));
  }

  @Test
  public void testEqualsDifferentSubjectReturnsFalse() {
    Event event1 = new Event(SUBJECT, START, END);
    Event event2 = new Event("Different Subject", START, END);

    assertFalse(event1.equals(event2));
  }

  @Test
  public void testEqualsDifferentStartReturnsFalse() {
    Event event1 = new Event(SUBJECT, START, END);
    Event event2 = new Event(SUBJECT, START.plusHours(1), END.plusHours(1));

    assertFalse(event1.equals(event2));
  }

  @Test
  public void testEqualsDifferentEndReturnsFalse() {
    Event event1 = new Event(SUBJECT, START, END);
    Event event2 = new Event(SUBJECT, START, END.plusHours(1));

    assertFalse(event1.equals(event2));
  }

  @Test
  public void testEqualsSameInstanceReturnsTrue() {
    Event event = new Event(SUBJECT, START, END);

    assertTrue(event.equals(event));
  }

  @Test
  public void testEqualsNullObjectReturnsFalse() {
    Event event = new Event(SUBJECT, START, END);

    assertFalse(event.equals(null));
  }

  @Test
  public void testEqualsDifferentClassReturnsFalse() {
    Event event = new Event(SUBJECT, START, END);
    String notAnEvent = "not an event";

    assertFalse(event.equals(notAnEvent));
  }

  @Test
  public void testEqualsInterfaceEventReturnsTrue() {
    Event event1 = new Event(SUBJECT, START, END);
    InterfaceEvent event2 = new Event(SUBJECT, START, END);

    assertTrue(event1.equals(event2));
  }

  @Test
  public void testHashCodeEqualEventsHaveSameHashCode() {
    Event event1 = new Event(SUBJECT, START, END);
    Event event2 = new Event(SUBJECT, START, END);

    assertEquals(event1.hashCode(), event2.hashCode());
  }

  @Test
  public void testHashCodeDifferentEventsHaveDifferentHashCodes() {
    Event event1 = new Event(SUBJECT, START, END);
    Event event2 = new Event("Different Subject", START, END);

    assertFalse(event1.hashCode() == event2.hashCode());
  }

  @Test
  public void testToStringReturnsExpectedFormat() {
    Event event = new Event(SUBJECT, START, END);
    String expected = SUBJECT + " from " + START + " to " + END;

    assertEquals(expected, event.toString());
  }

  @Test
  public void testUpdateStartTimeValidNewStartUpdatesStartAndMaintainsDuration() {
    Event event = new Event(SUBJECT, START, END);
    LocalDateTime newStart = START.plusHours(2);
    long expectedDuration = java.time.Duration.between(START, END).toMinutes();
    LocalDateTime expectedEnd = newStart.plusMinutes(expectedDuration);

    event.updateStartTime(newStart);

    assertEquals(newStart, event.getStart());
    assertEquals(expectedEnd, event.getEnd());
  }

  @Test
  public void testWithUpdatesAllParametersNullReturnsSameEvent() {
    Event originalEvent = new Event(SUBJECT, START, END);

    Event updatedEvent = originalEvent.withUpdates(null, null, null);

    assertEquals(originalEvent.getSubject(), updatedEvent.getSubject());
    assertEquals(originalEvent.getStart(), updatedEvent.getStart());
    assertEquals(originalEvent.getEnd(), updatedEvent.getEnd());
  }

  @Test
  public void testWithUpdatesNewSubjectReturnsEventWithNewSubject() {
    Event originalEvent = new Event(SUBJECT, START, END);
    String newSubject = "Updated Meeting";

    Event updatedEvent = originalEvent.withUpdates(newSubject, null, null);

    assertEquals(newSubject, updatedEvent.getSubject());
    assertEquals(originalEvent.getStart(), updatedEvent.getStart());
    assertEquals(originalEvent.getEnd(), updatedEvent.getEnd());
  }

  @Test
  public void testWithUpdatesNewStartReturnsEventWithNewStart() {
    Event originalEvent = new Event(SUBJECT, START, END);
    LocalDateTime newStart = START.plusMinutes(30);

    Event updatedEvent = originalEvent.withUpdates(null, newStart, null);

    assertEquals(originalEvent.getSubject(), updatedEvent.getSubject());
    assertEquals(newStart, updatedEvent.getStart());
    assertEquals(originalEvent.getEnd(), updatedEvent.getEnd());
  }

  @Test
  public void testWithUpdatesNewEndReturnsEventWithNewEnd() {
    Event originalEvent = new Event(SUBJECT, START, END);
    LocalDateTime newEnd = END.plusHours(1);

    Event updatedEvent = originalEvent.withUpdates(null, null, newEnd);

    assertEquals(originalEvent.getSubject(), updatedEvent.getSubject());
    assertEquals(originalEvent.getStart(), updatedEvent.getStart());
    assertEquals(newEnd, updatedEvent.getEnd());
  }

  @Test
  public void testWithUpdatesAllParametersNewReturnsEventWithAllUpdates() {
    Event originalEvent = new Event(SUBJECT, START, END);
    String newSubject = "Updated Meeting";
    LocalDateTime newStart = START.plusHours(1);
    LocalDateTime newEnd = END.plusHours(2);

    Event updatedEvent = originalEvent.withUpdates(newSubject, newStart, newEnd);

    assertEquals(newSubject, updatedEvent.getSubject());
    assertEquals(newStart, updatedEvent.getStart());
    assertEquals(newEnd, updatedEvent.getEnd());
  }

  @Test
  public void testEventCreationWithoutValidationSkipsValidation() {
    Event event = new Event(SUBJECT, START, END, false);

    assertNotNull(event);
    assertEquals(SUBJECT, event.getSubject());
    assertEquals(START, event.getStart());
    assertEquals(END, event.getEnd());
  }

  @Test
  public void testEventCreationWithoutValidationAllowsInvalidParameters() {
    Event event = new Event(null, null, null, false);

    assertNotNull(event);
    assertNull(event.getSubject());
    assertNull(event.getStart());
    assertNull(event.getEnd());
  }

  @Test
  public void testMultiplePropertyUpdatesAllPropertiesUpdated() {
    Event event = new Event(SUBJECT, START, END);

    event.setLocation(LOCATION);
    event.setDescription(DESCRIPTION);
    event.setStatus(STATUS);

    assertEquals(LOCATION, event.getLocation());
    assertEquals(DESCRIPTION, event.getDescription());
    assertEquals(STATUS, event.getStatus());
  }

  @Test
  public void testEventCreationLongDurationHandlesCorrectly() {
    LocalDateTime longStart = LocalDateTime.of(2023, 1, 1, 9, 0);
    LocalDateTime longEnd = LocalDateTime.of(2023, 1, 1, 17, 0);

    Event event = new Event(SUBJECT, longStart, longEnd);

    assertEquals(longStart, event.getStart());
    assertEquals(longEnd, event.getEnd());
  }

  @Test
  public void testEventCreationMultiDayHandlesCorrectly() {
    LocalDateTime multiDayStart = LocalDateTime.of(2023, 12, 15, 10, 0);
    LocalDateTime multiDayEnd = LocalDateTime.of(2023, 12, 16, 15, 0);

    Event event = new Event(SUBJECT, multiDayStart, multiDayEnd);

    assertEquals(multiDayStart, event.getStart());
    assertEquals(multiDayEnd, event.getEnd());
  }
}