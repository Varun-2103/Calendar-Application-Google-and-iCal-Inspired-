package calendar.model;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.time.ZoneId;
import java.util.List;
import java.util.Set;
import org.junit.Test;

/**
 * Comprehensive test suite for the CalendarManager class.
 * Tests all functionality including calendar creation, management, active calendar handling,
 * and edge cases.
 */
public class CalendarManagerTest {

  private static final String CALENDAR = "Work Calendar";
  private static final String CALENDAR_2 = "Personal Calendar";
  private static final ZoneId UTC = ZoneId.of("UTC");
  private static final ZoneId EST = ZoneId.of("America/New_York");
  private static final ZoneId PST = ZoneId.of("America/Los_Angeles");

  @Test
  public void testCalendarManagerCreationCreatesEmptyManager() {
    CalendarManager manager = new CalendarManager();

    assertNotNull(manager);
    assertFalse(manager.hasCalendars());
    assertFalse(manager.hasActiveCalendar());
    assertTrue(manager.getAllCalendarNames().isEmpty());
    assertTrue(manager.getAllCalendars().isEmpty());
  }

  @Test
  public void testCreateCalendarValidParametersCreatesCalendar() {
    CalendarManager manager = new CalendarManager();

    manager.createCalendar(CALENDAR, UTC);

    assertTrue(manager.calendarExists(CALENDAR));
    assertTrue(manager.hasCalendars());
    assertEquals(1, manager.getAllCalendarNames().size());
    assertTrue(manager.getAllCalendarNames().contains(CALENDAR));
    assertEquals(1, manager.getAllCalendars().size());
    assertEquals(UTC, manager.getCalendarTimezone(CALENDAR));
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateCalendarNullNameThrowsException() {
    CalendarManager manager = new CalendarManager();

    manager.createCalendar(null, UTC);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateCalendarEmptyNameThrowsException() {
    CalendarManager manager = new CalendarManager();

    manager.createCalendar("   ", UTC);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateCalendarNullTimezoneThrowsException() {
    CalendarManager manager = new CalendarManager();

    manager.createCalendar(CALENDAR, null);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateCalendarDuplicateNameThrowsException() {
    CalendarManager manager = new CalendarManager();

    manager.createCalendar(CALENDAR, UTC);
    manager.createCalendar(CALENDAR, EST);
  }

  @Test
  public void testCreateCalendarMultipleCalendarsCreatesAllCalendars() {
    CalendarManager manager = new CalendarManager();

    manager.createCalendar(CALENDAR, UTC);
    manager.createCalendar(CALENDAR_2, EST);

    assertEquals(2, manager.getAllCalendarNames().size());
    assertTrue(manager.getAllCalendarNames().contains(CALENDAR));
    assertTrue(manager.getAllCalendarNames().contains(CALENDAR_2));
    assertEquals(2, manager.getAllCalendars().size());
    assertEquals(UTC, manager.getCalendarTimezone(CALENDAR));
    assertEquals(EST, manager.getCalendarTimezone(CALENDAR_2));
  }

  @Test
  public void testEditCalendarNameValidNewNameUpdatesName() {
    CalendarManager manager = new CalendarManager();
    String newName = "Updated Calendar";

    manager.createCalendar(CALENDAR, UTC);
    manager.editCalendar(CALENDAR, "name", newName);

    assertFalse(manager.calendarExists(CALENDAR));
    assertTrue(manager.calendarExists(newName));
    assertTrue(manager.getAllCalendarNames().contains(newName));
    assertEquals(UTC, manager.getCalendarTimezone(newName));
  }

  @Test(expected = IllegalArgumentException.class)
  public void testEditCalendarNameEmptyNewNameThrowsException() {
    CalendarManager manager = new CalendarManager();

    manager.createCalendar(CALENDAR, UTC);
    manager.editCalendar(CALENDAR, "name", "   ");
  }

  @Test(expected = IllegalArgumentException.class)
  public void testEditCalendarNameDuplicateNameThrowsException() {
    CalendarManager manager = new CalendarManager();

    manager.createCalendar(CALENDAR, UTC);
    manager.createCalendar(CALENDAR_2, EST);
    manager.editCalendar(CALENDAR, "name", CALENDAR_2);
  }

  @Test
  public void testEditCalendarNameSameNameKeepsName() {
    CalendarManager manager = new CalendarManager();

    manager.createCalendar(CALENDAR, UTC);
    manager.editCalendar(CALENDAR, "name", CALENDAR);

    assertTrue(manager.calendarExists(CALENDAR));
    assertEquals(1, manager.getAllCalendarNames().size());
  }

  @Test
  public void testEditCalendarTimezoneValidTimezoneUpdatesTimezone() {
    CalendarManager manager = new CalendarManager();

    manager.createCalendar(CALENDAR, UTC);
    manager.editCalendar(CALENDAR, "timezone", EST.toString());

    assertEquals(EST, manager.getCalendarTimezone(CALENDAR));
  }

  @Test(expected = IllegalArgumentException.class)
  public void testEditCalendarTimezoneInvalidTimezoneThrowsException() {
    CalendarManager manager = new CalendarManager();

    manager.createCalendar(CALENDAR, UTC);
    manager.editCalendar(CALENDAR, "timezone", "Invalid/Timezone");
  }

  @Test(expected = IllegalArgumentException.class)
  public void testEditCalendarNonExistentCalendarThrowsException() {
    CalendarManager manager = new CalendarManager();

    manager.editCalendar(CALENDAR, "name", "New Name");
  }

  @Test(expected = IllegalArgumentException.class)
  public void testEditCalendarNullPropertyThrowsException() {
    CalendarManager manager = new CalendarManager();

    manager.createCalendar(CALENDAR, UTC);
    manager.editCalendar(CALENDAR, null, "value");
  }

  @Test(expected = IllegalArgumentException.class)
  public void testEditCalendarEmptyPropertyThrowsException() {
    CalendarManager manager = new CalendarManager();

    manager.createCalendar(CALENDAR, UTC);
    manager.editCalendar(CALENDAR, "   ", "value");
  }

  @Test(expected = IllegalArgumentException.class)
  public void testEditCalendarNullValueThrowsException() {
    CalendarManager manager = new CalendarManager();

    manager.createCalendar(CALENDAR, UTC);
    manager.editCalendar(CALENDAR, "name", null);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testEditCalendarEmptyValueThrowsException() {
    CalendarManager manager = new CalendarManager();

    manager.createCalendar(CALENDAR, UTC);
    manager.editCalendar(CALENDAR, "name", "   ");
  }

  @Test(expected = IllegalArgumentException.class)
  public void testEditCalendarInvalidPropertyThrowsException() {
    CalendarManager manager = new CalendarManager();

    manager.createCalendar(CALENDAR, UTC);
    manager.editCalendar(CALENDAR, "invalid", "value");
  }

  @Test
  public void testUseCalendarValidCalendarSetsActiveCalendar() {
    CalendarManager manager = new CalendarManager();

    manager.createCalendar(CALENDAR, UTC);
    manager.useCalendar(CALENDAR);

    assertTrue(manager.hasActiveCalendar());
    assertEquals(CALENDAR, manager.getActiveCalendarName());
    assertEquals(UTC, manager.getActiveCalendarTimezone());
    assertNotNull(manager.getActiveCalendar());
  }

  @Test(expected = IllegalArgumentException.class)
  public void testUseCalendarNonExistentCalendarThrowsException() {
    CalendarManager manager = new CalendarManager();

    manager.useCalendar(CALENDAR);
  }

  @Test
  public void testUseCalendarMultipleSwitchesSwitchesCorrectly() {
    CalendarManager manager = new CalendarManager();

    manager.createCalendar(CALENDAR, UTC);
    manager.createCalendar(CALENDAR_2, EST);

    manager.useCalendar(CALENDAR);
    assertEquals(CALENDAR, manager.getActiveCalendarName());

    manager.useCalendar(CALENDAR_2);
    assertEquals(CALENDAR_2, manager.getActiveCalendarName());
  }

  @Test(expected = IllegalStateException.class)
  public void testGetActiveCalendarNameNoActiveCalendarThrowsException() {
    CalendarManager manager = new CalendarManager();

    manager.getActiveCalendarName();
  }

  @Test(expected = IllegalStateException.class)
  public void testGetActiveCalendarTimezoneNoActiveCalendarThrowsException() {
    CalendarManager manager = new CalendarManager();

    manager.getActiveCalendarTimezone();
  }

  @Test(expected = IllegalStateException.class)
  public void testGetActiveCalendarNoActiveCalendarThrowsException() {
    CalendarManager manager = new CalendarManager();

    manager.getActiveCalendar();
  }

  @Test
  public void testGetCalendarExistingCalendarReturnsCalendar() {
    CalendarManager manager = new CalendarManager();

    manager.createCalendar(CALENDAR, UTC);

    InterfaceCalendar calendar = manager.getCalendar(CALENDAR);
    assertNotNull(calendar);
  }

  @Test
  public void testGetCalendarNonExistentCalendarReturnsNull() {
    CalendarManager manager = new CalendarManager();

    InterfaceCalendar calendar = manager.getCalendar(CALENDAR);
    assertNull(calendar);
  }

  @Test
  public void testGetCalendarTimezoneExistingCalendarReturnsTimezone() {
    CalendarManager manager = new CalendarManager();

    manager.createCalendar(CALENDAR, UTC);

    ZoneId timezone = manager.getCalendarTimezone(CALENDAR);
    assertEquals(UTC, timezone);
  }

  @Test
  public void testGetCalendarTimezoneNonExistentCalendarReturnsNull() {
    CalendarManager manager = new CalendarManager();

    ZoneId timezone = manager.getCalendarTimezone(CALENDAR);
    assertNull(timezone);
  }

  @Test
  public void testGetAllCalendarNamesWithCalendarsReturnsAllNames() {
    CalendarManager manager = new CalendarManager();

    manager.createCalendar(CALENDAR, UTC);
    manager.createCalendar(CALENDAR_2, EST);

    Set<String> names = manager.getAllCalendarNames();
    assertEquals(2, names.size());
    assertTrue(names.contains(CALENDAR));
    assertTrue(names.contains(CALENDAR_2));
  }

  @Test
  public void testGetAllCalendarNamesEmptyManagerReturnsEmptySet() {
    CalendarManager manager = new CalendarManager();

    Set<String> names = manager.getAllCalendarNames();
    assertTrue(names.isEmpty());
  }

  @Test
  public void testGetAllCalendarsWithCalendarsReturnsAllCalendars() {
    CalendarManager manager = new CalendarManager();

    manager.createCalendar(CALENDAR, UTC);
    manager.createCalendar(CALENDAR_2, EST);

    List<InterfaceCalendar> calendars = manager.getAllCalendars();
    assertEquals(2, calendars.size());
  }

  @Test
  public void testGetAllCalendarsEmptyManagerReturnsEmptyList() {
    CalendarManager manager = new CalendarManager();

    List<InterfaceCalendar> calendars = manager.getAllCalendars();
    assertTrue(calendars.isEmpty());
  }

  @Test
  public void testCalendarExistsExistingCalendarReturnsTrue() {
    CalendarManager manager = new CalendarManager();

    manager.createCalendar(CALENDAR, UTC);

    assertTrue(manager.calendarExists(CALENDAR));
  }

  @Test
  public void testCalendarExistsNonExistentCalendarReturnsFalse() {
    CalendarManager manager = new CalendarManager();

    assertFalse(manager.calendarExists(CALENDAR));
  }

  @Test
  public void testHasCalendarsWithCalendarsReturnsTrue() {
    CalendarManager manager = new CalendarManager();

    manager.createCalendar(CALENDAR, UTC);

    assertTrue(manager.hasCalendars());
  }

  @Test
  public void testHasCalendarsEmptyManagerReturnsFalse() {
    CalendarManager manager = new CalendarManager();

    assertFalse(manager.hasCalendars());
  }

  @Test
  public void testHasActiveCalendarWithActiveCalendarReturnsTrue() {
    CalendarManager manager = new CalendarManager();

    manager.createCalendar(CALENDAR, UTC);
    manager.useCalendar(CALENDAR);

    assertTrue(manager.hasActiveCalendar());
  }

  @Test
  public void testHasActiveCalendarNoActiveCalendarReturnsFalse() {
    CalendarManager manager = new CalendarManager();

    assertFalse(manager.hasActiveCalendar());
  }

  @Test
  public void testEditCalendarNameActiveCalendarUpdatesActiveCalendarName() {
    CalendarManager manager = new CalendarManager();
    String newName = "Updated Calendar";

    manager.createCalendar(CALENDAR, UTC);
    manager.useCalendar(CALENDAR);
    manager.editCalendar(CALENDAR, "name", newName);

    assertEquals(newName, manager.getActiveCalendarName());
    assertTrue(manager.hasActiveCalendar());
  }

  @Test
  public void testCaseInsensitivePropertyEditWorksCorrectly() {
    CalendarManager manager = new CalendarManager();

    manager.createCalendar(CALENDAR, UTC);
    manager.editCalendar(CALENDAR, "NAME", "New Name");

    assertFalse(manager.calendarExists(CALENDAR));
    assertTrue(manager.calendarExists("New Name"));
  }

  @Test
  public void testMultipleCalendarOperationsMaintainsConsistency() {
    CalendarManager manager = new CalendarManager();

    manager.createCalendar(CALENDAR, UTC);
    manager.createCalendar(CALENDAR_2, EST);
    manager.useCalendar(CALENDAR);
    manager.editCalendar(CALENDAR, "timezone", PST.toString());
    manager.useCalendar(CALENDAR_2);

    assertEquals(CALENDAR_2, manager.getActiveCalendarName());
    assertEquals(EST, manager.getActiveCalendarTimezone());
    assertEquals(PST, manager.getCalendarTimezone(CALENDAR));
    assertEquals(EST, manager.getCalendarTimezone(CALENDAR_2));
    assertTrue(manager.calendarExists(CALENDAR));
    assertTrue(manager.calendarExists(CALENDAR_2));
    assertEquals(2, manager.getAllCalendarNames().size());
    assertEquals(2, manager.getAllCalendars().size());
  }

  @Test
  public void testLargeNumberOfCalendarsHandlesCorrectly() {
    CalendarManager manager = new CalendarManager();
    int calendarCount = 100;

    for (int i = 0; i < calendarCount; i++) {
      manager.createCalendar("Calendar " + i, UTC);
    }

    assertEquals(calendarCount, manager.getAllCalendarNames().size());
    assertEquals(calendarCount, manager.getAllCalendars().size());
    assertTrue(manager.hasCalendars());
    assertFalse(manager.hasActiveCalendar());

    manager.useCalendar("Calendar 50");
    assertTrue(manager.hasActiveCalendar());
    assertEquals("Calendar 50", manager.getActiveCalendarName());
  }

  @Test
  public void testEdgeCaseCalendarNameWithSpecialCharactersHandlesCorrectly() {
    CalendarManager manager = new CalendarManager();
    String specialName = "Calendar with spaces & symbols!";

    manager.createCalendar(specialName, UTC);

    assertTrue(manager.calendarExists(specialName));
    assertTrue(manager.getAllCalendarNames().contains(specialName));
  }

  @Test
  public void testEdgeCaseCalendarNameWithUnicodeHandlesCorrectly() {
    CalendarManager manager = new CalendarManager();
    String unicodeName = "📅 日历 Calendrier";

    manager.createCalendar(unicodeName, UTC);

    assertTrue(manager.calendarExists(unicodeName));
    assertTrue(manager.getAllCalendarNames().contains(unicodeName));
  }

  @Test
  public void testGetAllCalendarNamesReturnsCopyNotReference() {
    CalendarManager manager = new CalendarManager();

    manager.createCalendar(CALENDAR, UTC);

    Set<String> names = manager.getAllCalendarNames();
    names.clear();

    assertEquals(1, manager.getAllCalendarNames().size());
  }

  @Test
  public void testGetAllCalendarsReturnsCopyNotReference() {
    CalendarManager manager = new CalendarManager();

    manager.createCalendar(CALENDAR, UTC);

    List<InterfaceCalendar> calendars = manager.getAllCalendars();
    calendars.clear();

    assertEquals(1, manager.getAllCalendars().size());
  }
}