package calendar.model;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.List;
import java.util.Set;
import org.junit.Test;

/**
 * Comprehensive test suite for the Calendar class.
 * Tests all functionality including event creation, series, editing, querying, and edge cases.
 */
public class CalendarTest {

  private static final String SUBJECT = "Team Meeting";
  private static final LocalDateTime START = LocalDateTime.of(2023, 12, 15, 10, 0);
  private static final LocalDateTime END = LocalDateTime.of(2023, 12, 15, 11, 0);
  private static final LocalDate DATE = LocalDate.of(2023, 12, 15);
  private static final String WEEKDAYS = "MWF";
  private static final ZoneId UTC = ZoneId.of("UTC");
  private static final ZoneId EST = ZoneId.of("America/New_York");

  @Test
  public void testCalendarCreationDefaultConstructorCreatesCalendarWithUtcTimezone() {
    Calendar calendar = new Calendar();

    assertNotNull(calendar);
    assertEquals(UTC, calendar.getTimezone());
    assertTrue(calendar.getAllEvents().isEmpty());
  }

  @Test
  public void testCalendarCreationWithTimezoneCreatesCalendarWithSpecifiedTimezone() {
    Calendar calendar = new Calendar(EST);

    assertNotNull(calendar);
    assertEquals(EST, calendar.getTimezone());
    assertTrue(calendar.getAllEvents().isEmpty());
  }

  @Test
  public void testCalendarCreationNullTimezoneCreatesCalendarWithUtcTimezone() {
    Calendar calendar = new Calendar(null);

    assertNotNull(calendar);
    assertEquals(UTC, calendar.getTimezone());
  }

  @Test
  public void testCreateEventValidParametersCreatesEvent() {
    Calendar calendar = new Calendar();

    calendar.createEvent(SUBJECT, START, END);

    List<InterfaceEvent> events = calendar.getAllEvents();
    assertEquals(1, events.size());
    InterfaceEvent event = events.get(0);
    assertEquals(SUBJECT, event.getSubject());
    assertEquals(START, event.getStart());
    assertEquals(END, event.getEnd());
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateEventDuplicateEventThrowsException() {
    Calendar calendar = new Calendar();

    calendar.createEvent(SUBJECT, START, END);
    calendar.createEvent(SUBJECT, START, END);
  }

  @Test
  public void testCreateAllDayEventValidDateCreatesEvent() {
    Calendar calendar = new Calendar();

    calendar.createAllDayEvent(SUBJECT, DATE);

    List<InterfaceEvent> events = calendar.getAllEvents();
    assertEquals(1, events.size());
    InterfaceEvent event = events.get(0);
    assertEquals(SUBJECT, event.getSubject());
    assertEquals(DATE.atTime(8, 0), event.getStart());
    assertEquals(DATE.atTime(17, 0), event.getEnd());
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateAllDayEventNullDateThrowsException() {
    Calendar calendar = new Calendar();

    calendar.createAllDayEvent(SUBJECT, null);
  }

  @Test
  public void testCreateEventSeriesValidParametersCreatesSeries() {
    Calendar calendar = new Calendar();

    calendar.createEventSeries(SUBJECT, START, END, WEEKDAYS, 3);

    List<InterfaceEvent> events = calendar.getAllEvents();
    assertEquals(3, events.size());
    for (InterfaceEvent event : events) {
      assertEquals(SUBJECT, event.getSubject());
      assertEquals(START.toLocalTime(), event.getStart().toLocalTime());
      assertEquals(END.toLocalTime(), event.getEnd().toLocalTime());
      DayOfWeek dayOfWeek = event.getStart().getDayOfWeek();
      assertTrue(dayOfWeek == DayOfWeek.MONDAY || dayOfWeek == DayOfWeek.WEDNESDAY
          || dayOfWeek == DayOfWeek.FRIDAY);
    }
  }

  @Test
  public void testCreateEventSeriesUntilValidParametersCreatesSeriesUntilDate() {
    Calendar calendar = new Calendar();
    LocalDate until = DATE.plusWeeks(2);

    calendar.createEventSeriesUntil(SUBJECT, START, END, WEEKDAYS, until);

    List<InterfaceEvent> events = calendar.getAllEvents();
    assertTrue(events.size() > 0);
    for (InterfaceEvent event : events) {
      assertTrue(!event.getStart().toLocalDate().isAfter(until));
    }
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateEventSeriesDuplicateEventInSeriesThrowsException() {
    Calendar calendar = new Calendar();

    calendar.createEvent(SUBJECT, START, END);
    calendar.createEventSeries(SUBJECT, START, END, WEEKDAYS, 1);
  }

  @Test
  public void testEditEventValidPropertyUpdatesEvent() {
    Calendar calendar = new Calendar();
    calendar.createEvent(SUBJECT, START, END);

    calendar.editEvent(SUBJECT, START, "location", "Conference Room");

    List<InterfaceEvent> events = calendar.getAllEvents();
    assertEquals(1, events.size());
    assertEquals("Conference Room", events.get(0).getLocation());
  }

  @Test(expected = IllegalArgumentException.class)
  public void testEditEventNonExistentEventThrowsException() {
    Calendar calendar = new Calendar();

    calendar.editEvent(SUBJECT, START, "location", "Conference Room");
  }

  @Test(expected = IllegalArgumentException.class)
  public void testEditEventDuplicateAfterEditThrowsException() {
    Calendar calendar = new Calendar();
    LocalDateTime otherStart = START.plusMinutes(30);
    LocalDateTime otherEnd = END.plusMinutes(30);
    calendar.createEvent(SUBJECT, START, END);
    calendar.createEvent("Other Event", otherStart, otherEnd);

    calendar.editEvent("Other Event", otherStart, "subject", SUBJECT);
    calendar.editEvent(SUBJECT, otherStart, "start", "2023-12-15T10:00");
  }

  @Test
  public void testEditEventsFromSingleEventEditsEvent() {
    Calendar calendar = new Calendar();
    calendar.createEvent(SUBJECT, START, END);

    calendar.editEventsFrom(SUBJECT, START, "location", "Conference Room");

    List<InterfaceEvent> events = calendar.getAllEvents();
    assertEquals(1, events.size());
    assertEquals("Conference Room", events.get(0).getLocation());
  }

  @Test
  public void testEditEventsFromSeriesEditsFromSpecifiedDate() {
    Calendar calendar = new Calendar();
    LocalDate startDate = DATE;
    LocalDate endDate = DATE.plusWeeks(2);
    calendar.createEventSeriesUntil(SUBJECT, START, END, WEEKDAYS, endDate);

    LocalDateTime editFrom = DATE.plusDays(7).atTime(10, 0);
    calendar.editEventsFrom(SUBJECT, editFrom, "location", "Conference Room");

    List<InterfaceEvent> events = calendar.getAllEvents();
    for (InterfaceEvent event : events) {
      if (!event.getStart().isBefore(editFrom)) {
        assertEquals("Conference Room", event.getLocation());
      } else {
        assertNull(event.getLocation());
      }
    }
  }

  @Test
  public void testEditSeriesSeriesEditsAllEventsInSeries() {
    Calendar calendar = new Calendar();
    calendar.createEventSeries(SUBJECT, START, END, WEEKDAYS, 3);

    calendar.editSeries(SUBJECT, START, "location", "Conference Room");

    List<InterfaceEvent> events = calendar.getAllEvents();
    for (InterfaceEvent event : events) {
      assertEquals("Conference Room", event.getLocation());
    }
  }

  @Test
  public void testGetEventsOnValidDateReturnsEventsOnDate() {
    Calendar calendar = new Calendar();
    LocalDate date1 = DATE;
    LocalDate date2 = DATE.plusDays(1);
    LocalDateTime start1 = date1.atTime(10, 0);
    LocalDateTime end1 = date1.atTime(11, 0);
    LocalDateTime start2 = date2.atTime(10, 0);
    LocalDateTime end2 = date2.atTime(11, 0);

    calendar.createEvent("Event 1", start1, end1);
    calendar.createEvent("Event 2", start2, end2);
    calendar.createEvent("Event 3", date1.atTime(14, 0), date1.atTime(15, 0));

    List<InterfaceEvent> eventsOnDate1 = calendar.getEventsOn(date1);
    assertEquals(2, eventsOnDate1.size());
    eventsOnDate1.forEach(event -> assertEquals(date1, event.getStart().toLocalDate()));
  }

  @Test(expected = IllegalArgumentException.class)
  public void testGetEventsOnNullDateThrowsException() {
    Calendar calendar = new Calendar();

    calendar.getEventsOn(null);
  }

  @Test
  public void testGetEventsBetweenValidRangeReturnsEventsInRange() {
    Calendar calendar = new Calendar();
    LocalDateTime rangeStart = DATE.atTime(9, 0);
    LocalDateTime rangeEnd = DATE.atTime(16, 0);
    LocalDateTime event1Start = DATE.atTime(10, 0);
    LocalDateTime event1End = DATE.atTime(11, 0);
    LocalDateTime event2Start = DATE.atTime(15, 0);
    LocalDateTime event2End = DATE.atTime(16, 0);
    LocalDateTime event3Start = DATE.atTime(17, 0);
    LocalDateTime event3End = DATE.atTime(18, 0);

    calendar.createEvent("Event 1", event1Start, event1End);
    calendar.createEvent("Event 2", event2Start, event2End);
    calendar.createEvent("Event 3", event3Start, event3End);

    List<InterfaceEvent> eventsInRange = calendar.getEventsBetween(rangeStart, rangeEnd);
    assertEquals(2, eventsInRange.size());
  }

  @Test(expected = IllegalArgumentException.class)
  public void testGetEventsBetweenNullStartThrowsException() {
    Calendar calendar = new Calendar();

    calendar.getEventsBetween(null, END);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testGetEventsBetweenNullEndThrowsException() {
    Calendar calendar = new Calendar();

    calendar.getEventsBetween(START, null);
  }

  @Test
  public void testIsBusyBusyTimeReturnsTrue() {
    Calendar calendar = new Calendar();
    LocalDateTime busyTime = START.plusMinutes(30);

    calendar.createEvent(SUBJECT, START, END);

    assertTrue(calendar.isBusy(busyTime));
  }

  @Test
  public void testIsBusyNotBusyTimeReturnsFalse() {
    Calendar calendar = new Calendar();
    LocalDateTime freeTime = START.plusHours(2);

    calendar.createEvent(SUBJECT, START, END);

    assertFalse(calendar.isBusy(freeTime));
  }

  @Test(expected = IllegalArgumentException.class)
  public void testIsBusyNullDateTimeThrowsException() {
    Calendar calendar = new Calendar();

    calendar.isBusy(null);
  }

  @Test
  public void testGetAllEventsWithEventsReturnsAllEvents() {
    Calendar calendar = new Calendar();

    calendar.createEvent("Event 1", START, END);
    calendar.createEvent("Event 2", START.plusHours(2), END.plusHours(2));

    List<InterfaceEvent> allEvents = calendar.getAllEvents();
    assertEquals(2, allEvents.size());
  }

  @Test
  public void testGetAllEventsEmptyCalendarReturnsEmptyList() {
    Calendar calendar = new Calendar();

    List<InterfaceEvent> allEvents = calendar.getAllEvents();

    assertTrue(allEvents.isEmpty());
  }

  @Test
  public void testSetTimezoneValidTimezoneUpdatesTimezone() {
    Calendar calendar = new Calendar();

    calendar.setTimezone(EST);

    assertEquals(EST, calendar.getTimezone());
  }

  @Test
  public void testSetTimezoneNullTimezoneSetsToUtc() {
    Calendar calendar = new Calendar();

    calendar.setTimezone(null);

    assertEquals(UTC, calendar.getTimezone());
  }

  @Test
  public void testMultiDayEventGetEventsOnReturnsEventForAllDays() {
    Calendar calendar = new Calendar();
    LocalDate startDate = DATE;
    LocalDate endDate = DATE.plusDays(2);
    LocalDateTime multiDayStart = startDate.atTime(10, 0);
    LocalDateTime multiDayEnd = endDate.atTime(15, 0);

    calendar.createEvent(SUBJECT, multiDayStart, multiDayEnd);

    for (LocalDate date = startDate; !date.isAfter(endDate); date = date.plusDays(1)) {
      List<InterfaceEvent> eventsOnDate = calendar.getEventsOn(date);
      assertEquals(1, eventsOnDate.size());
    }
  }

  @Test
  public void testEventSeriesWithWeekendDaysCreatesEventsOnlyOnSpecifiedWeekdays() {
    Calendar calendar = new Calendar();
    String weekdays = "SU";
    LocalDateTime weekendStart = DATE.with(DayOfWeek.SATURDAY).atTime(10, 0);
    LocalDateTime weekendEnd = DATE.with(DayOfWeek.SATURDAY).atTime(11, 0);

    calendar.createEventSeries(SUBJECT, weekendStart, weekendEnd, weekdays, 4);

    List<InterfaceEvent> events = calendar.getAllEvents();
    assertEquals(4, events.size());
    for (InterfaceEvent event : events) {
      DayOfWeek dayOfWeek = event.getStart().getDayOfWeek();
      assertTrue(dayOfWeek == DayOfWeek.SATURDAY || dayOfWeek == DayOfWeek.SUNDAY);
    }
  }

  @Test
  public void testEditEventSubjectUpdatesSubjectAndMaintainsUniqueness() {
    Calendar calendar = new Calendar();
    String newSubject = "Updated Meeting";

    calendar.createEvent(SUBJECT, START, END);
    calendar.editEvent(SUBJECT, START, "subject", newSubject);

    List<InterfaceEvent> events = calendar.getAllEvents();
    assertEquals(1, events.size());
    assertEquals(newSubject, events.get(0).getSubject());
  }

  @Test
  public void testEditEventStartUpdatesStartAndMaintainsDuration() {
    Calendar calendar = new Calendar();
    LocalDateTime newStart = START.plusHours(1);

    calendar.createEvent(SUBJECT, START, END);
    calendar.editEvent(SUBJECT, START, "start", newStart.toString());

    List<InterfaceEvent> events = calendar.getAllEvents();
    assertEquals(1, events.size());
    assertEquals(newStart, events.get(0).getStart());
    long expectedDuration = java.time.Duration.between(START, END).toMinutes();
    LocalDateTime expectedEnd = newStart.plusMinutes(expectedDuration);
    assertEquals(expectedEnd, events.get(0).getEnd());
  }

  @Test
  public void testEditEventEndUpdatesEnd() {
    Calendar calendar = new Calendar();
    LocalDateTime newEnd = END.plusHours(1);

    calendar.createEvent(SUBJECT, START, END);
    calendar.editEvent(SUBJECT, START, "end", newEnd.toString());

    List<InterfaceEvent> events = calendar.getAllEvents();
    assertEquals(1, events.size());
    assertEquals(newEnd, events.get(0).getEnd());
  }

  @Test
  public void testLargeNumberOfEventsPerformanceTest() {
    Calendar calendar = new Calendar();
    int eventCount = 1000;

    for (int i = 0; i < eventCount; i++) {
      LocalDateTime eventStart = START.plusDays(i);
      LocalDateTime eventEnd = END.plusDays(i);
      calendar.createEvent(SUBJECT + " " + i, eventStart, eventEnd);
    }

    List<InterfaceEvent> allEvents = calendar.getAllEvents();
    assertEquals(eventCount, allEvents.size());
  }

  @Test
  public void testEdgeCaseEventAtMidnightHandlesCorrectly() {
    Calendar calendar = new Calendar();
    LocalDateTime midnightStart = DATE.atStartOfDay();
    LocalDateTime midnightEnd = DATE.atTime(0, 30);

    calendar.createEvent(SUBJECT, midnightStart, midnightEnd);

    List<InterfaceEvent> events = calendar.getAllEvents();
    assertEquals(1, events.size());
    assertEquals(midnightStart, events.get(0).getStart());
    assertEquals(midnightEnd, events.get(0).getEnd());
  }

  @Test(expected = IllegalArgumentException.class)
  public void testEditEventNullStartThrowsException() {
    Calendar calendar = new Calendar();
    calendar.createEvent(SUBJECT, START, END);

    calendar.editEvent(SUBJECT, null, "location", "Conference Room");
  }

  @Test(expected = IllegalArgumentException.class)
  public void testEditEventsFromNullStartThrowsException() {
    Calendar calendar = new Calendar();
    calendar.createEvent(SUBJECT, START, END);

    calendar.editEventsFrom(SUBJECT, null, "location", "Conference Room");
  }

  @Test(expected = IllegalArgumentException.class)
  public void testEditSeriesNullStartThrowsException() {
    Calendar calendar = new Calendar();
    calendar.createEvent(SUBJECT, START, END);

    calendar.editSeries(SUBJECT, null, "location", "Conference Room");
  }

  @Test(expected = IllegalArgumentException.class)
  public void testEditEventNonExistentSubjectThrowsException() {
    Calendar calendar = new Calendar();
    calendar.createEvent(SUBJECT, START, END);

    calendar.editEvent("NonExistent", START, "location", "Conference Room");
  }

  @Test(expected = IllegalArgumentException.class)
  public void testEditEventsFromNonExistentEventThrowsException() {
    Calendar calendar = new Calendar();
    calendar.createEvent(SUBJECT, START, END);

    calendar.editEventsFrom("NonExistent", START, "location", "Conference Room");
  }

  @Test(expected = IllegalArgumentException.class)
  public void testEditSeriesNonExistentEventThrowsException() {
    Calendar calendar = new Calendar();
    calendar.createEvent(SUBJECT, START, END);

    calendar.editSeries("NonExistent", START, "location", "Conference Room");
  }

  @Test
  public void testEditEventStartPropertyOnSeriesRemovesFromSeries() {
    Calendar calendar = new Calendar();
    calendar.createEventSeries(SUBJECT, START, END, WEEKDAYS, 3);

    LocalDateTime firstEventStart = calendar.getAllEvents().get(0).getStart();
    calendar.editEvent(SUBJECT, firstEventStart, "start", "2023-12-15T09:00");

    List<InterfaceEvent> events = calendar.getAllEvents();
    assertEquals(3, events.size());
  }

  @Test
  public void testEditEventsFromNonStartPropertyOnSeriesUpdatesSeries() {
    Calendar calendar = new Calendar();
    calendar.createEventSeries(SUBJECT, START, END, WEEKDAYS, 3);

    calendar.editEventsFrom(SUBJECT, START, "location", "Conference Room");

    List<InterfaceEvent> events = calendar.getAllEvents();
    for (InterfaceEvent event : events) {
      assertEquals("Conference Room", event.getLocation());
    }
  }

  @Test
  public void testEditSeriesOnSeriesUpdatesAllEvents() {
    Calendar calendar = new Calendar();
    calendar.createEventSeries(SUBJECT, START, END, WEEKDAYS, 3);

    calendar.editSeries(SUBJECT, START, "location", "Conference Room");

    List<InterfaceEvent> events = calendar.getAllEvents();
    for (InterfaceEvent event : events) {
      assertEquals("Conference Room", event.getLocation());
    }
  }

  @Test
  public void testEditSeriesOnSingleEventEditsEvent() {
    Calendar calendar = new Calendar();
    calendar.createEvent(SUBJECT, START, END);

    calendar.editSeries(SUBJECT, START, "location", "Conference Room");

    List<InterfaceEvent> events = calendar.getAllEvents();
    assertEquals(1, events.size());
    assertEquals("Conference Room", events.get(0).getLocation());
  }

  @Test
  public void testUpdateIdentityPropertySubject() {
    Calendar calendar = new Calendar();
    calendar.createEvent(SUBJECT, START, END);

    calendar.editEvent(SUBJECT, START, "subject", "New Subject");

    List<InterfaceEvent> events = calendar.getAllEvents();
    assertEquals(1, events.size());
    assertEquals("New Subject", events.get(0).getSubject());
  }

  @Test
  public void testUpdateIdentityPropertyStart() {
    Calendar calendar = new Calendar();
    calendar.createEvent(SUBJECT, START, END);

    calendar.editEvent(SUBJECT, START, "start", "2023-12-15T09:00");

    List<InterfaceEvent> events = calendar.getAllEvents();
    assertEquals(1, events.size());
    assertEquals(LocalDateTime.of(2023, 12, 15, 9, 0), events.get(0).getStart());
  }

  @Test
  public void testUpdateIdentityPropertyEnd() {
    Calendar calendar = new Calendar();
    calendar.createEvent(SUBJECT, START, END);

    calendar.editEvent(SUBJECT, START, "end", "2023-12-15T12:00");

    List<InterfaceEvent> events = calendar.getAllEvents();
    assertEquals(1, events.size());
    assertEquals(LocalDateTime.of(2023, 12, 15, 12, 0), events.get(0).getEnd());
  }

  @Test(expected = IllegalArgumentException.class)
  public void testUpdateIdentityPropertyUnknownThrowsException() {
    Calendar calendar = new Calendar();
    calendar.createEvent(SUBJECT, START, END);

    calendar.editEvent(SUBJECT, START, "unknown", "value");
  }

  @Test
  public void testUpdateSimplePropertyLocation() {
    Calendar calendar = new Calendar();
    calendar.createEvent(SUBJECT, START, END);

    calendar.editEvent(SUBJECT, START, "location", "Conference Room");

    List<InterfaceEvent> events = calendar.getAllEvents();
    assertEquals(1, events.size());
    assertEquals("Conference Room", events.get(0).getLocation());
  }

  @Test
  public void testUpdateSimplePropertyDescription() {
    Calendar calendar = new Calendar();
    calendar.createEvent(SUBJECT, START, END);

    calendar.editEvent(SUBJECT, START, "description", "Team discussion");

    List<InterfaceEvent> events = calendar.getAllEvents();
    assertEquals(1, events.size());
    assertEquals("Team discussion", events.get(0).getDescription());
  }

  @Test
  public void testUpdateSimplePropertyStatus() {
    Calendar calendar = new Calendar();
    calendar.createEvent(SUBJECT, START, END);

    calendar.editEvent(SUBJECT, START, "status", "private");

    List<InterfaceEvent> events = calendar.getAllEvents();
    assertEquals(1, events.size());
    assertEquals("private", events.get(0).getStatus());
  }

  @Test(expected = IllegalArgumentException.class)
  public void testUpdateSimplePropertyUnknownThrowsException() {
    Calendar calendar = new Calendar();
    calendar.createEvent(SUBJECT, START, END);

    calendar.editEvent(SUBJECT, START, "unknown", "value");
  }

  @Test
  public void testUpdateEventStartTimeWithEventInstance() {
    Calendar calendar = new Calendar();
    calendar.createEvent(SUBJECT, START, END);

    LocalDateTime newStart = START.plusHours(1);
    calendar.editEvent(SUBJECT, START, "start", newStart.toString());

    List<InterfaceEvent> events = calendar.getAllEvents();
    assertEquals(1, events.size());
    assertEquals(newStart, events.get(0).getStart());
    long expectedDuration = java.time.Duration.between(START, END).toMinutes();
    LocalDateTime expectedEnd = newStart.plusMinutes(expectedDuration);
    assertEquals(expectedEnd, events.get(0).getEnd());
  }

  @Test
  public void testEditEventsFromWithStartPropertySplitsSeries() {
    Calendar calendar = new Calendar();
    calendar.createEventSeries("Daily Standup",
        LocalDateTime.of(2025, 12, 1, 9, 0),
        LocalDateTime.of(2025, 12, 1, 9, 15),
        "MTWRF", 10);

    calendar.editEventsFrom("Daily Standup",
        LocalDateTime.of(2025, 12, 3, 9, 0),
        "start", "2025-12-03T10:00");

    List<InterfaceEvent> events = calendar.getAllEvents();
    InterfaceEvent editedEvent = events.stream()
        .filter(e -> e.getStart().toLocalDate().equals(LocalDate.of(2025, 12, 3)))
        .findFirst()
        .orElse(null);

    assertNotNull(editedEvent);
    assertEquals(10, editedEvent.getStart().getHour());
  }

  @Test
  public void testEditEventsFromWithLocationPropertyOnSeries() {
    Calendar calendar = new Calendar();
    calendar.createEventSeries("Team Meeting",
        LocalDateTime.of(2025, 12, 1, 14, 0),
        LocalDateTime.of(2025, 12, 1, 15, 0),
        "MW", 5);

    calendar.editEventsFrom("Team Meeting",
        LocalDateTime.of(2025, 12, 3, 14, 0),
        "location", "Room 101");

    List<InterfaceEvent> events = calendar.getAllEvents();
    for (InterfaceEvent event : events) {
      if (!event.getStart().isBefore(LocalDateTime.of(2025, 12, 3, 14, 0))) {
        assertEquals("Room 101", event.getLocation());
      }
    }
  }

  @Test
  public void testEditSeriesOfNonSeriesEventEditsEvent() {
    Calendar calendar = new Calendar();
    calendar.createEvent("Solo Event",
        LocalDateTime.of(2025, 12, 5, 10, 0),
        LocalDateTime.of(2025, 12, 5, 11, 0));

    calendar.editSeries("Solo Event",
        LocalDateTime.of(2025, 12, 5, 10, 0),
        "location", "Room 202");

    InterfaceEvent event = calendar.getAllEvents().get(0);
    assertEquals("Room 202", event.getLocation());
  }

  @Test
  public void testEditEventsFromOnNonSeriesEventEditsEvent() {
    Calendar calendar = new Calendar();
    calendar.createEvent("Single Meeting",
        LocalDateTime.of(2025, 12, 8, 13, 0),
        LocalDateTime.of(2025, 12, 8, 14, 0));

    calendar.editEventsFrom("Single Meeting",
        LocalDateTime.of(2025, 12, 8, 13, 0),
        "description", "Project kickoff");

    InterfaceEvent event = calendar.getAllEvents().get(0);
    assertEquals("Project kickoff", event.getDescription());
  }

  @Test
  public void testIsBusyAtEventEndReturnsFalse() {
    Calendar calendar = new Calendar();
    calendar.createEvent("Meeting",
        LocalDateTime.of(2025, 12, 1, 10, 0),
        LocalDateTime.of(2025, 12, 1, 11, 0));

    assertFalse(calendar.isBusy(LocalDateTime.of(2025, 12, 1, 11, 0)));
  }

  @Test
  public void testIsBusyBeforeEventReturnsFalse() {
    Calendar calendar = new Calendar();
    calendar.createEvent("Meeting",
        LocalDateTime.of(2025, 12, 1, 10, 0),
        LocalDateTime.of(2025, 12, 1, 11, 0));

    assertFalse(calendar.isBusy(LocalDateTime.of(2025, 12, 1, 9, 0)));
  }

  @Test
  public void testSplitSeriesWithMultipleEventsCreatesNewSeries() {
    Calendar calendar = new Calendar();
    calendar.createEventSeries("Recurring",
        LocalDateTime.of(2025, 12, 1, 15, 0),
        LocalDateTime.of(2025, 12, 1, 16, 0),
        "MTWRF", 10);

    calendar.editEventsFrom("Recurring",
        LocalDateTime.of(2025, 12, 8, 15, 0),
        "start", "2025-12-08T16:00");

    assertTrue(calendar.getAllEvents().size() >= 10);
  }

  @Test
  public void testEditEventsFromStartPropertyUpdatesMultipleEvents() {
    Calendar calendar = new Calendar();
    calendar.createEventSeries("Series Event",
        LocalDateTime.of(2025, 12, 1, 9, 0),
        LocalDateTime.of(2025, 12, 1, 9, 30),
        "MTWRF", 8);

    calendar.editEventsFrom("Series Event",
        LocalDateTime.of(2025, 12, 4, 9, 0),
        "start", "2025-12-04T10:00");

    List<InterfaceEvent> events = calendar.getAllEvents();
    long editedCount = events.stream()
        .filter(e -> e.getStart().getHour() == 10)
        .count();

    assertTrue(editedCount > 0);
  }

  @Test
  public void testHasSameIdentityChecksAllThreeFields() {
    Calendar calendar = new Calendar();
    calendar.createEvent("Event1",
        LocalDateTime.of(2025, 12, 1, 10, 0),
        LocalDateTime.of(2025, 12, 1, 11, 0));

    calendar.createEvent("Event2",
        LocalDateTime.of(2025, 12, 1, 10, 0),
        LocalDateTime.of(2025, 12, 1, 11, 0));

    List<InterfaceEvent> events = calendar.getAllEvents();
    assertEquals(2, events.size());
  }

  @Test
  public void testIsBusyDuringEventReturnsTrue() {
    Calendar calendar = new Calendar();
    calendar.createEvent("Meeting",
        LocalDateTime.of(2025, 12, 1, 10, 0),
        LocalDateTime.of(2025, 12, 1, 11, 0));

    assertTrue(calendar.isBusy(LocalDateTime.of(2025, 12, 1, 10, 30)));
  }

  @Test
  public void testIsBusyAfterEventReturnsFalse() {
    Calendar calendar = new Calendar();
    calendar.createEvent("Meeting",
        LocalDateTime.of(2025, 12, 1, 10, 0),
        LocalDateTime.of(2025, 12, 1, 11, 0));

    assertFalse(calendar.isBusy(LocalDateTime.of(2025, 12, 1, 12, 0)));
  }
}