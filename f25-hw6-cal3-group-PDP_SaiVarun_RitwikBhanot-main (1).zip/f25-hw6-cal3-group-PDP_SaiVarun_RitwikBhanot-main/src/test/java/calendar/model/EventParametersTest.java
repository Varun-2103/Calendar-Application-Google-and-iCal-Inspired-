package calendar.model;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.time.LocalDateTime;
import java.time.LocalTime;
import org.junit.Test;

/**
 * Comprehensive test suite for EventParameters class.
 * Tests builder pattern, getters, and utility methods.
 */
public class EventParametersTest {

  private static final String SUBJECT = "Team Meeting";
  private static final LocalDateTime START = LocalDateTime.of(2023, 12, 15, 10, 0);
  private static final LocalDateTime END = LocalDateTime.of(2023, 12, 15, 11, 0);
  private static final String WEEKDAYS = "Monday,Wednesday,Friday";
  private static final int OCCURRENCES = 10;
  private static final LocalDateTime UNTIL = LocalDateTime.of(2023, 12, 31, 23, 59);

  @Test
  public void testBuilderCreatesSingleEventParameters() {
    EventParameters params = EventParameters.builder()
        .subject(SUBJECT)
        .start(START)
        .end(END)
        .build();

    assertEquals(SUBJECT, params.getSubject());
    assertEquals(START, params.getStart());
    assertEquals(END, params.getEnd());
    assertEquals(null, params.getWeekdays());
    assertEquals(0, params.getOccurrences());
    assertEquals(null, params.getUntil());
  }

  @Test
  public void testBuilderCreatesSeriesWithOccurrencesParameters() {
    EventParameters params = EventParameters.builder()
        .subject(SUBJECT)
        .start(START)
        .end(END)
        .weekdays(WEEKDAYS)
        .occurrences(OCCURRENCES)
        .build();

    assertEquals(SUBJECT, params.getSubject());
    assertEquals(START, params.getStart());
    assertEquals(END, params.getEnd());
    assertEquals(WEEKDAYS, params.getWeekdays());
    assertEquals(OCCURRENCES, params.getOccurrences());
    assertEquals(null, params.getUntil());
  }

  @Test
  public void testBuilderCreatesSeriesWithUntilParameters() {
    EventParameters params = EventParameters.builder()
        .subject(SUBJECT)
        .start(START)
        .end(END)
        .weekdays(WEEKDAYS)
        .until(UNTIL)
        .build();

    assertEquals(SUBJECT, params.getSubject());
    assertEquals(START, params.getStart());
    assertEquals(END, params.getEnd());
    assertEquals(WEEKDAYS, params.getWeekdays());
    assertEquals(0, params.getOccurrences());
    assertEquals(UNTIL, params.getUntil());
  }

  @Test
  public void testBuilderWithAllParameters() {
    EventParameters params = EventParameters.builder()
        .subject(SUBJECT)
        .start(START)
        .end(END)
        .weekdays(WEEKDAYS)
        .occurrences(OCCURRENCES)
        .until(UNTIL)
        .build();

    assertEquals(SUBJECT, params.getSubject());
    assertEquals(START, params.getStart());
    assertEquals(END, params.getEnd());
    assertEquals(WEEKDAYS, params.getWeekdays());
    assertEquals(OCCURRENCES, params.getOccurrences());
    assertEquals(UNTIL, params.getUntil());
  }

  @Test
  public void testBuilderWithNullSubject() {
    EventParameters params = EventParameters.builder()
        .subject(null)
        .start(START)
        .end(END)
        .build();

    assertEquals(null, params.getSubject());
    assertEquals(START, params.getStart());
    assertEquals(END, params.getEnd());
  }

  @Test
  public void testBuilderWithEmptySubject() {
    EventParameters params = EventParameters.builder()
        .subject("")
        .start(START)
        .end(END)
        .build();

    assertEquals("", params.getSubject());
    assertEquals(START, params.getStart());
    assertEquals(END, params.getEnd());
  }

  @Test
  public void testBuilderWithZeroOccurrences() {
    EventParameters params = EventParameters.builder()
        .subject(SUBJECT)
        .start(START)
        .end(END)
        .weekdays(WEEKDAYS)
        .occurrences(0)
        .build();

    assertEquals(WEEKDAYS, params.getWeekdays());
    assertEquals(0, params.getOccurrences());
  }

  @Test
  public void testBuilderWithNegativeOccurrences() {
    EventParameters params = EventParameters.builder()
        .subject(SUBJECT)
        .start(START)
        .end(END)
        .weekdays(WEEKDAYS)
        .occurrences(-5)
        .build();

    assertEquals(WEEKDAYS, params.getWeekdays());
    assertEquals(-5, params.getOccurrences());
  }

  @Test
  public void testIsSeriesReturnsFalseForSingleEvent() {
    EventParameters params = EventParameters.builder()
        .subject(SUBJECT)
        .start(START)
        .end(END)
        .build();

    assertFalse(params.isSeries());
  }

  @Test
  public void testIsSeriesReturnsTrueForSeriesWithOccurrences() {
    EventParameters params = EventParameters.builder()
        .subject(SUBJECT)
        .start(START)
        .end(END)
        .weekdays(WEEKDAYS)
        .occurrences(OCCURRENCES)
        .build();

    assertTrue(params.isSeries());
  }

  @Test
  public void testIsSeriesReturnsTrueForSeriesWithUntil() {
    EventParameters params = EventParameters.builder()
        .subject(SUBJECT)
        .start(START)
        .end(END)
        .weekdays(WEEKDAYS)
        .until(UNTIL)
        .build();

    assertTrue(params.isSeries());
  }

  @Test
  public void testIsSeriesReturnsFalseWithNullWeekdays() {
    EventParameters params = EventParameters.builder()
        .subject(SUBJECT)
        .start(START)
        .end(END)
        .weekdays(null)
        .occurrences(OCCURRENCES)
        .build();

    assertFalse(params.isSeries());
  }

  @Test
  public void testIsSeriesReturnsFalseWithEmptyWeekdays() {
    EventParameters params = EventParameters.builder()
        .subject(SUBJECT)
        .start(START)
        .end(END)
        .weekdays("")
        .occurrences(OCCURRENCES)
        .build();

    assertTrue(params.isSeries()); // Empty string is still considered weekdays
  }

  @Test
  public void testIsSeriesWithOccurrencesReturnsTrueForValidSeries() {
    EventParameters params = EventParameters.builder()
        .subject(SUBJECT)
        .start(START)
        .end(END)
        .weekdays(WEEKDAYS)
        .occurrences(OCCURRENCES)
        .build();

    assertTrue(params.isSeriesWithOccurrences());
  }

  @Test
  public void testIsSeriesWithOccurrencesReturnsFalseForSingleEvent() {
    EventParameters params = EventParameters.builder()
        .subject(SUBJECT)
        .start(START)
        .end(END)
        .build();

    assertFalse(params.isSeriesWithOccurrences());
  }

  @Test
  public void testIsSeriesWithOccurrencesReturnsFalseForZeroOccurrences() {
    EventParameters params = EventParameters.builder()
        .subject(SUBJECT)
        .start(START)
        .end(END)
        .weekdays(WEEKDAYS)
        .occurrences(0)
        .build();

    assertFalse(params.isSeriesWithOccurrences());
  }

  @Test
  public void testIsSeriesWithOccurrencesReturnsFalseForNegativeOccurrences() {
    EventParameters params = EventParameters.builder()
        .subject(SUBJECT)
        .start(START)
        .end(END)
        .weekdays(WEEKDAYS)
        .occurrences(-1)
        .build();

    assertFalse(params.isSeriesWithOccurrences());
  }

  @Test
  public void testIsSeriesWithUntilReturnsTrueForValidSeries() {
    EventParameters params = EventParameters.builder()
        .subject(SUBJECT)
        .start(START)
        .end(END)
        .weekdays(WEEKDAYS)
        .until(UNTIL)
        .build();

    assertTrue(params.isSeriesWithUntil());
  }

  @Test
  public void testIsSeriesWithUntilReturnsFalseForSingleEvent() {
    EventParameters params = EventParameters.builder()
        .subject(SUBJECT)
        .start(START)
        .end(END)
        .build();

    assertFalse(params.isSeriesWithUntil());
  }

  @Test
  public void testIsSeriesWithUntilReturnsFalseForNullUntil() {
    EventParameters params = EventParameters.builder()
        .subject(SUBJECT)
        .start(START)
        .end(END)
        .weekdays(WEEKDAYS)
        .until(null)
        .build();

    assertFalse(params.isSeriesWithUntil());
  }

  @Test
  public void testGetStartTimeReturnsCorrectTime() {
    EventParameters params = EventParameters.builder()
        .subject(SUBJECT)
        .start(START)
        .end(END)
        .build();

    assertEquals(LocalTime.of(10, 0), params.getStartTime());
  }

  @Test
  public void testGetEndTimeReturnsCorrectTime() {
    EventParameters params = EventParameters.builder()
        .subject(SUBJECT)
        .start(START)
        .end(END)
        .build();

    assertEquals(LocalTime.of(11, 0), params.getEndTime());
  }

  @Test
  public void testGetStartTimeWithMidnight() {
    LocalDateTime midnightStart = LocalDateTime.of(2023, 12, 15, 0, 0);
    EventParameters params = EventParameters.builder()
        .subject(SUBJECT)
        .start(midnightStart)
        .end(END)
        .build();

    assertEquals(LocalTime.of(0, 0), params.getStartTime());
  }

  @Test
  public void testGetEndTimeWithMidnight() {
    LocalDateTime midnightEnd = LocalDateTime.of(2023, 12, 15, 0, 0);
    EventParameters params = EventParameters.builder()
        .subject(SUBJECT)
        .start(START)
        .end(midnightEnd)
        .build();

    assertEquals(LocalTime.of(0, 0), params.getEndTime());
  }

  @Test
  public void testBuilderMethodChaining() {
    EventParameters params = EventParameters.builder()
        .subject(SUBJECT)
        .start(START)
        .end(END)
        .weekdays(WEEKDAYS)
        .occurrences(OCCURRENCES)
        .until(UNTIL)
        .build();

    // Verify all properties were set correctly through chaining
    assertEquals(SUBJECT, params.getSubject());
    assertEquals(START, params.getStart());
    assertEquals(END, params.getEnd());
    assertEquals(WEEKDAYS, params.getWeekdays());
    assertEquals(OCCURRENCES, params.getOccurrences());
    assertEquals(UNTIL, params.getUntil());
  }

  @Test
  public void testBuilderReturnsNewInstanceEachTime() {
    EventParameters.Builder builder1 = EventParameters.builder();
    EventParameters.Builder builder2 = EventParameters.builder();

    assertTrue(builder1 != builder2);
  }

  @Test
  public void testBuildCreatesImmutableParameters() {
    EventParameters params = EventParameters.builder()
        .subject(SUBJECT)
        .start(START)
        .end(END)
        .build();

    // Parameters should be immutable - trying to change them shouldn't affect the original
    String originalSubject = params.getSubject();
    LocalDateTime originalStart = params.getStart();
    LocalDateTime originalEnd = params.getEnd();

    // Create new parameters with different values
    EventParameters newParams = EventParameters.builder()
        .subject("Different Subject")
        .start(START.plusDays(1))
        .end(END.plusDays(1))
        .build();

    // Original parameters should remain unchanged
    assertEquals(originalSubject, params.getSubject());
    assertEquals(originalStart, params.getStart());
    assertEquals(originalEnd, params.getEnd());
  }

  @Test
  public void testBuilderWithMinimalParameters() {
    EventParameters params = EventParameters.builder()
        .build();

    assertEquals(null, params.getSubject());
    assertEquals(null, params.getStart());
    assertEquals(null, params.getEnd());
    assertEquals(null, params.getWeekdays());
    assertEquals(0, params.getOccurrences());
    assertEquals(null, params.getUntil());
  }

  @Test
  public void testBuilderWithOnlySubject() {
    EventParameters params = EventParameters.builder()
        .subject(SUBJECT)
        .build();

    assertEquals(SUBJECT, params.getSubject());
    assertEquals(null, params.getStart());
    assertEquals(null, params.getEnd());
  }

  @Test
  public void testBuilderWithOnlyStartAndEnd() {
    EventParameters params = EventParameters.builder()
        .start(START)
        .end(END)
        .build();

    assertEquals(null, params.getSubject());
    assertEquals(START, params.getStart());
    assertEquals(END, params.getEnd());
  }

  @Test
  public void testBuilderWithOnlyWeekdays() {
    EventParameters params = EventParameters.builder()
        .weekdays(WEEKDAYS)
        .build();

    assertEquals(null, params.getSubject());
    assertEquals(null, params.getStart());
    assertEquals(null, params.getEnd());
    assertEquals(WEEKDAYS, params.getWeekdays());
  }
}