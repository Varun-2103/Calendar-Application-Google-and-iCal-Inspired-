package calendar.model;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.time.DayOfWeek;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.List;
import java.util.Set;
import org.junit.Test;

/**
 * Comprehensive test suite for the EventSeries class.
 * Tests all functionality including creation, event management, property updates, and edge cases.
 */
public class EventSeriesTest {

  private static final String SUBJECT = "Weekly Meeting";
  private static final LocalTime START_TIME = LocalTime.of(10, 0);
  private static final LocalTime END_TIME = LocalTime.of(11, 0);
  private static final Set<DayOfWeek> WEEKDAYS = Set.of(
      DayOfWeek.MONDAY, DayOfWeek.WEDNESDAY, DayOfWeek.FRIDAY);
  private static final LocalDateTime EVENT1_START = LocalDateTime.of(2023, 12, 11, 10, 0);
  private static final LocalDateTime EVENT1_END = LocalDateTime.of(2023, 12, 11, 11, 0);
  private static final LocalDateTime EVENT2_START = LocalDateTime.of(2023, 12, 13, 10, 0);
  private static final LocalDateTime EVENT2_END = LocalDateTime.of(2023, 12, 13, 11, 0);

  @Test
  public void testEventSeriesCreationValidParametersCreatesSeries() {
    EventSeries series = new EventSeries(SUBJECT, START_TIME, END_TIME, WEEKDAYS);

    assertNotNull(series);
    assertEquals(SUBJECT, series.getSubject());
    assertEquals(START_TIME, series.getStartTime());
    assertEquals(END_TIME, series.getEndTime());
    assertEquals(WEEKDAYS, series.getWeekdays());
    assertTrue(series.getAllEvents().isEmpty());
  }

  @Test(expected = IllegalArgumentException.class)
  public void testEventSeriesCreationNullSubjectThrowsException() {
    new EventSeries(null, START_TIME, END_TIME, WEEKDAYS);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testEventSeriesCreationEmptySubjectThrowsException() {
    new EventSeries("", START_TIME, END_TIME, WEEKDAYS);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testEventSeriesCreationNullStartTimeThrowsException() {
    new EventSeries(SUBJECT, null, END_TIME, WEEKDAYS);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testEventSeriesCreationNullEndTimeThrowsException() {
    new EventSeries(SUBJECT, START_TIME, null, WEEKDAYS);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testEventSeriesCreationNullWeekdaysThrowsException() {
    new EventSeries(SUBJECT, START_TIME, END_TIME, null);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testEventSeriesCreationEmptyWeekdaysThrowsException() {
    new EventSeries(SUBJECT, START_TIME, END_TIME, Set.of());
  }

  @Test
  public void testAddEventValidCompatibleEventAddsEvent() {
    EventSeries series = new EventSeries(SUBJECT, START_TIME, END_TIME, WEEKDAYS);
    InterfaceEvent event = new Event(SUBJECT, EVENT1_START, EVENT1_END);

    series.addEvent(event);

    List<InterfaceEvent> events = series.getAllEvents();
    assertEquals(1, events.size());
    assertEquals(event, events.get(0));
  }

  @Test(expected = IllegalArgumentException.class)
  public void testAddEventNullEventThrowsException() {
    EventSeries series = new EventSeries(SUBJECT, START_TIME, END_TIME, WEEKDAYS);

    series.addEvent(null);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testAddEventDifferentSubjectThrowsException() {
    EventSeries series = new EventSeries(SUBJECT, START_TIME, END_TIME, WEEKDAYS);
    InterfaceEvent event = new Event("Different Subject", EVENT1_START, EVENT1_END);

    series.addEvent(event);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testAddEventDifferentStartTimeThrowsException() {
    EventSeries series = new EventSeries(SUBJECT, START_TIME, END_TIME, WEEKDAYS);
    LocalDateTime differentStart = EVENT1_START.withHour(9).withMinute(0).withSecond(0).withNano(0);
    InterfaceEvent event = new Event(SUBJECT, differentStart, EVENT1_END);

    series.addEvent(event);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testAddEventDifferentEndTimeThrowsException() {
    EventSeries series = new EventSeries(SUBJECT, START_TIME, END_TIME, WEEKDAYS);
    LocalDateTime differentEnd = EVENT1_END.withHour(12).withMinute(0).withSecond(0).withNano(0);
    InterfaceEvent event = new Event(SUBJECT, EVENT1_START, differentEnd);

    series.addEvent(event);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testAddEventDuplicateEventThrowsException() {
    EventSeries series = new EventSeries(SUBJECT, START_TIME, END_TIME, WEEKDAYS);
    InterfaceEvent event = new Event(SUBJECT, EVENT1_START, EVENT1_END);

    series.addEvent(event);
    series.addEvent(event);
  }

  @Test
  public void testRemoveEventExistingEventRemovesEvent() {
    EventSeries series = new EventSeries(SUBJECT, START_TIME, END_TIME, WEEKDAYS);
    InterfaceEvent event = new Event(SUBJECT, EVENT1_START, EVENT1_END);
    series.addEvent(event);

    series.removeEvent(event);

    assertTrue(series.getAllEvents().isEmpty());
  }

  @Test(expected = IllegalArgumentException.class)
  public void testRemoveEventNullEventThrowsException() {
    EventSeries series = new EventSeries(SUBJECT, START_TIME, END_TIME, WEEKDAYS);

    series.removeEvent(null);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testRemoveEventNonExistentEventThrowsException() {
    EventSeries series = new EventSeries(SUBJECT, START_TIME, END_TIME, WEEKDAYS);
    InterfaceEvent event = new Event(SUBJECT, EVENT1_START, EVENT1_END);

    series.removeEvent(event);
  }

  @Test
  public void testUpdatePropertyValidSubjectUpdatesAllEventsAndSeries() {
    EventSeries series = new EventSeries(SUBJECT, START_TIME, END_TIME, WEEKDAYS);
    InterfaceEvent event1 = new Event(SUBJECT, EVENT1_START, EVENT1_END);
    InterfaceEvent event2 = new Event(SUBJECT, EVENT2_START, EVENT2_END);
    series.addEvent(event1);
    series.addEvent(event2);
    String newSubject = "Updated Meeting";

    series.updateProperty("subject", newSubject);

    assertEquals(newSubject, series.getSubject());
    for (InterfaceEvent event : series.getAllEvents()) {
      assertEquals(newSubject, event.getSubject());
    }
  }

  @Test
  public void testUpdatePropertyValidLocationUpdatesAllEvents() {
    EventSeries series = new EventSeries(SUBJECT, START_TIME, END_TIME, WEEKDAYS);
    InterfaceEvent event1 = new Event(SUBJECT, EVENT1_START, EVENT1_END);
    InterfaceEvent event2 = new Event(SUBJECT, EVENT2_START, EVENT2_END);
    series.addEvent(event1);
    series.addEvent(event2);
    String newLocation = "Conference Room";

    series.updateProperty("location", newLocation);

    for (InterfaceEvent event : series.getAllEvents()) {
      assertEquals(newLocation, event.getLocation());
    }
  }

  @Test
  public void testUpdatePropertyValidDescriptionUpdatesAllEvents() {
    EventSeries series = new EventSeries(SUBJECT, START_TIME, END_TIME, WEEKDAYS);
    InterfaceEvent event1 = new Event(SUBJECT, EVENT1_START, EVENT1_END);
    InterfaceEvent event2 = new Event(SUBJECT, EVENT2_START, EVENT2_END);
    series.addEvent(event1);
    series.addEvent(event2);
    String newDescription = "Weekly team sync";

    series.updateProperty("description", newDescription);

    for (InterfaceEvent event : series.getAllEvents()) {
      assertEquals(newDescription, event.getDescription());
    }
  }

  @Test
  public void testUpdatePropertyValidStatusUpdatesAllEvents() {
    EventSeries series = new EventSeries(SUBJECT, START_TIME, END_TIME, WEEKDAYS);
    InterfaceEvent event1 = new Event(SUBJECT, EVENT1_START, EVENT1_END);
    InterfaceEvent event2 = new Event(SUBJECT, EVENT2_START, EVENT2_END);
    series.addEvent(event1);
    series.addEvent(event2);
    String newStatus = "private";

    series.updateProperty("status", newStatus);

    for (InterfaceEvent event : series.getAllEvents()) {
      assertEquals(newStatus, event.getStatus());
    }
  }

  @Test
  public void testUpdatePropertyValidStartUpdatesAllEvents() {
    EventSeries series = new EventSeries(SUBJECT, START_TIME, END_TIME, WEEKDAYS);
    InterfaceEvent event1 = new Event(SUBJECT, EVENT1_START, EVENT1_END);
    InterfaceEvent event2 = new Event(SUBJECT, EVENT2_START, EVENT2_END);
    series.addEvent(event1);
    series.addEvent(event2);
    String newStart = EVENT1_START.withHour(9).withMinute(0).withSecond(0).withNano(0).toString();

    series.updateProperty("start", newStart);

    for (InterfaceEvent event : series.getAllEvents()) {
      assertEquals(LocalTime.parse(newStart.split("T")[1]), event.getStart().toLocalTime());
    }
  }

  @Test
  public void testUpdatePropertyValidEndUpdatesAllEvents() {
    EventSeries series = new EventSeries(SUBJECT, START_TIME, END_TIME, WEEKDAYS);
    InterfaceEvent event1 = new Event(SUBJECT, EVENT1_START, EVENT1_END);
    InterfaceEvent event2 = new Event(SUBJECT, EVENT2_START, EVENT2_END);
    series.addEvent(event1);
    series.addEvent(event2);
    String newEnd = EVENT1_END.withHour(12).withMinute(0).withSecond(0).withNano(0).toString();

    series.updateProperty("end", newEnd);

    for (InterfaceEvent event : series.getAllEvents()) {
      assertEquals(LocalTime.parse(newEnd.split("T")[1]), event.getEnd().toLocalTime());
    }
  }

  @Test(expected = IllegalArgumentException.class)
  public void testUpdatePropertyInvalidPropertyThrowsException() {
    EventSeries series = new EventSeries(SUBJECT, START_TIME, END_TIME, WEEKDAYS);
    InterfaceEvent event = new Event(SUBJECT, EVENT1_START, EVENT1_END);
    series.addEvent(event);

    series.updateProperty("invalid", "value");
  }

  @Test
  public void testUpdatePropertyFromValidDateUpdatesEventsFromSpecifiedDate() {
    EventSeries series = new EventSeries(SUBJECT, START_TIME, END_TIME, WEEKDAYS);
    InterfaceEvent event1 = new Event(SUBJECT, EVENT1_START, EVENT1_END);
    InterfaceEvent event2 = new Event(SUBJECT, EVENT2_START, EVENT2_END);
    series.addEvent(event1);
    series.addEvent(event2);
    String newLocation = "Conference Room";

    series.updatePropertyFrom(EVENT2_START, "location", newLocation);

    assertEquals(null, event1.getLocation());
    assertEquals(newLocation, event2.getLocation());
  }

  @Test(expected = IllegalArgumentException.class)
  public void testUpdatePropertyFromNullStartDateThrowsException() {
    EventSeries series = new EventSeries(SUBJECT, START_TIME, END_TIME, WEEKDAYS);

    series.updatePropertyFrom(null, "location", "Conference Room");
  }

  @Test(expected = IllegalArgumentException.class)
  public void testUpdatePropertyFromInvalidPropertyThrowsException() {
    EventSeries series = new EventSeries(SUBJECT, START_TIME, END_TIME, WEEKDAYS);
    InterfaceEvent event1 = new Event(SUBJECT, EVENT1_START, EVENT1_END);
    series.addEvent(event1);

    series.updatePropertyFrom(EVENT1_START, "invalid", "value");
  }

  @Test
  public void testGetAllEventsWithEventsReturnsCopyOfEvents() {
    EventSeries series = new EventSeries(SUBJECT, START_TIME, END_TIME, WEEKDAYS);
    InterfaceEvent event1 = new Event(SUBJECT, EVENT1_START, EVENT1_END);
    InterfaceEvent event2 = new Event(SUBJECT, EVENT2_START, EVENT2_END);
    series.addEvent(event1);
    series.addEvent(event2);

    List<InterfaceEvent> events = series.getAllEvents();
    assertEquals(2, events.size());

    events.clear();
    assertEquals(2, series.getAllEvents().size());
  }

  @Test
  public void testGetAllEventsEmptySeriesReturnsEmptyList() {
    EventSeries series = new EventSeries(SUBJECT, START_TIME, END_TIME, WEEKDAYS);

    List<InterfaceEvent> events = series.getAllEvents();

    assertTrue(events.isEmpty());
  }

  @Test
  public void testCaseInsensitivePropertyUpdateWorksCorrectly() {
    EventSeries series = new EventSeries(SUBJECT, START_TIME, END_TIME, WEEKDAYS);
    InterfaceEvent event = new Event(SUBJECT, EVENT1_START, EVENT1_END);
    series.addEvent(event);

    series.updateProperty("LOCATION", "Conference Room");

    assertEquals("Conference Room", event.getLocation());
  }

  @Test
  public void testMultiplePropertyUpdatesAllPropertiesUpdated() {
    EventSeries series = new EventSeries(SUBJECT, START_TIME, END_TIME, WEEKDAYS);
    InterfaceEvent event = new Event(SUBJECT, EVENT1_START, EVENT1_END);
    series.addEvent(event);

    series.updateProperty("location", "Conference Room");
    series.updateProperty("description", "Team sync");
    series.updateProperty("status", "private");

    assertEquals("Conference Room", event.getLocation());
    assertEquals("Team sync", event.getDescription());
    assertEquals("private", event.getStatus());
  }

  @Test
  public void testEventSeriesWithSingleWeekdayHandlesCorrectly() {
    EventSeries series = new EventSeries(SUBJECT, START_TIME, END_TIME, Set.of(DayOfWeek.MONDAY));
    InterfaceEvent event = new Event(SUBJECT, EVENT1_START, EVENT1_END);

    series.addEvent(event);

    assertEquals(1, series.getAllEvents().size());
  }

  @Test
  public void testEventSeriesWithAllWeekdaysHandlesCorrectly() {
    EventSeries series = new EventSeries(SUBJECT, START_TIME, END_TIME, 
        Set.of(DayOfWeek.MONDAY, DayOfWeek.TUESDAY, DayOfWeek.WEDNESDAY, 
               DayOfWeek.THURSDAY, DayOfWeek.FRIDAY, DayOfWeek.SATURDAY, DayOfWeek.SUNDAY));

    assertEquals(7, series.getWeekdays().size());
  }

  @Test
  public void testAddMultipleEventsAllAddedSuccessfully() {
    EventSeries series = new EventSeries(SUBJECT, START_TIME, END_TIME, WEEKDAYS);
    InterfaceEvent event1 = new Event(SUBJECT, EVENT1_START, EVENT1_END);
    InterfaceEvent event2 = new Event(SUBJECT, EVENT2_START, EVENT2_END);
    LocalDateTime event3Start = EVENT2_START.plusDays(2);
    LocalDateTime event3End = EVENT2_END.plusDays(2);
    InterfaceEvent event3 = new Event(SUBJECT, event3Start, event3End);

    series.addEvent(event1);
    series.addEvent(event2);
    series.addEvent(event3);

    assertEquals(3, series.getAllEvents().size());
  }

  @Test
  public void testRemoveMultipleEventsAllRemovedSuccessfully() {
    EventSeries series = new EventSeries(SUBJECT, START_TIME, END_TIME, WEEKDAYS);
    InterfaceEvent event1 = new Event(SUBJECT, EVENT1_START, EVENT1_END);
    InterfaceEvent event2 = new Event(SUBJECT, EVENT2_START, EVENT2_END);
    series.addEvent(event1);
    series.addEvent(event2);

    series.removeEvent(event1);
    series.removeEvent(event2);

    assertTrue(series.getAllEvents().isEmpty());
  }

  @Test
  public void testUpdatePropertyFromWithNoEventsBeforeDateUpdatesAllEvents() {
    EventSeries series = new EventSeries(SUBJECT, START_TIME, END_TIME, WEEKDAYS);
    InterfaceEvent event1 = new Event(SUBJECT, EVENT1_START, EVENT1_END);
    InterfaceEvent event2 = new Event(SUBJECT, EVENT2_START, EVENT2_END);
    series.addEvent(event1);
    series.addEvent(event2);
    LocalDateTime beforeAllEvents = EVENT1_START.minusDays(1);
    String newLocation = "Conference Room";

    series.updatePropertyFrom(beforeAllEvents, "location", newLocation);

    for (InterfaceEvent event : series.getAllEvents()) {
      assertEquals(newLocation, event.getLocation());
    }
  }

  @Test
  public void testUpdatePropertyFromWithNoEventsAfterDateUpdatesNoEvents() {
    EventSeries series = new EventSeries(SUBJECT, START_TIME, END_TIME, WEEKDAYS);
    InterfaceEvent event1 = new Event(SUBJECT, EVENT1_START, EVENT1_END);
    InterfaceEvent event2 = new Event(SUBJECT, EVENT2_START, EVENT2_END);
    series.addEvent(event1);
    series.addEvent(event2);
    LocalDateTime afterAllEvents = EVENT2_END.plusDays(1);
    String newLocation = "Conference Room";

    series.updatePropertyFrom(afterAllEvents, "location", newLocation);

    for (InterfaceEvent event : series.getAllEvents()) {
      assertEquals(null, event.getLocation());
    }
  }

  @Test
  public void testEdgeCaseEventAtMidnightHandlesCorrectly() {
    EventSeries series = new EventSeries(SUBJECT, LocalTime.MIDNIGHT, 
        LocalTime.of(0, 30), WEEKDAYS);
    LocalDateTime midnightStart = EVENT1_START.withHour(0).withMinute(0).withSecond(0).withNano(0);
    LocalDateTime midnightEnd = EVENT1_END.withHour(0).withMinute(30).withSecond(0).withNano(0);
    InterfaceEvent event = new Event(SUBJECT, midnightStart, midnightEnd);

    series.addEvent(event);

    assertEquals(1, series.getAllEvents().size());
    assertEquals(event, series.getAllEvents().get(0));
  }

  @Test
  public void testEdgeCaseEventNearMidnightHandlesCorrectly() {
    EventSeries series = new EventSeries(SUBJECT, LocalTime.of(23, 30), 
        LocalTime.of(23, 59), WEEKDAYS);
    LocalDateTime lateStart = EVENT1_START.withHour(23).withMinute(30).withSecond(0).withNano(0);
    LocalDateTime lateEnd = EVENT1_END.withHour(23).withMinute(59).withSecond(0).withNano(0);
    InterfaceEvent event = new Event(SUBJECT, lateStart, lateEnd);

    series.addEvent(event);

    assertEquals(1, series.getAllEvents().size());
    assertEquals(event, series.getAllEvents().get(0));
  }
}