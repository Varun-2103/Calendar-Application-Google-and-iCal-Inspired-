package calendar.view;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import calendar.model.InterfaceEvent;
import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * Comprehensive test suite for CalendarTextView class.
 * Tests message display, event formatting, and error handling.
 */
public class CalendarTextViewTest {

  private CalendarTextView view;
  private ByteArrayOutputStream outputStream;
  private ByteArrayOutputStream errorStream;
  private PrintStream originalOut;
  private PrintStream originalErr;

  /**
   * Sets up test fixtures before each test.
   */
  @Before
  public void setUp() {
    view = new CalendarTextView();
    outputStream = new ByteArrayOutputStream();
    errorStream = new ByteArrayOutputStream();
    originalOut = System.out;
    originalErr = System.err;
    System.setOut(new PrintStream(outputStream));
    System.setErr(new PrintStream(errorStream));
  }

  /**
   * Cleans up after each test.
   */
  @After
  public void tearDown() {
    System.setOut(originalOut);
    System.setErr(originalErr);
  }

  @Test
  public void testCalendarTextViewConstructorCreatesView() {
    CalendarTextView newView = new CalendarTextView();
    assertTrue(newView instanceof CalendarTextView);
  }

  @Test
  public void testDisplayMessageOutputsToSystemOut() {
    String message = "Test message";
    view.displayMessage(message);
    
    String output = outputStream.toString().trim();
    assertEquals(message, output);
  }

  @Test
  public void testDisplayMessageWithEmptyString() {
    String message = "";
    view.displayMessage(message);
    
    String output = outputStream.toString();
    assertTrue(output.endsWith(System.lineSeparator()));
  }

  @Test
  public void testDisplayMessageWithNull() {
    view.displayMessage(null);
    
    String output = outputStream.toString();
    assertTrue(output.endsWith(System.lineSeparator()));
  }

  @Test
  public void testDisplayMessageWithSpecialCharacters() {
    String message = "Message with @#$%^&*() special chars!";
    view.displayMessage(message);
    
    String output = outputStream.toString().trim();
    assertEquals(message, output);
  }

  @Test
  public void testDisplayErrorOutputsToSystemErr() {
    String error = "Test error message";
    view.displayError(error);
    
    String output = errorStream.toString().trim();
    assertEquals("Error: " + error, output);
  }

  @Test
  public void testDisplayErrorWithEmptyString() {
    String error = "";
    view.displayError(error);
    
    String output = errorStream.toString().trim();
    assertEquals("Error:", output);
  }

  @Test
  public void testDisplayErrorWithNull() {
    view.displayError(null);
    
    String output = errorStream.toString().trim();
    assertEquals("Error: null", output);
  }

  @Test
  public void testDisplaySuccessOutputsToSystemOut() {
    String message = "Operation completed successfully";
    view.displaySuccess(message);
    
    String output = outputStream.toString().trim();
    assertEquals("Success: " + message, output);
  }

  @Test
  public void testDisplaySuccessWithEmptyString() {
    String message = "";
    view.displaySuccess(message);
    
    String output = outputStream.toString().trim();
    assertEquals("Success:", output);
  }

  @Test
  public void testDisplaySuccessWithNull() {
    view.displaySuccess(null);
    
    String output = outputStream.toString().trim();
    assertEquals("Success: null", output);
  }

  @Test
  public void testDisplayEventsWithEmptyList() {
    List<InterfaceEvent> events = Collections.emptyList();
    view.displayEvents(events);
    
    String output = outputStream.toString().trim();
    assertEquals("No events found.", output);
  }

  @Test
  public void testDisplayEventsWithNullList() {
    view.displayEvents(null);
    
    String output = outputStream.toString().trim();
    assertEquals("No events found.", output);
  }

  @Test
  public void testDisplayEventsWithSingleEvent() {
    InterfaceEvent mockEvent = createMockEvent("Team Meeting", 
                                              LocalDateTime.of(2023, 12, 15, 10, 0),
                                              LocalDateTime.of(2023, 12, 15, 11, 0),
                                              null);
    
    List<InterfaceEvent> events = Arrays.asList(mockEvent);
    view.displayEvents(events);
    
    String output = outputStream.toString().trim();
    assertEquals("- Team Meeting starting on 2023-12-15 at 10:00, ending on 2023-12-15 at 11:00",
                 output);
  }

  @Test
  public void testDisplayEventsWithSingleEventWithLocation() {
    InterfaceEvent mockEvent = createMockEvent("Team Meeting", 
                                              LocalDateTime.of(2023, 12, 15, 10, 0),
                                              LocalDateTime.of(2023, 12, 15, 11, 0),
                                              "Conference Room A");
    
    List<InterfaceEvent> events = Arrays.asList(mockEvent);
    view.displayEvents(events);
    
    String output = outputStream.toString().trim();
    assertEquals("- Team Meeting starting on 2023-12-15 at 10:00, ending on 2023-12-15 at 11:00 "
                 + "(Location: Conference Room A)", output);
  }

  @Test
  public void testDisplayEventsWithMultipleEvents() {
    InterfaceEvent event1 = createMockEvent("Morning Meeting", 
                                           LocalDateTime.of(2023, 12, 15, 9, 0),
                                           LocalDateTime.of(2023, 12, 15, 10, 0),
                                           "Room 1");
    InterfaceEvent event2 = createMockEvent("Lunch Break", 
                                           LocalDateTime.of(2023, 12, 15, 12, 0),
                                           LocalDateTime.of(2023, 12, 15, 13, 0),
                                           null);
    
    List<InterfaceEvent> events = Arrays.asList(event1, event2);
    view.displayEvents(events);
    
    String output = outputStream.toString().trim();
    String[] lines = output.split(System.lineSeparator());
    
    assertEquals(2, lines.length);
    assertEquals("- Morning Meeting starting on 2023-12-15 at 09:00, ending on 2023-12-15 at 10:00 "
                 + "(Location: Room 1)", lines[0]);
    assertEquals("- Lunch Break starting on 2023-12-15 at 12:00, ending on 2023-12-15 at 13:00",
                 lines[1]);
  }

  @Test
  public void testDisplayEventsWithEmptyLocation() {
    InterfaceEvent mockEvent = createMockEvent("Team Meeting", 
                                              LocalDateTime.of(2023, 12, 15, 10, 0),
                                              LocalDateTime.of(2023, 12, 15, 11, 0),
                                              "");
    
    List<InterfaceEvent> events = Arrays.asList(mockEvent);
    view.displayEvents(events);
    
    String output = outputStream.toString().trim();
    assertEquals("- Team Meeting starting on 2023-12-15 at 10:00, ending on 2023-12-15 at 11:00",
                 output);
  }

  @Test
  public void testDisplayEventsWithMultiDayEvent() {
    InterfaceEvent mockEvent = createMockEvent("Conference", 
                                              LocalDateTime.of(2023, 12, 15, 9, 0),
                                              LocalDateTime.of(2023, 12, 16, 17, 0),
                                              "Main Hall");
    
    List<InterfaceEvent> events = Arrays.asList(mockEvent);
    view.displayEvents(events);
    
    String output = outputStream.toString().trim();
    assertEquals("- Conference starting on 2023-12-15 at 09:00, ending on 2023-12-16 at 17:00 "
                 + "(Location: Main Hall)", output);
  }

  @Test
  public void testDisplayEventsWithEventWithSpecialCharactersInSubject() {
    InterfaceEvent mockEvent = createMockEvent("Meeting @ Office #1", 
                                              LocalDateTime.of(2023, 12, 15, 10, 0),
                                              LocalDateTime.of(2023, 12, 15, 11, 0),
                                              null);
    
    List<InterfaceEvent> events = Arrays.asList(mockEvent);
    view.displayEvents(events);
    
    String output = outputStream.toString().trim();
    assertEquals("- Meeting @ Office #1 starting on 2023-12-15 at 10:00, "
                 + "ending on 2023-12-15 at 11:00", output);
  }

  @Test
  public void testDisplayEventsWithEventWithSpecialCharactersInLocation() {
    InterfaceEvent mockEvent = createMockEvent("Team Meeting", 
                                              LocalDateTime.of(2023, 12, 15, 10, 0),
                                              LocalDateTime.of(2023, 12, 15, 11, 0),
                                              "Room @ Building #1");
    
    List<InterfaceEvent> events = Arrays.asList(mockEvent);
    view.displayEvents(events);
    
    String output = outputStream.toString().trim();
    assertEquals("- Team Meeting starting on 2023-12-15 at 10:00, ending on 2023-12-15 at 11:00 "
                 + "(Location: Room @ Building #1)", output);
  }

  @Test
  public void testDisplayEventsWithEventAtMidnight() {
    InterfaceEvent mockEvent = createMockEvent("New Year Party", 
                                              LocalDateTime.of(2023, 12, 31, 23, 0),
                                              LocalDateTime.of(2024, 1, 1, 1, 0),
                                              null);
    
    List<InterfaceEvent> events = Arrays.asList(mockEvent);
    view.displayEvents(events);
    
    String output = outputStream.toString().trim();
    assertEquals("- New Year Party starting on 2023-12-31 at 23:00, ending on 2024-01-01 at 01:00",
                 output);
  }

  @Test
  public void testMultipleDisplayCallsAccumulateOutput() {
    view.displayMessage("First message");
    view.displaySuccess("Success message");
    view.displayError("Error message");
    
    String outOutput = outputStream.toString();
    String errOutput = errorStream.toString();
    
    assertTrue(outOutput.contains("First message"));
    assertTrue(outOutput.contains("Success: Success message"));
    assertTrue(errOutput.contains("Error: Error message"));
  }

  @Test
  public void testDisplayEventsWithNullEventProperties() {
    InterfaceEvent mockEvent = createMockEvent(null, 
                                              null,
                                              null,
                                              null);
    
    List<InterfaceEvent> events = Arrays.asList(mockEvent);
    view.displayEvents(events);
    
    String output = outputStream.toString().trim();
    // Should handle null properties gracefully
    assertTrue(output.contains("starting on null"));
    assertTrue(output.contains("ending on null"));
  }

  /**
   * Helper method to create a mock event for testing.
   */
  private InterfaceEvent createMockEvent(String subject, LocalDateTime start, LocalDateTime end,
                                        String location) {
    return new InterfaceEvent() {
      @Override
      public String getSubject() {
        return subject;
      }
      
      @Override
      public LocalDateTime getStart() {
        return start;
      }
      
      @Override
      public LocalDateTime getEnd() {
        return end;
      }
      
      @Override
      public String getLocation() {
        return location;
      }
      
      @Override
      public String getDescription() {
        return "Test Description";
      }
      
      @Override
      public String getStatus() {
        return "public";
      }
      
      @Override
      public void setSubject(String subject) {}
      
      @Override
      public void setStart(LocalDateTime start) {}
      
      @Override
      public void setEnd(LocalDateTime end) {}
      
      @Override
      public void setLocation(String location) {}
      
      @Override
      public void setDescription(String description) {}
      
      @Override
      public void setStatus(String status) {}
    };
  }
}