package calendar.controller;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import calendar.controller.strategies.CommandStrategy;
import calendar.controller.strategies.CommandStrategyFactory;
import calendar.model.CalendarManager;
import calendar.model.InterfaceCalendarManager;
import calendar.view.CalendarTextView;
import calendar.view.InterfaceCalendarView;
import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.time.ZoneId;
import java.util.Arrays;
import java.util.List;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * Unit test for CalendarController.
 */
public class CalendarControllerTest {

  private CalendarController controller;
  private InterfaceCalendarView view;
  private InterfaceCalendarManager manager;
  private ByteArrayOutputStream outputStream;
  private PrintStream originalOut;
  private PrintStream originalErr;

  /**
   * Sets up test fixtures before each test.
   */
  @Before
  public void setUp() {
    manager = new CalendarManager();
    controller = new CalendarController(manager);
    view = new CalendarTextView();
    outputStream = new ByteArrayOutputStream();
    originalOut = System.out;
    originalErr = System.err;
    System.setOut(new PrintStream(outputStream));
    System.setErr(new PrintStream(outputStream));
  }

  /**
   * Restores system output streams after each test.
   */
  @After
  public void tearDown() {
    System.setOut(originalOut);
    System.setErr(originalErr);
  }

  @Test
  public void testCalendarControllerDefaultConstructorCreatesController() {
    CalendarController defaultController = new CalendarController();
    assertNotNull(defaultController);
  }

  @Test
  public void testCalendarControllerWithNullManagerUsesDefault() {
    CalendarController controllerWithNull = new CalendarController(null);
    assertNotNull(controllerWithNull);
  }

  @Test
  public void testCalendarControllerWithCustomManager() {
    InterfaceCalendarManager customManager = new CalendarManager();
    CalendarController customController = new CalendarController(customManager);
    assertNotNull(customController);
  }

  @Test
  public void testExecuteCommandWithValidCreateCalendarCommand() {
    controller.executeCommand("create calendar --name Test --timezone America/New_York", view);

    String output = outputStream.toString();
    assertTrue(output.contains("Success") || output.contains("created"));
  }

  @Test
  public void testExecuteCommandWithValidCreateEventCommand() {
    manager.createCalendar("Test", ZoneId.of("America/New_York"));
    manager.useCalendar("Test");

    controller.executeCommand("create event \"Test Event\" from 2023-12-15T10:00 "
        + "to 2023-12-15T11:00", view);

    String output = outputStream.toString();
    assertTrue(output.contains("Success") || output.contains("created"));
  }

  @Test
  public void testExecuteCommandWithEmptyCommand() {
    controller.executeCommand("", view);

    String output = outputStream.toString();
    assertTrue(output.contains("Error") || output.contains("Invalid"));
  }

  @Test
  public void testExecuteCommandWithInvalidCommand() {
    controller.executeCommand("invalid command", view);

    String output = outputStream.toString();
    assertTrue(output.contains("Error") || output.contains("Unknown"));
  }

  @Test
  public void testExecuteCommandWithNullCommand() {
    controller.executeCommand(null, view);

    String output = outputStream.toString();
    assertTrue(output.contains("Error") || output.contains("Invalid"));
  }

  @Test
  public void testExecuteCommandResultWithEvents() {
    manager.createCalendar("Test", ZoneId.of("America/New_York"));
    manager.useCalendar("Test");
    manager.getActiveCalendar().createEvent("Meeting",
        java.time.LocalDateTime.of(2025, 12, 1, 10, 0),
        java.time.LocalDateTime.of(2025, 12, 1, 11, 0));

    controller.executeCommand("print events on 2025-12-01", view);

    String output = outputStream.toString();
    assertTrue(output.contains("Meeting"));
  }

  @Test
  public void testExecuteCommandResultWithNoEvents() {
    manager.createCalendar("Test", ZoneId.of("America/New_York"));
    manager.useCalendar("Test");

    controller.executeCommand("print events on 2025-12-01", view);

    String output = outputStream.toString();
    assertTrue(output.contains("No events") || output.contains("no events"));
  }

  @Test
  public void testExecuteCommandShowStatusBusy() {
    manager.createCalendar("Test", ZoneId.of("America/New_York"));
    manager.useCalendar("Test");
    manager.getActiveCalendar().createEvent("Meeting",
        java.time.LocalDateTime.of(2025, 12, 1, 10, 0),
        java.time.LocalDateTime.of(2025, 12, 1, 11, 0));

    controller.executeCommand("show status on 2025-12-01T10:30", view);

    String output = outputStream.toString();
    assertTrue(output.toLowerCase().contains("busy"));
  }

  @Test
  public void testExecuteCommandShowStatusAvailable() {
    manager.createCalendar("Test", ZoneId.of("America/New_York"));
    manager.useCalendar("Test");

    controller.executeCommand("show status on 2025-12-01T10:30", view);

    String output = outputStream.toString();
    assertTrue(output.toLowerCase().contains("available"));
  }

  @Test
  public void testExecuteCommandWithCamelCaseThrowsError() {
    controller.executeCommand("createEvent Meeting from 2025-12-01T10:00 "
        + "to 2025-12-01T11:00", view);

    String output = outputStream.toString();
    assertTrue(output.contains("Error") || output.contains("Unknown"));
  }

  @Test
  public void testExecuteCommandTooShortThrowsError() {
    controller.executeCommand("create", view);

    String output = outputStream.toString();
    assertTrue(output.contains("Error") || output.contains("Invalid"));
  }

  @Test
  public void testTokenizeWithQuotedStringContainingSpaces() {
    manager.createCalendar("Test", ZoneId.of("America/New_York"));
    manager.useCalendar("Test");

    controller.executeCommand("create event \"Team Status Meeting\" from 2025-12-01T10:00 "
        + "to 2025-12-01T11:00", view);

    String output = outputStream.toString();
    assertTrue(output.contains("Success") || output.contains("created"));
  }

  @Test
  public void testTokenizeWithMultipleSpacesBetweenTokens() {
    controller.executeCommand("create    calendar    --name    Test    --timezone    "
        + "America/New_York", view);

    String output = outputStream.toString();
    assertTrue(output.contains("Success") || output.contains("created"));
  }

  @Test
  public void testExecuteCommandPrintEventsWithRange() {
    manager.createCalendar("Test", ZoneId.of("America/New_York"));
    manager.useCalendar("Test");

    controller.executeCommand("print events from 2025-12-01T00:00 to 2025-12-31T23:59", view);

    String output = outputStream.toString();
    assertTrue(output.contains("No events") || output.length() > 0);
  }

  @Test
  public void testExecuteCommandWithSuccessMessageOnly() {
    controller.executeCommand("create calendar --name Cal1 --timezone UTC", view);
    outputStream.reset();

    controller.executeCommand("use calendar --name Cal1", view);

    String output = outputStream.toString();
    assertTrue(output.contains("Success") || output.contains("using"));
  }

  @Test
  public void testExecuteCommandIllegalArgumentExceptionHandling() {
    controller.executeCommand("create calendar --name", view);

    String output = outputStream.toString();
    assertTrue(output.contains("Error") || output.contains("Invalid"));
  }

  @Test
  public void testExecuteCommandGeneralExceptionHandling() {
    controller.executeCommand("use calendar --name NonExistent", view);

    String output = outputStream.toString();
    assertTrue(output.contains("Error"));
  }

  @Test
  public void testCommandStrategyFactorySupportsExpectedCommands() {
    CommandStrategyFactory factory = new CommandStrategyFactory();
    String[] supportedCommands = factory.getSupportedCommands();

    assertNotNull(supportedCommands);
    assertTrue(supportedCommands.length > 0);

    List<String> commandList = Arrays.asList(supportedCommands);
    assertTrue(commandList.contains("create event"));
    assertTrue(commandList.contains("create calendar"));
    assertTrue(commandList.contains("edit calendar"));
    assertTrue(commandList.contains("use calendar"));
  }

  @Test
  public void testExecuteEditEventCommand() {
    manager.createCalendar("Test", ZoneId.of("America/New_York"));
    manager.useCalendar("Test");
    manager.getActiveCalendar().createEvent("Meeting",
        java.time.LocalDateTime.of(2025, 12, 1, 10, 0),
        java.time.LocalDateTime.of(2025, 12, 1, 11, 0));

    controller.executeCommand("edit event location \"Meeting\" from 2025-12-01T10:00 "
        + "to 2025-12-01T11:00 with \"Room A\"", view);

    String output = outputStream.toString();
    assertTrue(output.contains("Success") || output.contains("updated"));
  }

  @Test
  public void testExecuteExportCommand() {
    manager.createCalendar("Test", ZoneId.of("America/New_York"));
    manager.useCalendar("Test");

    controller.executeCommand("export cal test.csv", view);

    String output = outputStream.toString();
    assertTrue(output.length() > 0);
  }

  @Test
  public void testExecuteCopyEventCommand() {
    manager.createCalendar("Cal1", ZoneId.of("America/New_York"));
    manager.createCalendar("Cal2", ZoneId.of("America/New_York"));
    manager.useCalendar("Cal1");
    manager.getActiveCalendar().createEvent("Meeting",
        java.time.LocalDateTime.of(2025, 12, 1, 10, 0),
        java.time.LocalDateTime.of(2025, 12, 1, 11, 0));

    controller.executeCommand("copy event \"Meeting\" on 2025-12-01T10:00 "
        + "--target Cal2 to 2025-12-02T10:00", view);

    String output = outputStream.toString();
    assertTrue(output.contains("Success") || output.contains("copied"));
  }

  @Test
  public void testTokenizeCommandWithEmptyQuotes() {
    controller.executeCommand("create event \"\" from 2025-12-01T10:00 "
        + "to 2025-12-01T11:00", view);

    String output = outputStream.toString();
    assertTrue(output.contains("Error"));
  }

  @Test
  public void testTokenizeCommandWithNestedQuotes() {
    manager.createCalendar("Test", ZoneId.of("America/New_York"));
    manager.useCalendar("Test");

    controller.executeCommand("create event \"Quote \\\"Test\\\"\" from 2025-12-01T10:00 "
        + "to 2025-12-01T11:00", view);

    assertTrue(outputStream.toString().length() > 0);
  }

  @Test
  public void testExecuteCommandWithNullMessage() {
    manager.createCalendar("Test", ZoneId.of("America/New_York"));
    manager.useCalendar("Test");

    controller.executeCommand("print events on 2025-12-01", view);

    assertTrue(outputStream.toString().length() >= 0);
  }

  @Test
  public void testExecuteCommandWithEmptyMessage() {
    manager.createCalendar("Test", ZoneId.of("America/New_York"));

    controller.executeCommand("use calendar --name Test", view);

    String output = outputStream.toString();
    assertTrue(output.contains("Success") || output.contains("using"));
  }
}