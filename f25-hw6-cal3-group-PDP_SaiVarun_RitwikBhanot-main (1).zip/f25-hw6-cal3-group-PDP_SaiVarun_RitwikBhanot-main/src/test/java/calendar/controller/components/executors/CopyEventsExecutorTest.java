package calendar.controller.components.executors;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import calendar.controller.CommandResult;
import calendar.model.Calendar;
import calendar.model.CalendarManager;
import calendar.model.InterfaceCalendar;
import calendar.model.InterfaceCalendarManager;
import calendar.model.InterfaceEvent;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import org.junit.Before;
import org.junit.Test;

/**
 * Test suite for CopyEventsExecutor.
 * Tests copying multiple events within date range between calendars.
 */
public class CopyEventsExecutorTest {

  private CopyEventsExecutor executor;
  private InterfaceCalendarManager calendarManager;
  private InterfaceCalendar sourceCalendar;
  private InterfaceCalendar targetCalendar;
  
  private static final LocalDate START_DATE = LocalDate.of(2023, 12, 15);
  private static final LocalDate END_DATE = LocalDate.of(2023, 12, 17);
  private static final String TARGET_CALENDAR = "Work";
  private static final LocalDate TARGET_DATE = LocalDate.of(2023, 12, 20);
  private static final ZoneId UTC = ZoneId.of("UTC");
  private static final ZoneId EST = ZoneId.of("America/New_York");

  /**
   * Sets up test environment before each test.
   */
  @Before
  public void setUp() {
    calendarManager = new CalendarManager();
    executor = new CopyEventsExecutor(calendarManager);
    
    // Create source and target calendars
    calendarManager.createCalendar("Personal", UTC);
    calendarManager.createCalendar(TARGET_CALENDAR, EST);
    calendarManager.useCalendar("Personal");
    
    sourceCalendar = calendarManager.getActiveCalendar();
    targetCalendar = calendarManager.getCalendar(TARGET_CALENDAR);
  }

  @Test
  public void testExecuteValidCopyWithEvents() {
    // Create events in source calendar
    LocalDateTime event1Start = LocalDateTime.of(2023, 12, 15, 10, 0);
    LocalDateTime event1End = LocalDateTime.of(2023, 12, 15, 11, 0);
    LocalDateTime event2Start = LocalDateTime.of(2023, 12, 16, 14, 0);
    LocalDateTime event2End = LocalDateTime.of(2023, 12, 16, 15, 0);
    
    sourceCalendar.createEvent("Meeting 1", event1Start, event1End);
    sourceCalendar.createEvent("Meeting 2", event2Start, event2End);
    
    Object[] parameters = {START_DATE, END_DATE, TARGET_CALENDAR, TARGET_DATE};
    CommandResult result = executor.execute(parameters);
    
    assertTrue(result.isSuccess());
    assertTrue(result.getMessage().contains("Successfully copied"));
    assertTrue(result.getMessage().contains("2"));
    
    // Verify events were created in target calendar
    assertEquals(2, targetCalendar.getAllEvents().size());
  }

  @Test
  public void testExecuteNoActiveCalendar() {
    // Create new manager without active calendar
    InterfaceCalendarManager emptyManager = new CalendarManager();
    CopyEventsExecutor emptyExecutor = new CopyEventsExecutor(emptyManager);
    
    Object[] parameters = {START_DATE, END_DATE, TARGET_CALENDAR, TARGET_DATE};
    CommandResult result = emptyExecutor.execute(parameters);
    
    assertFalse(result.isSuccess());
    assertEquals("Error copying events: No calendar is currently active. "
        + "Use 'use calendar' command first.", result.getMessage());
  }

  @Test
  public void testExecuteTargetCalendarNotFound() {
    String nonExistentCalendar = "NonExistent";
    
    Object[] parameters = {START_DATE, END_DATE, nonExistentCalendar, TARGET_DATE};
    CommandResult result = executor.execute(parameters);
    
    assertFalse(result.isSuccess());
    assertEquals("Target calendar '" + nonExistentCalendar + "' not found", result.getMessage());
  }

  @Test
  public void testExecuteInvalidDateRange() {
    LocalDate invalidEndDate = START_DATE.minusDays(1);
    
    Object[] parameters = {START_DATE, invalidEndDate, TARGET_CALENDAR, TARGET_DATE};
    CommandResult result = executor.execute(parameters);
    
    assertFalse(result.isSuccess());
    assertEquals("Invalid date range: end date cannot be before start date", result.getMessage());
  }

  @Test
  public void testExecuteNoEventsInRange() {
    // Use date range with no events
    LocalDate futureStart = LocalDate.of(2024, 1, 1);
    LocalDate futureEnd = LocalDate.of(2024, 1, 2);
    LocalDate futureTarget = LocalDate.of(2024, 1, 3);
    
    Object[] parameters = {futureStart, futureEnd, TARGET_CALENDAR, futureTarget};
    CommandResult result = executor.execute(parameters);
    
    assertTrue(result.isSuccess());
    assertEquals("No events found in the specified date range", result.getMessage());
    
    // Verify no events were created in target calendar
    assertEquals(0, targetCalendar.getAllEvents().size());
  }

  @Test
  public void testExecuteSingleEvent() {
    // Create single event
    LocalDateTime eventStart = LocalDateTime.of(2023, 12, 15, 10, 0);
    LocalDateTime eventEnd = LocalDateTime.of(2023, 12, 15, 11, 0);
    
    sourceCalendar.createEvent("Single Meeting", eventStart, eventEnd);
    
    Object[] parameters = {START_DATE, END_DATE, TARGET_CALENDAR, TARGET_DATE};
    CommandResult result = executor.execute(parameters);
    
    assertTrue(result.isSuccess());
    assertTrue(result.getMessage().contains("Successfully copied"));
    assertTrue(result.getMessage().contains("1"));
    
    // Verify one event was created in target calendar
    assertEquals(1, targetCalendar.getAllEvents().size());
  }

  @Test
  public void testExecuteWithSameTimezone() {
    // Create target calendar with same timezone
    calendarManager.createCalendar("SameTZ", UTC);
    InterfaceCalendar sameTzCalendar = calendarManager.getCalendar("SameTZ");
    
    LocalDateTime eventStart = LocalDateTime.of(2023, 12, 15, 10, 0);
    LocalDateTime eventEnd = LocalDateTime.of(2023, 12, 15, 11, 0);
    
    sourceCalendar.createEvent("Meeting", eventStart, eventEnd);
    
    Object[] parameters = {START_DATE, END_DATE, "SameTZ", TARGET_DATE};
    CommandResult result = executor.execute(parameters);
    
    assertTrue(result.isSuccess());
    assertEquals(1, sameTzCalendar.getAllEvents().size());
  }

  @Test
  public void testExecuteWithDifferentTimezones() {
    // Create events in source calendar
    LocalDateTime eventStart = LocalDateTime.of(2023, 12, 15, 10, 0);
    LocalDateTime eventEnd = LocalDateTime.of(2023, 12, 15, 11, 0);
    
    sourceCalendar.createEvent("Meeting", eventStart, eventEnd);
    
    Object[] parameters = {START_DATE, END_DATE, TARGET_CALENDAR, TARGET_DATE};
    CommandResult result = executor.execute(parameters);
    
    assertTrue(result.isSuccess());
    assertEquals(1, targetCalendar.getAllEvents().size());
    
    // Verify the event was converted to target timezone
    InterfaceEvent copiedEvent = targetCalendar.getAllEvents().get(0);
    assertEquals("Meeting", copiedEvent.getSubject());
  }

  @Test
  public void testExecuteWithMultipleEventsDifferentDates() {
    // Create events on different dates
    LocalDateTime event1Start = LocalDateTime.of(2023, 12, 15, 10, 0);
    LocalDateTime event1End = LocalDateTime.of(2023, 12, 15, 11, 0);
    LocalDateTime event2Start = LocalDateTime.of(2023, 12, 17, 14, 0);
    LocalDateTime event2End = LocalDateTime.of(2023, 12, 17, 15, 0);
    
    sourceCalendar.createEvent("Early Meeting", event1Start, event1End);
    sourceCalendar.createEvent("Late Meeting", event2Start, event2End);
    
    Object[] parameters = {START_DATE, END_DATE, TARGET_CALENDAR, TARGET_DATE};
    CommandResult result = executor.execute(parameters);
    
    assertTrue(result.isSuccess());
    assertTrue(result.getMessage().contains("Successfully copied"));
    assertTrue(result.getMessage().contains("2"));
    
    // Verify both events were created
    assertEquals(2, targetCalendar.getAllEvents().size());
  }

  @Test
  public void testExecuteWithNullParameters() {
    Object[] parameters = null;
    CommandResult result = executor.execute(parameters);
    
    assertFalse(result.isSuccess());
    assertTrue(result.getMessage().contains("Error copying events"));
  }

  @Test
  public void testExecuteWithInvalidParameterTypes() {
    Object[] parameters = {"invalid", "parameters", TARGET_CALENDAR, TARGET_DATE};
    CommandResult result = executor.execute(parameters);
    
    assertFalse(result.isSuccess());
    assertTrue(result.getMessage().contains("Error copying events"));
  }

  @Test
  public void testExecuteWithEmptyParameterArray() {
    Object[] parameters = new Object[0];
    CommandResult result = executor.execute(parameters);
    
    assertFalse(result.isSuccess());
    assertTrue(result.getMessage().contains("Error copying events"));
  }

  @Test
  public void testExecuteWithPartialParameters() {
    Object[] parameters = {START_DATE}; // Missing required parameters
    CommandResult result = executor.execute(parameters);
    
    assertFalse(result.isSuccess());
    assertTrue(result.getMessage().contains("Error copying events"));
  }

  @Test
  public void testExecuteWithEventsOnSameDay() {
    // Create multiple events on the same day
    LocalDateTime event1Start = LocalDateTime.of(2023, 12, 15, 10, 0);
    LocalDateTime event1End = LocalDateTime.of(2023, 12, 15, 11, 0);
    LocalDateTime event2Start = LocalDateTime.of(2023, 12, 15, 14, 0);
    LocalDateTime event2End = LocalDateTime.of(2023, 12, 15, 15, 0);
    
    sourceCalendar.createEvent("Morning Meeting", event1Start, event1End);
    sourceCalendar.createEvent("Afternoon Meeting", event2Start, event2End);
    
    Object[] parameters = {START_DATE, END_DATE, TARGET_CALENDAR, TARGET_DATE};
    CommandResult result = executor.execute(parameters);
    
    assertTrue(result.isSuccess());
    assertTrue(result.getMessage().contains("Successfully copied"));
    assertTrue(result.getMessage().contains("2"));
    
    // Verify both events were created with proper offset
    assertEquals(2, targetCalendar.getAllEvents().size());
  }
}