package calendar.controller.components.validators;

import java.util.Arrays;
import java.util.List;
import org.junit.Test;

/**
 * Test class for PrintEventsValidator.
 */
public class PrintEventsValidatorTest {

  private final PrintEventsValidator validator = new PrintEventsValidator();

  @Test
  public void testValidateOnFormatValid() {
    List<String> tokens = Arrays.asList("print", "events", "on", "2023-12-01");
    validator.validate(tokens);
  }

  @Test
  public void testValidateFromFormatValid() {
    List<String> tokens = Arrays.asList("print", "events", "from", "2023-12-01T10:00",
        "to", "2023-12-01T14:00");
    validator.validate(tokens);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testValidateCommandTooShort() {
    List<String> tokens = Arrays.asList("print", "events");
    validator.validate(tokens);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testValidateInvalidFirstToken() {
    List<String> tokens = Arrays.asList("invalid", "events", "on", "2023-12-01");
    validator.validate(tokens);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testValidateInvalidSecondToken() {
    List<String> tokens = Arrays.asList("print", "invalid", "on", "2023-12-01");
    validator.validate(tokens);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testValidateOnMissingDate() {
    List<String> tokens = Arrays.asList("print", "events", "on");
    validator.validate(tokens);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testValidateOnInvalidDate() {
    List<String> tokens = Arrays.asList("print", "events", "on", "invalid");
    validator.validate(tokens);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testValidateFromTooShort() {
    List<String> tokens = Arrays.asList("print", "events", "from", "2023-12-01T10:00");
    validator.validate(tokens);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testValidateFromInvalidDateTime() {
    List<String> tokens = Arrays.asList("print", "events", "from", "invalid",
        "to", "2023-12-01T14:00");
    validator.validate(tokens);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testValidateFromMissingToKeyword() {
    List<String> tokens = Arrays.asList("print", "events", "from", "2023-12-01T10:00",
        "wrong", "2023-12-01T14:00");
    validator.validate(tokens);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testValidateFromMissingToDateTime() {
    List<String> tokens = Arrays.asList("print", "events", "from", "2023-12-01T10:00", "to");
    validator.validate(tokens);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testValidateFromInvalidToDateTime() {
    List<String> tokens = Arrays.asList("print", "events", "from", "2023-12-01T10:00",
        "to", "invalid");
    validator.validate(tokens);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testValidateInvalidThirdToken() {
    List<String> tokens = Arrays.asList("print", "events", "invalid", "2023-12-01");
    validator.validate(tokens);
  }
}