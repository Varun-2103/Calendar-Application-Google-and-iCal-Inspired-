package calendar.controller.components.executors;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import calendar.controller.CommandResult;
import calendar.model.CalendarManager;
import calendar.model.InterfaceCalendarManager;
import java.time.LocalDateTime;
import java.time.ZoneId;
import org.junit.Before;
import org.junit.Test;

/**
 * Unit test for EditEventsExecutor to increase branch coverage.
 */
public class EditEventsExecutorTest {

  private EditEventsExecutor executor;
  private InterfaceCalendarManager calendarManager;

  /**
   * Sets up test fixtures before each test.
   */
  @Before
  public void setUp() {
    calendarManager = new CalendarManager();
    executor = new EditEventsExecutor(calendarManager);
    calendarManager.createCalendar("Test", ZoneId.systemDefault());
    calendarManager.useCalendar("Test");
  }

  @Test
  public void testExecuteNullParametersReturnsError() {
    CommandResult result = executor.execute(null);

    assertFalse(result.isSuccess());
    assertEquals("Expected 4 parameters for edit events", result.getMessage());
  }

  @Test
  public void testExecuteInvalidParameterCountReturnsError() {
    Object[] parameters = {"subject", "Meeting", LocalDateTime.now()};
    CommandResult result = executor.execute(parameters);

    assertFalse(result.isSuccess());
    assertEquals("Expected 4 parameters for edit events", result.getMessage());
  }

  @Test
  public void testExecuteNoActiveCalendarReturnsError() {
    InterfaceCalendarManager emptyManager = new CalendarManager();
    EditEventsExecutor emptyExecutor = new EditEventsExecutor(emptyManager);
    String property = "subject";
    String subject = "Meeting";
    LocalDateTime fromDateTime = LocalDateTime.of(2023, 12, 15, 10, 0);
    Object newValue = "Updated Meeting";
    Object[] parameters = {property, subject, fromDateTime, newValue};

    CommandResult result = emptyExecutor.execute(parameters);

    assertFalse(result.isSuccess());
    assertEquals(
        "Error editing events: No calendar is currently active. Use 'use calendar' command first.",
        result.getMessage());
  }

  @Test
  public void testExecuteNoMatchingEventsReturnsError() {
    String property = "subject";
    String subject = "NonExistent";
    LocalDateTime fromDateTime = LocalDateTime.of(2023, 12, 15, 10, 0);
    Object newValue = "Updated Meeting";
    Object[] parameters = {property, subject, fromDateTime, newValue};

    CommandResult result = executor.execute(parameters);

    assertFalse(result.isSuccess());
    assertEquals("No matching events found from specified time", result.getMessage());
  }

  @Test
  public void testEditSubjectSuccess() {
    createMultipleTestEvents();
    String property = "subject";
    String subject = "Meeting";
    LocalDateTime fromDateTime = LocalDateTime.of(2023, 12, 15, 10, 0);
    Object newValue = "Updated Meeting";
    Object[] parameters = {property, subject, fromDateTime, newValue};

    CommandResult result = executor.execute(parameters);

    assertTrue(result.isSuccess());
    assertEquals("Successfully edited 2 events", result.getMessage());
  }

  @Test
  public void testEditLocationSuccess() {
    createMultipleTestEvents();
    String property = "location";
    String subject = "Meeting";
    LocalDateTime fromDateTime = LocalDateTime.of(2023, 12, 15, 10, 0);
    Object newValue = "Conference Room";
    Object[] parameters = {property, subject, fromDateTime, newValue};

    CommandResult result = executor.execute(parameters);

    assertTrue(result.isSuccess());
    assertEquals("Successfully edited 2 events", result.getMessage());
  }

  @Test
  public void testEditDescriptionSuccess() {
    createMultipleTestEvents();
    String property = "description";
    String subject = "Meeting";
    LocalDateTime fromDateTime = LocalDateTime.of(2023, 12, 15, 10, 0);
    Object newValue = "Team discussion";
    Object[] parameters = {property, subject, fromDateTime, newValue};

    CommandResult result = executor.execute(parameters);

    assertTrue(result.isSuccess());
    assertEquals("Successfully edited 2 events", result.getMessage());
  }

  @Test
  public void testEditStatusSuccess() {
    createMultipleTestEvents();
    String property = "status";
    String subject = "Meeting";
    LocalDateTime fromDateTime = LocalDateTime.of(2023, 12, 15, 10, 0);
    Object newValue = "private";
    Object[] parameters = {property, subject, fromDateTime, newValue};

    CommandResult result = executor.execute(parameters);

    assertTrue(result.isSuccess());
    assertEquals("Successfully edited 2 events", result.getMessage());
  }

  @Test
  public void testEditStartSuccess() {
    createMultipleTestEvents();
    String property = "start";
    String subject = "Meeting";
    LocalDateTime fromDateTime = LocalDateTime.of(2023, 12, 15, 10, 0);
    Object newValue = LocalDateTime.of(2023, 12, 15, 9, 0);
    Object[] parameters = {property, subject, fromDateTime, newValue};

    CommandResult result = executor.execute(parameters);

    assertTrue(result.isSuccess());
    assertEquals("Successfully edited 2 events", result.getMessage());
  }

  @Test
  public void testEditStartWithConflictReturnsError() {
    createMultipleTestEvents();
    createConflictingEvent();
    String property = "start";
    String subject = "Meeting";
    LocalDateTime fromDateTime = LocalDateTime.of(2023, 12, 15, 10, 0);
    Object newValue = LocalDateTime.of(2023, 12, 15, 11, 30);
    Object[] parameters = {property, subject, fromDateTime, newValue};

    CommandResult result = executor.execute(parameters);

    assertFalse(result.isSuccess());
    assertEquals("Event conflicts with existing event", result.getMessage());
  }

  @Test
  public void testEditInvalidPropertyReturnsError() {
    createMultipleTestEvents();
    String property = "invalid";
    String subject = "Meeting";
    LocalDateTime fromDateTime = LocalDateTime.of(2023, 12, 15, 10, 0);
    Object newValue = "value";
    Object[] parameters = {property, subject, fromDateTime, newValue};

    CommandResult result = executor.execute(parameters);

    assertFalse(result.isSuccess());
    assertEquals("Invalid property: invalid", result.getMessage());
  }

  @Test
  public void testEditEventsBeforeFromDateTimeNotAffected() {
    createMultipleTestEvents();
    String property = "subject";
    String subject = "Meeting";
    LocalDateTime fromDateTime = LocalDateTime.of(2023, 12, 16, 11, 0);
    Object newValue = "Updated Meeting";
    Object[] parameters = {property, subject, fromDateTime, newValue};

    CommandResult result = executor.execute(parameters);

    assertFalse(result.isSuccess());
    assertEquals("No matching events found from specified time", result.getMessage());
  }

  private void createMultipleTestEvents() {
    CreateEventExecutor createExecutor = new CreateEventExecutor(calendarManager);
    
    Object[] event1Params = {"Meeting", LocalDateTime.of(2023, 12, 15, 10, 0),
                             LocalDateTime.of(2023, 12, 15, 11, 0)};
    createExecutor.execute(event1Params);
    
    Object[] event2Params = {"Meeting", LocalDateTime.of(2023, 12, 16, 10, 0),
                             LocalDateTime.of(2023, 12, 16, 11, 0)};
    createExecutor.execute(event2Params);
  }

  private void createConflictingEvent() {
    CreateEventExecutor createExecutor = new CreateEventExecutor(calendarManager);
    Object[] conflictParams = {"Conflict", LocalDateTime.of(2023, 12, 15, 11, 0),
                               LocalDateTime.of(2023, 12, 15, 12, 0)};
    createExecutor.execute(conflictParams);
  }
}