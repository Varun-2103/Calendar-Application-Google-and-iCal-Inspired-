package calendar.controller.components.parsers;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;
import org.junit.Test;

/**
 * Test suite for EditSeriesParser.
 * Tests parsing of edit series commands with various properties and formats.
 */
public class EditSeriesParserTest {

  private static final LocalDateTime FROM_DATETIME = LocalDateTime.of(2023, 12, 15, 10, 0);

  @Test
  public void testParseEditSubjectProperty() {
    EditSeriesParser parser = new EditSeriesParser();
    List<String> tokens = Arrays.asList("edit", "series", "subject", "Team Meeting",
        "from", "2023-12-15T10:00", "with", "Updated Meeting");

    Object[] result = parser.parse(tokens);

    assertNotNull(result);
    assertEquals(4, result.length);
    assertEquals("subject", result[0]);
    assertEquals("Team Meeting", result[1]);
    assertEquals(FROM_DATETIME, result[2]);
    assertEquals("Updated Meeting", result[3]);
  }

  @Test
  public void testParseEditLocationProperty() {
    EditSeriesParser parser = new EditSeriesParser();
    List<String> tokens = Arrays.asList("edit", "series", "location", "Team Meeting",
        "from", "2023-12-15T10:00", "with", "Conference Room");

    Object[] result = parser.parse(tokens);

    assertNotNull(result);
    assertEquals(4, result.length);
    assertEquals("location", result[0]);
    assertEquals("Team Meeting", result[1]);
    assertEquals(FROM_DATETIME, result[2]);
    assertEquals("Conference Room", result[3]);
  }

  @Test
  public void testParseEditDescriptionProperty() {
    EditSeriesParser parser = new EditSeriesParser();
    List<String> tokens = Arrays.asList("edit", "series", "description", "Team Meeting",
        "from", "2023-12-15T10:00", "with", "Weekly team sync");

    Object[] result = parser.parse(tokens);

    assertNotNull(result);
    assertEquals(4, result.length);
    assertEquals("description", result[0]);
    assertEquals("Team Meeting", result[1]);
    assertEquals(FROM_DATETIME, result[2]);
    assertEquals("Weekly team sync", result[3]);
  }

  @Test
  public void testParseEditStartProperty() {
    EditSeriesParser parser = new EditSeriesParser();
    List<String> tokens = Arrays.asList("edit", "series", "start", "Team Meeting",
        "from", "2023-12-15T10:00", "with", "2023-12-15T09:00");

    Object[] result = parser.parse(tokens);

    assertNotNull(result);
    assertEquals(4, result.length);
    assertEquals("start", result[0]);
    assertEquals("Team Meeting", result[1]);
    assertEquals(FROM_DATETIME, result[2]);
    assertEquals("2023-12-15T09:00",
        result[3]);
  }

  @Test
  public void testParseEditEndProperty() {
    EditSeriesParser parser = new EditSeriesParser();
    List<String> tokens = Arrays.asList("edit", "series", "end", "Team Meeting",
        "from", "2023-12-15T10:00", "with", "2023-12-15T11:00");

    Object[] result = parser.parse(tokens);

    assertNotNull(result);
    assertEquals(4, result.length);
    assertEquals("end", result[0]);
    assertEquals("Team Meeting", result[1]);
    assertEquals(FROM_DATETIME, result[2]);
    assertEquals("2023-12-15T11:00", result[3]);
  }

  @Test
  public void testParseEditStatusProperty() {
    EditSeriesParser parser = new EditSeriesParser();
    List<String> tokens = Arrays.asList("edit", "series", "status", "Team Meeting",
        "from", "2023-12-15T10:00", "with", "PRIVATE");

    Object[] result = parser.parse(tokens);

    assertNotNull(result);
    assertEquals(4, result.length);
    assertEquals("status", result[0]);
    assertEquals("Team Meeting", result[1]);
    assertEquals(FROM_DATETIME, result[2]);
    assertEquals("private", result[3]); // Should be converted to lowercase
  }

  @Test
  public void testParseWithQuotedSubject() {
    EditSeriesParser parser = new EditSeriesParser();
    List<String> tokens = Arrays.asList("edit", "series", "location", "\"Team Meeting\"",
        "from", "2023-12-15T10:00", "with", "Conference Room");

    Object[] result = parser.parse(tokens);

    assertNotNull(result);
    assertEquals(4, result.length);
    assertEquals("location", result[0]);
    assertEquals("Team Meeting", result[1]);
    assertEquals(FROM_DATETIME, result[2]);
    assertEquals("Conference Room", result[3]);
  }

  @Test
  public void testParseWithQuotedNewValue() {
    EditSeriesParser parser = new EditSeriesParser();
    List<String> tokens = Arrays.asList("edit", "series", "description", "Team Meeting",
        "from", "2023-12-15T10:00", "with", "\"Weekly team sync meeting\"");

    Object[] result = parser.parse(tokens);

    assertNotNull(result);
    assertEquals(4, result.length);
    assertEquals("description", result[0]);
    assertEquals("Team Meeting", result[1]);
    assertEquals(FROM_DATETIME, result[2]);
    assertEquals("Weekly team sync meeting", result[3]);
  }

  @Test
  public void testParseWithDifferentDateTime() {
    EditSeriesParser parser = new EditSeriesParser();
    List<String> tokens = Arrays.asList("edit", "series", "subject", "Meeting",
        "from", "2023-12-20T14:30", "with", "Updated Meeting");

    Object[] result = parser.parse(tokens);

    assertNotNull(result);
    assertEquals(4, result.length);
    assertEquals("subject", result[0]);
    assertEquals("Meeting", result[1]);
    assertEquals(LocalDateTime.of(2023, 12, 20, 14, 30), result[2]);
    assertEquals("Updated Meeting", result[3]);
  }

  @Test
  public void testParseWithEmptyValues() {
    EditSeriesParser parser = new EditSeriesParser();
    List<String> tokens = Arrays.asList("edit", "series", "description", "Meeting",
        "from", "2023-12-15T10:00", "with", "");

    Object[] result = parser.parse(tokens);

    assertNotNull(result);
    assertEquals(4, result.length);
    assertEquals("description", result[0]);
    assertEquals("Meeting", result[1]);
    assertEquals(FROM_DATETIME, result[2]);
    assertEquals("", result[3]);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testParseUnknownPropertyThrowsException() {
    EditSeriesParser parser = new EditSeriesParser();
    List<String> tokens = Arrays.asList("edit", "series", "unknown", "Team Meeting",
        "from", "2023-12-15T10:00", "with", "value");

    parser.parse(tokens);
  }

  @Test
  public void testParseWithMixedCaseProperty() {
    EditSeriesParser parser = new EditSeriesParser();
    List<String> tokens = Arrays.asList("edit", "series", "STATUS", "Team Meeting",
        "from", "2023-12-15T10:00", "with", "PUBLIC");

    Object[] result = parser.parse(tokens);

    assertNotNull(result);
    assertEquals(4, result.length);
    assertEquals("status", result[0]); // Should be converted to lowercase
    assertEquals("Team Meeting", result[1]);
    assertEquals(FROM_DATETIME, result[2]);
    assertEquals("public", result[3]); // Status should be converted to lowercase
  }

  @Test
  public void testParseWithSpecialCharacters() {
    EditSeriesParser parser = new EditSeriesParser();
    List<String> tokens = Arrays.asList("edit", "series", "location", "Meeting",
        "from", "2023-12-15T10:00", "with", "Room #101, Building A");

    Object[] result = parser.parse(tokens);

    assertNotNull(result);
    assertEquals(4, result.length);
    assertEquals("location", result[0]);
    assertEquals("Meeting", result[1]);
    assertEquals(FROM_DATETIME, result[2]);
    assertEquals("Room #101, Building A", result[3]);
  }

  @Test
  public void testParseWithTimeInStartProperty() {
    EditSeriesParser parser = new EditSeriesParser();
    List<String> tokens = Arrays.asList("edit", "series", "start", "Daily Standup",
        "from", "2023-12-15T09:00", "with", "09:30");

    Object[] result = parser.parse(tokens);

    assertNotNull(result);
    assertEquals(4, result.length);
    assertEquals("start", result[0]);
    assertEquals("Daily Standup", result[1]);
    assertEquals(LocalDateTime.of(2023, 12, 15, 9, 0), result[2]);
    assertEquals("09:30", result[3]); // Start property is treated as string
  }

  @Test
  public void testParseWithTimeInEndProperty() {
    EditSeriesParser parser = new EditSeriesParser();
    List<String> tokens = Arrays.asList("edit", "series", "end", "Daily Standup",
        "from", "2023-12-15T09:00", "with", "10:00");

    Object[] result = parser.parse(tokens);

    assertNotNull(result);
    assertEquals(4, result.length);
    assertEquals("end", result[0]);
    assertEquals("Daily Standup", result[1]);
    assertEquals(LocalDateTime.of(2023, 12, 15, 9, 0), result[2]);
    assertEquals("10:00", result[3]); // End property is treated as string
  }
}