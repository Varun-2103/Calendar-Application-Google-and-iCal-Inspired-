package calendar.controller.components.parsers;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;
import org.junit.Before;
import org.junit.Test;

/**
 * Unit test for CreateEventParser without external dependencies.
 */
public class CreateEventParserTest {

  private CreateEventParser parser;

  /**
   * Sets up test fixtures before each test.
   */
  @Before
  public void setUp() {
    parser = new CreateEventParser();
  }

  @Test
  public void testCreateEventParserConstructorCreatesParser() {
    assertNotNull(parser);
  }

  @Test
  public void testParseSingleTimedEvent() {
    List<String> tokens = Arrays.asList("create", "event", "\"Team Meeting\"", "from", 
                                       "2023-12-15T10:00", "to", "2023-12-15T11:00");
    
    try {
      Object[] result = parser.parse(tokens);
      assertNotNull(result);
      assertEquals(3, result.length);
      assertEquals("Team Meeting", result[0]);
      assertEquals(LocalDateTime.of(2023, 12, 15, 10, 0), result[1]);
      assertEquals(LocalDateTime.of(2023, 12, 15, 11, 0), result[2]);
    } catch (Exception e) {
      fail("Valid timed event should not throw exception: " + e.getMessage());
    }
  }

  @Test
  public void testParseAllDayEvent() {
    List<String> tokens = Arrays.asList("create", "event", "\"Conference\"", "on", "2023-12-15");
    
    try {
      Object[] result = parser.parse(tokens);
      assertNotNull(result);
      assertEquals(3, result.length);
      assertEquals("Conference", result[0]);
      assertEquals(LocalDateTime.of(2023, 12, 15, 8, 0), result[1]);
      assertEquals(LocalDateTime.of(2023, 12, 15, 17, 0), result[2]);
    } catch (Exception e) {
      fail("Valid all-day event should not throw exception: " + e.getMessage());
    }
  }

  @Test
  public void testParseRecurringEventWithOccurrences() {
    List<String> tokens = Arrays.asList("create", "event", "\"Weekly Meeting\"", "from", 
                                       "2023-12-15T10:00", "to", "2023-12-15T11:00", 
                                       "repeats", "M", "for", "5", "times");
    
    try {
      Object[] result = parser.parse(tokens);
      assertNotNull(result);
      assertEquals(6, result.length);
      assertEquals("Weekly Meeting", result[0]);
      assertEquals(LocalDateTime.of(2023, 12, 15, 10, 0), result[1]);
      assertEquals(LocalDateTime.of(2023, 12, 15, 11, 0), result[2]);
      assertEquals("M", result[3]);
      assertEquals(5, result[4]);
      assertEquals(true, result[5]);
    } catch (Exception e) {
      fail("Valid recurring event should not throw exception: " + e.getMessage());
    }
  }

  @Test
  public void testParseRecurringEventWithUntilDate() {
    List<String> tokens = Arrays.asList("create", "event", "\"Daily Standup\"", "from", 
                                       "2023-12-15T09:00", "to", "2023-12-15T09:30", 
                                       "repeats", "MTWRF", 
                                       "until", "2023-12-31");
    
    try {
      Object[] result = parser.parse(tokens);
      assertNotNull(result);
      assertEquals(6, result.length);
      assertEquals("Daily Standup", result[0]);
      assertEquals(LocalDateTime.of(2023, 12, 15, 9, 0), result[1]);
      assertEquals(LocalDateTime.of(2023, 12, 15, 9, 30), result[2]);
      assertEquals("MTWRF", result[3]);
      assertEquals(LocalDate.of(2023, 12, 31), result[4]);
      assertEquals(false, result[5]);
    } catch (Exception e) {
      fail("Valid recurring event should not throw exception: " + e.getMessage());
    }
  }

  @Test
  public void testParseEventWithUnquotedSubject() {
    List<String> tokens = Arrays.asList("create", "event", "Meeting", "from", 
                                       "2023-12-15T10:00", "to", "2023-12-15T11:00");
    
    try {
      Object[] result = parser.parse(tokens);
      assertNotNull(result);
      assertEquals(3, result.length);
      assertEquals("Meeting", result[0]);
    } catch (Exception e) {
      fail("Valid event with unquoted subject should not throw exception: " + e.getMessage());
    }
  }

  @Test
  public void testParseEventWithEmptyQuotedSubject() {
    List<String> tokens = Arrays.asList("create", "event", "\"\"", "from", 
                                       "2023-12-15T10:00", "to", "2023-12-15T11:00");
    
    try {
      Object[] result = parser.parse(tokens);
      assertNotNull(result);
      assertEquals(3, result.length);
      assertEquals("", result[0]);
    } catch (Exception e) {
      fail("Valid event with empty subject should not throw exception: " + e.getMessage());
    }
  }

  @Test
  public void testParseEventWithSubjectContainingSpaces() {
    List<String> tokens = Arrays.asList("create", "event", "\"Team Meeting - Weekly Sync\"", "from",
                                       "2023-12-15T10:00", "to", "2023-12-15T11:00");
    
    try {
      Object[] result = parser.parse(tokens);
      assertNotNull(result);
      assertEquals(3, result.length);
      assertEquals("Team Meeting - Weekly Sync", result[0]);
    } catch (Exception e) {
      fail("Valid event with spaced subject should not throw exception: " + e.getMessage());
    }
  }

  @Test
  public void testParseEventWithCaseInsensitiveKeywords() {
    List<String> tokens = Arrays.asList("create", "event", "\"Meeting\"", "FROM", 
                                       "2023-12-15T10:00", "TO", "2023-12-15T11:00");
    
    try {
      Object[] result = parser.parse(tokens);
      assertNotNull(result);
      assertEquals(3, result.length);
      assertEquals("Meeting", result[0]);
    } catch (Exception e) {
      fail("Case insensitive keywords should be valid: " + e.getMessage());
    }
  }

  @Test(expected = IllegalArgumentException.class)
  public void testParseEventWithoutOnOrFromThrowsException() {
    List<String> tokens = Arrays.asList("create", "event", "\"Meeting\"", "at", "2023-12-15");
    parser.parse(tokens);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testParseEventWithIncompleteFromClauseThrowsException() {
    List<String> tokens = Arrays.asList("create", "event", "\"Meeting\"", "from",
                                       "2023-12-15T10:00");
    parser.parse(tokens);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testParseEventWithIncompleteOnClauseThrowsException() {
    List<String> tokens = Arrays.asList("create", "event", "\"Meeting\"", "on");
    parser.parse(tokens);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testParseRecurringEventWithoutWeekdaysThrowsException() {
    List<String> tokens = Arrays.asList("create", "event", "\"Meeting\"", "from", 
                                       "2023-12-15T10:00", "to", "2023-12-15T11:00", "repeats");
    parser.parse(tokens);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testParseRecurringEventWithIncompleteForClauseThrowsException() {
    List<String> tokens = Arrays.asList("create", "event", "\"Meeting\"", "from", 
                                       "2023-12-15T10:00", "to", "2023-12-15T11:00", 
                                       "repeats", "Monday", "for", "5");
    parser.parse(tokens);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testParseRecurringEventWithIncompleteUntilClauseThrowsException() {
    List<String> tokens = Arrays.asList("create", "event", "\"Meeting\"", "from", 
                                       "2023-12-15T10:00", "to", "2023-12-15T11:00", 
                                       "repeats", "Monday", "until");
    parser.parse(tokens);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testParseRecurringEventWithoutForOrUntilThrowsException() {
    List<String> tokens = Arrays.asList("create", "event", "\"Meeting\"", "from", 
                                       "2023-12-15T10:00", "to", "2023-12-15T11:00", 
                                       "repeats", "Monday", "invalid");
    parser.parse(tokens);
  }

  @Test
  public void testParseAllDayEventWithOnButNotFrom() {
    List<String> tokens = Arrays.asList("create", "event", "\"Conference\"", "on", "2023-12-15");
    
    try {
      Object[] result = parser.parse(tokens);
      assertNotNull(result);
      assertEquals(3, result.length);
      assertEquals("Conference", result[0]);
      assertEquals(LocalDateTime.of(2023, 12, 15, 8, 0), result[1]);
      assertEquals(LocalDateTime.of(2023, 12, 15, 17, 0), result[2]);
    } catch (Exception e) {
      fail("Valid all-day event should not throw exception: " + e.getMessage());
    }
  }

  @Test
  public void testParseSeriesWithForTimesAndExtraParameters() {
    List<String> tokens = Arrays.asList("create", "event", "\"Weekly Meeting\"", "from", 
                                       "2023-12-15T10:00", "to", "2023-12-15T11:00", 
                                       "repeats", "M", "for", "5", "times", "extra");
    
    try {
      Object[] result = parser.parse(tokens);
      assertNotNull(result);
      assertEquals(6, result.length);
      assertEquals("Weekly Meeting", result[0]);
      assertEquals(5, result[4]);
      assertEquals(true, result[5]);
    } catch (Exception e) {
      fail("Valid series with extra parameters should not throw exception: " + e.getMessage());
    }
  }

  @Test(expected = IllegalArgumentException.class)
  public void testParseSeriesWithInvalidForTimesFormat() {
    List<String> tokens = Arrays.asList("create", "event", "\"Meeting\"", "from", 
                                       "2023-12-15T10:00", "to", "2023-12-15T11:00", 
                                       "repeats", "M", "for", "5", "invalid");
    parser.parse(tokens);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testParseSeriesWithIncompleteForTimesFormat() {
    List<String> tokens = Arrays.asList("create", "event", "\"Meeting\"", "from", 
                                       "2023-12-15T10:00", "to", "2023-12-15T11:00", 
                                       "repeats", "M", "for", "5");
    parser.parse(tokens);
  }

  @Test
  public void testParseSeriesWithUntilDate() {
    List<String> tokens = Arrays.asList("create", "event", "\"Daily Meeting\"", "from", 
                                       "2023-12-15T10:00", "to", "2023-12-15T11:00", 
                                       "repeats", "M", "until", "2023-12-31");
    
    try {
      Object[] result = parser.parse(tokens);
      assertNotNull(result);
      assertEquals(6, result.length);
      assertEquals("Daily Meeting", result[0]);
      assertEquals(LocalDate.of(2023, 12, 31), result[4]);
      assertEquals(false, result[5]);
    } catch (Exception e) {
      fail("Valid series with until date should not throw exception: " + e.getMessage());
    }
  }

  @Test(expected = IllegalArgumentException.class)
  public void testParseSeriesWithIncompleteUntilFormat() {
    List<String> tokens = Arrays.asList("create", "event", "\"Meeting\"", "from", 
                                       "2023-12-15T10:00", "to", "2023-12-15T11:00", 
                                       "repeats", "M", "until");
    parser.parse(tokens);
  }



  @Test
  public void testRemoveQuotesWithQuotedString() {
    List<String> tokens = Arrays.asList("create", "event", "\"Quoted Meeting\"", "from", 
                                       "2023-12-15T10:00", "to", "2023-12-15T11:00");
    
    try {
      Object[] result = parser.parse(tokens);
      assertNotNull(result);
      assertEquals("Quoted Meeting", result[0]);
    } catch (Exception e) {
      fail("Valid quoted string should not throw exception: " + e.getMessage());
    }
  }

  @Test
  public void testFindKeywordIndexWithMatchingKeyword() {
    List<String> tokens = Arrays.asList("create", "event", "\"Meeting\"", "from", 
                                       "2023-12-15T10:00", "to", "2023-12-15T11:00");
    
    try {
      Object[] result = parser.parse(tokens);
      assertNotNull(result);
      assertEquals(3, result.length);
    } catch (Exception e) {
      fail("Valid tokens with matching keyword should not throw exception: " + e.getMessage());
    }
  }

  @Test
  public void testParseEventWithBothOnAndFrom() {
    // Contains both "on" and "from" - should take the "from" path (from takes precedence)
    List<String> tokens = Arrays.asList("create", "event", "\"Meeting\"", "on", "2023-12-15",
                                       "from", "2023-12-15T10:00", "to", "2023-12-15T11:00");
    
    try {
      Object[] result = parser.parse(tokens);
      assertNotNull(result);
      assertEquals(3, result.length);
      assertEquals("Meeting", result[0]);
      assertEquals(LocalDateTime.of(2023, 12, 15, 10, 0), result[1]);
      assertEquals(LocalDateTime.of(2023, 12, 15, 11, 0), result[2]);
    } catch (Exception e) {
      fail("Event with both on and from should not throw exception: " + e.getMessage());
    }
  }

  @Test(expected = IllegalArgumentException.class)
  public void testParseRecurringEventWithWeekdaysButNoForOrUntil() {
    // Has repeats and weekdays but no "for" or "until" keyword
    List<String> tokens = Arrays.asList("create", "event", "\"Meeting\"", "from", 
                                       "2023-12-15T10:00", "to", "2023-12-15T11:00", 
                                       "repeats", "M");
    parser.parse(tokens);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testParseRecurringEventWithInvalidKeywordAfterWeekdays() {
    // Has repeats and weekdays but invalid continuation keyword
    List<String> tokens = Arrays.asList("create", "event", "\"Meeting\"", "from", 
                                       "2023-12-15T10:00", "to", "2023-12-15T11:00", 
                                       "repeats", "M", "invalid");
    parser.parse(tokens);
  }

  @Test
  public void testParseEventWithPartialStartQuote() {
    // Subject has only opening quote, should not be removed
    List<String> tokens = Arrays.asList("create", "event", "\"Meeting", "from", 
                                       "2023-12-15T10:00", "to", "2023-12-15T11:00");
    
    try {
      Object[] result = parser.parse(tokens);
      assertNotNull(result);
      assertEquals("\"Meeting", result[0]);
    } catch (Exception e) {
      fail("Partial start quote should not throw exception: " + e.getMessage());
    }
  }

  @Test
  public void testParseEventWithPartialEndQuote() {
    // Subject has only closing quote, should not be removed
    List<String> tokens = Arrays.asList("create", "event", "Meeting\"", "from", 
                                       "2023-12-15T10:00", "to", "2023-12-15T11:00");
    
    try {
      Object[] result = parser.parse(tokens);
      assertNotNull(result);
      assertEquals("Meeting\"", result[0]);
    } catch (Exception e) {
      fail("Partial end quote should not throw exception: " + e.getMessage());
    }
  }

  @Test
  public void testParseEventWithSubjectContainingOnlyQuotes() {
    // Subject is just quotes, should be removed to empty string
    List<String> tokens = Arrays.asList("create", "event", "\"\"", "from", 
                                       "2023-12-15T10:00", "to", "2023-12-15T11:00");
    
    try {
      Object[] result = parser.parse(tokens);
      assertNotNull(result);
      assertEquals("", result[0]);
    } catch (Exception e) {
      fail("Empty quoted subject should not throw exception: " + e.getMessage());
    }
  }

  @Test(expected = IllegalArgumentException.class)
  public void testParseEventWithInvalidDateTimeFormat() {
    // Invalid date-time format should cause parsing to fail
    List<String> tokens = Arrays.asList("create", "event", "\"Meeting\"", "from", 
                                       "invalid-date", "to", "2023-12-15T11:00");
    parser.parse(tokens);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testParseEventWithInvalidDateFormat() {
    // Invalid date format should cause parsing to fail
    List<String> tokens = Arrays.asList("create", "event", "\"Meeting\"", "on", 
                                       "invalid-date");
    parser.parse(tokens);
  }
}