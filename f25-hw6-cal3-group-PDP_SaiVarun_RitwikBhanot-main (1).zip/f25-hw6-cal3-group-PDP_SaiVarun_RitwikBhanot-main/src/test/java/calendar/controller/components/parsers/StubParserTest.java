package calendar.controller.components.parsers;

import java.util.Arrays;
import java.util.List;
import org.junit.Test;

/**
 * Test class for StubParser.
 */
public class StubParserTest {

  @Test(expected = UnsupportedOperationException.class)
  public void testParseThrowsUnsupportedOperationException() {
    StubParser parser = new StubParser("test command");
    List<String> tokens = Arrays.asList("test", "command");
    parser.parse(tokens);
  }
}