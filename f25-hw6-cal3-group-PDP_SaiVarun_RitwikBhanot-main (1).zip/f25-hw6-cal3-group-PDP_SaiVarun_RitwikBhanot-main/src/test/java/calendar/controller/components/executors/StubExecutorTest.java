package calendar.controller.components.executors;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import calendar.controller.CommandResult;
import org.junit.Test;

/**
 * Test class for StubExecutor.
 */
public class StubExecutorTest {

  @Test
  public void testExecuteReturnsNotImplementedMessage() {
    StubExecutor executor = new StubExecutor("test command");
    Object[] params = new Object[]{};

    CommandResult result = executor.execute(params);

    assertFalse(result.isSuccess());
    assertTrue(result.getMessage().contains("test command"));
    assertTrue(result.getMessage().contains("not implemented yet"));
  }
}