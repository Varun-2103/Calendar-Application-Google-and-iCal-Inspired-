package calendar.controller.components.executors;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import calendar.controller.CommandResult;
import calendar.model.CalendarManager;
import calendar.model.InterfaceCalendar;
import calendar.model.InterfaceCalendarManager;
import java.time.LocalDateTime;
import java.time.ZoneId;
import org.junit.Before;
import org.junit.Test;

/**
 * Test class for EditSeriesExecutor.
 */
public class EditSeriesExecutorTest {

  private EditSeriesExecutor executor;
  private InterfaceCalendarManager calendarManager;

  /**
   * Setup for the test class.
   */
  @Before
  public void setUp() {
    calendarManager = new CalendarManager();
    executor = new EditSeriesExecutor(calendarManager);
  }

  @Test
  public void testExecuteNullParameters() {
    CommandResult result = executor.execute(null);
    assertFalse(result.isSuccess());
    assertEquals("Expected 4 parameters for edit series", result.getMessage());
  }

  @Test
  public void testExecuteWrongNumberOfParameters() {
    Object[] params = new Object[]{"subject", "Meeting"};
    CommandResult result = executor.execute(params);
    assertFalse(result.isSuccess());
    assertEquals("Expected 4 parameters for edit series", result.getMessage());
  }

  @Test
  public void testExecuteNoActiveCalendar() {
    Object[] params = new Object[]{"subject", "Meeting", LocalDateTime.now(), "New Meeting"};
    CommandResult result = executor.execute(params);
    assertFalse(result.isSuccess());
    assertTrue(result.getMessage().contains("Error editing series"));
  }

  @Test
  public void testExecuteEditSubject() {
    calendarManager.createCalendar("Test", ZoneId.systemDefault());
    calendarManager.useCalendar("Test");
    InterfaceCalendar calendar = calendarManager.getActiveCalendar();
    calendar.createEvent("Meeting", LocalDateTime.of(2023, 12, 1, 10, 0),
        LocalDateTime.of(2023, 12, 1, 11, 0));

    Object[] params = new Object[]{"subject", "Meeting", LocalDateTime.of(2023, 12, 1, 10, 0),
        "New Meeting"};
    CommandResult result = executor.execute(params);
    assertTrue(result.isSuccess());
    assertEquals("Successfully edited 1 events in series", result.getMessage());
  }

  @Test
  public void testExecuteEditLocation() {
    calendarManager.createCalendar("Test", ZoneId.systemDefault());
    calendarManager.useCalendar("Test");
    InterfaceCalendar calendar = calendarManager.getActiveCalendar();
    calendar.createEvent("Meeting", LocalDateTime.of(2023, 12, 1, 10, 0),
        LocalDateTime.of(2023, 12, 1, 11, 0));

    Object[] params = new Object[]{"location", "Meeting", LocalDateTime.of(2023, 12, 1, 10, 0),
        "Room 101"};
    CommandResult result = executor.execute(params);
    assertTrue(result.isSuccess());
  }

  @Test
  public void testExecuteEditDescription() {
    calendarManager.createCalendar("Test", ZoneId.systemDefault());
    calendarManager.useCalendar("Test");
    InterfaceCalendar calendar = calendarManager.getActiveCalendar();
    calendar.createEvent("Meeting", LocalDateTime.of(2023, 12, 1, 10, 0),
        LocalDateTime.of(2023, 12, 1, 11, 0));

    Object[] params = new Object[]{"description", "Meeting", LocalDateTime.of(2023, 12, 1, 10, 0),
        "Details"};
    CommandResult result = executor.execute(params);
    assertTrue(result.isSuccess());
  }

  @Test
  public void testExecuteEditStatus() {
    calendarManager.createCalendar("Test", ZoneId.systemDefault());
    calendarManager.useCalendar("Test");
    InterfaceCalendar calendar = calendarManager.getActiveCalendar();
    calendar.createEvent("Meeting", LocalDateTime.of(2023, 12, 1, 10, 0),
        LocalDateTime.of(2023, 12, 1, 11, 0));

    Object[] params = new Object[]{"status", "Meeting", LocalDateTime.of(2023, 12, 1, 10, 0),
        "private"};
    CommandResult result = executor.execute(params);
    assertTrue(result.isSuccess());
  }

  @Test
  public void testExecuteEditStart() {
    calendarManager.createCalendar("Test", ZoneId.systemDefault());
    calendarManager.useCalendar("Test");
    InterfaceCalendar calendar = calendarManager.getActiveCalendar();
    calendar.createEvent("Meeting", LocalDateTime.of(2023, 12, 1, 10, 0),
        LocalDateTime.of(2023, 12, 1, 11, 0));

    Object[] params = new Object[]{"start", "Meeting", LocalDateTime.of(2023, 12, 1, 10, 0),
        "2023-12-01T09:00"};
    CommandResult result = executor.execute(params);
    assertTrue(result.isSuccess());
  }

  @Test
  public void testExecuteEditEnd() {
    calendarManager.createCalendar("Test", ZoneId.systemDefault());
    calendarManager.useCalendar("Test");
    InterfaceCalendar calendar = calendarManager.getActiveCalendar();
    calendar.createEvent("Meeting", LocalDateTime.of(2023, 12, 1, 10, 0),
        LocalDateTime.of(2023, 12, 1, 11, 0));

    Object[] params = new Object[]{"end", "Meeting", LocalDateTime.of(2023, 12, 1, 10, 0),
        "2023-12-01T12:00"};
    CommandResult result = executor.execute(params);
    assertTrue(result.isSuccess());
  }

  @Test
  public void testExecuteInvalidProperty() {
    calendarManager.createCalendar("Test", ZoneId.systemDefault());
    calendarManager.useCalendar("Test");
    InterfaceCalendar calendar = calendarManager.getActiveCalendar();
    calendar.createEvent("Meeting", LocalDateTime.of(2023, 12, 1, 10, 0),
        LocalDateTime.of(2023, 12, 1, 11, 0));

    Object[] params = new Object[]{"invalid", "Meeting", LocalDateTime.of(2023, 12, 1, 10, 0),
        "value"};
    CommandResult result = executor.execute(params);
    assertFalse(result.isSuccess());
    assertTrue(result.getMessage().contains("Invalid property"));
  }

  @Test
  public void testExecuteNoMatchingEvents() {
    calendarManager.createCalendar("Test", ZoneId.systemDefault());
    calendarManager.useCalendar("Test");

    Object[] params = new Object[]{"subject", "NonExistent", LocalDateTime.of(2023, 12, 1, 10, 0),
        "New"};
    CommandResult result = executor.execute(params);
    assertFalse(result.isSuccess());
    assertEquals("No matching events found for series", result.getMessage());
  }
}