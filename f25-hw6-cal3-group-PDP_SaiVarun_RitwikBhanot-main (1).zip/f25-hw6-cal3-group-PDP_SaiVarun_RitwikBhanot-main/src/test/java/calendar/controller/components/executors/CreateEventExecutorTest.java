package calendar.controller.components.executors;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import calendar.controller.CommandResult;
import calendar.model.CalendarManager;
import calendar.model.InterfaceCalendar;
import calendar.model.InterfaceCalendarManager;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import org.junit.Before;
import org.junit.Test;

/**
 * Unit test for CreateEventExecutor without external dependencies.
 */
public class CreateEventExecutorTest {

  private CreateEventExecutor executor;
  private InterfaceCalendarManager calendarManager;

  /**
   * Sets up test fixtures before each test.
   */
  @Before
  public void setUp() {
    calendarManager = new CalendarManager();
    executor = new CreateEventExecutor(calendarManager);
  }

  @Test
  public void testCreateEventExecutorConstructorCreatesExecutor() {
    CreateEventExecutor newExecutor = new CreateEventExecutor(calendarManager);
    assertTrue(newExecutor instanceof CreateEventExecutor);
  }

  @Test
  public void testExecuteSingleEventSuccess() {
    // Create a calendar first
    calendarManager.createCalendar("Test", ZoneId.systemDefault());
    calendarManager.useCalendar("Test");

    String subject = "Team Meeting";
    LocalDateTime start = LocalDateTime.of(2023, 12, 15, 10, 0);
    LocalDateTime end = LocalDateTime.of(2023, 12, 15, 11, 0);
    Object[] parameters = {subject, start, end};

    CommandResult result = executor.execute(parameters);

    assertTrue(result.isSuccess());
    assertEquals("Event created successfully", result.getMessage());
  }

  @Test
  public void testExecuteEventSeriesWithOccurrencesSuccess() {
    // Create a calendar first
    calendarManager.createCalendar("Test", ZoneId.systemDefault());
    calendarManager.useCalendar("Test");

    String subject = "Weekly Meeting";
    LocalDateTime start = LocalDateTime.of(2023, 12, 15, 10, 0);
    LocalDateTime end = LocalDateTime.of(2023, 12, 15, 11, 0);
    String weekdays = "M";
    int occurrences = 5;
    boolean isForTimes = true;
    Object[] parameters = {subject, start, end, weekdays, occurrences, isForTimes};

    CommandResult result = executor.execute(parameters);

    assertTrue(result.isSuccess());
    assertEquals("Event series created successfully", result.getMessage());
  }

  @Test
  public void testExecuteEventSeriesWithUntilDateSuccess() {
    // Create a calendar first
    calendarManager.createCalendar("Test", ZoneId.systemDefault());
    calendarManager.useCalendar("Test");

    String subject = "Daily Standup";
    LocalDateTime start = LocalDateTime.of(2023, 12, 15, 9, 0);
    LocalDateTime end = LocalDateTime.of(2023, 12, 15, 9, 30);
    String weekdays = "MTWRF";
    LocalDate until = LocalDate.of(2023, 12, 31);
    boolean isForTimes = false;
    Object[] parameters = {subject, start, end, weekdays, until, isForTimes};

    CommandResult result = executor.execute(parameters);

    assertTrue(result.isSuccess());
    assertEquals("Event series created successfully", result.getMessage());
  }

  @Test
  public void testExecuteNoActiveCalendarReturnsError() {
    String subject = "Team Meeting";
    LocalDateTime start = LocalDateTime.of(2023, 12, 15, 10, 0);
    LocalDateTime end = LocalDateTime.of(2023, 12, 15, 11, 0);
    Object[] parameters = {subject, start, end};

    CommandResult result = executor.execute(parameters);

    assertFalse(result.isSuccess());
    assertEquals("Failed to create event: No calendar is currently active. "
                 + "Use 'use calendar' command first.", result.getMessage());
  }

  @Test
  public void testExecuteInvalidParameterCountReturnsError() {
    Object[] parameters = {"only one parameter"};

    CommandResult result = executor.execute(parameters);

    assertFalse(result.isSuccess());
    assertEquals("Failed to create event: No calendar is currently active. "
                 + "Use 'use calendar' command first.", result.getMessage());
  }

  @Test
  public void testExecuteNullParametersReturnsError() {
    CommandResult result = executor.execute(null);

    assertFalse(result.isSuccess());
    assertEquals("Failed to create event: No calendar is currently active. "
                 + "Use 'use calendar' command first.", result.getMessage());
  }

  @Test
  public void testExecuteEmptyParametersReturnsError() {
    Object[] parameters = new Object[0];

    CommandResult result = executor.execute(parameters);

    assertFalse(result.isSuccess());
    assertEquals("Failed to create event: No calendar is currently active. "
                 + "Use 'use calendar' command first.", result.getMessage());
  }

  @Test
  public void testExecuteWithInvalidEventParametersReturnsError() {
    // Create a calendar first
    calendarManager.createCalendar("Test", ZoneId.systemDefault());
    calendarManager.useCalendar("Test");

    String subject = "Team Meeting";
    LocalDateTime start = LocalDateTime.of(2023, 12, 15, 10, 0);
    LocalDateTime end = LocalDateTime.of(2023, 12, 15, 9, 0); // End before start
    Object[] parameters = {subject, start, end};

    CommandResult result = executor.execute(parameters);

    assertFalse("Expected failure but got success with message: " + result.getMessage(),
                result.isSuccess());
    assertTrue("Expected error message to contain 'Start time must be before end time' but got: "
               + result.getMessage(),
               result.getMessage().contains("Start time must be before end time"));
  }

  @Test
  public void testExecuteWithMultipleWeekdays() {
    // Create a calendar first
    calendarManager.createCalendar("Test", ZoneId.systemDefault());
    calendarManager.useCalendar("Test");

    String subject = "Team Meeting";
    LocalDateTime start = LocalDateTime.of(2023, 12, 15, 10, 0);
    LocalDateTime end = LocalDateTime.of(2023, 12, 15, 11, 0);
    String weekdays = "MWF";
    int occurrences = 10;
    boolean isForTimes = true;
    Object[] parameters = {subject, start, end, weekdays, occurrences, isForTimes};

    CommandResult result = executor.execute(parameters);

    assertTrue(result.isSuccess());
    assertEquals("Event series created successfully", result.getMessage());
  }

  @Test
  public void testExecuteWithZeroOccurrences() {
    // Create a calendar first
    calendarManager.createCalendar("Test", ZoneId.systemDefault());
    calendarManager.useCalendar("Test");

    String subject = "Test Meeting";
    LocalDateTime start = LocalDateTime.of(2023, 12, 15, 10, 0);
    LocalDateTime end = LocalDateTime.of(2023, 12, 15, 11, 0);
    String weekdays = "M";
    int occurrences = 0;
    boolean isForTimes = true;
    Object[] parameters = {subject, start, end, weekdays, occurrences, isForTimes};

    CommandResult result = executor.execute(parameters);

    assertFalse("Expected failure for zero occurrences but got: " + result.getMessage(),
                result.isSuccess());
    assertTrue("Expected error message to contain 'Invalid number of occurrences' but got: "
               + result.getMessage(),
               result.getMessage().contains("Invalid number of occurrences"));
  }

  @Test
  public void testExecuteWithPastUntilDate() {
    // Create a calendar first
    calendarManager.createCalendar("Test", ZoneId.systemDefault());
    calendarManager.useCalendar("Test");

    String subject = "Test Meeting";
    LocalDateTime start = LocalDateTime.of(2023, 12, 15, 10, 0);
    LocalDateTime end = LocalDateTime.of(2023, 12, 15, 11, 0);
    String weekdays = "M";
    LocalDate until = LocalDate.of(2023, 11, 30); // Past date
    boolean isForTimes = false;
    Object[] parameters = {subject, start, end, weekdays, until, isForTimes};

    CommandResult result = executor.execute(parameters);

    assertFalse("Expected failure for past until date but got: " + result.getMessage(),
                result.isSuccess());
    assertTrue("Expected error message to contain 'Until date must be on or after start date' "
               + "but got: " + result.getMessage(),
               result.getMessage().contains("Until date must be on or after start date"));
  }

  @Test
  public void testExecuteNoActiveCalendar() {
    InterfaceCalendarManager emptyManager = new CalendarManager();
    CreateEventExecutor emptyExecutor = new CreateEventExecutor(emptyManager);

    Object[] params = new Object[]{"Meeting", LocalDateTime.of(2023, 12, 1, 10, 0),
        LocalDateTime.of(2023, 12, 1, 11, 0)};
    CommandResult result = emptyExecutor.execute(params);
    assertFalse(result.isSuccess());
    assertTrue(result.getMessage().contains("Failed to create event"));
  }

  @Test
  public void testExecuteInvalidParameters() {
    calendarManager.createCalendar("Test", ZoneId.systemDefault());
    calendarManager.useCalendar("Test");

    Object[] params = new Object[]{"Meeting", "invalid"};
    CommandResult result = executor.execute(params);
    assertFalse(result.isSuccess());
    assertTrue(result.getMessage().contains("Invalid parameters for event creation"));
  }

  @Test
  public void testExecuteIllegalArgumentException() {
    calendarManager.createCalendar("Test", ZoneId.systemDefault());
    calendarManager.useCalendar("Test");

    Object[] params = new Object[]{"", LocalDateTime.of(2023, 12, 1, 10, 0),
        LocalDateTime.of(2023, 12, 1, 11, 0)};
    CommandResult result = executor.execute(params);
    assertFalse(result.isSuccess());
    assertTrue(result.getMessage().contains("Subject cannot be null or empty"));
  }
}