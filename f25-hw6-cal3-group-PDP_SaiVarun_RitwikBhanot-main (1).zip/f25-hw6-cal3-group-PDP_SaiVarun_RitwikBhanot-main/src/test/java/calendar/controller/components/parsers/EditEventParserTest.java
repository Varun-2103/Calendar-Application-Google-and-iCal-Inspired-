package calendar.controller.components.parsers;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.fail;

import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;
import org.junit.Before;
import org.junit.Test;

/**
 * Test suite for EditEventParser to increase branch coverage.
 * Tests all parsing scenarios including edge cases and error handling.
 */
public class EditEventParserTest {

  private EditEventParser parser;

  /**
   * Sets up test fixtures before each test.
   */
  @Before
  public void setUp() {
    parser = new EditEventParser();
  }

  @Test
  public void testParseEditSubject() {
    List<String> tokens = Arrays.asList("edit", "event", "subject", "\"Old Meeting\"", "from",
        "2023-12-15T10:00", "to", "2023-12-15T11:00", "with", "\"New Meeting\"");
    
    try {
      Object[] result = parser.parse(tokens);
      assertNotNull(result);
      assertEquals(5, result.length);
      assertEquals("subject", result[0]);
      assertEquals("Old Meeting", result[1]);
      assertEquals(LocalDateTime.of(2023, 12, 15, 10, 0), result[2]);
      assertEquals(LocalDateTime.of(2023, 12, 15, 11, 0), result[3]);
      assertEquals("New Meeting", result[4]);
    } catch (Exception e) {
      fail("Valid edit subject should not throw exception: " + e.getMessage());
    }
  }

  @Test
  public void testParseEditLocation() {
    List<String> tokens = Arrays.asList("edit", "event", "location", "\"Meeting\"", "from",
        "2023-12-15T10:00", "to", "2023-12-15T11:00", "with", "\"Conference Room\"");
    
    try {
      Object[] result = parser.parse(tokens);
      assertNotNull(result);
      assertEquals(5, result.length);
      assertEquals("location", result[0]);
      assertEquals("Meeting", result[1]);
      assertEquals("Conference Room", result[4]);
    } catch (Exception e) {
      fail("Valid edit location should not throw exception: " + e.getMessage());
    }
  }

  @Test
  public void testParseEditDescription() {
    List<String> tokens = Arrays.asList("edit", "event", "description", "\"Meeting\"", "from",
        "2023-12-15T10:00", "to", "2023-12-15T11:00", "with", "\"Team discussion\"");
    
    try {
      Object[] result = parser.parse(tokens);
      assertNotNull(result);
      assertEquals(5, result.length);
      assertEquals("description", result[0]);
      assertEquals("Team discussion", result[4]);
    } catch (Exception e) {
      fail("Valid edit description should not throw exception: " + e.getMessage());
    }
  }

  @Test
  public void testParseEditStart() {
    List<String> tokens = Arrays.asList("edit", "event", "start", "\"Meeting\"", "from",
        "2023-12-15T10:00", "to", "2023-12-15T11:00", "with", "2023-12-15T09:00");
    
    try {
      Object[] result = parser.parse(tokens);
      assertNotNull(result);
      assertEquals(5, result.length);
      assertEquals("start", result[0]);
      assertEquals(LocalDateTime.of(2023, 12, 15, 9, 0), result[4]);
    } catch (Exception e) {
      fail("Valid edit start should not throw exception: " + e.getMessage());
    }
  }

  @Test
  public void testParseEditEnd() {
    List<String> tokens = Arrays.asList("edit", "event", "end", "\"Meeting\"", "from",
        "2023-12-15T10:00", "to", "2023-12-15T11:00", "with", "2023-12-15T12:00");
    
    try {
      Object[] result = parser.parse(tokens);
      assertNotNull(result);
      assertEquals(5, result.length);
      assertEquals("end", result[0]);
      assertEquals(LocalDateTime.of(2023, 12, 15, 12, 0), result[4]);
    } catch (Exception e) {
      fail("Valid edit end should not throw exception: " + e.getMessage());
    }
  }

  @Test
  public void testParseEditStatus() {
    List<String> tokens = Arrays.asList("edit", "event", "status", "\"Meeting\"", "from",
        "2023-12-15T10:00", "to", "2023-12-15T11:00", "with", "private");
    
    try {
      Object[] result = parser.parse(tokens);
      assertNotNull(result);
      assertEquals(5, result.length);
      assertEquals("status", result[0]);
      assertEquals("private", result[4]);
    } catch (Exception e) {
      fail("Valid edit status should not throw exception: " + e.getMessage());
    }
  }

  @Test
  public void testParseEditStatusWithCaps() {
    List<String> tokens = Arrays.asList("edit", "event", "STATUS", "\"Meeting\"", "from",
        "2023-12-15T10:00", "to", "2023-12-15T11:00", "with", "PRIVATE");
    
    try {
      Object[] result = parser.parse(tokens);
      assertNotNull(result);
      assertEquals(5, result.length);
      assertEquals("status", result[0]); // Should be lowercase
      assertEquals("private", result[4]); // Should be lowercase
    } catch (Exception e) {
      fail("Valid edit status with caps should not throw exception: " + e.getMessage());
    }
  }

  @Test(expected = IllegalArgumentException.class)
  public void testParseEditUnknownProperty() {
    List<String> tokens = Arrays.asList("edit", "event", "unknown", "\"Meeting\"", "from",
        "2023-12-15T10:00", "to", "2023-12-15T11:00", "with", "value");
    parser.parse(tokens);
  }

  @Test
  public void testParseWithUnquotedSubject() {
    List<String> tokens = Arrays.asList("edit", "event", "subject", "Meeting", "from",
        "2023-12-15T10:00", "to", "2023-12-15T11:00", "with", "NewMeeting");
    
    try {
      Object[] result = parser.parse(tokens);
      assertNotNull(result);
      assertEquals(5, result.length);
      assertEquals("Meeting", result[1]);
      assertEquals("NewMeeting", result[4]);
    } catch (Exception e) {
      fail("Valid unquoted values should not throw exception: " + e.getMessage());
    }
  }

  @Test
  public void testParseWithEmptyQuotedValues() {
    List<String> tokens = Arrays.asList("edit", "event", "subject", "\"Meeting\"", "from",
        "2023-12-15T10:00", "to", "2023-12-15T11:00", "with", "\"\"");
    
    try {
      Object[] result = parser.parse(tokens);
      assertNotNull(result);
      assertEquals(5, result.length);
      assertEquals("", result[4]);
    } catch (Exception e) {
      fail("Valid empty quoted value should not throw exception: " + e.getMessage());
    }
  }

  @Test
  public void testParseWithPartialQuotes() {
    List<String> tokens = Arrays.asList("edit", "event", "subject", "\"Meeting", "from",
        "2023-12-15T10:00", "to", "2023-12-15T11:00", "with", "New\"");
    
    try {
      Object[] result = parser.parse(tokens);
      assertNotNull(result);
      assertEquals(5, result.length);
      assertEquals("\"Meeting", result[1]); // Partial quotes should remain
      assertEquals("New\"", result[4]);     // Partial quotes should remain
    } catch (Exception e) {
      fail("Valid partial quotes should not throw exception: " + e.getMessage());
    }
  }

  @Test(expected = IllegalArgumentException.class)
  public void testParseWithInvalidDateTime() {
    List<String> tokens = Arrays.asList("edit", "event", "start", "\"Meeting\"", "from",
        "invalid-date", "to", "2023-12-15T11:00", "with", "2023-12-15T09:00");
    parser.parse(tokens);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testParseWithInvalidNewDateTime() {
    List<String> tokens = Arrays.asList("edit", "event", "start", "\"Meeting\"", "from",
        "2023-12-15T10:00", "to", "2023-12-15T11:00", "with", "invalid-date");
    parser.parse(tokens);
  }

  @Test
  public void testParseWithCaseInsensitiveKeywords() {
    List<String> tokens = Arrays.asList("edit", "event", "subject", "\"Meeting\"", "FROM",
        "2023-12-15T10:00", "TO", "2023-12-15T11:00", "WITH", "\"New Meeting\"");
    
    try {
      Object[] result = parser.parse(tokens);
      assertNotNull(result);
      assertEquals(5, result.length);
      assertEquals("New Meeting", result[4]);
    } catch (Exception e) {
      fail("Case insensitive keywords should be valid: " + e.getMessage());
    }
  }

  @Test
  public void testParseWithExtraTokens() {
    List<String> tokens = Arrays.asList("edit", "event", "subject", "\"Meeting\"", "extra", "from",
        "2023-12-15T10:00", "to", "2023-12-15T11:00", "with", "\"New Meeting\"");
    
    try {
      Object[] result = parser.parse(tokens);
      assertNotNull(result);
      assertEquals(5, result.length);
      // Should still work despite extra token
    } catch (Exception e) {
      fail("Extra tokens should not cause exception: " + e.getMessage());
    }
  }
}