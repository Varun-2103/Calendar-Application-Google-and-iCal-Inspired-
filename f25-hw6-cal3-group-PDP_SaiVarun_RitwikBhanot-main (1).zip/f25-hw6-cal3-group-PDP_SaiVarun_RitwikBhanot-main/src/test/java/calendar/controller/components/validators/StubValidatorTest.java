package calendar.controller.components.validators;

import java.util.Arrays;
import java.util.List;
import org.junit.Test;

/**
 * Test class for StubValidator.
 */
public class StubValidatorTest {

  @Test(expected = UnsupportedOperationException.class)
  public void testValidateThrowsUnsupportedOperationException() {
    StubValidator validator = new StubValidator("test command");
    List<String> tokens = Arrays.asList("test", "command");
    validator.validate(tokens);
  }
}