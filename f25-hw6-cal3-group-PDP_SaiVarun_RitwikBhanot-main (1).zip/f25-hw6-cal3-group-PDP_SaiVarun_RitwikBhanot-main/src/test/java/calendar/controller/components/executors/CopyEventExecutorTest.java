package calendar.controller.components.executors;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import calendar.controller.CommandResult;
import calendar.model.Calendar;
import calendar.model.CalendarManager;
import calendar.model.InterfaceCalendar;
import calendar.model.InterfaceCalendarManager;
import calendar.model.InterfaceEvent;
import java.time.LocalDateTime;
import java.time.ZoneId;
import org.junit.Before;
import org.junit.Test;

/**
 * Test suite for CopyEventExecutor to increase branch coverage.
 * Tests all execution paths including error handling and timezone conversion.
 */
public class CopyEventExecutorTest {

  private static final String EVENT_NAME = "Meeting";
  private static final LocalDateTime EVENT_TIME = LocalDateTime.of(2023, 12, 15, 10, 0);
  private static final LocalDateTime TARGET_TIME = LocalDateTime.of(2023, 12, 20, 10, 0);
  private static final String TARGET_CALENDAR = "Target";
  
  private CopyEventExecutor executor;
  private InterfaceCalendarManager calendarManager;
  private InterfaceCalendar sourceCalendar;
  private InterfaceCalendar targetCalendar;

  /**
   * Sets up test fixtures before each test.
   */
  @Before
  public void setUp() {
    calendarManager = new CalendarManager();
    executor = new CopyEventExecutor(calendarManager);
    
    // Create source calendar with events
    calendarManager.createCalendar("Source", ZoneId.of("America/New_York"));
    calendarManager.useCalendar("Source");
    sourceCalendar = calendarManager.getActiveCalendar();
    
    // Create target calendar
    calendarManager.createCalendar(TARGET_CALENDAR, ZoneId.of("America/Los_Angeles"));
    targetCalendar = calendarManager.getCalendar(TARGET_CALENDAR);
  }

  @Test
  public void testExecuteNoActiveCalendar() {
    // Create new manager without active calendar
    InterfaceCalendarManager emptyManager = new CalendarManager();
    CopyEventExecutor emptyExecutor = new CopyEventExecutor(emptyManager);
    
    Object[] parameters = {EVENT_NAME, EVENT_TIME, TARGET_CALENDAR, TARGET_TIME};
    CommandResult result = emptyExecutor.execute(parameters);
    
    assertFalse(result.isSuccess());
    assertEquals("Error copying event: No calendar is currently active. "
        + "Use 'use calendar' command first.", result.getMessage());
  }

  @Test
  public void testExecuteTargetCalendarNotFound() {
    String nonExistentCalendar = "NonExistent";
    
    Object[] parameters = {EVENT_NAME, EVENT_TIME, nonExistentCalendar, TARGET_TIME};
    CommandResult result = executor.execute(parameters);
    
    assertFalse(result.isSuccess());
    assertEquals("Target calendar '" + nonExistentCalendar + "' not found", result.getMessage());
  }

  @Test
  public void testExecuteEventNotFound() {
    String nonExistentEvent = "NonExistent";
    
    Object[] parameters = {nonExistentEvent, EVENT_TIME, TARGET_CALENDAR, TARGET_TIME};
    CommandResult result = executor.execute(parameters);
    
    assertFalse(result.isSuccess());
    assertEquals("Event '" + nonExistentEvent + "' at "
        + EVENT_TIME + " not found", result.getMessage());
  }

  @Test
  public void testExecuteSuccessfulCopy() {
    createTestEvent();
    
    Object[] parameters = {EVENT_NAME, EVENT_TIME, TARGET_CALENDAR, TARGET_TIME};
    CommandResult result = executor.execute(parameters);
    
    assertTrue(result.isSuccess());
    assertEquals("Successfully copied event '" + EVENT_NAME + "' to '"
        + TARGET_CALENDAR + "'", result.getMessage());
    
    // Verify event was copied
    assertEquals(1, targetCalendar.getAllEvents().size());
    InterfaceEvent copiedEvent = targetCalendar.getAllEvents().get(0);
    assertEquals(EVENT_NAME, copiedEvent.getSubject());
    assertEquals(TARGET_TIME, copiedEvent.getStart());
  }

  @Test
  public void testExecuteSuccessfulCopyWithTimezoneConversion() {
    createTestEvent();
    
    // Copy to different timezone (should convert time)
    Object[] parameters = {EVENT_NAME, EVENT_TIME, TARGET_CALENDAR, TARGET_TIME};
    CommandResult result = executor.execute(parameters);
    
    assertTrue(result.isSuccess());
    assertEquals("Successfully copied event '" + EVENT_NAME + "' to '"
        + TARGET_CALENDAR + "'", result.getMessage());
    
    // Verify event was copied with timezone conversion
    assertEquals(1, targetCalendar.getAllEvents().size());
    InterfaceEvent copiedEvent = targetCalendar.getAllEvents().get(0);
    assertEquals(EVENT_NAME, copiedEvent.getSubject());
    // Time should be adjusted for timezone difference
  }

  @Test
  public void testExecuteCopyWithConflict() {
    createTestEvent();
    createConflictingEvent();
    
    Object[] parameters = {EVENT_NAME, EVENT_TIME, TARGET_CALENDAR, TARGET_TIME};
    CommandResult result = executor.execute(parameters);
    
    assertFalse(result.isSuccess());
    assertEquals("Event conflicts with existing event in target calendar", result.getMessage());
    
    // Verify no event was created in target calendar
    assertEquals(1, targetCalendar.getAllEvents().size()); // Only the conflicting event
  }

  @Test
  public void testExecuteCopyWithNoConflict() {
    createTestEvent();
    createNonConflictingEvent();
    
    Object[] parameters = {EVENT_NAME, EVENT_TIME, TARGET_CALENDAR, TARGET_TIME};
    CommandResult result = executor.execute(parameters);
    
    assertTrue(result.isSuccess());
    assertEquals("Successfully copied event '" + EVENT_NAME + "' to '"
        + TARGET_CALENDAR + "'", result.getMessage());
    
    // Verify event was copied alongside non-conflicting event
    assertEquals(2, targetCalendar.getAllEvents().size());
  }

  @Test
  public void testExecuteCopyWithBoundaryNoConflict() {
    createTestEvent();
    createBoundaryEvent();
    
    Object[] parameters = {EVENT_NAME, EVENT_TIME, TARGET_CALENDAR, TARGET_TIME};
    CommandResult result = executor.execute(parameters);
    
    assertTrue(result.isSuccess());
    assertEquals("Successfully copied event '" + EVENT_NAME + "' to '"
        + TARGET_CALENDAR + "'", result.getMessage());
    
    // Boundary events should not conflict
    assertEquals(2, targetCalendar.getAllEvents().size());
  }

  @Test
  public void testExecuteWithNullParameters() {
    CommandResult result = executor.execute(null);
    
    assertFalse(result.isSuccess());
    assertTrue(result.getMessage().contains("Error copying event:"));
  }

  @Test
  public void testExecuteWithInvalidParameterTypes() {
    createTestEvent();
    
    Object[] parameters = {123, EVENT_TIME, TARGET_CALENDAR, TARGET_TIME};
    CommandResult result = executor.execute(parameters);
    
    assertFalse(result.isSuccess());
    assertTrue(result.getMessage().contains("Error copying event:"));
  }

  @Test
  public void testExecuteWithMultipleEventsFindCorrectOne() {
    createTestEvent();
    createDifferentEvent();
    
    Object[] parameters = {EVENT_NAME, EVENT_TIME, TARGET_CALENDAR, TARGET_TIME};
    CommandResult result = executor.execute(parameters);
    
    assertTrue(result.isSuccess());
    assertEquals("Successfully copied event '" + EVENT_NAME + "' to '"
        + TARGET_CALENDAR + "'", result.getMessage());
    
    // Verify correct event was copied
    assertEquals(1, targetCalendar.getAllEvents().size());
    InterfaceEvent copiedEvent = targetCalendar.getAllEvents().get(0);
    assertEquals(EVENT_NAME, copiedEvent.getSubject());
  }

  @Test
  public void testExecuteWithSameTimezone() {
    createTestEvent();
    
    // Create target calendar with same timezone
    calendarManager.createCalendar("SameTZ", ZoneId.of("America/New_York"));
    InterfaceCalendar sameTzCalendar = calendarManager.getCalendar("SameTZ");
    
    Object[] parameters = {EVENT_NAME, EVENT_TIME, "SameTZ", TARGET_TIME};
    CommandResult result = executor.execute(parameters);
    
    assertTrue(result.isSuccess());
    assertEquals("Successfully copied event '" + EVENT_NAME + "' to 'SameTZ'", result.getMessage());
    
    // Verify event was copied without timezone conversion
    assertEquals(1, sameTzCalendar.getAllEvents().size());
  }

  /**
   * Creates a test event in the source calendar.
   */
  private void createTestEvent() {
    sourceCalendar.createEvent(EVENT_NAME, EVENT_TIME, EVENT_TIME.plusHours(1));
  }

  /**
   * Creates a different event in the source calendar.
   */
  private void createDifferentEvent() {
    sourceCalendar.createEvent("Different Meeting", LocalDateTime.of(2023, 12, 15, 14, 0), 
        LocalDateTime.of(2023, 12, 15, 15, 0));
  }

  /**
   * Creates a conflicting event in the target calendar.
   */
  private void createConflictingEvent() {
    targetCalendar.createEvent("Conflict", TARGET_TIME, TARGET_TIME.plusHours(1));
  }

  /**
   * Creates a non-conflicting event in the target calendar.
   */
  private void createNonConflictingEvent() {
    targetCalendar.createEvent("Other", TARGET_TIME.plusHours(2), TARGET_TIME.plusHours(3));
  }

  /**
   * Creates a boundary event in the target calendar (touches but doesn't overlap).
   */
  private void createBoundaryEvent() {
    LocalDateTime eventEnd = TARGET_TIME.plusHours(1); // Test event is 1 hour
    // Starts exactly when test event ends
    targetCalendar.createEvent("Boundary", eventEnd, eventEnd.plusHours(1));
  }
}