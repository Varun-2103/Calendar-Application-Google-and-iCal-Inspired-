package calendar.controller.components.validators;

import java.util.Arrays;
import java.util.List;
import org.junit.Test;

/**
 * Test class for ExportCalValidator.
 */
public class ExportCalValidatorTest {

  private final ExportCalValidator validator = new ExportCalValidator();

  @Test
  public void testValidateValidCsvCommand() {
    List<String> tokens = Arrays.asList("export", "cal", "test.csv");
    validator.validate(tokens);
  }

  @Test
  public void testValidateValidIcalCommand() {
    List<String> tokens = Arrays.asList("export", "cal", "test.ical");
    validator.validate(tokens);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testValidateCommandTooShort() {
    List<String> tokens = Arrays.asList("export", "cal");
    validator.validate(tokens);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testValidateInvalidFirstToken() {
    List<String> tokens = Arrays.asList("invalid", "cal", "test.csv");
    validator.validate(tokens);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testValidateInvalidSecondToken() {
    List<String> tokens = Arrays.asList("export", "invalid", "test.csv");
    validator.validate(tokens);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testValidateEmptyFilename() {
    List<String> tokens = Arrays.asList("export", "cal", "\"\"");
    validator.validate(tokens);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testValidateFilenameWithoutExtension() {
    List<String> tokens = Arrays.asList("export", "cal", "test");
    validator.validate(tokens);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testValidateInvalidExtension() {
    List<String> tokens = Arrays.asList("export", "cal", "test.txt");
    validator.validate(tokens);
  }

  @Test
  public void testValidateFilenameWithQuotes() {
    List<String> tokens = Arrays.asList("export", "cal", "\"test.csv\"");
    validator.validate(tokens);
  }

  @Test
  public void testValidateFilenameWithQuotesIcal() {
    List<String> tokens = Arrays.asList("export", "cal", "\"test.ical\"");
    validator.validate(tokens);
  }
}