package calendar.controller.components.validators;

import java.util.Arrays;
import java.util.List;
import org.junit.Test;

/**
 * Test class for EditEventValidator.
 */
public class EditEventValidatorTest {

  private final EditEventValidator validator = new EditEventValidator();

  @Test
  public void testValidateValidCommand() {
    List<String> tokens = Arrays.asList("edit", "event", "subject", "\"Meeting\"", "from",
        "2023-12-01T10:00", "to", "2023-12-01T11:00", "with", "\"New Meeting\"");
    validator.validate(tokens);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testValidateCommandTooShort() {
    List<String> tokens = Arrays.asList("edit", "event", "subject");
    validator.validate(tokens);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testValidateInvalidFirstToken() {
    List<String> tokens = Arrays.asList("invalid", "event", "subject", "\"Meeting\"", "from",
        "2023-12-01T10:00", "to", "2023-12-01T11:00", "with", "\"New\"");
    validator.validate(tokens);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testValidateInvalidSecondToken() {
    List<String> tokens = Arrays.asList("edit", "invalid", "subject", "\"Meeting\"", "from",
        "2023-12-01T10:00", "to", "2023-12-01T11:00", "with", "\"New\"");
    validator.validate(tokens);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testValidateInvalidProperty() {
    List<String> tokens = Arrays.asList("edit", "event", "invalid", "\"Meeting\"", "from",
        "2023-12-01T10:00", "to", "2023-12-01T11:00", "with", "\"New\"");
    validator.validate(tokens);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testValidateMissingFromKeyword() {
    List<String> tokens = Arrays.asList("edit", "event", "subject", "\"Meeting\"", "wrong",
        "2023-12-01T10:00", "to", "2023-12-01T11:00", "with", "\"New\"");
    validator.validate(tokens);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testValidateMissingToKeyword() {
    List<String> tokens = Arrays.asList("edit", "event", "subject", "\"Meeting\"", "from",
        "2023-12-01T10:00", "wrong", "2023-12-01T11:00", "with", "\"New\"");
    validator.validate(tokens);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testValidateMissingWithKeyword() {
    List<String> tokens = Arrays.asList("edit", "event", "subject", "\"Meeting\"", "from",
        "2023-12-01T10:00", "to", "2023-12-01T11:00", "wrong", "\"New\"");
    validator.validate(tokens);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testValidateMissingValueAfterWith() {
    List<String> tokens = Arrays.asList("edit", "event", "subject", "\"Meeting\"", "from",
        "2023-12-01T10:00", "to", "2023-12-01T11:00", "with");
    validator.validate(tokens);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testValidateInvalidDateTimeFormat() {
    List<String> tokens = Arrays.asList("edit", "event", "subject", "\"Meeting\"", "from",
        "invalid", "to", "2023-12-01T11:00", "with", "\"New\"");
    validator.validate(tokens);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testValidateInvalidStatus() {
    List<String> tokens = Arrays.asList("edit", "event", "status", "\"Meeting\"", "from",
        "2023-12-01T10:00", "to", "2023-12-01T11:00", "with", "\"invalid\"");
    validator.validate(tokens);
  }

  @Test
  public void testValidateStatusPublic() {
    List<String> tokens = Arrays.asList("edit", "event", "status", "\"Meeting\"", "from",
        "2023-12-01T10:00", "to", "2023-12-01T11:00", "with", "\"public\"");
    validator.validate(tokens);
  }

  @Test
  public void testValidateStatusPrivate() {
    List<String> tokens = Arrays.asList("edit", "event", "status", "\"Meeting\"", "from",
        "2023-12-01T10:00", "to", "2023-12-01T11:00", "with", "\"private\"");
    validator.validate(tokens);
  }

  @Test
  public void testValidateStatusTentative() {
    List<String> tokens = Arrays.asList("edit", "event", "status", "\"Meeting\"", "from",
        "2023-12-01T10:00", "to", "2023-12-01T11:00", "with", "\"tentative\"");
    validator.validate(tokens);
  }

  @Test
  public void testValidateStatusConfirmed() {
    List<String> tokens = Arrays.asList("edit", "event", "status", "\"Meeting\"", "from",
        "2023-12-01T10:00", "to", "2023-12-01T11:00", "with", "\"confirmed\"");
    validator.validate(tokens);
  }

  @Test
  public void testValidatePropertySubject() {
    List<String> tokens = Arrays.asList("edit", "event", "subject", "\"Meeting\"", "from",
        "2023-12-01T10:00", "to", "2023-12-01T11:00", "with", "\"New\"");
    validator.validate(tokens);
  }

  @Test
  public void testValidatePropertyLocation() {
    List<String> tokens = Arrays.asList("edit", "event", "location", "\"Meeting\"", "from",
        "2023-12-01T10:00", "to", "2023-12-01T11:00", "with", "\"Room 101\"");
    validator.validate(tokens);
  }

  @Test
  public void testValidatePropertyStart() {
    List<String> tokens = Arrays.asList("edit", "event", "start", "\"Meeting\"", "from",
        "2023-12-01T10:00", "to", "2023-12-01T11:00", "with", "\"2023-12-01T09:00\"");
    validator.validate(tokens);
  }

  @Test
  public void testValidatePropertyEnd() {
    List<String> tokens = Arrays.asList("edit", "event", "end", "\"Meeting\"", "from",
        "2023-12-01T10:00", "to", "2023-12-01T11:00", "with", "\"2023-12-01T12:00\"");
    validator.validate(tokens);
  }

  @Test
  public void testValidatePropertyDescription() {
    List<String> tokens = Arrays.asList("edit", "event", "description", "\"Meeting\"", "from",
        "2023-12-01T10:00", "to", "2023-12-01T11:00", "with", "\"Details\"");
    validator.validate(tokens);
  }

  @Test
  public void testValidateStatusWithQuotedValue() {
    List<String> tokens = Arrays.asList("edit", "event", "status", "\"Meeting\"", "from",
        "2023-12-01T10:00", "to", "2023-12-01T11:00", "with", "\"public\"");
    validator.validate(tokens);
  }

  @Test
  public void testValidateStatusWithUnquotedValue() {
    List<String> tokens = Arrays.asList("edit", "event", "status", "\"Meeting\"", "from",
        "2023-12-01T10:00", "to", "2023-12-01T11:00", "with", "private");
    validator.validate(tokens);
  }

  @Test
  public void testValidateStatusWithMixedCaseValue() {
    List<String> tokens = Arrays.asList("edit", "event", "status", "\"Meeting\"", "from",
        "2023-12-01T10:00", "to", "2023-12-01T11:00", "with", "TENTATIVE");
    validator.validate(tokens);
  }

  @Test
  public void testValidateSubjectWithQuotedValue() {
    List<String> tokens = Arrays.asList("edit", "event", "subject", "\"Meeting\"", "from",
        "2023-12-01T10:00", "to", "2023-12-01T11:00", "with", "\"New Subject\"");
    validator.validate(tokens);
  }

  @Test
  public void testValidateSubjectWithUnquotedValue() {
    List<String> tokens = Arrays.asList("edit", "event", "subject", "\"Meeting\"", "from",
        "2023-12-01T10:00", "to", "2023-12-01T11:00", "with", "NewSubject");
    validator.validate(tokens);
  }

  @Test
  public void testValidateLocationWithQuotedValue() {
    List<String> tokens = Arrays.asList("edit", "event", "location", "\"Meeting\"", "from",
        "2023-12-01T10:00", "to", "2023-12-01T11:00", "with", "\"Conference Room\"");
    validator.validate(tokens);
  }

  @Test
  public void testValidateLocationWithUnquotedValue() {
    List<String> tokens = Arrays.asList("edit", "event", "location", "\"Meeting\"", "from",
        "2023-12-01T10:00", "to", "2023-12-01T11:00", "with", "Room101");
    validator.validate(tokens);
  }
}