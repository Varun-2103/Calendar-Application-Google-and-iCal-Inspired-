package calendar.controller.components.validators;

import java.util.Arrays;
import java.util.List;
import org.junit.Test;

/**
 * Test class for CopyEventsValidator.
 */
public class CopyEventsValidatorTest {

  private final CopyEventsValidator validator = new CopyEventsValidator();

  @Test
  public void testValidateBetweenFormatValid() {
    List<String> tokens = Arrays.asList("copy", "events", "between", "2023-12-01", "and",
        "2023-12-02", "--target", "Target", "to", "2023-12-10");
    validator.validate(tokens);
  }

  @Test
  public void testValidateOnFormatValid() {
    List<String> tokens = Arrays.asList("copy", "events", "on", "2023-12-01", "--target",
        "Target", "to", "2023-12-02");
    validator.validate(tokens);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testValidateInvalidFirstOrSecondToken() {
    List<String> tokens = Arrays.asList("invalid", "events");
    validator.validate(tokens);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testValidateMissingDateSpecification() {
    List<String> tokens = Arrays.asList("copy", "events");
    validator.validate(tokens);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testValidateInvalidThirdToken() {
    List<String> tokens = Arrays.asList("copy", "events", "invalid");
    validator.validate(tokens);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testValidateBetweenMissingStartDate() {
    List<String> tokens = Arrays.asList("copy", "events", "between");
    validator.validate(tokens);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testValidateBetweenInvalidStartDate() {
    List<String> tokens = Arrays.asList("copy", "events", "between", "invalid");
    validator.validate(tokens);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testValidateBetweenMissingAndKeyword() {
    List<String> tokens = Arrays.asList("copy", "events", "between", "2023-12-01");
    validator.validate(tokens);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testValidateBetweenWrongAndKeyword() {
    List<String> tokens = Arrays.asList("copy", "events", "between", "2023-12-01", "wrong");
    validator.validate(tokens);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testValidateBetweenMissingEndDate() {
    List<String> tokens = Arrays.asList("copy", "events", "between", "2023-12-01", "and");
    validator.validate(tokens);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testValidateBetweenInvalidEndDate() {
    List<String> tokens = Arrays.asList("copy", "events", "between", "2023-12-01",
        "and", "invalid");
    validator.validate(tokens);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testValidateBetweenEndBeforeStart() {
    List<String> tokens = Arrays.asList("copy", "events", "between", "2023-12-05", "and",
        "2023-12-01");
    validator.validate(tokens);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testValidateBetweenMissingTargetFlag() {
    List<String> tokens = Arrays.asList("copy", "events", "between", "2023-12-01", "and",
        "2023-12-02");
    validator.validate(tokens);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testValidateBetweenWrongTargetFlag() {
    List<String> tokens = Arrays.asList("copy", "events", "between", "2023-12-01", "and",
        "2023-12-02", "wrong");
    validator.validate(tokens);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testValidateBetweenMissingTargetCalendarName() {
    List<String> tokens = Arrays.asList("copy", "events", "between", "2023-12-01", "and",
        "2023-12-02", "--target");
    validator.validate(tokens);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testValidateBetweenMissingToKeyword() {
    List<String> tokens = Arrays.asList("copy", "events", "between", "2023-12-01", "and",
        "2023-12-02", "--target", "Target");
    validator.validate(tokens);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testValidateBetweenWrongToKeyword() {
    List<String> tokens = Arrays.asList("copy", "events", "between", "2023-12-01", "and",
        "2023-12-02", "--target", "Target", "wrong");
    validator.validate(tokens);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testValidateBetweenMissingTargetDate() {
    List<String> tokens = Arrays.asList("copy", "events", "between", "2023-12-01", "and",
        "2023-12-02", "--target", "Target", "to");
    validator.validate(tokens);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testValidateBetweenInvalidTargetDate() {
    List<String> tokens = Arrays.asList("copy", "events", "between", "2023-12-01", "and",
        "2023-12-02", "--target", "Target", "to", "invalid");
    validator.validate(tokens);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testValidateOnMissingDate() {
    List<String> tokens = Arrays.asList("copy", "events", "on");
    validator.validate(tokens);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testValidateOnInvalidDate() {
    List<String> tokens = Arrays.asList("copy", "events", "on", "invalid");
    validator.validate(tokens);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testValidateOnMissingTargetFlag() {
    List<String> tokens = Arrays.asList("copy", "events", "on", "2023-12-01");
    validator.validate(tokens);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testValidateOnWrongTargetFlag() {
    List<String> tokens = Arrays.asList("copy", "events", "on", "2023-12-01", "wrong");
    validator.validate(tokens);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testValidateOnMissingTargetCalendarName() {
    List<String> tokens = Arrays.asList("copy", "events", "on", "2023-12-01", "--target");
    validator.validate(tokens);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testValidateOnMissingToKeyword() {
    List<String> tokens = Arrays.asList("copy", "events", "on", "2023-12-01", "--target", "Target");
    validator.validate(tokens);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testValidateOnWrongToKeyword() {
    List<String> tokens = Arrays.asList("copy", "events", "on", "2023-12-01", "--target",
        "Target", "wrong");
    validator.validate(tokens);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testValidateOnMissingTargetDate() {
    List<String> tokens = Arrays.asList("copy", "events", "on", "2023-12-01", "--target",
        "Target", "to");
    validator.validate(tokens);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testValidateOnInvalidTargetDate() {
    List<String> tokens = Arrays.asList("copy", "events", "on", "2023-12-01", "--target",
        "Target", "to", "invalid");
    validator.validate(tokens);
  }
}