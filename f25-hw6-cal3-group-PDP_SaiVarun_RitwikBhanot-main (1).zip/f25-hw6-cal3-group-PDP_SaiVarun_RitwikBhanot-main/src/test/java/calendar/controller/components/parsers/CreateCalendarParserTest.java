package calendar.controller.components.parsers;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.fail;

import java.time.ZoneId;
import java.util.Arrays;
import java.util.List;
import org.junit.Before;
import org.junit.Test;

/**
 * Test suite for CreateCalendarParser to increase branch coverage.
 * Tests all parsing scenarios including edge cases and error handling.
 */
public class CreateCalendarParserTest {

  private CreateCalendarParser parser;

  /**
   * Sets up test fixtures before each test.
   */
  @Before
  public void setUp() {
    parser = new CreateCalendarParser();
  }

  @Test
  public void testParseValidCalendarWithQuotedName() {
    List<String> tokens = Arrays.asList("create", "calendar", "--name", 
        "\"Work Calendar\"", "--timezone", "America/New_York");
    
    try {
      Object[] result = parser.parse(tokens);
      assertNotNull(result);
      assertEquals(2, result.length);
      assertEquals("Work Calendar", result[0]);
      assertEquals(ZoneId.of("America/New_York"), result[1]);
    } catch (Exception e) {
      fail("Valid calendar creation should not throw exception: " + e.getMessage());
    }
  }

  @Test
  public void testParseValidCalendarWithUnquotedName() {
    List<String> tokens = Arrays.asList("create", "calendar", "--name", 
        "WorkCalendar", "--timezone", "America/Los_Angeles");
    
    try {
      Object[] result = parser.parse(tokens);
      assertNotNull(result);
      assertEquals(2, result.length);
      assertEquals("WorkCalendar", result[0]);
      assertEquals(ZoneId.of("America/Los_Angeles"), result[1]);
    } catch (Exception e) {
      fail("Valid calendar creation with unquoted name should not throw exception: "
          + e.getMessage());
    }
  }

  @Test
  public void testParseValidCalendarWithUtc() {
    List<String> tokens = Arrays.asList("create", "calendar", "--name", 
        "\"UTC Calendar\"", "--timezone", "UTC");
    
    try {
      Object[] result = parser.parse(tokens);
      assertNotNull(result);
      assertEquals(2, result.length);
      assertEquals("UTC Calendar", result[0]);
      assertEquals(ZoneId.of("UTC"), result[1]);
    } catch (Exception e) {
      fail("Valid calendar creation with UTC should not throw exception: " + e.getMessage());
    }
  }

  @Test
  public void testParseValidCalendarWithGmt() {
    List<String> tokens = Arrays.asList("create", "calendar", "--name", 
        "\"GMT Calendar\"", "--timezone", "GMT");
    
    try {
      Object[] result = parser.parse(tokens);
      assertNotNull(result);
      assertEquals(2, result.length);
      assertEquals("GMT Calendar", result[0]);
      assertEquals(ZoneId.of("GMT"), result[1]);
    } catch (Exception e) {
      fail("Valid calendar creation with GMT should not throw exception: " + e.getMessage());
    }
  }

  @Test(expected = IllegalArgumentException.class)
  public void testParseMissingTimezone() {
    List<String> tokens = Arrays.asList("create", "calendar", "--name", "\"Work Calendar\"");
    parser.parse(tokens);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testParseIncompleteTimezoneFlag() {
    List<String> tokens = Arrays.asList("create", "calendar", "--name", 
        "\"Work Calendar\"", "--timezone");
    parser.parse(tokens);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testParseInvalidUtcOffset() {
    List<String> tokens = Arrays.asList("create", "calendar", "--name", 
        "\"Work Calendar\"", "--timezone", "UTC+5");
    parser.parse(tokens);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testParseInvalidGmtOffset() {
    List<String> tokens = Arrays.asList("create", "calendar", "--name", 
        "\"Work Calendar\"", "--timezone", "GMT-3");
    parser.parse(tokens);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testParseInvalidTimezoneFormat() {
    List<String> tokens = Arrays.asList("create", "calendar", "--name", 
        "\"Work Calendar\"", "--timezone", "Invalid/Timezone");
    parser.parse(tokens);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testParseEmptyTimezone() {
    List<String> tokens = Arrays.asList("create", "calendar", "--name", 
        "\"Work Calendar\"", "--timezone", "");
    parser.parse(tokens);
  }

  @Test
  public void testParseWithEmptyQuotedName() {
    List<String> tokens = Arrays.asList("create", "calendar", "--name", "\"\"", "--timezone", 
        "America/New_York");
    
    try {
      Object[] result = parser.parse(tokens);
      assertNotNull(result);
      assertEquals(2, result.length);
      assertEquals("", result[0]);
      assertEquals(ZoneId.of("America/New_York"), result[1]);
    } catch (Exception e) {
      fail("Valid calendar creation with empty quoted name should not throw exception: "
          + e.getMessage());
    }
  }

  @Test
  public void testParseWithPartialQuotes() {
    List<String> tokens = Arrays.asList("create", "calendar", "--name", 
        "\"Work Calendar", "--timezone", "America/New_York");
    
    try {
      Object[] result = parser.parse(tokens);
      assertNotNull(result);
      assertEquals(2, result.length);
      assertEquals("\"Work Calendar", result[0]); // Partial quotes should remain
    } catch (Exception e) {
      fail("Partial quotes should not cause exception: " + e.getMessage());
    }
  }

  @Test
  public void testParseWithExtraTokens() {
    List<String> tokens = Arrays.asList("create", "calendar", "--name", 
        "\"Work Calendar\"", "--timezone", "America/New_York", "extra");
    
    try {
      Object[] result = parser.parse(tokens);
      assertNotNull(result);
      assertEquals(2, result.length);
      assertEquals("Work Calendar", result[0]);
      // Should work despite extra tokens
    } catch (Exception e) {
      fail("Extra tokens should not cause exception: " + e.getMessage());
    }
  }

  @Test
  public void testParseWithDifferentTimezoneFormats() {
    List<String> tokens = Arrays.asList("create", "calendar", "--name", 
        "\"Europe Calendar\"", "--timezone", "Europe/London");
    
    try {
      Object[] result = parser.parse(tokens);
      assertNotNull(result);
      assertEquals(2, result.length);
      assertEquals("Europe Calendar", result[0]);
      assertEquals(ZoneId.of("Europe/London"), result[1]);
    } catch (Exception e) {
      fail("Valid timezone format should not throw exception: " + e.getMessage());
    }
  }

  @Test
  public void testParseWithComplexTimezone() {
    List<String> tokens = Arrays.asList("create", "calendar", "--name", 
        "\"Asia Calendar\"", "--timezone", "Asia/Tokyo");
    
    try {
      Object[] result = parser.parse(tokens);
      assertNotNull(result);
      assertEquals(2, result.length);
      assertEquals("Asia Calendar", result[0]);
      assertEquals(ZoneId.of("Asia/Tokyo"), result[1]);
    } catch (Exception e) {
      fail("Valid complex timezone should not throw exception: " + e.getMessage());
    }
  }
}