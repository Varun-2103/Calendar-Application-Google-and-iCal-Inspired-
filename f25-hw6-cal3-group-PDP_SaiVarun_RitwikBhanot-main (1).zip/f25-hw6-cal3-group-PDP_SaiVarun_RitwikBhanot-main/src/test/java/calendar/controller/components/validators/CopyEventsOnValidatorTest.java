package calendar.controller.components.validators;

import java.util.Arrays;
import java.util.List;
import org.junit.Test;

/**
 * Test class for CopyEventsOnValidator.
 */
public class CopyEventsOnValidatorTest {

  private final CopyEventsOnValidator validator = new CopyEventsOnValidator();

  @Test
  public void testValidateValidCommand() {
    List<String> tokens = Arrays.asList("copy", "events", "on", "2023-12-01", "--target",
        "Target", "to", "2023-12-02");
    validator.validate(tokens);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testValidateCommandTooShort() {
    List<String> tokens = Arrays.asList("copy", "events");
    validator.validate(tokens);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testValidateInvalidFirstToken() {
    List<String> tokens = Arrays.asList("invalid", "events", "on", "2023-12-01", "--target",
        "Target", "to", "2023-12-02");
    validator.validate(tokens);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testValidateInvalidSecondToken() {
    List<String> tokens = Arrays.asList("copy", "invalid", "on", "2023-12-01", "--target",
        "Target", "to", "2023-12-02");
    validator.validate(tokens);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testValidateMissingOnKeyword() {
    List<String> tokens = Arrays.asList("copy", "events", "wrong", "2023-12-01", "--target",
        "Target", "to", "2023-12-02");
    validator.validate(tokens);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testValidateSizeLessThan4() {
    List<String> tokens = Arrays.asList("copy", "events", "on");
    validator.validate(tokens);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testValidateInvalidDate() {
    List<String> tokens = Arrays.asList("copy", "events", "on", "invalid", "--target",
        "Target", "to", "2023-12-02");
    validator.validate(tokens);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testValidateMissingTargetFlag() {
    List<String> tokens = Arrays.asList("copy", "events", "on", "2023-12-01", "wrong",
        "Target", "to", "2023-12-02");
    validator.validate(tokens);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testValidateSizeLessThan6() {
    List<String> tokens = Arrays.asList("copy", "events", "on", "2023-12-01", "--target");
    validator.validate(tokens);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testValidateMissingToKeyword() {
    List<String> tokens = Arrays.asList("copy", "events", "on", "2023-12-01", "--target",
        "Target", "wrong", "2023-12-02");
    validator.validate(tokens);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testValidateSizeLessThan7() {
    List<String> tokens = Arrays.asList("copy", "events", "on", "2023-12-01", "--target",
        "Target", "to");
    validator.validate(tokens);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testValidateInvalidTargetDate() {
    List<String> tokens = Arrays.asList("copy", "events", "on", "2023-12-01", "--target",
        "Target", "to", "invalid");
    validator.validate(tokens);
  }
}