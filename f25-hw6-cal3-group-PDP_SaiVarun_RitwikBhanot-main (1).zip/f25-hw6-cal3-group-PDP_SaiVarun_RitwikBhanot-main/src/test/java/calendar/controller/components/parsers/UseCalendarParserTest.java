package calendar.controller.components.parsers;

import static org.junit.Assert.assertEquals;

import java.util.Arrays;
import java.util.List;
import org.junit.Test;

/**
 * Test class for UseCalendarParser.
 */
public class UseCalendarParserTest {

  private final UseCalendarParser parser = new UseCalendarParser();

  @Test
  public void testParseValidCommand() {
    List<String> tokens = Arrays.asList("use", "calendar", "--name", "\"Test\"");
    Object[] result = parser.parse(tokens);
    assertEquals(1, result.length);
    assertEquals("Test", result[0]);
  }

  @Test
  public void testParseCommandWithoutQuotes() {
    List<String> tokens = Arrays.asList("use", "calendar", "--name", "Test");
    Object[] result = parser.parse(tokens);
    assertEquals(1, result.length);
    assertEquals("Test", result[0]);
  }

  @Test
  public void testParseNullName() {
    List<String> tokens = Arrays.asList("use", "calendar", "--name", null);
    Object[] result = parser.parse(tokens);
    assertEquals(1, result.length);
    assertEquals(null, result[0]);
  }
}