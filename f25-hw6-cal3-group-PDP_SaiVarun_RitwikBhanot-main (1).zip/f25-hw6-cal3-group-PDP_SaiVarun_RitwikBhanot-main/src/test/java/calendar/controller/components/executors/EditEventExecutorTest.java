package calendar.controller.components.executors;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import calendar.controller.CommandResult;
import calendar.model.CalendarManager;
import calendar.model.InterfaceCalendarManager;
import java.time.LocalDateTime;
import java.time.ZoneId;
import org.junit.Before;
import org.junit.Test;

/**
 * Unit test for EditEventExecutor to increase branch coverage.
 */
public class EditEventExecutorTest {

  private EditEventExecutor executor;
  private InterfaceCalendarManager calendarManager;

  /**
   * Sets up test fixtures before each test.
   */
  @Before
  public void setUp() {
    calendarManager = new CalendarManager();
    executor = new EditEventExecutor(calendarManager);
    calendarManager.createCalendar("Test", ZoneId.systemDefault());
    calendarManager.useCalendar("Test");
  }

  @Test
  public void testExecuteNoActiveCalendarReturnsError() {
    InterfaceCalendarManager emptyManager = new CalendarManager();
    EditEventExecutor emptyExecutor = new EditEventExecutor(emptyManager);
    String property = "subject";
    String subject = "Meeting";
    LocalDateTime start = LocalDateTime.of(2023, 12, 15, 10, 0);
    LocalDateTime end = LocalDateTime.of(2023, 12, 15, 11, 0);
    Object newValue = "New Meeting";
    Object[] parameters = {property, subject, start, end, newValue};

    CommandResult result = emptyExecutor.execute(parameters);

    assertFalse(result.isSuccess());
    assertEquals("Failed to edit event: No calendar is currently active. "
                 + "Use 'use calendar' command first.", result.getMessage());
  }

  @Test
  public void testExecuteEventNotFoundReturnsError() {
    String property = "subject";
    String subject = "NonExistent";
    LocalDateTime start = LocalDateTime.of(2023, 12, 15, 10, 0);
    LocalDateTime end = LocalDateTime.of(2023, 12, 15, 11, 0);
    Object newValue = "New Meeting";
    Object[] parameters = {property, subject, start, end, newValue};

    CommandResult result = executor.execute(parameters);

    assertFalse(result.isSuccess());
    assertEquals("Event not found: NonExistent from 2023-12-15T10:00 to 2023-12-15T11:00",
                 result.getMessage());
  }

  @Test
  public void testEditSubjectSuccess() {
    createTestEvent();
    String property = "subject";
    String subject = "Meeting";
    LocalDateTime start = LocalDateTime.of(2023, 12, 15, 10, 0);
    LocalDateTime end = LocalDateTime.of(2023, 12, 15, 11, 0);
    Object newValue = "Updated Meeting";
    Object[] parameters = {property, subject, start, end, newValue};

    CommandResult result = executor.execute(parameters);

    assertTrue(result.isSuccess());
    assertEquals("Event subject updated successfully", result.getMessage());
  }

  @Test
  public void testEditSubjectEmptyReturnsError() {
    createTestEvent();
    String property = "subject";
    String subject = "Meeting";
    LocalDateTime start = LocalDateTime.of(2023, 12, 15, 10, 0);
    LocalDateTime end = LocalDateTime.of(2023, 12, 15, 11, 0);
    Object newValue = "";
    Object[] parameters = {property, subject, start, end, newValue};

    CommandResult result = executor.execute(parameters);

    assertFalse(result.isSuccess());
    assertEquals("Event subject cannot be empty", result.getMessage());
  }

  @Test
  public void testEditSubjectNullReturnsError() {
    createTestEvent();
    String property = "subject";
    String subject = "Meeting";
    LocalDateTime start = LocalDateTime.of(2023, 12, 15, 10, 0);
    LocalDateTime end = LocalDateTime.of(2023, 12, 15, 11, 0);
    Object newValue = null;
    Object[] parameters = {property, subject, start, end, newValue};

    CommandResult result = executor.execute(parameters);

    assertFalse(result.isSuccess());
    assertEquals("Event subject cannot be empty", result.getMessage());
  }

  @Test
  public void testEditLocationSuccess() {
    createTestEvent();
    String property = "location";
    String subject = "Meeting";
    LocalDateTime start = LocalDateTime.of(2023, 12, 15, 10, 0);
    LocalDateTime end = LocalDateTime.of(2023, 12, 15, 11, 0);
    Object newValue = "Conference Room";
    Object[] parameters = {property, subject, start, end, newValue};

    CommandResult result = executor.execute(parameters);

    assertTrue(result.isSuccess());
    assertEquals("Event location updated successfully", result.getMessage());
  }

  @Test
  public void testEditDescriptionSuccess() {
    createTestEvent();
    String property = "description";
    String subject = "Meeting";
    LocalDateTime start = LocalDateTime.of(2023, 12, 15, 10, 0);
    LocalDateTime end = LocalDateTime.of(2023, 12, 15, 11, 0);
    Object newValue = "Team discussion";
    Object[] parameters = {property, subject, start, end, newValue};

    CommandResult result = executor.execute(parameters);

    assertTrue(result.isSuccess());
    assertEquals("Event description updated successfully", result.getMessage());
  }

  @Test
  public void testEditStartSuccess() {
    createTestEvent();
    String property = "start";
    String subject = "Meeting";
    LocalDateTime start = LocalDateTime.of(2023, 12, 15, 10, 0);
    LocalDateTime end = LocalDateTime.of(2023, 12, 15, 11, 0);
    Object newValue = LocalDateTime.of(2023, 12, 15, 9, 0);
    Object[] parameters = {property, subject, start, end, newValue};

    CommandResult result = executor.execute(parameters);

    assertTrue(result.isSuccess());
    assertEquals("Event start updated successfully", result.getMessage());
  }

  @Test
  public void testEditStartWithConflictReturnsError() {
    createTestEvent();
    createConflictingEvent();
    String property = "start";
    String subject = "Meeting";
    LocalDateTime start = LocalDateTime.of(2023, 12, 15, 10, 0);
    LocalDateTime end = LocalDateTime.of(2023, 12, 15, 11, 0);
    Object newValue = LocalDateTime.of(2023, 12, 15, 10, 30);
    Object[] parameters = {property, subject, start, end, newValue};

    CommandResult result = executor.execute(parameters);

    assertFalse(result.isSuccess());
    assertEquals("Event conflicts with existing event", result.getMessage());
  }

  @Test
  public void testEditEndSuccess() {
    createTestEvent();
    String property = "end";
    String subject = "Meeting";
    LocalDateTime start = LocalDateTime.of(2023, 12, 15, 10, 0);
    LocalDateTime end = LocalDateTime.of(2023, 12, 15, 11, 0);
    Object newValue = LocalDateTime.of(2023, 12, 15, 12, 0);
    Object[] parameters = {property, subject, start, end, newValue};

    CommandResult result = executor.execute(parameters);

    assertTrue(result.isSuccess());
    assertEquals("Event end updated successfully", result.getMessage());
  }

  @Test
  public void testEditEndBeforeStartReturnsError() {
    createTestEvent();
    String property = "end";
    String subject = "Meeting";
    LocalDateTime start = LocalDateTime.of(2023, 12, 15, 10, 0);
    LocalDateTime end = LocalDateTime.of(2023, 12, 15, 11, 0);
    Object newValue = LocalDateTime.of(2023, 12, 15, 9, 0);
    Object[] parameters = {property, subject, start, end, newValue};

    CommandResult result = executor.execute(parameters);

    assertFalse(result.isSuccess());
    assertEquals("Event end time cannot be before start time", result.getMessage());
  }

  @Test
  public void testEditEndWithConflictReturnsError() {
    createTestEvent();
    createConflictingEvent();
    String property = "end";
    String subject = "Meeting";
    LocalDateTime start = LocalDateTime.of(2023, 12, 15, 10, 0);
    LocalDateTime end = LocalDateTime.of(2023, 12, 15, 11, 0);
    Object newValue = LocalDateTime.of(2023, 12, 15, 11, 30);
    Object[] parameters = {property, subject, start, end, newValue};

    CommandResult result = executor.execute(parameters);

    assertFalse(result.isSuccess());
    assertEquals("Event conflicts with existing event", result.getMessage());
  }

  @Test
  public void testEditStatusPublicSuccess() {
    createTestEvent();
    String property = "status";
    String subject = "Meeting";
    LocalDateTime start = LocalDateTime.of(2023, 12, 15, 10, 0);
    LocalDateTime end = LocalDateTime.of(2023, 12, 15, 11, 0);
    Object newValue = "public";
    Object[] parameters = {property, subject, start, end, newValue};

    CommandResult result = executor.execute(parameters);

    assertTrue(result.isSuccess());
    assertEquals("Event status updated successfully", result.getMessage());
  }

  @Test
  public void testEditStatusPrivateSuccess() {
    createTestEvent();
    String property = "status";
    String subject = "Meeting";
    LocalDateTime start = LocalDateTime.of(2023, 12, 15, 10, 0);
    LocalDateTime end = LocalDateTime.of(2023, 12, 15, 11, 0);
    Object newValue = "private";
    Object[] parameters = {property, subject, start, end, newValue};

    CommandResult result = executor.execute(parameters);

    assertTrue(result.isSuccess());
    assertEquals("Event status updated successfully", result.getMessage());
  }

  @Test
  public void testEditStatusTentativeSuccess() {
    createTestEvent();
    String property = "status";
    String subject = "Meeting";
    LocalDateTime start = LocalDateTime.of(2023, 12, 15, 10, 0);
    LocalDateTime end = LocalDateTime.of(2023, 12, 15, 11, 0);
    Object newValue = "tentative";
    Object[] parameters = {property, subject, start, end, newValue};

    CommandResult result = executor.execute(parameters);

    assertTrue(result.isSuccess());
    assertEquals("Event status updated successfully", result.getMessage());
  }

  @Test
  public void testEditStatusConfirmedSuccess() {
    createTestEvent();
    String property = "status";
    String subject = "Meeting";
    LocalDateTime start = LocalDateTime.of(2023, 12, 15, 10, 0);
    LocalDateTime end = LocalDateTime.of(2023, 12, 15, 11, 0);
    Object newValue = "confirmed";
    Object[] parameters = {property, subject, start, end, newValue};

    CommandResult result = executor.execute(parameters);

    assertTrue(result.isSuccess());
    assertEquals("Event status updated successfully", result.getMessage());
  }

  @Test
  public void testEditStatusInvalidReturnsError() {
    createTestEvent();
    String property = "status";
    String subject = "Meeting";
    LocalDateTime start = LocalDateTime.of(2023, 12, 15, 10, 0);
    LocalDateTime end = LocalDateTime.of(2023, 12, 15, 11, 0);
    Object newValue = "invalid";
    Object[] parameters = {property, subject, start, end, newValue};

    CommandResult result = executor.execute(parameters);

    assertFalse(result.isSuccess());
    assertEquals("Invalid status: invalid", result.getMessage());
  }

  @Test
  public void testEditUnknownPropertyReturnsError() {
    createTestEvent();
    String property = "unknown";
    String subject = "Meeting";
    LocalDateTime start = LocalDateTime.of(2023, 12, 15, 10, 0);
    LocalDateTime end = LocalDateTime.of(2023, 12, 15, 11, 0);
    Object newValue = "value";
    Object[] parameters = {property, subject, start, end, newValue};

    CommandResult result = executor.execute(parameters);

    assertFalse(result.isSuccess());
    assertEquals("Unknown property: unknown", result.getMessage());
  }

  @Test
  public void testExecuteWithInvalidParameterTypesReturnsError() {
    createTestEvent();
    Object[] parameters = {123, "Meeting", LocalDateTime.now(), LocalDateTime.now(), "value"};
    
    CommandResult result = executor.execute(parameters);
    
    assertFalse(result.isSuccess());
    assertTrue(result.getMessage().contains("Failed to edit event:"));
  }

  @Test
  public void testExecuteWithMultipleEventsExactMatch() {
    createTestEvent();
    createDifferentEvent();
    
    String property = "subject";
    String subject = "Meeting";
    LocalDateTime start = LocalDateTime.of(2023, 12, 15, 10, 0);
    LocalDateTime end = LocalDateTime.of(2023, 12, 15, 11, 0);
    Object newValue = "Updated Meeting";
    Object[] parameters = {property, subject, start, end, newValue};

    CommandResult result = executor.execute(parameters);

    assertTrue(result.isSuccess());
    assertEquals("Event subject updated successfully", result.getMessage());
  }

  @Test
  public void testExecuteWithPartialMatchSubjectOnly() {
    createTestEvent();
    createSameSubjectDifferentTimeEvent();
    
    String property = "subject";
    String subject = "Meeting";
    LocalDateTime start = LocalDateTime.of(2023, 12, 15, 10, 0);
    LocalDateTime end = LocalDateTime.of(2023, 12, 15, 11, 0);
    Object newValue = "Updated Meeting";
    Object[] parameters = {property, subject, start, end, newValue};

    CommandResult result = executor.execute(parameters);

    assertTrue(result.isSuccess());
    assertEquals("Event subject updated successfully", result.getMessage());
  }

  @Test
  public void testEditStartWithBoundaryNoConflict() {
    createTestEvent();
    createBoundaryEvent();
    
    String property = "start";
    String subject = "Meeting";
    LocalDateTime start = LocalDateTime.of(2023, 12, 15, 10, 0);
    LocalDateTime end = LocalDateTime.of(2023, 12, 15, 11, 0);
    // Move start to exactly when boundary event ends - should not conflict
    Object newValue = LocalDateTime.of(2023, 12, 15, 9, 0);
    Object[] parameters = {property, subject, start, end, newValue};

    CommandResult result = executor.execute(parameters);

    assertTrue(result.isSuccess());
    assertEquals("Event start updated successfully", result.getMessage());
  }

  @Test
  public void testEditEndWithBoundaryNoConflict() {
    createTestEvent();
    createBoundaryEvent();
    
    String property = "end";
    String subject = "Meeting";
    LocalDateTime start = LocalDateTime.of(2023, 12, 15, 10, 0);
    LocalDateTime end = LocalDateTime.of(2023, 12, 15, 11, 0);
    // Move end to exactly when boundary event starts - should not conflict
    Object newValue = LocalDateTime.of(2023, 12, 15, 12, 0);
    Object[] parameters = {property, subject, start, end, newValue};

    CommandResult result = executor.execute(parameters);

    assertTrue(result.isSuccess());
    assertEquals("Event end updated successfully", result.getMessage());
  }

  @Test
  public void testEditStatusWithNonStringValue() {
    createTestEvent();
    String property = "status";
    String subject = "Meeting";
    LocalDateTime start = LocalDateTime.of(2023, 12, 15, 10, 0);
    LocalDateTime end = LocalDateTime.of(2023, 12, 15, 11, 0);
    Object newValue = 123; // Non-String value
    Object[] parameters = {property, subject, start, end, newValue};

    CommandResult result = executor.execute(parameters);

    assertFalse(result.isSuccess());
    assertTrue(result.getMessage().contains("Failed to edit event:"));
  }

  private void createTestEvent() {
    Object[] createParams = {"Meeting", LocalDateTime.of(2023, 12, 15, 10, 0),
                             LocalDateTime.of(2023, 12, 15, 11, 0)};
    CreateEventExecutor createExecutor = new CreateEventExecutor(calendarManager);
    createExecutor.execute(createParams);
  }

  private void createConflictingEvent() {
    Object[] createParams = {"Conflict", LocalDateTime.of(2023, 12, 15, 11, 0),
                             LocalDateTime.of(2023, 12, 15, 12, 0)};
    CreateEventExecutor createExecutor = new CreateEventExecutor(calendarManager);
    createExecutor.execute(createParams);
  }

  private void createDifferentEvent() {
    Object[] createParams = {"Different", LocalDateTime.of(2023, 12, 16, 10, 0),
                             LocalDateTime.of(2023, 12, 16, 11, 0)};
    CreateEventExecutor createExecutor = new CreateEventExecutor(calendarManager);
    createExecutor.execute(createParams);
  }

  private void createSameSubjectDifferentTimeEvent() {
    Object[] createParams = {"Meeting", LocalDateTime.of(2023, 12, 15, 14, 0),
                             LocalDateTime.of(2023, 12, 15, 15, 0)};
    CreateEventExecutor createExecutor = new CreateEventExecutor(calendarManager);
    createExecutor.execute(createParams);
  }

  private void createBoundaryEvent() {
    Object[] createParams = {"Boundary", LocalDateTime.of(2023, 12, 15, 12, 0),
                             LocalDateTime.of(2023, 12, 15, 13, 0)};
    CreateEventExecutor createExecutor = new CreateEventExecutor(calendarManager);
    createExecutor.execute(createParams);
  }
}