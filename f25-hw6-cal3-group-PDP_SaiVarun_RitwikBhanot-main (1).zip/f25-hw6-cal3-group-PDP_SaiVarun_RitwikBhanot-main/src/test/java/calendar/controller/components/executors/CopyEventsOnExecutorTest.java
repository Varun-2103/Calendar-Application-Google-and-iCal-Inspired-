package calendar.controller.components.executors;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import calendar.controller.CommandResult;
import calendar.model.Calendar;
import calendar.model.CalendarManager;
import calendar.model.InterfaceCalendar;
import calendar.model.InterfaceCalendarManager;
import calendar.model.InterfaceEvent;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import org.junit.Before;
import org.junit.Test;

/**
 * Test suite for CopyEventsOnExecutor to increase branch coverage.
 * Tests all execution paths including error handling and timezone conversion.
 */
public class CopyEventsOnExecutorTest {

  private static final LocalDate SOURCE_DATE = LocalDate.of(2023, 12, 15);
  private static final LocalDate TARGET_DATE = LocalDate.of(2023, 12, 20);
  private static final String TARGET_CALENDAR = "Target";
  
  private CopyEventsOnExecutor executor;
  private InterfaceCalendarManager calendarManager;
  private InterfaceCalendar sourceCalendar;
  private InterfaceCalendar targetCalendar;

  /**
   * Sets up test fixtures before each test.
   */
  @Before
  public void setUp() {
    calendarManager = new CalendarManager();
    executor = new CopyEventsOnExecutor(calendarManager);
    
    // Create source calendar with events
    calendarManager.createCalendar("Source", ZoneId.of("America/New_York"));
    calendarManager.useCalendar("Source");
    sourceCalendar = calendarManager.getActiveCalendar();
    
    // Create target calendar
    calendarManager.createCalendar(TARGET_CALENDAR, ZoneId.of("America/Los_Angeles"));
    targetCalendar = calendarManager.getCalendar(TARGET_CALENDAR);
  }

  @Test
  public void testExecuteNoActiveCalendar() {
    // Create new manager without active calendar
    InterfaceCalendarManager emptyManager = new CalendarManager();
    CopyEventsOnExecutor emptyExecutor = new CopyEventsOnExecutor(emptyManager);
    
    Object[] parameters = {SOURCE_DATE, TARGET_CALENDAR, TARGET_DATE};
    CommandResult result = emptyExecutor.execute(parameters);
    
    assertFalse(result.isSuccess());
    assertEquals("Error copying events: No calendar is currently active. "
        + "Use 'use calendar' command first.", result.getMessage());
  }

  @Test
  public void testExecuteTargetCalendarNotFound() {
    String nonExistentCalendar = "NonExistent";
    
    Object[] parameters = {SOURCE_DATE, nonExistentCalendar, TARGET_DATE};
    CommandResult result = executor.execute(parameters);
    
    assertFalse(result.isSuccess());
    assertEquals("Target calendar '" + nonExistentCalendar + "' not found", result.getMessage());
  }

  @Test
  public void testExecuteNoEventsOnDate() {
    LocalDate emptyDate = LocalDate.of(2024, 1, 1);
    LocalDate futureTarget = LocalDate.of(2024, 1, 2);
    
    Object[] parameters = {emptyDate, TARGET_CALENDAR, futureTarget};
    CommandResult result = executor.execute(parameters);
    
    assertTrue(result.isSuccess());
    assertEquals("No events found on " + emptyDate, result.getMessage());
    
    // Verify no events were created in target calendar
    assertEquals(0, targetCalendar.getAllEvents().size());
  }

  @Test
  public void testExecuteAllDayEventCopy() {
    // Create all-day event (8:00 to 17:00)
    createAllDayEvent();
    
    Object[] parameters = {SOURCE_DATE, TARGET_CALENDAR, TARGET_DATE};
    CommandResult result = executor.execute(parameters);
    
    assertTrue(result.isSuccess());
    assertEquals("Successfully copied 1 events from " + SOURCE_DATE + " to '"
        + TARGET_CALENDAR + "' on " + TARGET_DATE, result.getMessage());
    
    // Verify event was copied as all-day event
    assertEquals(1, targetCalendar.getAllEvents().size());
    InterfaceEvent copiedEvent = targetCalendar.getAllEvents().get(0);
    assertEquals("All Day Meeting", copiedEvent.getSubject());
    assertEquals(LocalDateTime.of(TARGET_DATE, 
        LocalDateTime.of(2023, 12, 15, 8, 0).toLocalTime()), copiedEvent.getStart());
    assertEquals(LocalDateTime.of(TARGET_DATE, 
        LocalDateTime.of(2023, 12, 15, 17, 0).toLocalTime()), copiedEvent.getEnd());
  }

  @Test
  public void testExecuteRegularEventCopy() {
    // Create regular event (not all-day)
    createRegularEvent();
    
    Object[] parameters = {SOURCE_DATE, TARGET_CALENDAR, TARGET_DATE};
    CommandResult result = executor.execute(parameters);
    
    assertTrue(result.isSuccess());
    assertEquals("Successfully copied 1 events from " + SOURCE_DATE + " to '"
        + TARGET_CALENDAR + "' on " + TARGET_DATE, result.getMessage());
    
    // Verify event was copied with timezone conversion
    assertEquals(1, targetCalendar.getAllEvents().size());
    InterfaceEvent copiedEvent = targetCalendar.getAllEvents().get(0);
    assertEquals("Regular Meeting", copiedEvent.getSubject());
    // Time should be converted from EST to PST (3 hours difference)
    // 10:00 EST -> 07:00 PST
    assertEquals(LocalDateTime.of(2023, 12, 20, 7, 0), copiedEvent.getStart());
    // 11:00 EST -> 08:00 PST
    assertEquals(LocalDateTime.of(2023, 12, 20, 8, 0), copiedEvent.getEnd());
  }

  @Test
  public void testExecuteMixedEventsCopy() {
    // Create both all-day and regular events
    createAllDayEvent();
    createRegularEvent();
    
    Object[] parameters = {SOURCE_DATE, TARGET_CALENDAR, TARGET_DATE};
    CommandResult result = executor.execute(parameters);
    
    assertTrue(result.isSuccess());
    assertEquals("Successfully copied 2 events from " + SOURCE_DATE + " to '"
        + TARGET_CALENDAR + "' on " + TARGET_DATE, result.getMessage());
    
    // Verify both events were copied
    assertEquals(2, targetCalendar.getAllEvents().size());
  }

  @Test
  public void testExecuteWithNullParameters() {
    CommandResult result = executor.execute(null);
    
    assertFalse(result.isSuccess());
    assertTrue(result.getMessage().contains("Error copying events:"));
  }

  @Test
  public void testExecuteWithInvalidParameterTypes() {
    Object[] parameters = {"invalid", TARGET_CALENDAR, TARGET_DATE};
    
    CommandResult result = executor.execute(parameters);
    
    assertFalse(result.isSuccess());
    assertTrue(result.getMessage().contains("Error copying events:"));
  }

  @Test
  public void testExecuteSameTimezoneCopy() {
    createRegularEvent();
    
    // Create target calendar with same timezone
    calendarManager.createCalendar("SameTZ", ZoneId.of("America/New_York"));
    InterfaceCalendar sameTzCalendar = calendarManager.getCalendar("SameTZ");
    
    Object[] parameters = {SOURCE_DATE, "SameTZ", TARGET_DATE};
    CommandResult result = executor.execute(parameters);
    
    assertTrue(result.isSuccess());
    assertEquals("Successfully copied 1 events from " + SOURCE_DATE
        + " to 'SameTZ' on " + TARGET_DATE, result.getMessage());
    
    // Verify event was copied without timezone conversion
    assertEquals(1, sameTzCalendar.getAllEvents().size());
    InterfaceEvent copiedEvent = sameTzCalendar.getAllEvents().get(0);
    assertEquals("Regular Meeting", copiedEvent.getSubject());
    assertEquals(LocalDateTime.of(2023, 12, 20, 10, 0), copiedEvent.getStart());
    assertEquals(LocalDateTime.of(2023, 12, 20, 11, 0), copiedEvent.getEnd());
  }

  @Test
  public void testExecuteWithDifferentTargetDate() {
    createAllDayEvent();
    
    LocalDate differentTarget = LocalDate.of(2023, 12, 25);
    Object[] parameters = {SOURCE_DATE, TARGET_CALENDAR, differentTarget};
    CommandResult result = executor.execute(parameters);
    
    assertTrue(result.isSuccess());
    assertEquals("Successfully copied 1 events from " + SOURCE_DATE + " to '"
        + TARGET_CALENDAR + "' on " + differentTarget, result.getMessage());
    
    // Verify event was copied on different date
    InterfaceEvent copiedEvent = targetCalendar.getAllEvents().get(0);
    assertEquals(differentTarget, copiedEvent.getStart().toLocalDate());
  }

  /**
   * Creates an all-day event (8:00 to 17:00).
   */
  private void createAllDayEvent() {
    sourceCalendar.createEvent("All Day Meeting", 
        LocalDateTime.of(2023, 12, 15, 8, 0),
        LocalDateTime.of(2023, 12, 15, 17, 0));
  }

  /**
   * Creates a regular event (not all-day).
   */
  private void createRegularEvent() {
    sourceCalendar.createEvent("Regular Meeting", 
        LocalDateTime.of(2023, 12, 15, 10, 0),
        LocalDateTime.of(2023, 12, 15, 11, 0));
  }

  @Test
  public void testExecuteCopyAllDayEvent() {
    InterfaceCalendar sourceCalendar = calendarManager.getActiveCalendar();
    sourceCalendar.createEvent("All Day", LocalDateTime.of(2023, 12,
            1, 8, 0),
        LocalDateTime.of(2023, 12, 1, 17, 0));

    Object[] params = new Object[]{LocalDate.of(2023, 12, 1), "Target",
        LocalDate.of(2023, 12, 2)};
    CommandResult result = executor.execute(params);
    assertTrue(result.isSuccess());
  }

  @Test
  public void testExecuteCopyNonAllDayEvent() {
    InterfaceCalendar sourceCalendar = calendarManager.getActiveCalendar();
    sourceCalendar.createEvent("Regular", LocalDateTime.of(2023, 12,
            1, 10, 0),
        LocalDateTime.of(2023, 12, 1, 11, 0));

    Object[] params = new Object[]{LocalDate.of(2023, 12, 1), "Target",
        LocalDate.of(2023, 12, 2)};
    CommandResult result = executor.execute(params);
    assertTrue(result.isSuccess());
  }

}