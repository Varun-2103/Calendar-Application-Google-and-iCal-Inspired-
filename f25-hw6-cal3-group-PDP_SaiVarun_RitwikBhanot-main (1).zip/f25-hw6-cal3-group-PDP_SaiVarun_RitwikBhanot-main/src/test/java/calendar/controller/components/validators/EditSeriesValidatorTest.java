package calendar.controller.components.validators;

import java.util.Arrays;
import java.util.List;
import org.junit.Test;

/**
 * Test class for EditSeriesValidator.
 */
public class EditSeriesValidatorTest {

  private final EditSeriesValidator validator = new EditSeriesValidator();

  @Test
  public void testValidateValidCommand() {
    List<String> tokens = Arrays.asList("edit", "series", "subject", "\"Meeting\"", "from",
        "2023-12-01T10:00", "with", "\"New Meeting\"");
    validator.validate(tokens);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testValidateCommandTooShort() {
    List<String> tokens = Arrays.asList("edit", "series", "subject");
    validator.validate(tokens);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testValidateInvalidFirstToken() {
    List<String> tokens = Arrays.asList("invalid", "series", "subject", "\"Meeting\"", "from",
        "2023-12-01T10:00", "with", "\"New\"");
    validator.validate(tokens);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testValidateInvalidSecondToken() {
    List<String> tokens = Arrays.asList("edit", "invalid", "subject", "\"Meeting\"", "from",
        "2023-12-01T10:00", "with", "\"New\"");
    validator.validate(tokens);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testValidateInvalidProperty() {
    List<String> tokens = Arrays.asList("edit", "series", "invalid", "\"Meeting\"", "from",
        "2023-12-01T10:00", "with", "\"New\"");
    validator.validate(tokens);
  }


  @Test(expected = IllegalArgumentException.class)
  public void testValidateMissingFromKeyword() {
    List<String> tokens = Arrays.asList("edit", "series", "subject", "\"Meeting\"", "wrong",
        "2023-12-01T10:00", "with", "\"New\"");
    validator.validate(tokens);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testValidateInvalidFromDateTime() {
    List<String> tokens = Arrays.asList("edit", "series", "subject", "\"Meeting\"", "from",
        "invalid", "with", "\"New\"");
    validator.validate(tokens);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testValidateMissingWithKeyword() {
    List<String> tokens = Arrays.asList("edit", "series", "subject", "\"Meeting\"", "from",
        "2023-12-01T10:00", "wrong", "\"New\"");
    validator.validate(tokens);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testValidateMissingValueAfterWith() {
    List<String> tokens = Arrays.asList("edit", "series", "subject", "\"Meeting\"", "from",
        "2023-12-01T10:00", "with");
    validator.validate(tokens);
  }

  @Test
  public void testValidatePropertySubject() {
    List<String> tokens = Arrays.asList("edit", "series", "subject", "\"Meeting\"", "from",
        "2023-12-01T10:00", "with", "\"New\"");
    validator.validate(tokens);
  }

  @Test
  public void testValidatePropertyLocation() {
    List<String> tokens = Arrays.asList("edit", "series", "location", "\"Meeting\"", "from",
        "2023-12-01T10:00", "with", "\"Room 101\"");
    validator.validate(tokens);
  }

  @Test
  public void testValidatePropertyDescription() {
    List<String> tokens = Arrays.asList("edit", "series", "description", "\"Meeting\"", "from",
        "2023-12-01T10:00", "with", "\"Details\"");
    validator.validate(tokens);
  }

  @Test
  public void testValidatePropertyStatus() {
    List<String> tokens = Arrays.asList("edit", "series", "status", "\"Meeting\"", "from",
        "2023-12-01T10:00", "with", "\"private\"");
    validator.validate(tokens);
  }

  @Test
  public void testValidatePropertyStart() {
    List<String> tokens = Arrays.asList("edit", "series", "start", "\"Meeting\"", "from",
        "2023-12-01T10:00", "with", "\"2023-12-01T09:00\"");
    validator.validate(tokens);
  }

  @Test
  public void testValidatePropertyEnd() {
    List<String> tokens = Arrays.asList("edit", "series", "end", "\"Meeting\"", "from",
        "2023-12-01T10:00", "with", "\"2023-12-01T12:00\"");
    validator.validate(tokens);
  }
}