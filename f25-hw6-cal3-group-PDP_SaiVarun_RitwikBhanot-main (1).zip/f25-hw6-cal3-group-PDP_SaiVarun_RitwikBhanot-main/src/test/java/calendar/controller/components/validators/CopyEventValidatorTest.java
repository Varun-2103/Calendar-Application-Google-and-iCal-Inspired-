package calendar.controller.components.validators;

import java.util.Arrays;
import java.util.List;
import org.junit.Test;

/**
 * Test class for CopyEventValidator.
 */
public class CopyEventValidatorTest {

  private final CopyEventValidator validator = new CopyEventValidator();

  @Test
  public void testValidateValidCommand() {
    List<String> tokens = Arrays.asList("copy", "event", "\"Meeting\"", "on",
        "2023-12-01T10:00", "--target", "Target", "to", "2023-12-01T14:00");
    validator.validate(tokens);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testValidateInvalidFirstToken() {
    List<String> tokens = Arrays.asList("invalid", "event", "\"Meeting\"", "on",
        "2023-12-01T10:00", "--target", "Target", "to", "2023-12-01T14:00");
    validator.validate(tokens);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testValidateInvalidSecondToken() {
    List<String> tokens = Arrays.asList("copy", "invalid", "\"Meeting\"", "on",
        "2023-12-01T10:00", "--target", "Target", "to", "2023-12-01T14:00");
    validator.validate(tokens);
  }


  @Test(expected = IllegalArgumentException.class)
  public void testValidateMissingOnKeyword() {
    List<String> tokens = Arrays.asList("copy", "event", "\"Meeting\"", "wrong",
        "2023-12-01T10:00", "--target", "Target", "to", "2023-12-01T14:00");
    validator.validate(tokens);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testValidateInvalidOnDateTime() {
    List<String> tokens = Arrays.asList("copy", "event", "\"Meeting\"", "on",
        "invalid", "--target", "Target", "to", "2023-12-01T14:00");
    validator.validate(tokens);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testValidateMissingTargetFlag() {
    List<String> tokens = Arrays.asList("copy", "event", "\"Meeting\"", "on",
        "2023-12-01T10:00");
    validator.validate(tokens);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testValidateMissingTargetCalendarName() {
    List<String> tokens = Arrays.asList("copy", "event", "\"Meeting\"", "on",
        "2023-12-01T10:00", "--target");
    validator.validate(tokens);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testValidateWrongToKeyword() {
    List<String> tokens = Arrays.asList("copy", "event", "\"Meeting\"", "on",
        "2023-12-01T10:00", "--target", "Target", "wrong");
    validator.validate(tokens);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testValidateInvalidTargetDateTime() {
    List<String> tokens = Arrays.asList("copy", "event", "\"Meeting\"", "on",
        "2023-12-01T10:00", "--target", "Target", "to", "invalid");
    validator.validate(tokens);
  }
}