package calendar.controller.components.executors;

import static org.junit.Assert.assertFalse;

import calendar.controller.CommandResult;
import calendar.model.CalendarManager;
import calendar.model.InterfaceCalendarManager;
import java.time.LocalDateTime;
import org.junit.Before;
import org.junit.Test;

/**
 * Test class for ShowStatusExecutor.
 */
public class ShowStatusExecutorTest {

  private ShowStatusExecutor executor;
  private InterfaceCalendarManager calendarManager;

  /**
   * Setup for the test class.
   */
  @Before
  public void setUp() {
    calendarManager = new CalendarManager();
    executor = new ShowStatusExecutor(calendarManager);
  }

  @Test
  public void testExecuteNoActiveCalendar() {
    Object[] params = new Object[]{LocalDateTime.of(2023, 12, 1, 10, 0)};
    CommandResult result = executor.execute(params);
    assertFalse(result.isSuccess());
  }
}