package calendar.controller.components.parsers;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;
import org.junit.Test;

/**
 * Test suite for CopyEventParser.
 * Tests parsing of copy event commands with various formats and edge cases.
 */
public class CopyEventParserTest {

  private static final String EVENT_NAME = "Team Meeting";
  private static final LocalDateTime ON_DATETIME = LocalDateTime.of(2023, 12, 15, 10, 0);
  private static final LocalDateTime TO_DATETIME = LocalDateTime.of(2023, 12, 16, 14, 0);
  private static final String TARGET_CALENDAR = "Work";

  @Test
  public void testParseValidCommandWithQuotedEventName() {
    CopyEventParser parser = new CopyEventParser();
    List<String> tokens = Arrays.asList("copy", "event", "\"Team Meeting\"", "on", 
        "2023-12-15T10:00", "--target", "Work", "to", "2023-12-16T14:00");

    Object[] result = parser.parse(tokens);

    assertNotNull(result);
    assertEquals(4, result.length);
    assertEquals(EVENT_NAME, result[0]);
    assertEquals(ON_DATETIME, result[1]);
    assertEquals(TARGET_CALENDAR, result[2]);
    assertEquals(TO_DATETIME, result[3]);
  }

  @Test
  public void testParseValidCommandWithoutQuotes() {
    CopyEventParser parser = new CopyEventParser();
    List<String> tokens = Arrays.asList("copy", "event", "Team Meeting", "on", 
        "2023-12-15T10:00", "--target", "Work", "to", "2023-12-16T14:00");

    Object[] result = parser.parse(tokens);

    assertNotNull(result);
    assertEquals(4, result.length);
    assertEquals("Team Meeting", result[0]);
    assertEquals(ON_DATETIME, result[1]);
    assertEquals(TARGET_CALENDAR, result[2]);
    assertEquals(TO_DATETIME, result[3]);
  }

  @Test
  public void testParseValidCommandWithDifferentOrder() {
    CopyEventParser parser = new CopyEventParser();
    List<String> tokens = Arrays.asList("copy", "event", "Meeting", "on", 
        "2023-12-15T09:00", "--target", "Personal", "to", "2023-12-15T11:00");

    Object[] result = parser.parse(tokens);

    assertNotNull(result);
    assertEquals(4, result.length);
    assertEquals("Meeting", result[0]);
    assertEquals(LocalDateTime.of(2023, 12, 15, 9, 0), result[1]);
    assertEquals("Personal", result[2]);
    assertEquals(LocalDateTime.of(2023, 12, 15, 11, 0), result[3]);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testParseMissingOnKeywordThrowsException() {
    CopyEventParser parser = new CopyEventParser();
    List<String> tokens = Arrays.asList("copy", "event", "Team Meeting", 
        "2023-12-15T10:00", "--target", "Work", "to", "2023-12-16T14:00");

    parser.parse(tokens);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testParseMissingTargetOptionThrowsException() {
    CopyEventParser parser = new CopyEventParser();
    List<String> tokens = Arrays.asList("copy", "event", "Team Meeting", "on", 
        "2023-12-15T10:00", "Work", "to", "2023-12-16T14:00");

    parser.parse(tokens);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testParseMissingToKeywordThrowsException() {
    CopyEventParser parser = new CopyEventParser();
    List<String> tokens = Arrays.asList("copy", "event", "Team Meeting", "on", 
        "2023-12-15T10:00", "--target", "Work", "2023-12-16T14:00");

    parser.parse(tokens);
  }

  @Test
  public void testParseWithEmptyEventName() {
    CopyEventParser parser = new CopyEventParser();
    List<String> tokens = Arrays.asList("copy", "event", "", "on", 
        "2023-12-15T10:00", "--target", "Work", "to", "2023-12-16T14:00");

    Object[] result = parser.parse(tokens);

    assertNotNull(result);
    assertEquals(4, result.length);
    assertEquals("", result[0]);
    assertEquals(ON_DATETIME, result[1]);
    assertEquals(TARGET_CALENDAR, result[2]);
    assertEquals(TO_DATETIME, result[3]);
  }

  @Test
  public void testParseWithSingleWordEventName() {
    CopyEventParser parser = new CopyEventParser();
    List<String> tokens = Arrays.asList("copy", "event", "Meeting", "on", 
        "2023-12-15T10:00", "--target", "Work", "to", "2023-12-16T14:00");

    Object[] result = parser.parse(tokens);

    assertNotNull(result);
    assertEquals(4, result.length);
    assertEquals("Meeting", result[0]);
    assertEquals(ON_DATETIME, result[1]);
    assertEquals(TARGET_CALENDAR, result[2]);
    assertEquals(TO_DATETIME, result[3]);
  }

  @Test
  public void testParseWithSpecialCharactersInEventName() {
    CopyEventParser parser = new CopyEventParser();
    List<String> tokens = Arrays.asList("copy", "event", "\"Meeting @ Office\"", "on", 
        "2023-12-15T10:00", "--target", "Work", "to", "2023-12-16T14:00");

    Object[] result = parser.parse(tokens);

    assertNotNull(result);
    assertEquals(4, result.length);
    assertEquals("Meeting @ Office", result[0]);
    assertEquals(ON_DATETIME, result[1]);
    assertEquals(TARGET_CALENDAR, result[2]);
    assertEquals(TO_DATETIME, result[3]);
  }

  @Test
  public void testParseWithNumericTargetCalendar() {
    CopyEventParser parser = new CopyEventParser();
    List<String> tokens = Arrays.asList("copy", "event", "Meeting", "on", 
        "2023-12-15T10:00", "--target", "Calendar1", "to", "2023-12-16T14:00");

    Object[] result = parser.parse(tokens);

    assertNotNull(result);
    assertEquals(4, result.length);
    assertEquals("Meeting", result[0]);
    assertEquals(ON_DATETIME, result[1]);
    assertEquals("Calendar1", result[2]);
    assertEquals(TO_DATETIME, result[3]);
  }
}