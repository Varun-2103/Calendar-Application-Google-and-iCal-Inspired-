package calendar.controller.components.validators;

import java.util.Arrays;
import java.util.List;
import org.junit.Test;

/**
 * Test class for CreateEventValidator.
 */
public class CreateEventValidatorTest {

  private final CreateEventValidator validator = new CreateEventValidator();

  @Test
  public void testValidateOnFormatValid() {
    List<String> tokens = Arrays.asList("create", "event", "\"Meeting\"", "on", "2023-12-01");
    validator.validate(tokens);
  }

  @Test
  public void testValidateFromFormatValid() {
    List<String> tokens = Arrays.asList("create", "event", "\"Meeting\"", "from",
        "2023-12-01T10:00", "to", "2023-12-01T11:00");
    validator.validate(tokens);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testValidateCommandTooShort() {
    List<String> tokens = Arrays.asList("create", "event", "\"Meeting\"");
    validator.validate(tokens);
  }



  @Test(expected = IllegalArgumentException.class)
  public void testValidateOnMissingDate() {
    List<String> tokens = Arrays.asList("create", "event", "\"Meeting\"", "on");
    validator.validate(tokens);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testValidateFromMissingStartTime() {
    List<String> tokens = Arrays.asList("create", "event", "\"Meeting\"", "from");
    validator.validate(tokens);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testValidateFromMissingToKeyword() {
    List<String> tokens = Arrays.asList("create", "event", "\"Meeting\"", "from",
        "2023-12-01T10:00");
    validator.validate(tokens);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testValidateFromMissingEndTime() {
    List<String> tokens = Arrays.asList("create", "event", "\"Meeting\"", "from",
        "2023-12-01T10:00", "to");
    validator.validate(tokens);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testValidateMissingOnOrFrom() {
    List<String> tokens = Arrays.asList("create", "event", "\"Meeting\"", "wrong", "2023-12-01");
    validator.validate(tokens);
  }

  @Test
  public void testValidatePropertySubject() {
    List<String> tokens = Arrays.asList("create", "event", "\"Meeting\"", "from",
        "2023-12-01T10:00", "to", "2023-12-01T11:00");
    validator.validate(tokens);
  }

  @Test
  public void testValidatePropertyLocation() {
    List<String> tokens = Arrays.asList("create", "event", "\"Meeting\"", "from",
        "2023-12-01T10:00", "to", "2023-12-01T11:00");
    validator.validate(tokens);
  }

  @Test
  public void testValidatePropertyDescription() {
    List<String> tokens = Arrays.asList("create", "event", "\"Meeting\"", "from",
        "2023-12-01T10:00", "to", "2023-12-01T11:00");
    validator.validate(tokens);
  }

  @Test
  public void testValidatePropertyStatus() {
    List<String> tokens = Arrays.asList("create", "event", "\"Meeting\"", "from",
        "2023-12-01T10:00", "to", "2023-12-01T11:00");
    validator.validate(tokens);
  }

  @Test
  public void testValidatePropertyStart() {
    List<String> tokens = Arrays.asList("create", "event", "\"Meeting\"", "from",
        "2023-12-01T10:00", "to", "2023-12-01T11:00");
    validator.validate(tokens);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testValidateOnWithoutDate() {
    List<String> tokens = Arrays.asList("create", "event", "\"Meeting\"", "on");
    validator.validate(tokens);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testValidateFromWithoutStartTime() {
    List<String> tokens = Arrays.asList("create", "event", "\"Meeting\"", "from", "to", 
        "2023-12-01T11:00");
    validator.validate(tokens);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testValidateFromWithoutToKeyword() {
    List<String> tokens = Arrays.asList("create", "event", "\"Meeting\"", "from", 
        "2023-12-01T10:00");
    validator.validate(tokens);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testValidateFromWithoutEndTime() {
    List<String> tokens = Arrays.asList("create", "event", "\"Meeting\"", "from", 
        "2023-12-01T10:00", "to");
    validator.validate(tokens);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testValidateNeitherOnNorFrom() {
    List<String> tokens = Arrays.asList("create", "event", "\"Meeting\"", "at", "2023-12-01");
    validator.validate(tokens);
  }

  @Test
  public void testValidateBothOnAndFrom() {
    // This should validate the "from" path since both are present
    List<String> tokens = Arrays.asList("create", "event", "\"Meeting\"", "on", 
        "2023-12-01", "from", "2023-12-01T10:00", "to", "2023-12-01T11:00");
    validator.validate(tokens);
  }

  @Test
  public void testValidateFindKeywordIndexCaseInsensitive() {
    // Test that findKeywordIndex is case insensitive
    List<String> tokens = Arrays.asList("create", "event", "\"Meeting\"", "FROM",
        "2023-12-01T10:00", "TO", "2023-12-01T11:00");
    validator.validate(tokens);
  }

  @Test
  public void testValidateWithExtraTokensAfterFrom() {
    // Test with extra tokens between from and time
    List<String> tokens = Arrays.asList("create", "event", "\"Meeting\"", "from",
        "extra", "2023-12-01T10:00", "to", "2023-12-01T11:00");
    validator.validate(tokens);
  }

  @Test
  public void testValidateWithExtraTokensAfterTo() {
    // Test with extra tokens between to and time
    List<String> tokens = Arrays.asList("create", "event", "\"Meeting\"", "from",
        "2023-12-01T10:00", "to", "extra", "2023-12-01T11:00");
    validator.validate(tokens);
  }


  @Test(expected = IllegalArgumentException.class)
  public void testValidateOnAtCommandEnd() {
    List<String> tokens = Arrays.asList("create", "event", "\"Meeting\"", "on");
    validator.validate(tokens);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testValidateFromAtTokensEnd() {
    List<String> tokens = Arrays.asList("create", "event", "\"Meeting\"", "from");
    validator.validate(tokens);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testValidateToAtTokensEnd() {
    List<String> tokens = Arrays.asList("create", "event", "\"Meeting\"", "from",
        "2023-12-01T10:00", "to");
    validator.validate(tokens);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testValidateToWithoutEndTime() {
    List<String> tokens = Arrays.asList("create", "event", "\"Meeting\"", "from",
        "2023-12-01T10:00", "to");
    validator.validate(tokens);
  }
}