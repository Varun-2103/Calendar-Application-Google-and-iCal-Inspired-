package calendar.controller.components.validators;

import java.util.Arrays;
import java.util.List;
import org.junit.Test;

/**
 * Test class for ShowStatusValidator.
 */
public class ShowStatusValidatorTest {

  private final ShowStatusValidator validator = new ShowStatusValidator();

  @Test
  public void testValidateValidCommand() {
    List<String> tokens = Arrays.asList("show", "status", "on", "2023-12-01T10:00");
    validator.validate(tokens);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testValidateCommandTooShort() {
    List<String> tokens = Arrays.asList("show", "status");
    validator.validate(tokens);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testValidateMissingOnKeyword() {
    List<String> tokens = Arrays.asList("show", "status", "wrong", "2023-12-01T10:00");
    validator.validate(tokens);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testValidateSizeLessThan4() {
    List<String> tokens = Arrays.asList("show", "status", "on");
    validator.validate(tokens);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testValidateEmptyDateTime() {
    List<String> tokens = Arrays.asList("show", "status", "on", "");
    validator.validate(tokens);
  }
}