package calendar.controller;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import calendar.model.Event;
import calendar.model.InterfaceEvent;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import org.junit.Test;

/**
 * Comprehensive test suite for CommandResult class.
 * Tests all functionality including creation, properties, and edge cases.
 */
public class CommandResultTest {

  private static final String COMPLETED_SUCCESSFULLY = "Operation completed successfully";
  private static final String OPERATION_FAILED = "Operation failed";
  private static final List<InterfaceEvent> IMPLEMENTS = Arrays.asList(
      new Event("Meeting 1", LocalDateTime.of(2023, 12, 15, 10, 0),
          LocalDateTime.of(2023, 12, 15, 11, 0)),
      new Event("Meeting 2", LocalDateTime.of(2023, 12, 16, 14, 0),
          LocalDateTime.of(2023, 12, 16, 15, 0))
  );

  @Test
  public void testCommandResultCreationWithSuccessOnlyCreatesSuccessfulResult() {
    CommandResult result = new CommandResult(true, COMPLETED_SUCCESSFULLY);

    assertTrue(result.isSuccess());
    assertEquals(COMPLETED_SUCCESSFULLY, result.getMessage());
    assertNotNull(result.getEvents());
    assertFalse(result.hasEvents());
  }

  @Test
  public void testCommandResultCreationWithFailureOnlyCreatesFailedResult() {
    CommandResult result = new CommandResult(false, OPERATION_FAILED);

    assertFalse(result.isSuccess());
    assertEquals(OPERATION_FAILED, result.getMessage());
    assertNotNull(result.getEvents());
    assertFalse(result.hasEvents());
  }

  @Test
  public void testCommandResultCreationWithEventsCreatesResultWithEvents() {
    CommandResult result = new CommandResult(true, COMPLETED_SUCCESSFULLY, IMPLEMENTS);

    assertTrue(result.isSuccess());
    assertEquals(COMPLETED_SUCCESSFULLY, result.getMessage());
    assertNotNull(result.getEvents());
    assertEquals(IMPLEMENTS.size(), result.getEvents().size());
  }

  @Test
  public void testCommandResultCreationWithNullEventsCreatesResultWithEmptyEvents() {
    CommandResult result = new CommandResult(true, COMPLETED_SUCCESSFULLY, null);

    assertTrue(result.isSuccess());
    assertEquals(COMPLETED_SUCCESSFULLY, result.getMessage());
    assertNotNull(result.getEvents());
    assertFalse(result.hasEvents());
  }

  @Test
  public void testGetEventsReturnsCopyNotReference() {
    List<InterfaceEvent> originalEvents = new ArrayList<>();
    CommandResult result = new CommandResult(true, COMPLETED_SUCCESSFULLY, originalEvents);

    List<InterfaceEvent> retrievedEvents = result.getEvents();
    retrievedEvents.clear();

    assertFalse(result.hasEvents());
  }

  @Test
  public void testHasEventsWithEventsReturnsTrue() {
    CommandResult result = new CommandResult(true, COMPLETED_SUCCESSFULLY, IMPLEMENTS);

    assertTrue(result.hasEvents());
  }

  @Test
  public void testHasEventsWithoutEventsReturnsFalse() {
    CommandResult result = new CommandResult(true, COMPLETED_SUCCESSFULLY);

    assertFalse(result.hasEvents());
  }

  @Test
  public void testHasEventsWithNullEventsReturnsFalse() {
    CommandResult result = new CommandResult(true, COMPLETED_SUCCESSFULLY, null);

    assertFalse(result.hasEvents());
  }

  @Test
  public void testGetEventsWithEventsReturnsEvents() {
    CommandResult result = new CommandResult(true, COMPLETED_SUCCESSFULLY, IMPLEMENTS);

    List<InterfaceEvent> events = result.getEvents();
    assertEquals(IMPLEMENTS.size(), events.size());
  }

  @Test
  public void testGetEventsWithoutEventsReturnsEmptyList() {
    CommandResult result = new CommandResult(true, COMPLETED_SUCCESSFULLY);

    List<InterfaceEvent> events = result.getEvents();
    assertNotNull(events);
    assertTrue(events.isEmpty());
  }

  @Test
  public void testGetEventsWithNullEventsReturnsEmptyList() {
    CommandResult result = new CommandResult(true, COMPLETED_SUCCESSFULLY, null);

    List<InterfaceEvent> events = result.getEvents();
    assertNotNull(events);
    assertTrue(events.isEmpty());
  }

  @Test
  public void testIsSuccessSuccessfulResultReturnsTrue() {
    CommandResult result = new CommandResult(true, COMPLETED_SUCCESSFULLY);

    assertTrue(result.isSuccess());
  }

  @Test
  public void testIsSuccessFailedResultReturnsFalse() {
    CommandResult result = new CommandResult(false, OPERATION_FAILED);

    assertFalse(result.isSuccess());
  }

  @Test
  public void testGetMessageSuccessfulResultReturnsSuccessMessage() {
    CommandResult result = new CommandResult(true, COMPLETED_SUCCESSFULLY);

    assertEquals(COMPLETED_SUCCESSFULLY, result.getMessage());
  }

  @Test
  public void testGetMessageFailedResultReturnsErrorMessage() {
    CommandResult result = new CommandResult(false, OPERATION_FAILED);

    assertEquals(OPERATION_FAILED, result.getMessage());
  }

  @Test
  public void testCommandResultWithEmptyMessageHandlesCorrectly() {
    CommandResult result = new CommandResult(true, "");

    assertTrue(result.isSuccess());
    assertEquals("", result.getMessage());
  }

  @Test
  public void testCommandResultWithNullMessageHandlesCorrectly() {
    CommandResult result = new CommandResult(true, null);

    assertTrue(result.isSuccess());
    assertEquals(null, result.getMessage());
  }

  @Test
  public void testCommandResultWithLongMessageHandlesCorrectly() {
    String longMessage = "This is a very long message that contains a lot of detail "
        + "about the operation that was performed and should be handled correctly "
        + "by the CommandResult class without any issues or truncation.";

    CommandResult result = new CommandResult(true, longMessage);

    assertTrue(result.isSuccess());
    assertEquals(longMessage, result.getMessage());
  }

  @Test
  public void testCommandResultWithSpecialCharactersHandlesCorrectly() {
    String specialMessage = "Operation completed with special chars: !@#$%^&*()+-=[]{}|;':\",./<>?";

    CommandResult result = new CommandResult(true, specialMessage);

    assertTrue(result.isSuccess());
    assertEquals(specialMessage, result.getMessage());
  }

  @Test
  public void testCommandResultWithUnicodeHandlesCorrectly() {
    String unicodeMessage = "操作成功完成 📅 日历 Calendrier";

    CommandResult result = new CommandResult(true, unicodeMessage);

    assertTrue(result.isSuccess());
    assertEquals(unicodeMessage, result.getMessage());
  }

  @Test
  public void testCommandResultWithMultipleEventsCreatesCorrectResult() {
    List<InterfaceEvent> multipleEvents = Arrays.asList(
        IMPLEMENTS.get(0),
        IMPLEMENTS.get(1)
    );
    CommandResult result = new CommandResult(true, COMPLETED_SUCCESSFULLY, multipleEvents);

    assertTrue(result.isSuccess());
    assertEquals(COMPLETED_SUCCESSFULLY, result.getMessage());
    assertEquals(2, result.getEvents().size());
    assertTrue(result.hasEvents());
  }

  @Test
  public void testCommandResultImmutabilityEventsListCannotModifyOriginal() {
    List<InterfaceEvent> originalEvents = new ArrayList<>(IMPLEMENTS);
    CommandResult result = new CommandResult(true, COMPLETED_SUCCESSFULLY, originalEvents);

    originalEvents.clear();

    assertTrue(result.hasEvents());
    assertEquals(IMPLEMENTS.size(), result.getEvents().size());
  }

  @Test
  public void testCommandResultImmutabilityRetrievedEventsCannotModifyResult() {
    CommandResult result = new CommandResult(true, COMPLETED_SUCCESSFULLY, IMPLEMENTS);

    List<InterfaceEvent> retrievedEvents = result.getEvents();
    retrievedEvents.clear();

    assertTrue(result.hasEvents());
    assertEquals(IMPLEMENTS.size(), result.getEvents().size());
  }

  @Test
  public void testCommandResultConsistencyMultipleCallsReturnSameValues() {
    CommandResult result = new CommandResult(true, COMPLETED_SUCCESSFULLY, IMPLEMENTS);

    for (int i = 0; i < 5; i++) {
      assertTrue(result.isSuccess());
      assertEquals(COMPLETED_SUCCESSFULLY, result.getMessage());
      assertTrue(result.hasEvents());
      assertEquals(IMPLEMENTS.size(), result.getEvents().size());
    }
  }

  @Test
  public void testCommandResultWithEmptyEventsListHandlesCorrectly() {
    List<InterfaceEvent> emptyEvents = new ArrayList<>();
    CommandResult result = new CommandResult(true, COMPLETED_SUCCESSFULLY, emptyEvents);

    assertTrue(result.isSuccess());
    assertEquals(COMPLETED_SUCCESSFULLY, result.getMessage());
    assertNotNull(result.getEvents());
    assertFalse(result.hasEvents());
  }

  @Test
  public void testCommandResultEdgeCasesAllCombinations() {
    CommandResult successWithoutEvents = new CommandResult(true, COMPLETED_SUCCESSFULLY);
    CommandResult successWithEvents = new CommandResult(true, COMPLETED_SUCCESSFULLY,
        IMPLEMENTS);

    assertTrue(successWithoutEvents.isSuccess());
    assertFalse(successWithoutEvents.hasEvents());

    assertTrue(successWithEvents.isSuccess());
    assertTrue(successWithEvents.hasEvents());

    CommandResult failureWithoutEvents = new CommandResult(false, OPERATION_FAILED);
    CommandResult failureWithEvents = new CommandResult(false, OPERATION_FAILED,
        IMPLEMENTS);

    assertFalse(failureWithoutEvents.isSuccess());
    assertFalse(failureWithoutEvents.hasEvents());

    assertFalse(failureWithEvents.isSuccess());
    assertTrue(failureWithEvents.hasEvents());
  }
}