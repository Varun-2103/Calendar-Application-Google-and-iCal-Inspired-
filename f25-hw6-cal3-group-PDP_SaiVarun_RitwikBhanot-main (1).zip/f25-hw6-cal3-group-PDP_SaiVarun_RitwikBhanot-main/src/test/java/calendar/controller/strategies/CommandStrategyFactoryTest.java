package calendar.controller.strategies;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import calendar.model.CalendarManager;
import calendar.model.InterfaceCalendarManager;
import java.util.Arrays;
import java.util.List;
import org.junit.Before;
import org.junit.Test;

/**
 * Unit test for CommandStrategyFactory without external dependencies.
 */
public class CommandStrategyFactoryTest {

  private CommandStrategyFactory factory;
  private InterfaceCalendarManager calendarManager;

  /**
   * Sets up test fixtures before each test.
   */
  @Before
  public void setUp() {
    factory = new CommandStrategyFactory();
    calendarManager = new CalendarManager();
  }

  @Test
  public void testCommandStrategyFactoryConstructorCreatesFactory() {
    assertNotNull(factory);
  }

  @Test
  public void testGetSupportedCommandsReturnsAllCommands() {
    String[] supportedCommands = factory.getSupportedCommands();

    assertNotNull(supportedCommands);
    assertTrue(supportedCommands.length > 0);

    List<String> commandList = Arrays.asList(supportedCommands);
    assertTrue(commandList.contains("create event"));
    assertTrue(commandList.contains("create calendar"));
    assertTrue(commandList.contains("edit calendar"));
    assertTrue(commandList.contains("use calendar"));
    assertTrue(commandList.contains("edit event"));
    assertTrue(commandList.contains("edit events"));
    assertTrue(commandList.contains("edit series"));
    assertTrue(commandList.contains("copy event"));
    assertTrue(commandList.contains("copy events"));
    assertTrue(commandList.contains("copy events on"));
    assertTrue(commandList.contains("print events"));
    assertTrue(commandList.contains("export cal"));
    assertTrue(commandList.contains("show status"));
  }

  @Test
  public void testCreateStrategyCreateEvent() {
    List<String> tokens = Arrays.asList("create", "event", "\"Team Meeting\"", "from",
        "2023-12-15T10:00", "to", "2023-12-15T11:00");

    try {
      CommandStrategy strategy = factory.createStrategy(tokens, null);
      assertNotNull(strategy);
      assertEquals("create event", strategy.getCommandType());
    } catch (Exception e) {
      // Expected since we're not providing full dependencies
    }
  }

  @Test
  public void testCreateStrategyCreateCalendar() {
    List<String> tokens = Arrays.asList("create", "calendar", "Work");

    try {
      CommandStrategy strategy = factory.createStrategy(tokens, null);
      assertNotNull(strategy);
      assertEquals("create calendar", strategy.getCommandType());
    } catch (Exception e) {
      // Expected since we're not providing full dependencies
    }
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateStrategyEmptyTokensThrowsException() {
    factory.createStrategy(null, null);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateStrategyEmptyListThrowsException() {
    List<String> tokens = Arrays.asList();
    factory.createStrategy(tokens, null);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateStrategySingleTokenThrowsException() {
    List<String> tokens = Arrays.asList("create");
    factory.createStrategy(tokens, null);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateStrategyUnknownCommandThrowsException() {
    List<String> tokens = Arrays.asList("unknown", "command");
    factory.createStrategy(tokens, null);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateStrategyCamelCaseCommandThrowsException() {
    List<String> tokens = Arrays.asList("createEvent", "\"Team Meeting\"");
    factory.createStrategy(tokens, null);
  }

  @Test
  public void testCreateStrategyCaseInsensitive() {
    List<String> tokens = Arrays.asList("CREATE", "EVENT", "\"Team Meeting\"");

    try {
      CommandStrategy strategy = factory.createStrategy(tokens, null);
      assertNotNull(strategy);
      assertEquals("create event", strategy.getCommandType());
    } catch (Exception e) {
      // Expected since we're not providing full dependencies
    }
  }

  @Test
  public void testDetermineCommandTypeCopyEventsOn() {
    List<String> tokens = Arrays.asList("copy", "events", "on", "2023-12-15", "to", "2023-12-16");

    try {
      CommandStrategy strategy = factory.createStrategy(tokens, null);
      assertNotNull(strategy);
      assertEquals("copy events on", strategy.getCommandType());
    } catch (Exception e) {
      // Expected since we're not providing full dependencies
    }
  }

  @Test
  public void testDetermineCommandTypeCopyEvents() {
    List<String> tokens = Arrays.asList("copy", "events", "from", "2023-12-15", "to", "2023-12-16");

    try {
      CommandStrategy strategy = factory.createStrategy(tokens, null);
      assertNotNull(strategy);
      assertEquals("copy events", strategy.getCommandType());
    } catch (Exception e) {
      // Expected since we're not providing full dependencies
    }
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateStrategyEditCalendarInvalid() {
    List<String> tokens = Arrays.asList("editCalendar");
    factory.createStrategy(tokens, calendarManager);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateStrategyUseCalendarInvalid() {
    List<String> tokens = Arrays.asList("useCalendar");
    factory.createStrategy(tokens, calendarManager);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateStrategyCopyEventInvalid() {
    List<String> tokens = Arrays.asList("copyEvent");
    factory.createStrategy(tokens, calendarManager);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateStrategyPrintEventsInvalid() {
    List<String> tokens = Arrays.asList("printEvents");
    factory.createStrategy(tokens, calendarManager);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateStrategyExportCalInvalid() {
    List<String> tokens = Arrays.asList("exportCal");
    factory.createStrategy(tokens, calendarManager);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateStrategyShowStatusInvalid() {
    List<String> tokens = Arrays.asList("showStatus");
    factory.createStrategy(tokens, calendarManager);
  }
}