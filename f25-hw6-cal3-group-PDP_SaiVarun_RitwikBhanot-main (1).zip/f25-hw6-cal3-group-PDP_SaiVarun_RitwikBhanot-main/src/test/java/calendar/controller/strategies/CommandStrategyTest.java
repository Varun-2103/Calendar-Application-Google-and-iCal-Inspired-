package calendar.controller.strategies;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import calendar.controller.CommandResult;
import calendar.controller.components.CommandExecutor;
import calendar.controller.components.CommandParser;
import calendar.controller.components.CommandValidator;
import java.util.Arrays;
import java.util.List;
import org.junit.Before;
import org.junit.Test;

/**
 * Unit test for CommandStrategy without external dependencies.
 */
public class CommandStrategyTest {

  private CommandStrategy strategy;
  private TestCommandValidator mockValidator;
  private TestCommandParser mockParser;
  private TestCommandExecutor mockExecutor;

  /**
   * Sets up test fixtures before each test.
   */
  @Before
  public void setUp() {
    mockValidator = new TestCommandValidator();
    mockParser = new TestCommandParser();
    mockExecutor = new TestCommandExecutor();
    
    strategy = new CommandStrategy("test command", mockValidator, mockParser, mockExecutor);
  }

  @Test
  public void testCommandStrategyConstructorCreatesStrategy() {
    assertNotNull(strategy);
    assertEquals("test command", strategy.getCommandType());
  }

  @Test
  public void testGetCommandTypeReturnsCorrectType() {
    assertEquals("test command", strategy.getCommandType());
  }

  @Test
  public void testExecuteSuccessfulValidationParsingAndExecution() {
    List<String> tokens = Arrays.asList("test", "command", "parameter1", "parameter2");
    
    CommandResult result = strategy.execute(tokens);

    assertTrue(result.isSuccess());
    assertEquals("Command executed successfully", result.getMessage());
  }

  @Test
  public void testExecuteWithValidationFailureReturnsErrorResult() {
    List<String> tokens = Arrays.asList("invalid", "command");
    mockValidator.setShouldFail(true);
    
    CommandResult result = strategy.execute(tokens);

    assertFalse(result.isSuccess());
    assertEquals("Validation failed", result.getMessage());
  }

  @Test
  public void testExecuteWithParsingFailureReturnsErrorResult() {
    List<String> tokens = Arrays.asList("test", "command");
    mockParser.setShouldFail(true);
    
    CommandResult result = strategy.execute(tokens);

    assertFalse(result.isSuccess());
    assertEquals("Parsing failed", result.getMessage());
  }

  @Test
  public void testExecuteWithExecutionFailureReturnsErrorResult() {
    List<String> tokens = Arrays.asList("test", "command");
    mockExecutor.setShouldFail(true);
    
    CommandResult result = strategy.execute(tokens);

    assertFalse(result.isSuccess());
    assertEquals("Execution failed", result.getMessage());
  }

  @Test
  public void testExecuteWithNullTokensStillValidates() {
    try {
      strategy.execute(null);
    } catch (Exception e) {
      // Expected to throw exception, but validator should still be called
    }
  }

  @Test
  public void testExecuteWithEmptyTokensStillValidates() {
    List<String> emptyTokens = Arrays.asList();
    
    try {
      strategy.execute(emptyTokens);
    } catch (Exception e) {
      // Expected to throw exception, but validator should still be called
    }
  }

  @Test
  public void testExecuteMultipleCallsWorkCorrectly() {
    List<String> tokens = Arrays.asList("test", "command");
    
    CommandResult result1 = strategy.execute(tokens);
    CommandResult result2 = strategy.execute(tokens);

    assertTrue(result1.isSuccess());
    assertTrue(result2.isSuccess());
  }

  @Test
  public void testExecuteWithDifferentTokenLists() {
    List<String> tokens1 = Arrays.asList("command1", "param1");
    List<String> tokens2 = Arrays.asList("command2", "param2", "param3");
    
    CommandResult result1 = strategy.execute(tokens1);
    CommandResult result2 = strategy.execute(tokens2);

    assertTrue(result1.isSuccess());
    assertTrue(result2.isSuccess());
  }

  // Test helper classes to avoid external dependencies
  private static class TestCommandValidator implements CommandValidator {
    private boolean shouldFail = false;

    public void setShouldFail(boolean shouldFail) {
      this.shouldFail = shouldFail;
    }

    @Override
    public void validate(List<String> tokens) {
      if (shouldFail) {
        throw new IllegalArgumentException("Validation failed");
      }
      if (tokens == null || tokens.isEmpty()) {
        throw new IllegalArgumentException("Empty tokens");
      }
    }
  }

  private static class TestCommandParser implements CommandParser {
    private boolean shouldFail = false;

    public void setShouldFail(boolean shouldFail) {
      this.shouldFail = shouldFail;
    }

    @Override
    public Object[] parse(List<String> tokens) {
      if (shouldFail) {
        throw new IllegalArgumentException("Parsing failed");
      }
      return new Object[]{"param1", "param2"};
    }
  }

  private static class TestCommandExecutor implements CommandExecutor {
    private boolean shouldFail = false;

    public void setShouldFail(boolean shouldFail) {
      this.shouldFail = shouldFail;
    }

    @Override
    public CommandResult execute(Object[] parameters) {
      if (shouldFail) {
        throw new IllegalArgumentException("Execution failed");
      }
      return new CommandResult(true, "Command executed successfully");
    }
  }
}