package calendar.integration;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import calendar.controller.CommandParser;
import calendar.controller.CommandResult;
import calendar.controller.InterfaceCommand;
import calendar.model.CalendarManager;
import org.junit.Before;
import org.junit.Test;

/**
 * Integration tests for edge cases and error scenarios across all commands.
 */
public class EdgeCasesIntegrationTest {

  private CommandParser parser;
  private CalendarManager manager;

  /** Sets up test environment before each test. */
  @Before
  public void setUp() {
    manager = new CalendarManager();
    parser = new CommandParser();
  }

  // Create Calendar Edge Cases
  @Test
  public void testCreateCalendarWithVeryLongName() {
    String longName = "This is a very long calendar name that contains many words "
        + "and should still be handled correctly by the system without any issues";

    InterfaceCommand command = parser.parse(
        "create calendar --name \"" + longName + "\" --timezone America/New_York");
    CommandResult result = command.execute(manager);

    assertTrue(result.isSuccess());
    assertTrue(manager.calendarExists(longName));
  }

  @Test
  public void testCreateCalendarWithSpecialCharacters() {
    InterfaceCommand command = parser.parse(
        "create calendar --name \"Work & Personal (2023)\" --timezone America/New_York");
    CommandResult result = command.execute(manager);

    assertTrue(result.isSuccess());
    assertTrue(manager.calendarExists("Work & Personal (2023)"));
  }

  @Test
  public void testCreateCalendarWithUnicodeCharacters() {
    InterfaceCommand command = parser.parse(
        "create calendar --name \"📅 日历 Calendrier Календарь\" --timezone Asia/Tokyo");
    CommandResult result = command.execute(manager);

    assertTrue(result.isSuccess());
    assertTrue(manager.calendarExists("📅 日历 Calendrier Календарь"));
  }

  @Test
  public void testCreateCalendarWithObscureTimezone() {
    InterfaceCommand command = parser.parse(
        "create calendar --name \"Remote\" --timezone Antarctica/McMurdo");
    CommandResult result = command.execute(manager);

    assertTrue(result.isSuccess());
    assertTrue(manager.calendarExists("Remote"));
  }

  // Use Calendar Edge Cases
  @Test
  public void testUseCalendarWithSpecialCharacters() {
    parser.parse("create calendar --name \"Test & Demo\" --timezone America/New_York")
        .execute(manager);

    InterfaceCommand command = parser.parse("use calendar --name \"Test & Demo\"");
    CommandResult result = command.execute(manager);

    assertTrue(result.isSuccess());
    assertEquals("Test & Demo", manager.getActiveCalendarName());
  }

  // Create Event Edge Cases
  @Test
  public void testCreateEventWithVeryLongSubject() {
    parser.parse("create calendar --name \"Test\" --timezone America/New_York").execute(manager);
    parser.parse("use calendar --name \"Test\"").execute(manager);

    String longSubject = "This is a very long event subject that contains many words "
        + "and should still be handled correctly by the system without any issues";

    InterfaceCommand command = parser.parse(
        "create event \"" + longSubject + "\" from 2023-12-01T10:00 to 2023-12-01T11:00");
    CommandResult result = command.execute(manager);

    assertTrue(result.isSuccess());
  }

  @Test
  public void testCreateEventWithSpecialCharacters() {
    parser.parse("create calendar --name \"Test\" --timezone America/New_York").execute(manager);
    parser.parse("use calendar --name \"Test\"").execute(manager);

    InterfaceCommand command = parser.parse(
        "create event \"Meeting @ Conference Room #1 (Important!)\" from 2023-12-01T10:00 "
            + "to 2023-12-01T11:00");
    CommandResult result = command.execute(manager);

    assertTrue(result.isSuccess());
  }

  @Test
  public void testCreateEventWithUnicodeCharacters() {
    parser.parse("create calendar --name \"Test\" --timezone America/New_York").execute(manager);
    parser.parse("use calendar --name \"Test\"").execute(manager);

    InterfaceCommand command = parser.parse(
        "create event \"会议 📅 Réunion\" from 2023-12-01T10:00 "
            + "to 2023-12-01T11:00");
    CommandResult result = command.execute(manager);

    assertTrue(result.isSuccess());
  }

  @Test
  public void testCreateEventAtMidnight() {
    parser.parse("create calendar --name \"Test\" --timezone America/New_York").execute(manager);
    parser.parse("use calendar --name \"Test\"").execute(manager);

    InterfaceCommand command = parser.parse(
        "create event \"Midnight Event\" from 2023-12-01T00:00 to 2023-12-01T01:00");
    CommandResult result = command.execute(manager);

    assertTrue(result.isSuccess());
  }

  @Test
  public void testCreateEventAtEndOfDay() {
    parser.parse("create calendar --name \"Test\" --timezone America/New_York").execute(manager);
    parser.parse("use calendar --name \"Test\"").execute(manager);

    InterfaceCommand command = parser.parse(
        "create event \"Late Night Event\" from 2023-12-01T23:00 to 2023-12-01T23:59");
    CommandResult result = command.execute(manager);

    assertTrue(result.isSuccess());
  }

  @Test
  public void testCreateMultiDayEventSpanningMonths() {
    parser.parse("create calendar --name \"Test\" --timezone America/New_York").execute(manager);
    parser.parse("use calendar --name \"Test\"").execute(manager);

    InterfaceCommand command = parser.parse(
        "create event \"Long Trip\" from 2023-12-30T10:00 "
            + "to 2024-01-02T17:00");
    CommandResult result = command.execute(manager);

    assertTrue(result.isSuccess());
  }

  @Test
  public void testCreateEventWithVeryShortDuration() {
    parser.parse("create calendar --name \"Test\" --timezone America/New_York").execute(manager);
    parser.parse("use calendar --name \"Test\"").execute(manager);

    InterfaceCommand command = parser.parse(
        "create event \"Quick Sync\" from 2023-12-01T10:00 to 2023-12-01T10:01");
    CommandResult result = command.execute(manager);

    assertTrue(result.isSuccess());
  }

  @Test
  public void testCreateEventWithZeroDuration() {
    parser.parse("create calendar --name \"Test\" --timezone America/New_York").execute(manager);
    parser.parse("use calendar --name \"Test\"").execute(manager);

    InterfaceCommand command = parser.parse(
        "create event \"Instant Event\" from 2023-12-01T10:00 to 2023-12-01T10:00");
    CommandResult result = command.execute(manager);

    // This might succeed or fail depending on implementation
    // Test that it doesn't crash the system
    assertTrue(result.isSuccess() || result.getMessage() != null);
  }

  // Event Series Edge Cases
  @Test
  public void testCreateEventSeriesWithSingleWeekday() {
    parser.parse("create calendar --name \"Test\" --timezone America/New_York").execute(manager);
    parser.parse("use calendar --name \"Test\"").execute(manager);

    InterfaceCommand command = parser.parse(
        "create event \"Weekly Meeting\" from 2023-12-01T10:00 to 2023-12-01T11:00 "
            + "repeats M for 10 times");
    CommandResult result = command.execute(manager);

    assertTrue(result.isSuccess());
  }

  @Test
  public void testCreateEventSeriesWithAllWeekdays() {
    parser.parse("create calendar --name \"Test\" --timezone America/New_York").execute(manager);
    parser.parse("use calendar --name \"Test\"").execute(manager);

    InterfaceCommand command = parser.parse(
        "create event \"Daily Task\" from 2023-12-01T08:00 to 2023-12-01T08:15 "
            + "repeats MTWRFSU for 14 times");
    CommandResult result = command.execute(manager);

    assertTrue(result.isSuccess());
  }

  @Test
  public void testCreateEventSeriesWithOnlyWeekends() {
    parser.parse("create calendar --name \"Test\" --timezone America/New_York").execute(manager);
    parser.parse("use calendar --name \"Test\"").execute(manager);

    InterfaceCommand command = parser.parse(
        "create event \"Weekend Activity\" from 2023-12-01T10:00 to 2023-12-01T12:00 "
            + "repeats SU for 8 times");
    CommandResult result = command.execute(manager);

    assertTrue(result.isSuccess());
  }

  @Test
  public void testCreateEventSeriesUntilLeapYear() {
    parser.parse("create calendar --name \"Test\" --timezone America/New_York").execute(manager);
    parser.parse("use calendar --name \"Test\"").execute(manager);

    InterfaceCommand command = parser.parse(
        "create event \"Leap Year Series\" from 2024-02-01T10:00 to 2024-02-01T11:00 "
            + "repeats D until 2024-03-01");
    CommandResult result = command.execute(manager);

    assertTrue(result.isSuccess());
  }

  // Edit Event Edge Cases
  @Test
  public void testEditEventToSameValues() {
    parser.parse("create calendar --name \"Test\" --timezone America/New_York").execute(manager);
    parser.parse("use calendar --name \"Test\"").execute(manager);
    parser.parse("create event \"Meeting\" from 2023-12-01T10:00 to 2023-12-01T11:00")
        .execute(manager);

    InterfaceCommand command = parser.parse(
        "edit event subject \"Meeting\" from 2023-12-01T10:00 to 2023-12-01T11:00 "
            + "with \"Meeting\"");
    CommandResult result = command.execute(manager);

    assertTrue(result.isSuccess());
  }

  @Test
  public void testEditEventWithEmptySubject() {
    parser.parse("create calendar --name \"Test\" --timezone America/New_York").execute(manager);
    parser.parse("use calendar --name \"Test\"").execute(manager);
    parser.parse("create event \"Meeting\" from 2023-12-01T10:00 to 2023-12-01T11:00")
        .execute(manager);

    InterfaceCommand command = parser.parse(
        "edit event subject \"Meeting\" from 2023-12-01T10:00 to 2023-12-01T11:00 "
            + "with \"\"");
    CommandResult result = command.execute(manager);

    assertFalse(result.isSuccess());
    assertTrue(result.getMessage().toLowerCase().contains("subject")
        || result.getMessage().toLowerCase().contains("empty"));
  }

  // Copy Event Edge Cases
  @Test
  public void testCopyEventToSameTime() {
    parser.parse("create calendar --name \"Source\" --timezone America/New_York").execute(manager);
    parser.parse("use calendar --name \"Source\"").execute(manager);
    parser.parse("create event \"Meeting\" from 2023-12-01T10:00 to 2023-12-01T11:00")
        .execute(manager);
    parser.parse("create calendar --name \"Target\" --timezone America/New_York").execute(manager);

    InterfaceCommand command = parser.parse(
        "copy event \"Meeting\" on 2023-12-01T10:00 --target Target to 2023-12-01T10:00");
    CommandResult result = command.execute(manager);

    assertTrue(result.isSuccess());
  }

  @Test
  public void testCopyEventAcrossYearBoundary() {
    parser.parse("create calendar --name \"Source\" --timezone America/New_York").execute(manager);
    parser.parse("use calendar --name \"Source\"").execute(manager);
    parser.parse("create event \"New Year Eve\" from 2023-12-31T23:00 to 2024-01-01T01:00")
        .execute(manager);
    parser.parse("create calendar --name \"Target\" --timezone America/New_York").execute(manager);

    InterfaceCommand command = parser.parse(
        "copy event \"New Year Eve\" on 2023-12-31T23:00 --target Target "
            + "to 2024-01-01T23:00");
    CommandResult result = command.execute(manager);

    assertTrue(result.isSuccess());
  }

  @Test
  public void testCopyEventsWithSameSourceAndTarget() {
    parser.parse("create calendar --name \"Work\" --timezone America/New_York").execute(manager);
    parser.parse("use calendar --name \"Work\"").execute(manager);
    parser.parse("create event \"Meeting\" from 2023-12-01T10:00 to 2023-12-01T11:00")
        .execute(manager);

    InterfaceCommand command = parser.parse(
        "copy event \"Meeting\" on 2023-12-01T10:00 --target Work to 2023-12-02T10:00");
    CommandResult result = command.execute(manager);

    assertTrue(result.isSuccess());
  }

  // Export Edge Cases
  @Test
  public void testExportEmptyCalendar() {
    parser.parse("create calendar --name \"Empty\" --timezone America/New_York").execute(manager);
    parser.parse("use calendar --name \"Empty\"").execute(manager);

    InterfaceCommand command = parser.parse("export cal empty_export.csv");
    CommandResult result = command.execute(manager);

    assertTrue(result.isSuccess());
    assertTrue(result.getMessage().contains("empty_export.csv"));
  }

  @Test
  public void testExportWithSpecialCharactersInFilename() {
    parser.parse("create calendar --name \"Test\" --timezone America/New_York").execute(manager);
    parser.parse("use calendar --name \"Test\"").execute(manager);
    parser.parse("create event \"Meeting\" from 2023-12-01T10:00 to 2023-12-01T11:00")
        .execute(manager);

    InterfaceCommand command = parser.parse("export cal \"test_export (2023).csv\"");
    CommandResult result = command.execute(manager);

    assertTrue(result.isSuccess());
  }

  @Test
  public void testExportToRelativePath() {
    parser.parse("create calendar --name \"Test\" --timezone America/New_York").execute(manager);
    parser.parse("use calendar --name \"Test\"").execute(manager);
    parser.parse("create event \"Meeting\" from 2023-12-01T10:00 to 2023-12-01T11:00")
        .execute(manager);

    InterfaceCommand command = parser.parse("export cal ./test_relative.csv");
    CommandResult result = command.execute(manager);

    assertTrue(result.isSuccess());
  }

  // Print Commands Edge Cases
  @Test
  public void testPrintEventsOnFebruary29th() {
    parser.parse("create calendar --name \"Test\" --timezone America/New_York").execute(manager);
    parser.parse("use calendar --name \"Test\"").execute(manager);
    parser.parse("create event \"Leap Day\" from 2024-02-29T12:00 to 2024-02-29T13:00")
        .execute(manager);

    InterfaceCommand command = parser.parse("print events on 2024-02-29");
    CommandResult result = command.execute(manager);

    assertTrue(result.isSuccess());
  }

  @Test
  public void testPrintEventsWithVeryLargeDateRange() {
    parser.parse("create calendar --name \"Test\" --timezone America/New_York").execute(manager);
    parser.parse("use calendar --name \"Test\"").execute(manager);
    parser.parse("create event \"Event\" from 2023-12-01T10:00 to 2023-12-01T11:00")
        .execute(manager);

    InterfaceCommand command = parser.parse(
        "print events from 2020-01-01T00:00 to 2030-12-31T23:59");
    CommandResult result = command.execute(manager);

    assertTrue(result.isSuccess());
  }

  // Show Status Edge Cases
  @Test
  public void testShowStatusAtMidnight() {
    parser.parse("create calendar --name \"Test\" --timezone America/New_York").execute(manager);
    parser.parse("use calendar --name \"Test\"").execute(manager);

    InterfaceCommand command = parser.parse("show status on 2023-12-01T00:00");
    CommandResult result = command.execute(manager);

    assertTrue(result.isSuccess());
  }

  @Test
  public void testShowStatusAtEndOfYear() {
    parser.parse("create calendar --name \"Test\" --timezone America/New_York").execute(manager);
    parser.parse("use calendar --name \"Test\"").execute(manager);

    InterfaceCommand command = parser.parse("show status on 2023-12-31T23:59");
    CommandResult result = command.execute(manager);

    assertTrue(result.isSuccess());
  }

  @Test
  public void testShowStatusAtStartOfYear() {
    parser.parse("create calendar --name \"Test\" --timezone America/New_York").execute(manager);
    parser.parse("use calendar --name \"Test\"").execute(manager);

    InterfaceCommand command = parser.parse("show status on 2023-01-01T00:00");
    CommandResult result = command.execute(manager);

    assertTrue(result.isSuccess());
  }

  // Timezone Edge Cases
  @Test
  public void testCreateCalendarWithUtcTimezone() {
    InterfaceCommand command = parser.parse(
        "create calendar --name \"UTC\" --timezone UTC");
    CommandResult result = command.execute(manager);

    assertTrue(result.isSuccess());
    assertTrue(manager.calendarExists("UTC"));
  }

  @Test
  public void testCreateCalendarWithHalfHourTimezone() {
    InterfaceCommand command = parser.parse(
        "create calendar --name \"India\" --timezone Asia/Kolkata");
    CommandResult result = command.execute(manager);

    assertTrue(result.isSuccess());
    assertTrue(manager.calendarExists("India"));
  }

  @Test
  public void testCreateCalendarWithNegativeOffsetTimezone() {
    InterfaceCommand command = parser.parse(
        "create calendar --name \"Hawaii\" --timezone Pacific/Honolulu");
    CommandResult result = command.execute(manager);

    assertTrue(result.isSuccess());
    assertTrue(manager.calendarExists("Hawaii"));
  }

  // Command Format Edge Cases
  @Test
  public void testCommandWithExtraSpaces() {
    parser.parse("create calendar --name \"Test\" --timezone America/New_York").execute(manager);

    InterfaceCommand command = parser.parse("use  calendar  --name  \"Test\"");
    CommandResult result = command.execute(manager);

    // This might fail depending on parser strictness
    // Test that it doesn't crash
    assertTrue(result.isSuccess() || result.getMessage() != null);
  }

  @Test
  public void testCommandWithMixedCase() {
    parser.parse("create calendar --name \"Test\" --timezone America/New_York").execute(manager);

    InterfaceCommand command = parser.parse("USE CALENDAR --NAME \"Test\"");
    CommandResult result = command.execute(manager);

    // This might fail depending on parser case sensitivity
    // Test that it doesn't crash
    assertTrue(result.isSuccess() || result.getMessage() != null);
  }

  @Test
  public void testCommandWithTrailingSpaces() {
    parser.parse("create calendar --name \"Test\" --timezone America/New_York").execute(manager);

    InterfaceCommand command = parser.parse("use calendar --name \"Test\"   ");
    CommandResult result = command.execute(manager);

    // This might succeed or fail depending on parser
    // Test that it doesn't crash
    assertTrue(result.isSuccess() || result.getMessage() != null);
  }

  // Performance and Stress Tests
  /** Tests creating many events. */
  // @Test
  public void testCreateManyEvents() {
    parser.parse("create calendar --name \"Stress\" --timezone America/New_York").execute(manager);
    parser.parse("use calendar --name \"Stress\"").execute(manager);

    // Create many events
    for (int i = 0; i < 100; i++) {
      InterfaceCommand command = parser.parse(
          "create event \"Event " + i + "\" from 2023-12-01T"
              + String.format("%02d", i % 24) + ":00 to 2023-12-01T"
              + String.format("%02d", (i + 1) % 24) + ":00");
      CommandResult result = command.execute(manager);
      assertTrue("Event " + i + " should be created", result.isSuccess());
    }
  }

  @Test
  public void testCreateLargeEventSeries() {
    parser.parse("create calendar --name \"Large\" --timezone America/New_York").execute(manager);
    parser.parse("use calendar --name \"Large\"").execute(manager);

    InterfaceCommand command = parser.parse(
        "create event \"Large Series\" from 2023-01-01T09:00 to 2023-01-01T09:30 "
            + "repeats MTWRF for 260 times");
    CommandResult result = command.execute(manager);

    assertTrue(result.isSuccess());
  }
}