package calendar.integration;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import calendar.controller.CommandParser;
import calendar.controller.CommandResult;
import calendar.controller.InterfaceCommand;
import calendar.model.CalendarManager;
import java.time.ZoneId;
import org.junit.Before;
import org.junit.Test;

/**
 * Integration tests for edit calendar command with new syntax.
 */
public class EditCalendarIntegrationTest {

  private CommandParser parser;
  private CalendarManager manager;

  /** Sets up test environment before each test. */
  @Before
  public void setUp() {
    manager = new CalendarManager();
    parser = new CommandParser();
  }

  @Test
  public void testEditCalendarName() {
    // Create calendar
    parser.parse("create calendar --name \"Original\" --timezone America/New_York")
        .execute(manager);

    // Edit calendar name
    InterfaceCommand editCommand = parser.parse(
        "edit calendar --name \"Original\" --property name \"Updated\"");
    CommandResult result = editCommand.execute(manager);

    assertTrue(result.isSuccess());
    assertFalse(manager.calendarExists("Original"));
    assertTrue(manager.calendarExists("Updated"));
    assertEquals(ZoneId.of("America/New_York"), manager.getCalendarTimezone("Updated"));
  }

  @Test
  public void testEditCalendarTimezone() {
    // Create calendar
    parser.parse("create calendar --name \"Work\" --timezone America/New_York").execute(manager);

    // Edit calendar timezone
    InterfaceCommand editCommand = parser.parse(
        "edit calendar --name \"Work\" --property timezone Europe/London");
    CommandResult result = editCommand.execute(manager);

    assertTrue(result.isSuccess());
    assertTrue(manager.calendarExists("Work"));
    assertEquals(ZoneId.of("Europe/London"), manager.getCalendarTimezone("Work"));
  }

  @Test
  public void testEditCalendarNameAndTimezoneSeparately() {
    // Create calendar
    parser.parse("create calendar --name \"OldName\" --timezone America/New_York").execute(manager);

    // Edit name first
    InterfaceCommand editName = parser.parse(
        "edit calendar --name \"OldName\" --property name \"NewName\"");
    CommandResult nameResult = editName.execute(manager);
    assertTrue(nameResult.isSuccess());

    // Edit timezone
    InterfaceCommand editTimezone = parser.parse(
        "edit calendar --name \"NewName\" --property timezone Asia/Tokyo");
    CommandResult timezoneResult = editTimezone.execute(manager);
    assertTrue(timezoneResult.isSuccess());

    // Verify both changes
    assertFalse(manager.calendarExists("OldName"));
    assertTrue(manager.calendarExists("NewName"));
    assertEquals(ZoneId.of("Asia/Tokyo"), manager.getCalendarTimezone("NewName"));
  }

  @Test
  public void testEditCalendarNameWithSpecialCharacters() {
    // Create calendar
    parser.parse("create calendar --name \"Simple\" --timezone America/New_York").execute(manager);

    // Edit name with special characters
    InterfaceCommand editCommand = parser.parse(
        "edit calendar --name \"Simple\" --property name \"Work & Personal Calendar\"");
    CommandResult result = editCommand.execute(manager);

    assertTrue(result.isSuccess());
    assertFalse(manager.calendarExists("Simple"));
    assertTrue(manager.calendarExists("Work & Personal Calendar"));
  }

  @Test
  public void testEditCalendarNameWithUnicodeCharacters() {
    // Create calendar
    parser.parse("create calendar --name \"Basic\" --timezone America/New_York").execute(manager);

    // Edit name with unicode characters
    InterfaceCommand editCommand = parser.parse(
        "edit calendar --name \"Basic\" --property name \"📅 日历 Calendrier\"");
    CommandResult result = editCommand.execute(manager);

    assertTrue(result.isSuccess());
    assertFalse(manager.calendarExists("Basic"));
    assertTrue(manager.calendarExists("📅 日历 Calendrier"));
  }

  @Test
  public void testEditCalendarToSameName() {
    // Create calendar
    parser.parse("create calendar --name \"Work\" --timezone America/New_York").execute(manager);

    // Edit to same name
    InterfaceCommand editCommand = parser.parse(
        "edit calendar --name \"Work\" --property name \"Work\"");
    CommandResult result = editCommand.execute(manager);

    assertTrue(result.isSuccess());
    assertTrue(manager.calendarExists("Work"));
    assertEquals(ZoneId.of("America/New_York"), manager.getCalendarTimezone("Work"));
  }

  @Test
  public void testEditCalendarToSameTimezone() {
    // Create calendar
    parser.parse("create calendar --name \"Test\" --timezone America/New_York").execute(manager);

    // Edit to same timezone
    InterfaceCommand editCommand = parser.parse(
        "edit calendar --name \"Test\" --property timezone America/New_York");
    CommandResult result = editCommand.execute(manager);

    assertTrue(result.isSuccess());
    assertTrue(manager.calendarExists("Test"));
    assertEquals(ZoneId.of("America/New_York"), manager.getCalendarTimezone("Test"));
  }

  @Test
  public void testEditActiveCalendarName() {
    // Create and use calendar
    parser.parse("create calendar --name \"Active\" --timezone America/New_York").execute(manager);
    parser.parse("use calendar --name \"Active\"").execute(manager);

    // Edit name while active
    InterfaceCommand editCommand = parser.parse(
        "edit calendar --name \"Active\" --property name \"RenamedActive\"");
    CommandResult result = editCommand.execute(manager);

    assertTrue(result.isSuccess());
    assertFalse(manager.calendarExists("Active"));
    assertTrue(manager.calendarExists("RenamedActive"));

    // Active calendar name should be updated
    assertEquals("RenamedActive", manager.getActiveCalendarName());
  }

  @Test
  public void testEditActiveCalendarTimezone() {
    // Create and use calendar
    parser.parse("create calendar --name \"ActiveTZ\" --timezone America/New_York")
        .execute(manager);
    parser.parse("use calendar --name \"ActiveTZ\"").execute(manager);

    // Edit timezone while active
    InterfaceCommand editCommand = parser.parse(
        "edit calendar --name \"ActiveTZ\" --property timezone Europe/Paris");
    CommandResult result = editCommand.execute(manager);

    assertTrue(result.isSuccess());
    assertTrue(manager.calendarExists("ActiveTZ"));
    assertEquals(ZoneId.of("Europe/Paris"), manager.getCalendarTimezone("ActiveTZ"));
    assertEquals(ZoneId.of("Europe/Paris"), manager.getActiveCalendarTimezone());
  }

  @Test
  public void testEditNonExistentCalendar() {
    // Try to edit non-existent calendar
    InterfaceCommand editCommand = parser.parse(
        "edit calendar --name \"NonExistent\" --property name \"NewName\"");
    CommandResult result = editCommand.execute(manager);

    assertFalse(result.isSuccess());
    assertTrue(result.getMessage().toLowerCase().contains("not found"));
  }

  @Test
  public void testEditCalendarToDuplicateName() {
    // Create two calendars
    parser.parse("create calendar --name \"First\" --timezone America/New_York").execute(manager);
    parser.parse("create calendar --name \"Second\" --timezone Europe/London").execute(manager);

    // Try to rename First to Second (duplicate)
    InterfaceCommand editCommand = parser.parse(
        "edit calendar --name \"First\" --property name \"Second\"");
    CommandResult result = editCommand.execute(manager);

    assertFalse(result.isSuccess());
    assertTrue(result.getMessage().toLowerCase().contains("already exists"));

    // Original calendars should remain unchanged
    assertTrue(manager.calendarExists("First"));
    assertTrue(manager.calendarExists("Second"));
  }

  @Test
  public void testEditCalendarWithInvalidTimezone() {
    // Create calendar
    parser.parse("create calendar --name \"Test\" --timezone America/New_York").execute(manager);

    // Try to edit with invalid timezone
    InterfaceCommand editCommand = parser.parse(
        "edit calendar --name \"Test\" --property timezone Invalid/Timezone");
    CommandResult result = editCommand.execute(manager);

    assertFalse(result.isSuccess());
    assertTrue(result.getMessage().toLowerCase().contains("timezone"));

    // Original timezone should remain unchanged
    assertEquals(ZoneId.of("America/New_York"), manager.getCalendarTimezone("Test"));
  }

  @Test
  public void testEditCalendarWithInvalidProperty() {
    // Create calendar
    parser.parse("create calendar --name \"Test\" --timezone America/New_York").execute(manager);

    // Try to edit with invalid property
    InterfaceCommand editCommand = parser.parse(
        "edit calendar --name \"Test\" --property invalid value");
    CommandResult result = editCommand.execute(manager);

    assertFalse(result.isSuccess());
    assertTrue(result.getMessage().toLowerCase().contains("property"));
  }

  @Test
  public void testEditCalendarWithEmptyName() {
    // Create calendar
    parser.parse("create calendar --name \"Test\" --timezone America/New_York").execute(manager);

    // Try to edit with empty name
    InterfaceCommand editCommand = parser.parse(
        "edit calendar --name \"Test\" --property name \"\"");
    CommandResult result = editCommand.execute(manager);

    assertFalse(result.isSuccess());
    assertTrue(result.getMessage().toLowerCase().contains("name"));
  }

  @Test
  public void testEditCalendarWithNullLikeName() {
    // Create calendar
    parser.parse("create calendar --name \"Test\" --timezone America/New_York").execute(manager);

    // Try to edit with null-like name
    InterfaceCommand editCommand = parser.parse(
        "edit calendar --name \"Test\" --property name null");
    CommandResult result = editCommand.execute(manager);

    assertFalse(result.isSuccess());
    assertTrue(result.getMessage().toLowerCase().contains("name"));
  }

  @Test
  public void testEditCalendarWithEmptyTimezone() {
    // Create calendar
    parser.parse("create calendar --name \"Test\" --timezone America/New_York").execute(manager);

    // Try to edit with empty timezone
    InterfaceCommand editCommand = parser.parse(
        "edit calendar --name \"Test\" --property timezone \"\"");
    CommandResult result = editCommand.execute(manager);

    assertFalse(result.isSuccess());
    assertTrue(result.getMessage().toLowerCase().contains("timezone"));
  }

  @Test
  public void testEditCalendarWithMissingName() {
    // Try to edit without specifying calendar name
    InterfaceCommand editCommand = parser.parse(
        "edit calendar --property name \"NewName\"");
    CommandResult result = editCommand.execute(manager);

    assertFalse(result.isSuccess());
    assertTrue(result.getMessage().toLowerCase().contains("name"));
  }

  @Test
  public void testEditCalendarWithMissingProperty() {
    // Create calendar
    parser.parse("create calendar --name \"Test\" --timezone America/New_York").execute(manager);

    // Try to edit without specifying property
    InterfaceCommand editCommand = parser.parse(
        "edit calendar --name \"Test\" value");
    CommandResult result = editCommand.execute(manager);

    assertFalse(result.isSuccess());
    assertTrue(result.getMessage().toLowerCase().contains("property"));
  }

  @Test
  public void testEditCalendarWithMissingValue() {
    // Create calendar
    parser.parse("create calendar --name \"Test\" --timezone America/New_York").execute(manager);

    // Try to edit without specifying value
    InterfaceCommand editCommand = parser.parse(
        "edit calendar --name \"Test\" --property name");
    CommandResult result = editCommand.execute(manager);

    assertFalse(result.isSuccess());
    assertTrue(result.getMessage().toLowerCase().contains("value"));
  }

  @Test
  public void testEditCalendarCaseInsensitiveProperty() {
    // Create calendar
    parser.parse("create calendar --name \"Test\" --timezone America/New_York").execute(manager);

    // Edit with uppercase property name
    InterfaceCommand editCommand = parser.parse(
        "edit calendar --name \"Test\" --property NAME \"NewName\"");
    CommandResult result = editCommand.execute(manager);

    assertTrue(result.isSuccess());
    assertFalse(manager.calendarExists("Test"));
    assertTrue(manager.calendarExists("NewName"));
  }

  @Test
  public void testEditCalendarMultipleTimes() {
    // Create calendar
    parser.parse("create calendar --name \"MultiEdit\" --timezone America/New_York")
        .execute(manager);

    // Edit name
    parser.parse("edit calendar --name \"MultiEdit\" --property name \"Step1\"").execute(manager);
    assertTrue(manager.calendarExists("Step1"));

    // Edit timezone
    parser.parse("edit calendar --name \"Step1\" --property timezone Europe/London")
        .execute(manager);
    assertEquals(ZoneId.of("Europe/London"), manager.getCalendarTimezone("Step1"));

    // Edit name again
    parser.parse("edit calendar --name \"Step1\" --property name \"Final\"").execute(manager);
    assertTrue(manager.calendarExists("Final"));
    assertEquals(ZoneId.of("Europe/London"), manager.getCalendarTimezone("Final"));
  }

  @Test
  public void testEditCalendarWithDifferentTimezoneFormats() {
    // Create calendar
    parser.parse("create calendar --name \"TZTest\" --timezone America/New_York").execute(manager);

    // Edit to various valid timezone formats
    String[] timezones = {
        "UTC",
        "Europe/London",
        "Asia/Tokyo",
        "Australia/Sydney",
        "America/Los_Angeles"
    };

    for (String timezone : timezones) {
      String tempName = "Temp_" + timezone.replace("/", "_");

      // First rename to avoid conflicts
      parser.parse("edit calendar --name \"TZTest\" --property name \"" + tempName + "\"")
          .execute(manager);

      // Then edit timezone
      InterfaceCommand editCommand = parser.parse(
          "edit calendar --name \"" + tempName + "\" --property timezone " + timezone);
      CommandResult result = editCommand.execute(manager);

      assertTrue("Should edit timezone to: " + timezone, result.isSuccess());
      assertEquals(ZoneId.of(timezone), manager.getCalendarTimezone(tempName));

      // Rename back for next iteration
      parser.parse("edit calendar --name \"" + tempName + "\" --property name \"TZTest\"")
          .execute(manager);
    }
  }

  @Test
  public void testEditCalendarWithVeryLongName() {
    // Create calendar
    parser.parse("create calendar --name \"Short\" --timezone America/New_York").execute(manager);

    // Edit to very long name
    String longName = "This is a very long calendar name that contains many words "
        + "and should be handled correctly by the system without any issues";
    InterfaceCommand editCommand = parser.parse(
        "edit calendar --name \"Short\" --property name \"" + longName + "\"");
    CommandResult result = editCommand.execute(manager);

    assertTrue(result.isSuccess());
    assertFalse(manager.calendarExists("Short"));
    assertTrue(manager.calendarExists(longName));
  }
}