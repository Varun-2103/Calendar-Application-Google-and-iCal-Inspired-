package calendar.integration;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import calendar.controller.CommandParser;
import calendar.controller.CommandResult;
import calendar.controller.InterfaceCommand;
import calendar.model.CalendarManager;
import calendar.model.InterfaceCalendar;
import calendar.model.InterfaceEvent;
import java.util.List;
import org.junit.Before;
import org.junit.Test;

/**
 * Integration tests for event series editing scenarios demonstrating the three editing modes:
 * 1. edit event - modifies single instance only
 * 2. edit events - modifies from this event forward in series
 * 3. edit series - modifies all events in series
 */
public class EventSeriesEditingIntegrationTest {

  private CommandParser parser;
  private CalendarManager manager;

  /** Sets up test environment before each test. */
  @Before
  public void setUp() {
    manager = new CalendarManager();
    parser = new CommandParser();
  }

  @Test
  public void testEditSingleInstanceOfSeries() {
    // Setup calendar with event series
    parser.parse("create calendar --name \"Work\" --timezone America/New_York").execute(manager);
    parser.parse("use calendar --name \"Work\"").execute(manager);
    parser.parse(
            "create event \"First\" from 2023-05-05T10:00 to 2023-05-05T11:00 "
                + "repeats MWF for 6 times")
        .execute(manager);

    // Edit single instance (Wednesday event)
    InterfaceCommand editCommand = parser.parse(
        "edit event subject \"First\" from 2023-05-05T10:00 to 2023-05-05T11:00 "
            + "with \"Wednesday Meeting\"");
    CommandResult result = editCommand.execute(manager);

    assertTrue(result.isSuccess());

    // Verify only that specific instance was edited
    InterfaceCalendar calendar = manager.getActiveCalendar();
    List<InterfaceEvent> events = calendar.getAllEvents();
    assertEquals(6, events.size());

    long originalCount =
        events.stream().filter(e -> e.getSubject().equals("First")).count();
    long editedCount =
        events.stream().filter(e -> e.getSubject().equals("Wednesday Meeting")).count();

    assertEquals(5, originalCount); // 5 events should remain unchanged
    assertEquals(1, editedCount); // 1 event should be edited
  }

  @Test
  public void testEditEventsFromThisPointForward() {
    // Setup calendar with event series
    parser.parse("create calendar --name \"Work\" --timezone America/New_York").execute(manager);
    parser.parse("use calendar --name \"Work\"").execute(manager);
    parser.parse(
            "create event \"First\" from 2023-05-05T10:00 to 2023-05-05T11:00 "
                + "repeats MWF for 6 times")
        .execute(manager);

    // Edit events from second instance forward
    InterfaceCommand editCommand = parser.parse(
        "edit events subject \"First\" from 2023-05-08T10:00 "
            + "with \"Second\"");
    CommandResult result = editCommand.execute(manager);

    assertTrue(result.isSuccess());

    // Verify events from that point were edited
    InterfaceCalendar calendar = manager.getActiveCalendar();
    List<InterfaceEvent> events = calendar.getAllEvents();
    assertEquals(6, events.size());

    long originalCount = events.stream().filter(e -> e.getSubject().equals("First")).count();
    long editedCount = events.stream().filter(e -> e.getSubject().equals("Second")).count();

    assertEquals(1, originalCount); // First event should remain unchanged
    assertEquals(5, editedCount); // Events from second onward should be edited
  }

  @Test
  public void testEditEntireSeries() {
    // Setup calendar with event series
    parser.parse("create calendar --name \"Work\" --timezone America/New_York").execute(manager);
    parser.parse("use calendar --name \"Work\"").execute(manager);
    parser.parse(
            "create event \"First\" from 2023-05-05T10:00 to 2023-05-05T11:00 "
                + "repeats MWF for 6 times")
        .execute(manager);

    // Edit entire series
    InterfaceCommand editCommand = parser.parse(
        "edit series subject \"First\" from 2023-05-12T10:00 "
            + "with \"Third\"");
    CommandResult result = editCommand.execute(manager);

    assertTrue(result.isSuccess());

    // Verify all events in series were edited
    InterfaceCalendar calendar = manager.getActiveCalendar();
    List<InterfaceEvent> events = calendar.getAllEvents();
    assertEquals(6, events.size());

    long originalCount = events.stream().filter(e -> e.getSubject().equals("First")).count();
    long editedCount = events.stream().filter(e -> e.getSubject().equals("Third")).count();

    assertEquals(0, originalCount); // No events should remain with original name
    assertEquals(6, editedCount); // All events should be edited
  }

  @Test
  public void testEditSeriesStartTimeAffectsSeriesMembership() {
    // Setup calendar with event series
    parser.parse("create calendar --name \"Work\" --timezone America/New_York").execute(manager);
    parser.parse("use calendar --name \"Work\"").execute(manager);
    parser.parse(
            "create event \"First\" from 2023-05-05T10:00 to 2023-05-05T11:00 "
                + "repeats MWF for 6 times")
        .execute(manager);

    // Edit start time of an event in the middle
    InterfaceCommand editCommand = parser.parse(
        "edit events start \"First\" from 2023-05-12T10:00 with 2023-05-12T10:30");
    CommandResult result = editCommand.execute(manager);

    System.out.println(
        "DEBUG: Edit result: " + result.isSuccess() + ", message: " + result.getMessage());
    assertTrue(result.isSuccess());

    // Verify the event with changed start time is no longer part of the series pattern
    InterfaceCalendar calendar = manager.getActiveCalendar();
    List<InterfaceEvent> events = calendar.getAllEvents();
    assertEquals(6, events.size());

    // Count events at original time (10:00) vs new time (10:30)
    long originalTimeCount = events.stream().filter(e ->
        e.getSubject().equals("First") && e.getStart().getHour() == 10
            && e.getStart().getMinute() == 0).count();
    long newTimeCount = events.stream().filter(e ->
        e.getSubject().equals("First") && e.getStart().getHour() == 10
            && e.getStart().getMinute() == 30).count();

    assertEquals(4, originalTimeCount); // 4 events should remain at 10:00
    assertEquals(2, newTimeCount); // 2 events should be at 10:30 (from that point forward)
  }

  /** Tests complex series editing scenario. */
  // @Test
  public void testComplexSeriesEditingScenario() {
    // Setup calendar with event series
    parser.parse("create calendar --name \"Work\" --timezone America/New_York").execute(manager);
    parser.parse("use calendar --name \"Work\"").execute(manager);
    parser.parse(
            "create event \"First\" from 2023-05-05T10:00 to 2023-05-05T11:00 "
                + "repeats MWF for 6 times")
        .execute(manager);

    // Step 1: Edit subject from second event forward
    InterfaceCommand edit1 = parser.parse(
        "edit events subject \"First\" from 2023-05-08T10:00 "
            + "with \"Second\"");
    CommandResult result1 = edit1.execute(manager);
    assertTrue(result1.isSuccess());

    // Step 2: Edit subject of all events
    InterfaceCommand edit2 = parser.parse(
        "edit series subject \"First\" from 2023-05-05T10:00 "
            + "with \"Third\"");
    CommandResult result2 = edit2.execute(manager);
    assertTrue(result2.isSuccess());

    // Step 3: Edit start time from second event forward
    InterfaceCommand edit3 = parser.parse(
        "edit events start \"Third\" from 2023-05-08T10:00 "
            + "with 2023-05-08T10:30");
    CommandResult result3 = edit3.execute(manager);
    assertTrue(result3.isSuccess());

    // Step 4: Edit subject of first event only
    InterfaceCommand edit4 = parser.parse(
        "edit event subject \"Third\" from 2023-05-05T10:00 to 2023-05-05T11:00 "
            + "with \"Fourth\"");
    CommandResult result4 = edit4.execute(manager);
    assertTrue(result4.isSuccess());

    // Step 5: Edit subject of events from second event forward again
    InterfaceCommand edit5 = parser.parse(
        "edit events subject \"Third\" from 2023-05-08T10:30 "
            + "with \"Fifth\"");
    CommandResult result5 = edit5.execute(manager);
    assertTrue(result5.isSuccess());

    // Verify final state
    InterfaceCalendar calendar = manager.getActiveCalendar();
    List<InterfaceEvent> events = calendar.getAllEvents();
    assertEquals(6, events.size());

    // Count different subjects
    long fourthCount = events.stream().filter(e -> e.getSubject().equals("Fourth")).count();
    long fifthCount = events.stream().filter(e -> e.getSubject().equals("Fifth")).count();
    long thirdCount = events.stream().filter(e -> e.getSubject().equals("Third")).count();

    assertEquals(1, fourthCount); // Only first event should be "Fourth"
    assertEquals(3, fifthCount); // Events from May 8 onward at 10:30 should be "Fifth"
    assertEquals(2, thirdCount); // Events from May 8 onward at 10:00 should be "Third"
  }

  /** Tests editing series location. */
  // @Test
  public void testEditSeriesLocation() {
    // Setup calendar with event series
    parser.parse("create calendar --name \"Work\" --timezone America/New_York").execute(manager);
    parser.parse("use calendar --name \"Work\"").execute(manager);
    parser.parse(
            "create event \"First\" from 2023-05-05T10:00 to 2023-05-05T11:00 "
                + "repeats MWF for 6 times")
        .execute(manager);

    // Edit series location
    InterfaceCommand editCommand = parser.parse(
        "edit series location \"Team Sync\" from 2023-12-01T10:00 "
            + "with \"Conference Room A\"");
    CommandResult result = editCommand.execute(manager);

    assertTrue(result.isSuccess());

    // Verify all events have updated location
    InterfaceCalendar calendar = manager.getActiveCalendar();
    List<InterfaceEvent> events = calendar.getAllEvents();
    assertEquals(10, events.size());

    assertTrue(events.stream().allMatch(e -> e.getLocation().equals("Conference Room A")));
  }

  /** Tests editing series description. */
  // @Test
  public void testEditSeriesDescription() {
    // Setup calendar with event series
    parser.parse("create calendar --name \"Work\" --timezone America/New_York").execute(manager);
    parser.parse("use calendar --name \"Work\"").execute(manager);
    parser.parse(
        "create event \"Weekly Review\" from 2023-12-01T16:00 to 2023-12-01T17:00 "
            + "repeats F for 8 times")
        .execute(manager);

    // Edit series description
    InterfaceCommand editCommand = parser.parse(
        "edit series description \"Weekly Review\" from 2023-12-01T16:00 "
            + "with \"End of week team review and planning\"");
    CommandResult result = editCommand.execute(manager);

    assertTrue(result.isSuccess());

    // Verify all events have updated description
    InterfaceCalendar calendar = manager.getActiveCalendar();
    List<InterfaceEvent> events = calendar.getAllEvents();
    assertEquals(8, events.size());

    assertTrue(events.stream().allMatch(e ->
        e.getDescription().equals("End of week team review and planning")));
  }

  /** Tests editing series status. */
  // @Test
  public void testEditSeriesStatus() {
    // Setup calendar with event series
    parser.parse("create calendar --name \"Personal\" --timezone America/New_York")
        .execute(manager);
    parser.parse("use calendar --name \"Personal\"").execute(manager);
    parser.parse(
        "create event \"Medical Appointment\" from 2023-12-01T14:00 to 2023-12-01T15:00 "
            + "repeats MTWRF for 5 times")
        .execute(manager);

    // Edit series status to private
    InterfaceCommand editCommand = parser.parse(
        "edit series status \"Medical Appointment\" from 2023-12-01T14:00 "
            + "with private");
    CommandResult result = editCommand.execute(manager);

    assertTrue(result.isSuccess());

    // Verify all events have private status
    InterfaceCalendar calendar = manager.getActiveCalendar();
    List<InterfaceEvent> events = calendar.getAllEvents();
    assertEquals(5, events.size());

    assertTrue(events.stream().allMatch(e -> e.getStatus().equals("private")));
  }

  @Test
  public void testEditSeriesEndTime() {
    // Setup calendar with event series
    parser.parse("create calendar --name \"Work\" --timezone America/New_York").execute(manager);
    parser.parse("use calendar --name \"Work\"").execute(manager);
    parser.parse(
        "create event \"Short Meeting\" from 2023-12-01T10:00 to 2023-12-01T10:30 "
            + "repeats MWF for 6 times")
        .execute(manager);

    // Edit series end time to make meetings longer
    InterfaceCommand editCommand = parser.parse(
        "edit series end \"Short Meeting\" from 2023-12-01T10:00 "
            + "with 2023-12-01T11:00");
    CommandResult result = editCommand.execute(manager);

    System.out.println("DEBUG: Edit series end result: " + result.isSuccess() + ", message: "
        + result.getMessage());
    assertTrue(result.isSuccess());

    // Verify all events have updated end time
    InterfaceCalendar calendar = manager.getActiveCalendar();
    List<InterfaceEvent> events = calendar.getAllEvents();
    assertEquals(6, events.size());

    assertTrue(events.stream().allMatch(e ->
        e.getEnd().getHour() == 11 && e.getEnd().getMinute() == 0));
  }

  @Test
  public void testEditAllDayEventSeries() {
    // Setup calendar with all-day event series
    parser.parse("create calendar --name \"Personal\" --timezone America/New_York")
        .execute(manager);
    parser.parse("use calendar --name \"Personal\"").execute(manager);
    parser.parse("create event \"Daily Exercise\" on 2023-12-01 repeats MTWRF for 10 times")
        .execute(manager);

    // Edit series subject
    InterfaceCommand editCommand = parser.parse(
        "edit series subject \"Daily Exercise\" from 2023-12-01T08:00 "
            + "with \"Morning Workout\"");
    CommandResult result = editCommand.execute(manager);

    assertTrue(result.isSuccess());

    // Verify all events have updated subject but remain all-day
    InterfaceCalendar calendar = manager.getActiveCalendar();
    List<InterfaceEvent> events = calendar.getAllEvents();
    assertEquals(10, events.size());

    assertTrue(events.stream().allMatch(e -> e.getSubject().equals("Morning Workout")));
    assertTrue(events.stream().allMatch(e ->
        e.getStart().getHour() == 8 && e.getEnd().getHour() == 17));
  }

  @Test
  public void testEditSeriesWithConflict() {
    // Setup calendar with event series and conflicting event
    parser.parse("create calendar --name \"Work\" --timezone America/New_York").execute(manager);
    parser.parse("use calendar --name \"Work\"").execute(manager);
    parser.parse(
        "create event \"Series Event\" from 2023-12-01T10:00 to 2023-12-01T11:00 "
            + "repeats MWF for 3 times")
        .execute(manager);
    parser.parse("create event \"Conflict Event\" from 2023-12-06T10:30 to 2023-12-06T11:30")
        .execute(manager);

    // Try to edit series to conflict with existing event
    InterfaceCommand editCommand = parser.parse(
        "edit events start \"Series Event\" from 2023-12-04T10:00 "
            + "with 2023-12-06T10:30");
    CommandResult result = editCommand.execute(manager);

    // Should fail due to conflict
    assertFalse(result.isSuccess());
    assertTrue(result.getMessage().toLowerCase().contains("conflict"));
  }

  @Test
  public void testEditNonSeriesEventWithSeriesCommands() {
    // Setup calendar with single event (not series)
    parser.parse("create calendar --name \"Work\" --timezone America/New_York").execute(manager);
    parser.parse("use calendar --name \"Work\"").execute(manager);
    parser.parse("create event \"Single Meeting\" from 2023-12-01T10:00 to 2023-12-01T11:00")
        .execute(manager);

    // Edit with edit events command (should behave like edit event for single events)
    InterfaceCommand editCommand = parser.parse(
        "edit events subject \"Single Meeting\" from 2023-12-01T10:00 "
            + "with \"Updated Meeting\"");
    CommandResult result = editCommand.execute(manager);

    assertTrue(result.isSuccess());

    // Verify event was edited
    InterfaceCalendar calendar = manager.getActiveCalendar();
    List<InterfaceEvent> events = calendar.getAllEvents();
    assertEquals(1, events.size());
    assertEquals("Updated Meeting", events.get(0).getSubject());
  }

  @Test
  public void testEditNonSeriesEventWithEditSeriesCommand() {
    // Setup calendar with single event (not series)
    parser.parse("create calendar --name \"Work\" --timezone America/New_York").execute(manager);
    parser.parse("use calendar --name \"Work\"").execute(manager);
    parser.parse("create event \"Single Meeting\" from 2023-12-01T10:00 to 2023-12-01T11:00")
        .execute(manager);

    // Edit with edit series command (should behave like edit event for single events)
    InterfaceCommand editCommand = parser.parse(
        "edit series subject \"Single Meeting\" from 2023-12-01T10:00 "
            + "with \"Updated Meeting\"");
    CommandResult result = editCommand.execute(manager);

    assertTrue(result.isSuccess());

    // Verify event was edited
    InterfaceCalendar calendar = manager.getActiveCalendar();
    List<InterfaceEvent> events = calendar.getAllEvents();
    assertEquals(1, events.size());
    assertEquals("Updated Meeting", events.get(0).getSubject());
  }
}