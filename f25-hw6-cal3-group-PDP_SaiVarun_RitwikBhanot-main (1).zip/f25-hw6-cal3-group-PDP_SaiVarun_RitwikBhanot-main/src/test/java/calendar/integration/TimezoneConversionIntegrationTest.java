package calendar.integration;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import calendar.controller.CommandParser;
import calendar.controller.CommandResult;
import calendar.controller.InterfaceCommand;
import calendar.model.CalendarManager;
import calendar.model.InterfaceCalendar;
import calendar.model.InterfaceEvent;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.List;
import org.junit.Before;
import org.junit.Test;

/**
 * Integration tests for timezone conversion during event copying.
 */
public class TimezoneConversionIntegrationTest {

  private CommandParser parser;
  private CalendarManager manager;

  /** Sets up test environment before each test. */
  @Before
  public void setUp() {
    manager = new CalendarManager();
    parser = new CommandParser();
  }

  @Test
  public void testCopyEventFromNewYorkToLosAngeles() {
    // Create NY calendar (EST/EDT)
    parser.parse("create calendar --name \"NY\" --timezone America/New_York").execute(manager);
    parser.parse("use calendar --name \"NY\"").execute(manager);

    // Create event at 2 PM NY time
    parser.parse("create event \"Meeting\" from 2023-12-01T14:00 to 2023-12-01T15:00")
        .execute(manager);

    // Create LA calendar (PST/PDT)
    parser.parse("create calendar --name \"LA\" --timezone America/Los_Angeles").execute(manager);

    // Copy event to LA calendar - should convert to 11 AM LA time (3 hour difference)
    InterfaceCommand copyCommand = parser.parse(
        "copy event \"Meeting\" on 2023-12-01T14:00 --target LA to 2023-12-01T11:00");
    CommandResult result = copyCommand.execute(manager);

    assertTrue(result.isSuccess());

    // Verify event in LA calendar
    InterfaceCalendar laCalendar = manager.getCalendar("LA");
    List<InterfaceEvent> laEvents = laCalendar.getAllEvents();
    assertEquals(1, laEvents.size());

    InterfaceEvent laEvent = laEvents.get(0);
    assertEquals("Meeting", laEvent.getSubject());
    assertEquals(11, laEvent.getStart().getHour()); // 11 AM in LA
    assertEquals(0, laEvent.getStart().getMinute());
  }

  @Test
  public void testCopyEventFromLondonToTokyo() {
    // Create London calendar (GMT/BST)
    parser.parse("create calendar --name \"London\" --timezone Europe/London").execute(manager);
    parser.parse("use calendar --name \"London\"").execute(manager);

    // Create event at 9 AM London time
    parser.parse("create event \"Call\" from 2023-12-01T09:00 to 2023-12-01T10:00")
        .execute(manager);

    // Create Tokyo calendar (JST)
    parser.parse("create calendar --name \"Tokyo\" --timezone Asia/Tokyo").execute(manager);

    // Copy event to Tokyo calendar - should convert to 6 PM Tokyo time (9 hour difference)
    InterfaceCommand copyCommand = parser.parse(
        "copy event \"Call\" on 2023-12-01T09:00 --target Tokyo to 2023-12-01T18:00");
    CommandResult result = copyCommand.execute(manager);

    assertTrue(result.isSuccess());

    // Verify event in Tokyo calendar
    InterfaceCalendar tokyoCalendar = manager.getCalendar("Tokyo");
    List<InterfaceEvent> tokyoEvents = tokyoCalendar.getAllEvents();
    assertEquals(1, tokyoEvents.size());

    InterfaceEvent tokyoEvent = tokyoEvents.get(0);
    assertEquals("Call", tokyoEvent.getSubject());
    assertEquals(18, tokyoEvent.getStart().getHour()); // 6 PM in Tokyo
  }

  @Test
  public void testCopyEventsOnDateWithTimezoneConversion() {
    // Create NY calendar
    parser.parse("create calendar --name \"NY\" --timezone America/New_York").execute(manager);
    parser.parse("use calendar --name \"NY\"").execute(manager);

    // Create multiple events on same day
    parser.parse("create event \"Morning\" from 2023-12-01T09:00 to 2023-12-01T10:00")
        .execute(manager);
    parser.parse("create event \"Afternoon\" from 2023-12-01T15:00 to 2023-12-01T16:00")
        .execute(manager);
    parser.parse("create event \"Evening\" from 2023-12-01T20:00 to 2023-12-01T21:00")
        .execute(manager);

    // Create London calendar
    parser.parse("create calendar --name \"London\" --timezone Europe/London").execute(manager);

    // Copy all events from the day - times should be converted to London timezone
    InterfaceCommand copyCommand = parser.parse(
        "copy events on 2023-12-01 --target London to 2023-12-01");
    CommandResult result = copyCommand.execute(manager);

    assertTrue(result.isSuccess());

    // Verify events in London calendar
    InterfaceCalendar londonCalendar = manager.getCalendar("London");
    List<InterfaceEvent> londonEvents = londonCalendar.getAllEvents();
    assertEquals(3, londonEvents.size());

    // Events should be 5 hours later in London time (NY is 5 hours behind London in December)
    InterfaceEvent morningEvent = londonEvents.stream()
        .filter(e -> e.getSubject().equals("Morning"))
        .findFirst().orElse(null);
    assertNotNull(morningEvent);
    assertEquals(14, morningEvent.getStart().getHour()); // 9 AM NY = 2 PM London
  }

  @Test
  public void testCopyEventsBetweenDateRangesWithTimezoneConversion() {
    // Create Sydney calendar (UTC+11 in December)
    parser.parse("create calendar --name \"Sydney\" --timezone Australia/Sydney").execute(manager);
    parser.parse("use calendar --name \"Sydney\"").execute(manager);

    // Create events across multiple days
    parser.parse("create event \"Day1\" from 2023-12-01T10:00 to 2023-12-01T11:00")
        .execute(manager);
    parser.parse("create event \"Day2\" from 2023-12-02T10:00 to 2023-12-02T11:00")
        .execute(manager);
    parser.parse("create event \"Day3\" from 2023-12-03T10:00 to 2023-12-03T11:00")
        .execute(manager);

    // Create UTC calendar
    parser.parse("create calendar --name \"UTC\" --timezone UTC").execute(manager);

    // Copy events in date range - should convert to UTC (Sydney is 11 hours ahead)
    InterfaceCommand copyCommand = parser.parse(
        "copy events between 2023-12-01 and 2023-12-02 --target UTC to 2023-12-01");
    CommandResult result = copyCommand.execute(manager);

    assertTrue(result.isSuccess());

    // Verify events in UTC calendar
    InterfaceCalendar utcCalendar = manager.getCalendar("UTC");
    List<InterfaceEvent> utcEvents = utcCalendar.getAllEvents();
    assertEquals(2, utcEvents.size()); // Day1 and Day2 events

    // Events should be 11 hours earlier in UTC
    InterfaceEvent day1Event = utcEvents.stream()
        .filter(e -> e.getSubject().equals("Day1"))
        .findFirst().orElse(null);
    assertNotNull(day1Event);
    assertEquals(23, day1Event.getStart().getHour()); // 10 AM Sydney = 11 PM UTC (previous day)
  }

  @Test
  public void testCopyEventSeriesWithTimezoneConversion() {
    // Create NY calendar
    parser.parse("create calendar --name \"NY\" --timezone America/New_York").execute(manager);
    parser.parse("use calendar --name \"NY\"").execute(manager);

    // Create event series
    parser.parse(
        "create event \"Daily Standup\" from 2023-12-01T09:00 to 2023-12-01T09:30 "
            + "repeats MTWRF for 5 times")
        .execute(manager);

    // Create Paris calendar
    parser.parse("create calendar --name \"Paris\" --timezone Europe/Paris").execute(manager);

    // Copy events from date range - should convert to Paris timezone (6 hours ahead in December)
    InterfaceCommand copyCommand = parser.parse(
        "copy events between 2023-12-01 and 2023-12-05 --target Paris to 2023-12-01");
    CommandResult result = copyCommand.execute(manager);

    assertTrue(result.isSuccess());

    // Verify events in Paris calendar
    InterfaceCalendar parisCalendar = manager.getCalendar("Paris");
    List<InterfaceEvent> parisEvents = parisCalendar.getAllEvents();
    assertFalse(parisEvents.isEmpty());

    // Events should be 6 hours later in Paris time
    InterfaceEvent firstEvent = parisEvents.get(0);
    assertEquals(15, firstEvent.getStart().getHour()); // 9 AM NY = 3 PM Paris
  }

  @Test
  public void testCopyEventAcrossDstBoundary() {
    // Create NY calendar
    parser.parse("create calendar --name \"NY\" --timezone America/New_York").execute(manager);
    parser.parse("use calendar --name \"NY\"").execute(manager);

    // Create event in March (during DST transition period)
    parser.parse("create event \"Spring Meeting\" from 2024-03-10T14:00 to 2024-03-10T15:00")
        .execute(manager);

    // Create London calendar (London also has DST but different schedule)
    parser.parse("create calendar --name \"London\" --timezone Europe/London").execute(manager);

    // Copy event - should handle DST correctly
    InterfaceCommand copyCommand = parser.parse(
        "copy event \"Spring Meeting\" on 2024-03-10T14:00 --target London to 2024-03-10T18:00");
    CommandResult result = copyCommand.execute(manager);

    assertTrue(result.isSuccess());

    // Verify event in London calendar
    InterfaceCalendar londonCalendar = manager.getCalendar("London");
    List<InterfaceEvent> londonEvents = londonCalendar.getAllEvents();
    assertEquals(1, londonEvents.size());

    InterfaceEvent londonEvent = londonEvents.get(0);
    assertEquals("Spring Meeting", londonEvent.getSubject());
    assertEquals(18, londonEvent.getStart().getHour()); // Should account for DST differences
  }

  @Test
  public void testCopyEventWithSameTimezone() {
    // Create two calendars with same timezone
    parser.parse("create calendar --name \"Work1\" --timezone America/New_York").execute(manager);
    parser.parse("create calendar --name \"Work2\" --timezone America/New_York").execute(manager);

    // Create event in first calendar
    parser.parse("use calendar --name \"Work1\"").execute(manager);
    parser.parse("create event \"Team Sync\" from 2023-12-01T13:30 to 2023-12-01T14:30")
        .execute(manager);

    // Copy to second calendar (same timezone)
    InterfaceCommand copyCommand = parser.parse(
        "copy event \"Team Sync\" on 2023-12-01T13:30 --target Work2 to 2023-12-01T13:30");
    CommandResult result = copyCommand.execute(manager);

    assertTrue(result.isSuccess());

    // Verify time is preserved (no conversion needed)
    InterfaceCalendar work2Calendar = manager.getCalendar("Work2");
    List<InterfaceEvent> work2Events = work2Calendar.getAllEvents();
    assertEquals(1, work2Events.size());

    InterfaceEvent work2Event = work2Events.get(0);
    assertEquals(13, work2Event.getStart().getHour());
    assertEquals(30, work2Event.getStart().getMinute());
  }

  @Test
  public void testCopyEventWithUtcTimezone() {
    // Create UTC calendar
    parser.parse("create calendar --name \"UTC\" --timezone UTC").execute(manager);
    parser.parse("use calendar --name \"UTC\"").execute(manager);

    // Create event at 3 PM UTC
    parser.parse("create event \"UTC Meeting\" from 2023-12-01T15:00 to 2023-12-01T16:00")
        .execute(manager);

    // Create Mumbai calendar (UTC+5:30, no DST)
    parser.parse("create calendar --name \"Mumbai\" --timezone Asia/Kolkata").execute(manager);

    // Copy event to Mumbai calendar - should convert to 8:30 PM Mumbai time
    InterfaceCommand copyCommand = parser.parse(
        "copy event \"UTC Meeting\" on 2023-12-01T15:00 --target Mumbai to 2023-12-01T20:30");
    CommandResult result = copyCommand.execute(manager);

    assertTrue(result.isSuccess());

    // Verify event in Mumbai calendar
    InterfaceCalendar mumbaiCalendar = manager.getCalendar("Mumbai");
    List<InterfaceEvent> mumbaiEvents = mumbaiCalendar.getAllEvents();
    assertEquals(1, mumbaiEvents.size());

    InterfaceEvent mumbaiEvent = mumbaiEvents.get(0);
    assertEquals("UTC Meeting", mumbaiEvent.getSubject());
    assertEquals(20, mumbaiEvent.getStart().getHour()); // 8:30 PM
    assertEquals(30, mumbaiEvent.getStart().getMinute());
  }

  @Test
  public void testCopyAllDayEventWithTimezoneConversion() {
    // Create NY calendar
    parser.parse("create calendar --name \"NY\" --timezone America/New_York").execute(manager);
    parser.parse("use calendar --name \"NY\"").execute(manager);

    // Create all-day event
    parser.parse("create event \"Holiday\" on 2023-12-25").execute(manager);

    // Create Sydney calendar
    parser.parse("create calendar --name \"Sydney\" --timezone Australia/Sydney").execute(manager);

    // Copy all-day event - should remain all-day in target timezone
    InterfaceCommand copyCommand = parser.parse(
        "copy events on 2023-12-25 --target Sydney to 2023-12-25");
    CommandResult result = copyCommand.execute(manager);

    assertTrue(result.isSuccess());

    // Verify event in Sydney calendar
    InterfaceCalendar sydneyCalendar = manager.getCalendar("Sydney");
    List<InterfaceEvent> sydneyEvents = sydneyCalendar.getAllEvents();
    assertEquals(1, sydneyEvents.size());

    InterfaceEvent sydneyEvent = sydneyEvents.get(0);
    assertEquals("Holiday", sydneyEvent.getSubject());
    // All-day events should still be 8 AM to 5 PM in target timezone
    assertEquals(8, sydneyEvent.getStart().getHour());
    assertEquals(17, sydneyEvent.getEnd().getHour());
  }

  @Test
  public void testCopyEventWithHalfHourTimezoneDifference() {
    // Create Mumbai calendar (UTC+5:30)
    parser.parse("create calendar --name \"Mumbai\" --timezone Asia/Kolkata").execute(manager);
    parser.parse("use calendar --name \"Mumbai\"").execute(manager);

    // Create event at 12:30 PM Mumbai time
    parser.parse("create event \"Lunch\" from 2023-12-01T12:30 to 2023-12-01T13:30")
        .execute(manager);

    // Create Dubai calendar (UTC+4:00)
    parser.parse("create calendar --name \"Dubai\" --timezone Asia/Dubai").execute(manager);

    // Copy event to Dubai calendar - should convert to 11:00 AM Dubai time (1.5 hour difference)
    InterfaceCommand copyCommand = parser.parse(
        "copy event \"Lunch\" on 2023-12-01T12:30 --target Dubai to 2023-12-01T11:00");
    CommandResult result = copyCommand.execute(manager);

    assertTrue(result.isSuccess());

    // Verify event in Dubai calendar
    InterfaceCalendar dubaiCalendar = manager.getCalendar("Dubai");
    List<InterfaceEvent> dubaiEvents = dubaiCalendar.getAllEvents();
    assertEquals(1, dubaiEvents.size());

    InterfaceEvent dubaiEvent = dubaiEvents.get(0);
    assertEquals("Lunch", dubaiEvent.getSubject());
    assertEquals(11, dubaiEvent.getStart().getHour()); // 11 AM Dubai
    assertEquals(0, dubaiEvent.getStart().getMinute());
  }

  @Test
  public void testCopyEventWithNegativeTimezoneOffset() {
    // Create Hawaii calendar (UTC-10:00)
    parser.parse("create calendar --name \"Hawaii\" --timezone Pacific/Honolulu").execute(manager);
    parser.parse("use calendar --name \"Hawaii\"").execute(manager);

    // Create event at 2 PM Hawaii time
    parser.parse("create event \"Beach Time\" from 2023-12-01T14:00 to 2023-12-01T15:00")
        .execute(manager);

    // Create Singapore calendar (UTC+8:00)
    parser.parse("create calendar --name \"Singapore\" --timezone Asia/Singapore").execute(manager);

    // Copy event to Singapore calendar - should convert to next day 12 AM Singapore time
    // (18 hour difference)
    InterfaceCommand copyCommand = parser.parse(
        "copy event \"Beach Time\" on 2023-12-01T14:00 --target Singapore to 2023-12-02T00:00");
    CommandResult result = copyCommand.execute(manager);

    assertTrue(result.isSuccess());

    // Verify event in Singapore calendar
    InterfaceCalendar singaporeCalendar = manager.getCalendar("Singapore");
    List<InterfaceEvent> singaporeEvents = singaporeCalendar.getAllEvents();
    assertEquals(1, singaporeEvents.size());

    InterfaceEvent singaporeEvent = singaporeEvents.get(0);
    assertEquals("Beach Time", singaporeEvent.getSubject());
    assertEquals(0, singaporeEvent.getStart().getHour()); // Midnight next day
    assertEquals(2, singaporeEvent.getStart().getDayOfMonth()); // December 2nd
  }
}