package calendar.integration;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import calendar.controller.CommandParser;
import calendar.controller.CommandResult;
import calendar.controller.InterfaceCommand;
import calendar.model.CalendarManager;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * Integration tests for iCal export functionality.
 */
public class IcalExportIntegrationTest {

  private CommandParser parser;
  private CalendarManager manager;
  private String testCsvFile = "test_export.csv";
  private String testIcalFile = "test_export.ical";

  /** Sets up test environment before each test. */
  @Before
  public void setUp() {
    manager = new CalendarManager();
    parser = new CommandParser();
    cleanupTestFiles();
  }

  /** Cleans up test environment after each test. */
  @After
  public void tearDown() {
    cleanupTestFiles();
  }

  private void cleanupTestFiles() {
    try {
      Files.deleteIfExists(Paths.get(testCsvFile));
      Files.deleteIfExists(Paths.get(testIcalFile));
    } catch (IOException e) {
      // Ignore cleanup failures
    }
  }

  @Test
  public void testExportToCsvFormat() throws IOException {
    // Setup calendar with events
    parser.parse("create calendar --name \"Test\" --timezone America/New_York").execute(manager);
    parser.parse("use calendar --name \"Test\"").execute(manager);
    parser.parse("create event \"Meeting\" from 2023-12-01T10:00 to 2023-12-01T11:00")
        .execute(manager);

    // Export to CSV
    InterfaceCommand exportCommand = parser.parse("export cal " + testCsvFile);
    CommandResult result = exportCommand.execute(manager);

    assertTrue(result.isSuccess());
    assertNotNull(result.getMessage());
    assertTrue(result.getMessage().contains(testCsvFile));
    assertTrue(Files.exists(Paths.get(testCsvFile)));

    // Verify CSV format
    List<String> lines = readFileLines(testCsvFile);
    assertFalse(lines.isEmpty());
    assertTrue(lines.get(0).contains("Subject"));
    assertTrue(lines.get(0).contains("Start Date"));
  }

  @Test
  public void testExportToIcalFormat() throws IOException {
    // Setup calendar with events
    parser.parse("create calendar --name \"Test\" --timezone America/New_York").execute(manager);
    parser.parse("use calendar --name \"Test\"").execute(manager);
    parser.parse("create event \"Meeting\" from 2023-12-01T10:00 to 2023-12-01T11:00")
        .execute(manager);

    // Export to iCal
    InterfaceCommand exportCommand = parser.parse("export cal " + testIcalFile);
    CommandResult result = exportCommand.execute(manager);

    assertTrue(result.isSuccess());
    assertNotNull(result.getMessage());
    assertTrue(result.getMessage().contains(testIcalFile));
    assertTrue(Files.exists(Paths.get(testIcalFile)));

    // Verify iCal format
    String content = readFileContent(testIcalFile);
    assertTrue(content.contains("BEGIN:VCALENDAR"));
    assertTrue(content.contains("END:VCALENDAR"));
    assertTrue(content.contains("BEGIN:VEVENT"));
    assertTrue(content.contains("END:VEVENT"));
  }

  @Test
  public void testExportMultipleEventsToIcal() throws IOException {
    // Setup calendar with multiple events
    parser.parse("create calendar --name \"MultiEvent\" --timezone America/New_York")
        .execute(manager);
    parser.parse("use calendar --name \"MultiEvent\"").execute(manager);

    parser.parse("create event \"Morning Meeting\" from 2023-12-01T09:00 to 2023-12-01T10:00")
        .execute(manager);
    parser.parse("create event \"Lunch\" from 2023-12-01T12:00 to 2023-12-01T13:00")
        .execute(manager);
    parser.parse("create event \"Afternoon Sync\" from 2023-12-01T15:00 to 2023-12-01T16:00")
        .execute(manager);

    // Export to iCal
    InterfaceCommand exportCommand = parser.parse("export cal " + testIcalFile);
    CommandResult result = exportCommand.execute(manager);

    assertTrue(result.isSuccess());

    // Verify all events are in iCal
    String content = readFileContent(testIcalFile);
    assertTrue(content.contains("Morning Meeting"));
    assertTrue(content.contains("Lunch"));
    assertTrue(content.contains("Afternoon Sync"));

    // Count VEVENT blocks
    int eventCount = countOccurrences(content, "BEGIN:VEVENT");
    assertEquals(3, eventCount);
  }

  @Test
  public void testExportAllDayEventToIcal() throws IOException {
    // Setup calendar with all-day event
    parser.parse("create calendar --name \"AllDay\" --timezone America/New_York").execute(manager);
    parser.parse("use calendar --name \"AllDay\"").execute(manager);
    parser.parse("create event \"Holiday\" on 2023-12-25").execute(manager);

    // Export to iCal
    InterfaceCommand exportCommand = parser.parse("export cal " + testIcalFile);
    CommandResult result = exportCommand.execute(manager);

    assertTrue(result.isSuccess());

    // Verify all-day event format
    String content = readFileContent(testIcalFile);
    assertTrue(content.contains("Holiday"));
    // All-day events should have DATE format instead of DATETIME
    assertTrue(content.contains("X-MICROSOFT-CDO-ALLDAYEVENT:TRUE"));
  }

  @Test
  public void testExportEventWithDetailsToIcal() throws IOException {
    // Setup calendar with detailed event
    parser.parse("create calendar --name \"Detailed\" --timezone America/New_York")
        .execute(manager);
    parser.parse("use calendar --name \"Detailed\"").execute(manager);

    // Create event with location and description
    InterfaceCommand createEvent = parser.parse(
        "create event \"Conference\" from 2023-12-01T10:00 to 2023-12-01T17:00");
    createEvent.execute(manager);

    // Export to iCal
    InterfaceCommand exportCommand = parser.parse("export cal " + testIcalFile);
    CommandResult result = exportCommand.execute(manager);

    assertTrue(result.isSuccess());

    // Verify event details
    String content = readFileContent(testIcalFile);
    assertTrue(content.contains("Conference"));
    assertTrue(content.contains("DTSTART:20231201T100000"));
    assertTrue(content.contains("DTEND:20231201T170000"));
  }

  @Test
  public void testExportPrivateEventToIcal() throws IOException {
    // Setup calendar with private event
    parser.parse("create calendar --name \"Private\" --timezone America/New_York").execute(manager);
    parser.parse("use calendar --name \"Private\"").execute(manager);

    // Create private event
    InterfaceCommand createEvent = parser.parse(
        "create event \"Private Meeting\" from 2023-12-01T10:00 to 2023-12-01T11:00");
    createEvent.execute(manager);

    // Export to iCal
    InterfaceCommand exportCommand = parser.parse("export cal " + testIcalFile);
    CommandResult result = exportCommand.execute(manager);

    assertTrue(result.isSuccess());

    // Verify private event classification
    String content = readFileContent(testIcalFile);
    assertTrue(content.contains("Private Meeting"));
    // Private events should have CLASS:PRIVATE
  }

  @Test
  public void testExportEmptyCalendarToIcal() throws IOException {
    // Setup empty calendar
    parser.parse("create calendar --name \"Empty\" --timezone America/New_York").execute(manager);
    parser.parse("use calendar --name \"Empty\"").execute(manager);

    // Export to iCal
    InterfaceCommand exportCommand = parser.parse("export cal " + testIcalFile);
    CommandResult result = exportCommand.execute(manager);

    assertTrue(result.isSuccess());

    // Verify empty iCal structure
    String content = readFileContent(testIcalFile);
    assertTrue(content.contains("BEGIN:VCALENDAR"));
    assertTrue(content.contains("END:VCALENDAR"));
    assertFalse(content.contains("BEGIN:VEVENT"));
  }

  @Test
  public void testExportWithTimezoneInformation() throws IOException {
    // Setup calendar with specific timezone
    parser.parse("create calendar --name \"TZTest\" --timezone America/New_York").execute(manager);
    parser.parse("use calendar --name \"TZTest\"").execute(manager);
    parser.parse("create event \"TZ Meeting\" from 2023-12-01T10:00 to 2023-12-01T11:00")
        .execute(manager);

    // Export to iCal
    InterfaceCommand exportCommand = parser.parse("export cal " + testIcalFile);
    CommandResult result = exportCommand.execute(manager);

    assertTrue(result.isSuccess());

    // Verify timezone information
    String content = readFileContent(testIcalFile);
    assertTrue(content.contains("TZ Meeting"));
    // Should include timezone information
  }

  @Test
  public void testExportWithSpecialCharacters() throws IOException {
    // Setup calendar with special characters
    parser.parse("create calendar --name \"Special\" --timezone America/New_York").execute(manager);
    parser.parse("use calendar --name \"Special\"").execute(manager);
    parser.parse(
            "create event \"Meeting @ Conference Room #1\" from 2023-12-01T10:00 "
                + "to 2023-12-01T11:00")
        .execute(manager);

    // Export to iCal
    InterfaceCommand exportCommand = parser.parse("export cal " + testIcalFile);
    CommandResult result = exportCommand.execute(manager);

    assertTrue(result.isSuccess());

    // Verify special characters are handled
    String content = readFileContent(testIcalFile);
    assertTrue(content.contains("Meeting"));
  }

  @Test
  public void testExportWithoutActiveCalendar() {
    // Try to export without setting active calendar
    InterfaceCommand exportCommand = parser.parse("export cal " + testIcalFile);
    CommandResult result = exportCommand.execute(manager);

    assertFalse(result.isSuccess());
    assertTrue(result.getMessage().toLowerCase().contains("no calendar"));
  }

  @Test
  public void testExportWithInvalidFilePath() {
    // Setup calendar
    parser.parse("create calendar --name \"Test\" --timezone America/New_York").execute(manager);
    parser.parse("use calendar --name \"Test\"").execute(manager);

    // Try to export to invalid path
    InterfaceCommand exportCommand = parser.parse("export cal \"/invalid/path/test.ical\"");
    CommandResult result = exportCommand.execute(manager);

    assertFalse(result.isSuccess());
    assertTrue(result.getMessage().toLowerCase().contains("file"));
  }

  @Test
  public void testExportReturnsAbsolutePath() throws IOException {
    // Setup calendar
    parser.parse("create calendar --name \"PathTest\" --timezone America/New_York")
        .execute(manager);
    parser.parse("use calendar --name \"PathTest\"").execute(manager);
    parser.parse("create event \"Test\" from 2023-12-01T10:00 to 2023-12-01T11:00")
        .execute(manager);

    // Export
    InterfaceCommand exportCommand = parser.parse("export cal " + testIcalFile);
    CommandResult result = exportCommand.execute(manager);

    assertTrue(result.isSuccess());

    // Verify returned path is absolute
    String returnedPath = result.getMessage();
    File file = new File(returnedPath);
    assertTrue(file.isAbsolute());
    assertTrue(file.exists());
  }

  @Test
  public void testExportMultiDayEventToIcal() throws IOException {
    // Setup calendar with multi-day event
    parser.parse("create calendar --name \"MultiDay\" --timezone America/New_York")
        .execute(manager);
    parser.parse("use calendar --name \"MultiDay\"").execute(manager);
    parser.parse("create event \"Conference\" from 2023-12-01T10:00 to 2023-12-03T17:00")
        .execute(manager);

    // Export to iCal
    InterfaceCommand exportCommand = parser.parse("export cal " + testIcalFile);
    CommandResult result = exportCommand.execute(manager);

    assertTrue(result.isSuccess());

    // Verify multi-day event
    String content = readFileContent(testIcalFile);
    assertTrue(content.contains("Conference"));
    assertTrue(content.contains("DTSTART:20231201T100000"));
    assertTrue(content.contains("DTEND:20231203T170000"));
  }

  private List<String> readFileLines(String fileName) throws IOException {
    List<String> lines = new java.util.ArrayList<>();
    try (BufferedReader reader = new BufferedReader(new FileReader(fileName))) {
      String line;
      while ((line = reader.readLine()) != null) {
        lines.add(line);
      }
    }
    return lines;
  }

  private String readFileContent(String fileName) throws IOException {
    return new String(Files.readAllBytes(Paths.get(fileName)));
  }

  private int countOccurrences(String content, String substring) {
    int count = 0;
    int index = 0;
    while ((index = content.indexOf(substring, index)) != -1) {
      count++;
      index += substring.length();
    }
    return count;
  }
}