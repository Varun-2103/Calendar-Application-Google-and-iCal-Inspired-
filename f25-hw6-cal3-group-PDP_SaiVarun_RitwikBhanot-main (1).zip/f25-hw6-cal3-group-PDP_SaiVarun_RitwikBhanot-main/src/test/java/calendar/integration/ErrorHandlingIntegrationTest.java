package calendar.integration;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import calendar.controller.CommandParser;
import calendar.controller.CommandResult;
import calendar.controller.InterfaceCommand;
import calendar.model.CalendarManager;
import org.junit.Before;
import org.junit.Test;

/**
 * Comprehensive error handling tests for Part 2 commands.
 */
public class ErrorHandlingIntegrationTest {

  private CommandParser parser;
  private CalendarManager manager;

  /** Sets up test environment before each test. */
  @Before
  public void setUp() {
    manager = new CalendarManager();
    parser = new CommandParser();
  }

  // Create Calendar Command Error Tests
  @Test
  public void testCreateCalendarMissingName() {
    InterfaceCommand command = parser.parse("create calendar --timezone America/New_York");
    CommandResult result = command.execute(manager);

    assertFalse(result.isSuccess());
    assertTrue(result.getMessage().toLowerCase().contains("name"));
  }

  @Test
  public void testCreateCalendarMissingTimezone() {
    InterfaceCommand command = parser.parse("create calendar --name \"Test\"");
    CommandResult result = command.execute(manager);

    assertFalse(result.isSuccess());
    assertTrue(result.getMessage().toLowerCase().contains("timezone"));
  }

  @Test
  public void testCreateCalendarInvalidTimezone() {
    InterfaceCommand command = parser.parse(
        "create calendar --name \"Test\" --timezone Invalid/Timezone");
    CommandResult result = command.execute(manager);

    assertFalse(result.isSuccess());
    assertTrue(result.getMessage().toLowerCase().contains("timezone"));
  }

  @Test
  public void testCreateCalendarDuplicateName() {
    // Create first calendar
    parser.parse("create calendar --name \"Duplicate\" --timezone America/New_York")
        .execute(manager);

    // Try to create duplicate
    InterfaceCommand command = parser.parse(
        "create calendar --name \"Duplicate\" --timezone Europe/London");
    CommandResult result = command.execute(manager);

    assertFalse(result.isSuccess());
    assertTrue(result.getMessage().toLowerCase().contains("already exists"));
  }

  // Use Calendar Command Error Tests
  @Test
  public void testUseCalendarMissingName() {
    InterfaceCommand command = parser.parse("use calendar");
    CommandResult result = command.execute(manager);

    assertFalse(result.isSuccess());
    assertTrue(result.getMessage().toLowerCase().contains("name"));
  }

  @Test
  public void testUseNonExistentCalendar() {
    InterfaceCommand command = parser.parse("use calendar --name \"NonExistent\"");
    CommandResult result = command.execute(manager);

    assertFalse(result.isSuccess());
    assertTrue(result.getMessage().toLowerCase().contains("not found"));
  }

  // Edit Calendar Command Error Tests
  @Test
  public void testEditCalendarMissingName() {
    InterfaceCommand command = parser.parse(
        "edit calendar --property name \"NewName\"");
    CommandResult result = command.execute(manager);

    assertFalse(result.isSuccess());
    assertTrue(result.getMessage().toLowerCase().contains("name"));
  }

  @Test
  public void testEditCalendarMissingProperty() {
    InterfaceCommand command = parser.parse(
        "edit calendar --name \"Test\" \"NewName\"");
    CommandResult result = command.execute(manager);

    assertFalse(result.isSuccess());
    assertTrue(result.getMessage().toLowerCase().contains("property"));
  }

  @Test
  public void testEditCalendarMissingValue() {
    InterfaceCommand command = parser.parse(
        "edit calendar --name \"Test\" --property name");
    CommandResult result = command.execute(manager);

    assertFalse(result.isSuccess());
    assertTrue(result.getMessage().toLowerCase().contains("value"));
  }

  @Test
  public void testEditCalendarInvalidProperty() {
    InterfaceCommand command = parser.parse(
        "edit calendar --name \"Test\" --property invalid \"value\"");
    CommandResult result = command.execute(manager);

    assertFalse(result.isSuccess());
    assertTrue(result.getMessage().toLowerCase().contains("property"));
  }

  @Test
  public void testEditCalendarNonExistent() {
    InterfaceCommand command = parser.parse(
        "edit calendar --name \"NonExistent\" --property name \"NewName\"");
    CommandResult result = command.execute(manager);

    assertFalse(result.isSuccess());
    assertTrue(result.getMessage().toLowerCase().contains("not found"));
  }

  @Test
  public void testCopyEventMissingDateTime() {
    InterfaceCommand command = parser.parse(
        "copy event \"Meeting\" --target Target to 2023-12-01T10:00");
    CommandResult result = command.execute(manager);

    assertFalse(result.isSuccess());
    assertTrue(result.getMessage().toLowerCase().contains("date")
        || result.getMessage().toLowerCase().contains("time"));
  }

  @Test
  public void testCopyEventMissingTarget() {
    InterfaceCommand command = parser.parse(
        "copy event \"Meeting\" on 2023-12-01T10:00 to 2023-12-01T10:00");
    CommandResult result = command.execute(manager);

    assertFalse(result.isSuccess());
    assertTrue(result.getMessage().toLowerCase().contains("target"));
  }

  @Test
  public void testCopyEventMissingTargetTime() {
    InterfaceCommand command = parser.parse(
        "copy event \"Meeting\" on 2023-12-01T10:00 --target Target");
    CommandResult result = command.execute(manager);

    assertFalse(result.isSuccess());
    assertTrue(result.getMessage().toLowerCase().contains("time"));
  }

  @Test
  public void testCopyEventNonExistentEvent() {
    // Setup calendars
    parser.parse("create calendar --name \"Source\" --timezone America/New_York").execute(manager);
    parser.parse("create calendar --name \"Target\" --timezone America/New_York").execute(manager);
    parser.parse("use calendar --name \"Source\"").execute(manager);

    InterfaceCommand command = parser.parse(
        "copy event \"NonExistent\" on 2023-12-01T10:00 --target Target to 2023-12-01T10:00");
    CommandResult result = command.execute(manager);

    assertFalse(result.isSuccess());
    assertTrue(result.getMessage().toLowerCase().contains("not found"));
  }

  @Test
  public void testCopyEventNonExistentTargetCalendar() {
    // Setup source calendar
    parser.parse("create calendar --name \"Source\" --timezone America/New_York").execute(manager);
    parser.parse("use calendar --name \"Source\"").execute(manager);
    parser.parse("create event \"Meeting\" from 2023-12-01T10:00 to 2023-12-01T11:00")
        .execute(manager);

    InterfaceCommand command = parser.parse(
        "copy event \"Meeting\" on 2023-12-01T10:00 --target NonExistent to 2023-12-01T10:00");
    CommandResult result = command.execute(manager);

    assertFalse(result.isSuccess());
    assertTrue(result.getMessage().toLowerCase().contains("not found"));
  }

  // Copy Events Command Error Tests
  @Test
  public void testCopyEventsOnMissingDate() {
    InterfaceCommand command = parser.parse(
        "copy events --target Target to 2023-12-01");
    CommandResult result = command.execute(manager);

    assertFalse(result.isSuccess());
    assertTrue(result.getMessage().toLowerCase().contains("date"));
  }

  @Test
  public void testCopyEventsBetweenMissingStartDate() {
    InterfaceCommand command = parser.parse(
        "copy events and 2023-12-02 --target Target to 2023-12-01");
    CommandResult result = command.execute(manager);

    assertFalse(result.isSuccess());
    assertTrue(result.getMessage().toLowerCase().contains("date"));
  }

  @Test
  public void testCopyEventsBetweenMissingEndDate() {
    InterfaceCommand command = parser.parse(
        "copy events between 2023-12-01 --target Target to 2023-12-01");
    CommandResult result = command.execute(manager);

    assertFalse(result.isSuccess());
    assertTrue(result.getMessage().toLowerCase().contains("date"));
  }

  @Test
  public void testCopyEventsInvalidDateRange() {
    // Setup calendars
    parser.parse("create calendar --name \"Source\" --timezone America/New_York").execute(manager);
    parser.parse("create calendar --name \"Target\" --timezone America/New_York").execute(manager);

    InterfaceCommand command = parser.parse(
        "copy events between 2023-12-05 and 2023-12-01 --target Target to 2023-12-01");
    CommandResult result = command.execute(manager);

    assertFalse(result.isSuccess());
    assertTrue(result.getMessage().toLowerCase().contains("invalid")
        || result.getMessage().toLowerCase().contains("range"));
  }

  // Export Command Error Tests
  @Test
  public void testExportCalMissingFilename() {
    InterfaceCommand command = parser.parse("export cal");
    CommandResult result = command.execute(manager);

    assertFalse(result.isSuccess());
    assertTrue(result.getMessage().toLowerCase().contains("file"));
  }

  @Test
  public void testExportCalWithoutActiveCalendar() {
    InterfaceCommand command = parser.parse("export cal test.csv");
    CommandResult result = command.execute(manager);

    assertFalse(result.isSuccess());
    assertTrue(result.getMessage().toLowerCase().contains("calendar"));
  }

  @Test
  public void testExportCalInvalidFilePath() {
    // Setup calendar
    parser.parse("create calendar --name \"Test\" --timezone America/New_York").execute(manager);
    parser.parse("use calendar --name \"Test\"").execute(manager);

    InterfaceCommand command =
        parser.parse("export cal \"/invalid/path/that/does/not/exist/test.csv\"");
    CommandResult result = command.execute(manager);

    assertFalse(result.isSuccess());
    assertTrue(result.getMessage().toLowerCase().contains("file"));
  }

  // Event Creation Error Tests (without active calendar)
  @Test
  public void testCreateEventWithoutActiveCalendar() {
    InterfaceCommand command = parser.parse(
        "create event \"Meeting\" from 2023-12-01T10:00 to 2023-12-01T11:00");
    CommandResult result = command.execute(manager);

    assertFalse(result.isSuccess());
    assertTrue(result.getMessage().toLowerCase().contains("calendar"));
  }

  @Test
  public void testCreateEventSeriesWithoutActiveCalendar() {
    InterfaceCommand command = parser.parse(
        "create event \"Series\" from 2023-12-01T10:00 to 2023-12-01T11:00 "
            + "repeats MWF for 5 times");
    CommandResult result = command.execute(manager);

    assertFalse(result.isSuccess());
    assertTrue(result.getMessage().toLowerCase().contains("calendar"));
  }

  // Event Editing Error Tests (without active calendar)
  @Test
  public void testEditEventWithoutActiveCalendar() {
    InterfaceCommand command = parser.parse(
        "edit event subject \"Meeting\" from 2023-12-01T10:00 to 2023-12-01T11:00 "
            + "with \"New Meeting\"");
    CommandResult result = command.execute(manager);

    assertFalse(result.isSuccess());
    assertTrue(result.getMessage().toLowerCase().contains("calendar"));
  }

  // Print Commands Error Tests (without active calendar)
  @Test
  public void testPrintEventsWithoutActiveCalendar() {
    InterfaceCommand command = parser.parse("print events on 2023-12-01");
    CommandResult result = command.execute(manager);

    assertFalse(result.isSuccess());
    assertTrue(result.getMessage().toLowerCase().contains("calendar"));
  }

  @Test
  public void testPrintEventsInvalidDate() {
    // Setup calendar
    parser.parse("create calendar --name \"Test\" --timezone America/New_York").execute(manager);
    parser.parse("use calendar --name \"Test\"").execute(manager);

    InterfaceCommand command = parser.parse("print events on invalid-date");
    CommandResult result = command.execute(manager);

    assertFalse(result.isSuccess());
    assertTrue(result.getMessage().toLowerCase().contains("date"));
  }

  // Show Status Command Error Tests
  @Test
  public void testShowStatusWithoutActiveCalendar() {
    InterfaceCommand command = parser.parse("show status on 2023-12-01T10:00");
    CommandResult result = command.execute(manager);

    assertFalse(result.isSuccess());
    assertTrue(result.getMessage().toLowerCase().contains("calendar"));
  }

  @Test
  public void testShowStatusInvalidDateTime() {
    // Setup calendar
    parser.parse("create calendar --name \"Test\" --timezone America/New_York").execute(manager);
    parser.parse("use calendar --name \"Test\"").execute(manager);

    InterfaceCommand command = parser.parse("show status on invalid-datetime");
    CommandResult result = command.execute(manager);

    assertFalse(result.isSuccess());
    assertTrue(result.getMessage().toLowerCase().contains("date")
        || result.getMessage().toLowerCase().contains("time"));
  }

  // Invalid Command Tests
  @Test
  public void testUnknownCommand() {
    InterfaceCommand command = parser.parse("unknown command with parameters");
    CommandResult result = command.execute(manager);

    assertFalse(result.isSuccess());
    assertTrue(result.getMessage().toLowerCase().contains("command"));
  }

  @Test
  public void testMalformedCommand() {
    InterfaceCommand command = parser.parse("create");
    CommandResult result = command.execute(manager);

    assertFalse(result.isSuccess());
    assertTrue(result.getMessage().toLowerCase().contains("command")
        || result.getMessage().toLowerCase().contains("invalid"));
  }

  @Test
  public void testEmptyCommand() {
    InterfaceCommand command = parser.parse("");
    CommandResult result = command.execute(manager);

    assertFalse(result.isSuccess());
    assertTrue(result.getMessage().toLowerCase().contains("command"));
  }

  @Test
  public void testNullCommand() {
    InterfaceCommand command = parser.parse(null);
    CommandResult result = command.execute(manager);

    assertFalse(result.isSuccess());
    assertTrue(result.getMessage().toLowerCase().contains("command"));
  }

  // Edge Case Error Tests
  @Test
  public void testCreateCalendarWithEmptyName() {
    InterfaceCommand command = parser.parse(
        "create calendar --name \"\" --timezone America/New_York");
    CommandResult result = command.execute(manager);

    assertFalse(result.isSuccess());
    assertTrue(result.getMessage().toLowerCase().contains("name"));
  }

  @Test
  public void testCreateCalendarWithEmptyTimezone() {
    InterfaceCommand command = parser.parse(
        "create calendar --name \"Test\" --timezone \"\"");
    CommandResult result = command.execute(manager);

    assertFalse(result.isSuccess());
    assertTrue(result.getMessage().toLowerCase().contains("timezone"));
  }

  @Test
  public void testCopyEventWithEmptyEventName() {
    // Setup calendars
    parser.parse("create calendar --name \"Source\" --timezone America/New_York").execute(manager);
    parser.parse("create calendar --name \"Target\" --timezone America/New_York").execute(manager);

    InterfaceCommand command = parser.parse(
        "copy event \"\" on 2023-12-01T10:00 --target Target to 2023-12-01T10:00");
    CommandResult result = command.execute(manager);

    assertFalse(result.isSuccess());
    assertTrue(result.getMessage().toLowerCase().contains("event"));
  }

  @Test
  public void testCopyEventWithEmptyTargetCalendar() {
    // Setup calendars
    parser.parse("create calendar --name \"Source\" --timezone America/New_York").execute(manager);
    parser.parse("use calendar --name \"Source\"").execute(manager);
    parser.parse("create event \"Meeting\" from 2023-12-01T10:00 to 2023-12-01T11:00")
        .execute(manager);

    InterfaceCommand command = parser.parse(
        "copy event \"Meeting\" on 2023-12-01T10:00 --target \"\" to 2023-12-01T10:00");
    CommandResult result = command.execute(manager);

    assertFalse(result.isSuccess());
    assertTrue(result.getMessage().toLowerCase().contains("target"));
  }

  @Test
  public void testEventSeriesWithInvalidWeekdayPattern() {
    // Setup calendar
    parser.parse("create calendar --name \"Test\" --timezone America/New_York").execute(manager);
    parser.parse("use calendar --name \"Test\"").execute(manager);

    InterfaceCommand command = parser.parse(
        "create event \"Invalid Series\" from 2023-12-01T10:00 to 2023-12-01T11:00 "
            + "repeats XYZ for 5 times");
    CommandResult result = command.execute(manager);

    assertFalse(result.isSuccess());
    assertTrue(result.getMessage().toLowerCase().contains("weekday")
        || result.getMessage().toLowerCase().contains("pattern"));
  }

  @Test
  public void testEventSeriesWithInvalidOccurrences() {
    // Setup calendar
    parser.parse("create calendar --name \"Test\" --timezone America/New_York").execute(manager);
    parser.parse("use calendar --name \"Test\"").execute(manager);

    InterfaceCommand command = parser.parse(
        "create event \"Invalid Series\" from 2023-12-01T10:00 to 2023-12-01T11:00 "
            + "repeats M for -1 times");
    CommandResult result = command.execute(manager);

    assertFalse(result.isSuccess());
    assertTrue(result.getMessage().toLowerCase().contains("occurrences")
        || result.getMessage().toLowerCase().contains("invalid"));
  }

  @Test
  public void testEventSeriesWithInvalidUntilDate() {
    // Setup calendar
    parser.parse("create calendar --name \"Test\" --timezone America/New_York").execute(manager);
    parser.parse("use calendar --name \"Test\"").execute(manager);

    InterfaceCommand command = parser.parse(
        "create event \"Invalid Series\" from 2023-12-01T10:00 to 2023-12-01T11:00 "
            + "repeats M until invalid-date");
    CommandResult result = command.execute(manager);

    assertFalse(result.isSuccess());
    assertTrue(result.getMessage().toLowerCase().contains("date"));
  }
}