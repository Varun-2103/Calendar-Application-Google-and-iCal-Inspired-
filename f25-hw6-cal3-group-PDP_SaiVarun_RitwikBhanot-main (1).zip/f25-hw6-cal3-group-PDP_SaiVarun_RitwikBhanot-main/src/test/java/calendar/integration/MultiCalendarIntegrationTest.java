package calendar.integration;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import calendar.controller.CommandParser;
import calendar.controller.CommandResult;
import calendar.controller.InterfaceCommand;
import calendar.model.CalendarManager;
import calendar.model.InterfaceCalendar;
import java.time.ZoneId;
import java.util.Set;
import org.junit.Before;
import org.junit.Test;

/**
 * Integration tests for multi-calendar management functionality.
 */
public class MultiCalendarIntegrationTest {

  private CommandParser parser;
  private CalendarManager manager;

  /** Sets up test environment before each test. */
  @Before
  public void setUp() {
    manager = new CalendarManager();
    parser = new CommandParser();
  }

  @Test
  public void testCreateMultipleCalendars() {
    // Create multiple calendars
    InterfaceCommand workCommand = parser.parse(
        "create calendar --name \"Work\" --timezone America/New_York");
    InterfaceCommand personalCommand = parser.parse(
        "create calendar --name \"Personal\" --timezone Europe/London");
    InterfaceCommand schoolCommand = parser.parse(
        "create calendar --name \"School\" --timezone Asia/Kolkata");

    assertTrue(workCommand.execute(manager).isSuccess());
    assertTrue(personalCommand.execute(manager).isSuccess());
    assertTrue(schoolCommand.execute(manager).isSuccess());

    // Verify all calendars exist
    assertTrue(manager.calendarExists("Work"));
    assertTrue(manager.calendarExists("Personal"));
    assertTrue(manager.calendarExists("School"));
    assertEquals(3, manager.getAllCalendarNames().size());
  }

  @Test
  public void testSwitchBetweenCalendars() {
    // Create calendars
    parser.parse("create calendar --name \"Work\" --timezone America/New_York").execute(manager);
    parser.parse("create calendar --name \"Personal\" --timezone Europe/London").execute(manager);

    // Switch to Work calendar
    InterfaceCommand useWork = parser.parse("use calendar --name \"Work\"");
    CommandResult workResult = useWork.execute(manager);

    assertTrue(workResult.isSuccess());
    assertTrue(manager.hasActiveCalendar());
    assertEquals("Work", manager.getActiveCalendarName());
    assertEquals(ZoneId.of("America/New_York"), manager.getActiveCalendarTimezone());

    // Switch to Personal calendar
    InterfaceCommand usePersonal = parser.parse("use calendar --name \"Personal\"");
    CommandResult personalResult = usePersonal.execute(manager);

    assertTrue(personalResult.isSuccess());
    assertEquals("Personal", manager.getActiveCalendarName());
    assertEquals(ZoneId.of("Europe/London"), manager.getActiveCalendarTimezone());
  }

  @Test
  public void testEventsInMultipleCalendars() {
    // Create two calendars
    parser.parse("create calendar --name \"Work\" --timezone America/New_York").execute(manager);
    parser.parse("create calendar --name \"Personal\" --timezone Europe/London").execute(manager);

    // Add events to Work calendar
    parser.parse("use calendar --name \"Work\"").execute(manager);
    parser.parse("create event \"Work Meeting\" from 2023-12-01T10:00 to 2023-12-01T11:00")
        .execute(manager);
    parser.parse("create event \"Team Sync\" from 2023-12-01T15:00 to 2023-12-01T16:00")
        .execute(manager);

    // Add events to Personal calendar
    parser.parse("use calendar --name \"Personal\"").execute(manager);
    parser.parse("create event \"Doctor Appointment\" from 2023-12-02T14:00 to 2023-12-02T15:00")
        .execute(manager);
    parser.parse("create event \"Birthday Party\" from 2023-12-03T19:00 to 2023-12-03T22:00")
        .execute(manager);

    // Verify events are in correct calendars
    InterfaceCalendar workCalendar = manager.getCalendar("Work");
    InterfaceCalendar personalCalendar = manager.getCalendar("Personal");

    assertEquals(2, workCalendar.getAllEvents().size());
    assertEquals(2, personalCalendar.getAllEvents().size());

    // Verify event subjects
    assertTrue(workCalendar.getAllEvents().stream()
        .anyMatch(e -> e.getSubject().equals("Work Meeting")));
    assertTrue(personalCalendar.getAllEvents().stream()
        .anyMatch(e -> e.getSubject().equals("Doctor Appointment")));
  }

  @Test
  public void testCalendarIsolation() {
    // Create two calendars
    parser.parse("create calendar --name \"Cal1\" --timezone America/New_York").execute(manager);
    parser.parse("create calendar --name \"Cal2\" --timezone America/New_York").execute(manager);

    // Add event to Cal1
    parser.parse("use calendar --name \"Cal1\"").execute(manager);
    parser.parse("create event \"Shared Name\" from 2023-12-01T10:00 to 2023-12-01T11:00")
        .execute(manager);

    // Add event with same name to Cal2 (different time)
    parser.parse("use calendar --name \"Cal2\"").execute(manager);
    parser.parse("create event \"Shared Name\" from 2023-12-01T12:00 to 2023-12-01T13:00")
        .execute(manager);

    // Both calendars should have their own events
    InterfaceCalendar cal1 = manager.getCalendar("Cal1");
    InterfaceCalendar cal2 = manager.getCalendar("Cal2");

    assertEquals(1, cal1.getAllEvents().size());
    assertEquals(1, cal2.getAllEvents().size());
  }

  @Test
  public void testEditCalendarProperties() {
    // Create calendar
    parser.parse("create calendar --name \"Original\" --timezone America/New_York")
        .execute(manager);

    // Edit name
    InterfaceCommand editName = parser.parse(
        "edit calendar --name \"Original\" --property name \"Updated\"");
    CommandResult nameResult = editName.execute(manager);

    assertTrue(nameResult.isSuccess());
    assertFalse(manager.calendarExists("Original"));
    assertTrue(manager.calendarExists("Updated"));

    // Edit timezone
    InterfaceCommand editTimezone = parser.parse(
        "edit calendar --name \"Updated\" --property timezone Europe/London");
    CommandResult timezoneResult = editTimezone.execute(manager);

    assertTrue(timezoneResult.isSuccess());
    assertEquals(ZoneId.of("Europe/London"), manager.getCalendarTimezone("Updated"));
  }

  @Test
  public void testUseCalendarWithoutActiveCalendar() {
    // Create calendar but don't set active
    parser.parse("create calendar --name \"Test\" --timezone America/New_York").execute(manager);

    // Try to create event without active calendar
    InterfaceCommand createEvent = parser.parse(
        "create event \"No Active\" from 2023-12-01T10:00 to 2023-12-01T11:00");
    CommandResult result = createEvent.execute(manager);

    assertFalse(result.isSuccess());
    assertTrue(result.getMessage().toLowerCase().contains("no calendar"));
  }

  @Test
  public void testCalendarNameUniqueness() {
    // Create first calendar
    InterfaceCommand first = parser.parse(
        "create calendar --name \"Unique\" --timezone America/New_York");
    assertTrue(first.execute(manager).isSuccess());

    // Try to create duplicate
    InterfaceCommand duplicate = parser.parse(
        "create calendar --name \"Unique\" --timezone Europe/London");
    CommandResult result = duplicate.execute(manager);

    assertFalse(result.isSuccess());
    assertTrue(result.getMessage().toLowerCase().contains("already exists"));
  }

  @Test
  public void testUseNonExistentCalendar() {
    InterfaceCommand useCommand = parser.parse("use calendar --name \"NonExistent\"");
    CommandResult result = useCommand.execute(manager);

    assertFalse(result.isSuccess());
    assertTrue(result.getMessage().toLowerCase().contains("not found"));
  }

  @Test
  public void testEditNonExistentCalendar() {
    InterfaceCommand editCommand = parser.parse(
        "edit calendar --name \"NonExistent\" --property name \"NewName\"");
    CommandResult result = editCommand.execute(manager);

    assertFalse(result.isSuccess());
    assertTrue(result.getMessage().toLowerCase().contains("not found"));
  }

  @Test
  public void testCalendarWithSpecialCharacters() {
    // Create calendar with special characters
    InterfaceCommand createCommand = parser.parse(
        "create calendar --name \"Work & Personal\" --timezone America/New_York");
    CommandResult result = createCommand.execute(manager);

    assertTrue(result.isSuccess());
    assertTrue(manager.calendarExists("Work & Personal"));

    // Use calendar with special characters
    InterfaceCommand useCommand = parser.parse("use calendar --name \"Work & Personal\"");
    CommandResult useResult = useCommand.execute(manager);

    assertTrue(useResult.isSuccess());
    assertEquals("Work & Personal", manager.getActiveCalendarName());
  }

  @Test
  public void testCalendarWithUnicodeCharacters() {
    // Create calendar with unicode characters
    InterfaceCommand createCommand = parser.parse(
        "create calendar --name \"📅 日历 Calendrier\" --timezone Asia/Tokyo");
    CommandResult result = createCommand.execute(manager);

    assertTrue(result.isSuccess());
    assertTrue(manager.calendarExists("📅 日历 Calendrier"));

    // Use calendar with unicode characters
    InterfaceCommand useCommand = parser.parse("use calendar --name \"📅 日历 Calendrier\"");
    CommandResult useResult = useCommand.execute(manager);

    assertTrue(useResult.isSuccess());
    assertEquals("📅 日历 Calendrier", manager.getActiveCalendarName());
  }

  @Test
  public void testMultipleCalendarOperations() {
    // Create multiple calendars
    parser.parse("create calendar --name \"Work\" --timezone America/New_York").execute(manager);
    parser.parse("create calendar --name \"Personal\" --timezone Europe/London").execute(manager);
    parser.parse("create calendar --name \"School\" --timezone Asia/Kolkata").execute(manager);

    // Perform operations on different calendars
    parser.parse("use calendar --name \"Work\"").execute(manager);
    parser.parse("create event \"Work Event\" from 2023-12-01T09:00 to 2023-12-01T10:00")
        .execute(manager);

    parser.parse("use calendar --name \"Personal\"").execute(manager);
    parser.parse("create event \"Personal Event\" from 2023-12-01T14:00 to 2023-12-01T15:00")
        .execute(manager);

    parser.parse("use calendar --name \"School\"").execute(manager);
    parser.parse("create event \"School Event\" from 2023-12-01T18:00 to 2023-12-01T19:00")
        .execute(manager);

    // Verify all calendars have their events
    assertEquals(1, manager.getCalendar("Work").getAllEvents().size());
    assertEquals(1, manager.getCalendar("Personal").getAllEvents().size());
    assertEquals(1, manager.getCalendar("School").getAllEvents().size());

    // Verify active calendar is the last one used
    assertEquals("School", manager.getActiveCalendarName());
  }

  @Test
  public void testCalendarListManagement() {
    // Initially should be empty
    assertTrue(manager.getAllCalendarNames().isEmpty());
    assertFalse(manager.hasCalendars());

    // Add calendars
    parser.parse("create calendar --name \"A\" --timezone UTC").execute(manager);
    parser.parse("create calendar --name \"B\" --timezone UTC").execute(manager);
    parser.parse("create calendar --name \"C\" --timezone UTC").execute(manager);

    // Check list
    Set<String> names = manager.getAllCalendarNames();
    assertEquals(3, names.size());
    assertTrue(names.contains("A"));
    assertTrue(names.contains("B"));
    assertTrue(names.contains("C"));
    assertTrue(manager.hasCalendars());

    // Check calendar objects
    assertEquals(3, manager.getAllCalendars().size());
    assertNotNull(manager.getCalendar("A"));
    assertNotNull(manager.getCalendar("B"));
    assertNotNull(manager.getCalendar("C"));
  }

  @Test
  public void testActiveCalendarState() {
    // Initially no active calendar
    assertFalse(manager.hasActiveCalendar());

    // Create calendar but still no active calendar
    parser.parse("create calendar --name \"Test\" --timezone UTC").execute(manager);
    assertFalse(manager.hasActiveCalendar());

    // Set active calendar
    parser.parse("use calendar --name \"Test\"").execute(manager);
    assertTrue(manager.hasActiveCalendar());

    // Verify active calendar properties
    assertEquals("Test", manager.getActiveCalendarName());
    assertEquals(ZoneId.of("UTC"), manager.getActiveCalendarTimezone());
    assertNotNull(manager.getActiveCalendar());
  }

  @Test
  public void testCalendarTimezoneIndependence() {
    // Create calendars with different timezones
    parser.parse("create calendar --name \"NY\" --timezone America/New_York").execute(manager);
    parser.parse("create calendar --name \"London\" --timezone Europe/London").execute(manager);
    parser.parse("create calendar --name \"Tokyo\" --timezone Asia/Tokyo").execute(manager);

    // Verify timezones are independent
    assertEquals(ZoneId.of("America/New_York"), manager.getCalendarTimezone("NY"));
    assertEquals(ZoneId.of("Europe/London"), manager.getCalendarTimezone("London"));
    assertEquals(ZoneId.of("Asia/Tokyo"), manager.getCalendarTimezone("Tokyo"));

    // Switch between calendars and verify timezone changes
    parser.parse("use calendar --name \"NY\"").execute(manager);
    assertEquals(ZoneId.of("America/New_York"), manager.getActiveCalendarTimezone());

    parser.parse("use calendar --name \"London\"").execute(manager);
    assertEquals(ZoneId.of("Europe/London"), manager.getActiveCalendarTimezone());

    parser.parse("use calendar --name \"Tokyo\"").execute(manager);
    assertEquals(ZoneId.of("Asia/Tokyo"), manager.getActiveCalendarTimezone());
  }
}