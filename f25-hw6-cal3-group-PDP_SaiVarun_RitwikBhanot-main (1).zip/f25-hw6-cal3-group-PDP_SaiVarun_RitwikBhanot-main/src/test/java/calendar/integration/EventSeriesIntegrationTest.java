package calendar.integration;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import calendar.controller.CommandParser;
import calendar.controller.CommandResult;
import calendar.controller.InterfaceCommand;
import calendar.model.CalendarManager;
import calendar.model.InterfaceCalendar;
import calendar.model.InterfaceEvent;
import java.util.List;
import org.junit.Before;
import org.junit.Test;

/**
 * Integration tests for event series functionality with correct command syntax.
 */
public class EventSeriesIntegrationTest {

  private CommandParser parser;
  private CalendarManager manager;

  /** Sets up test environment before each test. */
  @Before
  public void setUp() {
    manager = new CalendarManager();
    parser = new CommandParser();
  }

  @Test
  public void testCreateEventSeriesForMultipleTimes() {
    // Setup calendar
    parser.parse("create calendar --name \"Work\" --timezone America/New_York").execute(manager);
    parser.parse("use calendar --name \"Work\"").execute(manager);

    // Create event series for N times
    InterfaceCommand createSeries = parser.parse(
        "create event \"Daily Standup\" from 2023-12-01T09:00 to 2023-12-01T09:30 "
            + "repeats MTWRF for 5 times");
    CommandResult result = createSeries.execute(manager);

    assertTrue(result.isSuccess());

    // Verify events were created
    InterfaceCalendar calendar = manager.getActiveCalendar();
    List<InterfaceEvent> events = calendar.getAllEvents();
    assertEquals(5, events.size());

    // Verify all events have same subject
    assertTrue(events.stream().allMatch(e -> e.getSubject().equals("Daily Standup")));
  }

  @Test
  public void testCreateEventSeriesUntilDate() {
    // Setup calendar
    parser.parse("create calendar --name \"Work\" --timezone America/New_York").execute(manager);
    parser.parse("use calendar --name \"Work\"").execute(manager);

    // Create event series until date
    InterfaceCommand createSeries = parser.parse(
        "create event \"Weekly Meeting\" from 2023-12-01T10:00 to 2023-12-01T11:00 "
            + "repeats MWF until 2023-12-15");
    CommandResult result = createSeries.execute(manager);

    assertTrue(result.isSuccess());

    // Verify events were created
    InterfaceCalendar calendar = manager.getActiveCalendar();
    List<InterfaceEvent> events = calendar.getAllEvents();
    assertFalse(events.isEmpty());

    // Verify all events are on Monday, Wednesday, or Friday
    assertTrue(events.stream().allMatch(e -> {
      int dayOfWeek = e.getStart().getDayOfWeek().getValue();
      return dayOfWeek == 1 || dayOfWeek == 3 || dayOfWeek == 5; // Mon=1, Wed=3, Fri=5
    }));
  }

  @Test
  public void testCreateAllDayEventSeries() {
    // Setup calendar
    parser.parse("create calendar --name \"Personal\" --timezone America/New_York")
        .execute(manager);
    parser.parse("use calendar --name \"Personal\"").execute(manager);

    // Create all-day event series
    InterfaceCommand createSeries = parser.parse(
        "create event \"Daily Exercise\" on 2023-12-01 repeats MTWRF for 10 times");
    CommandResult result = createSeries.execute(manager);

    assertTrue(result.isSuccess());

    // Verify events were created
    InterfaceCalendar calendar = manager.getActiveCalendar();
    List<InterfaceEvent> events = calendar.getAllEvents();
    assertEquals(10, events.size());

    // Verify all events are all-day (8am-5pm)
    assertTrue(events.stream().allMatch(e ->
        e.getStart().getHour() == 8 && e.getEnd().getHour() == 17));
  }

  @Test
  public void testCreateEventSeriesWithWeekendDays() {
    // Setup calendar
    parser.parse("create calendar --name \"Weekend\" --timezone America/New_York").execute(manager);
    parser.parse("use calendar --name \"Weekend\"").execute(manager);

    // Create event series for weekends
    InterfaceCommand createSeries = parser.parse(
        "create event \"Weekend Activity\" from 2023-12-01T10:00 to 2023-12-01T12:00 "
            + "repeats SS for 4 times");
    CommandResult result = createSeries.execute(manager);

    assertTrue(result.isSuccess());

    // Verify events were created
    InterfaceCalendar calendar = manager.getActiveCalendar();
    List<InterfaceEvent> events = calendar.getAllEvents();
    assertEquals(4, events.size());

    // Verify all events are on Saturday or Sunday
    assertTrue(events.stream().allMatch(e -> {
      int dayOfWeek = e.getStart().getDayOfWeek().getValue();
      return dayOfWeek == 6 || dayOfWeek == 7; // Sat=6, Sun=7
    }));
  }

  @Test
  public void testCreateEventSeriesWithAllWeekdays() {
    // Setup calendar
    parser.parse("create calendar --name \"Daily\" --timezone America/New_York").execute(manager);
    parser.parse("use calendar --name \"Daily\"").execute(manager);

    // Create event series for all weekdays
    InterfaceCommand createSeries = parser.parse(
        "create event \"Daily Task\" from 2023-12-01T08:00 to 2023-12-01T08:30 "
            + "repeats MTWRF for 10 times");
    CommandResult result = createSeries.execute(manager);

    assertTrue(result.isSuccess());

    // Verify events were created
    InterfaceCalendar calendar = manager.getActiveCalendar();
    List<InterfaceEvent> events = calendar.getAllEvents();
    assertEquals(10, events.size());
  }

  @Test
  public void testCreateEventSeriesWithSpecificWeekdays() {
    // Setup calendar
    parser.parse("create calendar --name \"Specific\" --timezone America/New_York")
        .execute(manager);
    parser.parse("use calendar --name \"Specific\"").execute(manager);

    // Create event series for Tuesday and Thursday only
    InterfaceCommand createSeries = parser.parse(
        "create event \"Biweekly Meeting\" from 2023-12-01T14:00 to 2023-12-01T15:00 "
            + "repeats TR for 6 times");
    CommandResult result = createSeries.execute(manager);

    assertTrue(result.isSuccess());

    // Verify events were created
    InterfaceCalendar calendar = manager.getActiveCalendar();
    List<InterfaceEvent> events = calendar.getAllEvents();
    assertEquals(6, events.size());

    // Verify all events are on Tuesday or Thursday
    assertTrue(events.stream().allMatch(e -> {
      int dayOfWeek = e.getStart().getDayOfWeek().getValue();
      return dayOfWeek == 2 || dayOfWeek == 4; // Tue=2, Thu=4
    }));
  }

  @Test
  public void testEventSeriesWithSameStartTime() {
    // Setup calendar
    parser.parse("create calendar --name \"Consistent\" --timezone America/New_York")
        .execute(manager);
    parser.parse("use calendar --name \"Consistent\"").execute(manager);

    // Create event series
    InterfaceCommand createSeries = parser.parse(
        "create event \"Consistent Time\" from 2023-12-01T15:30 to 2023-12-01T16:00 "
            + "repeats MWF for 9 times");
    CommandResult result = createSeries.execute(manager);

    assertTrue(result.isSuccess());

    // Verify all events have same start time
    InterfaceCalendar calendar = manager.getActiveCalendar();
    List<InterfaceEvent> events = calendar.getAllEvents();
    assertEquals(9, events.size());

    assertTrue(events.stream().allMatch(e ->
        e.getStart().getHour() == 15 && e.getStart().getMinute() == 30));
  }

  @Test
  public void testEventSeriesSpanningMultipleWeeks() {
    // Setup calendar
    parser.parse("create calendar --name \"MultiWeek\" --timezone America/New_York")
        .execute(manager);
    parser.parse("use calendar --name \"MultiWeek\"").execute(manager);

    // Create event series that spans multiple weeks
    InterfaceCommand createSeries = parser.parse(
        "create event \"Long Series\" from 2023-12-01T10:00 to 2023-12-01T11:00 "
            + "repeats MWF for 15 times");
    CommandResult result = createSeries.execute(manager);

    assertTrue(result.isSuccess());

    // Verify events span multiple weeks
    InterfaceCalendar calendar = manager.getActiveCalendar();
    List<InterfaceEvent> events = calendar.getAllEvents();
    assertEquals(15, events.size());

    // Check first and last event dates
    InterfaceEvent firstEvent = events.get(0);
    InterfaceEvent lastEvent = events.get(events.size() - 1);

    assertTrue(firstEvent.getStart().getDayOfMonth() <= 7); // First week

    // Check that series spans multiple weeks (has events at least 2 weeks apart)
    long daysBetween = java.time.temporal.ChronoUnit.DAYS.between(
        firstEvent.getStart().toLocalDate(),
        lastEvent.getStart().toLocalDate());
    assertTrue(daysBetween >= 14); // At least 2 weeks
  }

  @Test
  public void testMultipleEventSeriesInSameCalendar() {
    // Setup calendar
    parser.parse("create calendar --name \"Multiple\" --timezone America/New_York")
        .execute(manager);
    parser.parse("use calendar --name \"Multiple\"").execute(manager);

    // Create multiple event series
    parser.parse(
        "create event \"Morning Standup\" from 2023-12-01T09:00 to 2023-12-01T09:15 "
            + "repeats MTWRF for 10 times")
        .execute(manager);
    parser.parse(
        "create event \"Weekly Review\" from 2023-12-01T16:00 to 2023-12-01T17:00 "
            + "repeats F for 4 times")
        .execute(manager);
    parser.parse("create event \"Daily Exercise\" on 2023-12-01 repeats MTWRF for 20 times")
        .execute(manager);

    // Verify all events were created
    InterfaceCalendar calendar = manager.getActiveCalendar();
    List<InterfaceEvent> events = calendar.getAllEvents();
    assertEquals(34, events.size()); // 10 + 4 + 20

    // Verify different event types
    long morningEvents =
        events.stream().filter(e -> e.getSubject().equals("Morning Standup")).count();
    long reviewEvents = events.stream().filter(e -> e.getSubject().equals("Weekly Review")).count();
    long exerciseEvents =
        events.stream().filter(e -> e.getSubject().equals("Daily Exercise")).count();

    assertEquals(10, morningEvents);
    assertEquals(4, reviewEvents);
    assertEquals(20, exerciseEvents);
  }

  @Test
  public void testEventSeriesWithInvalidWeekdayPattern() {
    // Setup calendar
    parser.parse("create calendar --name \"Invalid\" --timezone America/New_York").execute(manager);
    parser.parse("use calendar --name \"Invalid\"").execute(manager);

    // Try to create event series with invalid weekday pattern
    InterfaceCommand createSeries = parser.parse(
        "create event \"Invalid Series\" from 2023-12-01T10:00 to 2023-12-01T11:00 "
            + "repeats XYZ for 5 times");
    CommandResult result = createSeries.execute(manager);

    assertFalse(result.isSuccess());
    assertTrue(result.getMessage().toLowerCase().contains("weekday"));
  }

  @Test
  public void testEventSeriesWithZeroOccurrences() {
    // Setup calendar
    parser.parse("create calendar --name \"Zero\" --timezone America/New_York").execute(manager);
    parser.parse("use calendar --name \"Zero\"").execute(manager);

    // Try to create event series with zero occurrences
    InterfaceCommand createSeries = parser.parse(
        "create event \"Zero Series\" from 2023-12-01T10:00 to 2023-12-01T11:00 "
            + "repeats M for 0 times");
    CommandResult result = createSeries.execute(manager);

    assertFalse(result.isSuccess());
    assertTrue(result.getMessage().toLowerCase().contains("invalid"));
  }

  @Test
  public void testEventSeriesWithPastStartDate() {
    // Setup calendar
    parser.parse("create calendar --name \"Past\" --timezone America/New_York").execute(manager);
    parser.parse("use calendar --name \"Past\"").execute(manager);

    // Create event series with past start date (should still work)
    InterfaceCommand createSeries = parser.parse(
        "create event \"Past Series\" from 2020-12-01T10:00 to 2020-12-01T11:00 "
            + "repeats M for 3 times");
    CommandResult result = createSeries.execute(manager);

    assertTrue(result.isSuccess());

    // Verify events were created in the past
    InterfaceCalendar calendar = manager.getActiveCalendar();
    List<InterfaceEvent> events = calendar.getAllEvents();
    assertEquals(3, events.size());

    assertTrue(events.stream().allMatch(e -> e.getStart().getYear() == 2020));
  }

  @Test
  public void testEventSeriesUntilDateWithInvalidDate() {
    // Setup calendar
    parser.parse("create calendar --name \"InvalidUntil\" --timezone America/New_York")
        .execute(manager);
    parser.parse("use calendar --name \"InvalidUntil\"").execute(manager);

    // Try to create event series with invalid until date
    InterfaceCommand createSeries = parser.parse(
        "create event \"Invalid Until\" from 2023-12-01T10:00 to 2023-12-01T11:00 "
            + "repeats M until invalid-date");
    CommandResult result = createSeries.execute(manager);

    assertFalse(result.isSuccess());
    assertTrue(result.getMessage().toLowerCase().contains("date"));
  }

  @Test
  public void testEventSeriesWithUntilDateBeforeStart() {
    // Setup calendar
    parser.parse("create calendar --name \"EarlyUntil\" --timezone America/New_York")
        .execute(manager);
    parser.parse("use calendar --name \"EarlyUntil\"").execute(manager);

    // Try to create event series with until date before start date
    InterfaceCommand createSeries = parser.parse(
        "create event \"Early Until\" from 2023-12-15T10:00 to 2023-12-15T11:00 "
            + "repeats M until 2023-12-10");
    CommandResult result = createSeries.execute(manager);

    assertFalse(result.isSuccess());
    assertTrue(result.getMessage().toLowerCase().contains("until"));
  }

  @Test
  public void testEventSeriesWithLongDuration() {
    // Setup calendar
    parser.parse("create calendar --name \"LongDuration\" --timezone America/New_York")
        .execute(manager);
    parser.parse("use calendar --name \"LongDuration\"").execute(manager);

    // Create event series with long duration events
    InterfaceCommand createSeries = parser.parse(
        "create event \"Long Event\" from 2023-12-01T09:00 to 2023-12-01T17:00 "
            + "repeats MWF for 6 times");
    CommandResult result = createSeries.execute(manager);

    assertTrue(result.isSuccess());

    // Verify events have 8-hour duration
    InterfaceCalendar calendar = manager.getActiveCalendar();
    List<InterfaceEvent> events = calendar.getAllEvents();
    assertEquals(6, events.size());

    assertTrue(events.stream().allMatch(e -> {
      long duration = java.time.Duration.between(e.getStart(), e.getEnd()).toHours();
      return duration == 8;
    }));
  }
}