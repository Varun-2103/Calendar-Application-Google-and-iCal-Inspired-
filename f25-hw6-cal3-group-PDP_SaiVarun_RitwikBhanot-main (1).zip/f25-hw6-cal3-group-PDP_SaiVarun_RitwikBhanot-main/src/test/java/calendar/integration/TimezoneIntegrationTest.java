package calendar.integration;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import calendar.controller.CalendarController;
import calendar.controller.CommandParser;
import calendar.controller.CommandResult;
import calendar.controller.InterfaceCommand;
import calendar.model.CalendarManager;
import java.time.ZoneId;
import org.junit.Before;
import org.junit.Test;

/**
 * Integration tests for timezone support functionality.
 */
public class TimezoneIntegrationTest {

  private CalendarController controller;
  private CommandParser parser;
  private CalendarManager manager;

  /** Sets up test environment before each test. */
  @Before
  public void setUp() {
    manager = new CalendarManager();
    controller = new CalendarController(manager);
    parser = new CommandParser();
  }

  @Test
  public void testCreateCalendarWithValidTimezone() {
    InterfaceCommand command = parser.parse(
        "create calendar --name \"Work\" --timezone America/New_York");
    CommandResult result = command.execute(manager);

    assertTrue(result.isSuccess());
    assertTrue(manager.calendarExists("Work"));
    assertEquals(ZoneId.of("America/New_York"), manager.getCalendarTimezone("Work"));
  }

  @Test
  public void testCreateCalendarWithDifferentTimezones() {
    // Create calendars with different timezones
    InterfaceCommand command1 = parser.parse(
        "create calendar --name \"NY\" --timezone America/New_York");
    InterfaceCommand command2 = parser.parse(
        "create calendar --name \"London\" --timezone Europe/London");
    InterfaceCommand command3 = parser.parse(
        "create calendar --name \"Tokyo\" --timezone Asia/Tokyo");

    assertTrue(command1.execute(manager).isSuccess());
    assertTrue(command2.execute(manager).isSuccess());
    assertTrue(command3.execute(manager).isSuccess());

    assertEquals(ZoneId.of("America/New_York"), manager.getCalendarTimezone("NY"));
    assertEquals(ZoneId.of("Europe/London"), manager.getCalendarTimezone("London"));
    assertEquals(ZoneId.of("Asia/Tokyo"), manager.getCalendarTimezone("Tokyo"));
  }

  @Test
  public void testCreateCalendarWithInvalidTimezone() {
    InterfaceCommand command = parser.parse(
        "create calendar --name \"Invalid\" --timezone Invalid/Timezone");
    CommandResult result = command.execute(manager);

    assertFalse(result.isSuccess());
    assertTrue(result.getMessage().toLowerCase().contains("timezone"));
    assertFalse(manager.calendarExists("Invalid"));
  }

  @Test
  public void testEditCalendarTimezone() {
    // Create calendar
    InterfaceCommand createCommand = parser.parse(
        "create calendar --name \"Work\" --timezone America/New_York");
    createCommand.execute(manager);

    // Edit timezone
    InterfaceCommand editCommand = parser.parse(
        "edit calendar --name \"Work\" --property timezone America/Los_Angeles");
    CommandResult result = editCommand.execute(manager);

    assertTrue(result.isSuccess());
    assertEquals(ZoneId.of("America/Los_Angeles"), manager.getCalendarTimezone("Work"));
  }

  @Test
  public void testEditCalendarName() {
    // Create calendar
    InterfaceCommand createCommand = parser.parse(
        "create calendar --name \"OldName\" --timezone America/New_York");
    createCommand.execute(manager);

    // Edit name
    InterfaceCommand editCommand = parser.parse(
        "edit calendar --name \"OldName\" --property name \"NewName\"");
    CommandResult result = editCommand.execute(manager);

    assertTrue(result.isSuccess());
    assertFalse(manager.calendarExists("OldName"));
    assertTrue(manager.calendarExists("NewName"));
    assertEquals(ZoneId.of("America/New_York"), manager.getCalendarTimezone("NewName"));
  }

  @Test
  public void testUseCalendarWithTimezone() {
    // Create calendar
    InterfaceCommand createCommand = parser.parse(
        "create calendar --name \"Test\" --timezone Europe/Paris");
    createCommand.execute(manager);

    // Use calendar
    InterfaceCommand useCommand = parser.parse(
        "use calendar --name \"Test\"");
    CommandResult result = useCommand.execute(manager);

    assertTrue(result.isSuccess());
    assertTrue(manager.hasActiveCalendar());
    assertEquals("Test", manager.getActiveCalendarName());
    assertEquals(ZoneId.of("Europe/Paris"), manager.getActiveCalendarTimezone());
  }

  @Test
  public void testEventsInDifferentTimezones() {
    // Create NY calendar
    InterfaceCommand nyCommand = parser.parse(
        "create calendar --name \"NY\" --timezone America/New_York");
    nyCommand.execute(manager);
    parser.parse("use calendar --name \"NY\"").execute(manager);

    // Create event in NY
    InterfaceCommand nyEvent = parser.parse(
        "create event \"NY Meeting\" from 2023-12-01T10:00 to 2023-12-01T11:00");
    assertTrue(nyEvent.execute(manager).isSuccess());

    // Create London calendar
    InterfaceCommand londonCommand = parser.parse(
        "create calendar --name \"London\" --timezone Europe/London");
    londonCommand.execute(manager);
    parser.parse("use calendar --name \"London\"").execute(manager);

    // Create event in London
    InterfaceCommand londonEvent = parser.parse(
        "create event \"London Meeting\" from 2023-12-01T10:00 to 2023-12-01T11:00");
    assertTrue(londonEvent.execute(manager).isSuccess());

    // Both calendars should have events
    assertNotNull(manager.getCalendar("NY"));
    assertNotNull(manager.getCalendar("London"));
    assertFalse(manager.getCalendar("NY").getAllEvents().isEmpty());
    assertFalse(manager.getCalendar("London").getAllEvents().isEmpty());
  }

  @Test
  public void testTimezoneValidationEdgeCases() {
    // Test with various valid IANA timezones
    String[] validTimezones = {
        "UTC",
        "America/New_York",
        "Europe/London",
        "Asia/Tokyo",
        "Australia/Sydney",
        "Africa/Cairo",
        "America/Los_Angeles",
        "Europe/Paris",
        "Asia/Kolkata"
    };

    for (String timezone : validTimezones) {
      InterfaceCommand command = parser.parse(
          String.format("create calendar --name \"Cal_%s\" --timezone %s",
              timezone.replace("/", "_"), timezone));
      CommandResult result = command.execute(manager);
      assertTrue("Should create calendar with timezone: " + timezone, result.isSuccess());
    }
  }

  @Test
  public void testInvalidTimezoneFormats() {
    String[] invalidTimezones = {
        "Invalid/Timezone",
        "America/NonExistent",
        "Not/A/Timezone",
        "",
        "12345",
        "UTC+5",
        "GMT-8"
    };

    for (String timezone : invalidTimezones) {
      InterfaceCommand command = parser.parse(
          String.format("create calendar --name \"Invalid_%s\" --timezone %s",
              timezone.replace("/", "_").replace("+", "_"), timezone));
      CommandResult result = command.execute(manager);
      assertFalse("Should reject invalid timezone: " + timezone, result.isSuccess());
    }
  }

  @Test
  public void testCalendarTimezonePersistence() {
    // Create calendar
    InterfaceCommand createCommand = parser.parse(
        "create calendar --name \"Persistent\" --timezone Asia/Kolkata");
    createCommand.execute(manager);

    // Switch to another calendar
    parser.parse("create calendar --name \"Temp\" --timezone UTC").execute(manager);
    parser.parse("use calendar --name \"Temp\"").execute(manager);

    // Switch back - timezone should be preserved
    InterfaceCommand useCommand = parser.parse("use calendar --name \"Persistent\"");
    CommandResult result = useCommand.execute(manager);

    assertTrue(result.isSuccess());
    assertEquals(ZoneId.of("Asia/Kolkata"), manager.getActiveCalendarTimezone());
  }
}