package calendar.integration;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import calendar.controller.CommandParser;
import calendar.controller.CommandResult;
import calendar.controller.InterfaceCommand;
import calendar.model.CalendarManager;
import calendar.model.InterfaceCalendar;
import calendar.model.InterfaceEvent;
import java.util.List;
import org.junit.Before;
import org.junit.Test;

/**
 * Integration tests for event copying functionality between calendars.
 */
public class EventCopyingIntegrationTest {

  private CommandParser parser;
  private CalendarManager manager;

  /** Sets up test environment before each test. */
  @Before
  public void setUp() {
    manager = new CalendarManager();
    parser = new CommandParser();
  }

  @Test
  public void testCopySingleEventBetweenCalendars() {
    // Setup source calendar
    InterfaceCommand createSource = parser.parse(
        "create calendar --name \"Source\" --timezone America/New_York");
    createSource.execute(manager);
    parser.parse("use calendar --name \"Source\"").execute(manager);

    // Create event in source
    InterfaceCommand createEvent = parser.parse(
        "create event \"Team Meeting\" from 2023-12-01T10:00 to 2023-12-01T11:00");
    createEvent.execute(manager);

    // Create target calendar
    InterfaceCommand createTarget = parser.parse(
        "create calendar --name \"Target\" --timezone America/Los_Angeles");
    createTarget.execute(manager);

    // Copy event
    InterfaceCommand copyCommand = parser.parse(
        "copy event \"Team Meeting\" on 2023-12-01T10:00 --target Target to 2023-12-01T07:00");
    CommandResult result = copyCommand.execute(manager);

    System.out.println(
        "DEBUG: Copy command result: " + result.isSuccess() + " - " + result.getMessage());

    assertTrue(result.isSuccess());

    // Verify event exists in target
    InterfaceCalendar targetCalendar = manager.getCalendar("Target");
    List<InterfaceEvent> targetEvents = targetCalendar.getAllEvents();
    assertEquals(1, targetEvents.size());
    assertEquals("Team Meeting", targetEvents.get(0).getSubject());
  }

  @Test
  public void testCopyEventsOnSpecificDay() {
    // Setup source calendar with multiple events
    InterfaceCommand createSource = parser.parse(
        "create calendar --name \"Source\" --timezone America/New_York");
    createSource.execute(manager);
    parser.parse("use calendar --name \"Source\"").execute(manager);

    // Create multiple events on same day
    parser.parse("create event \"Morning Meeting\" from 2023-12-01T09:00 to 2023-12-01T10:00")
        .execute(manager);
    parser.parse("create event \"Lunch\" from 2023-12-01T12:00 to 2023-12-01T13:00")
        .execute(manager);
    parser.parse("create event \"Afternoon Sync\" from 2023-12-01T15:00 to 2023-12-01T16:00")
        .execute(manager);

    // Create target calendar
    InterfaceCommand createTarget = parser.parse(
        "create calendar --name \"Target\" --timezone America/Los_Angeles");
    createTarget.execute(manager);

    // Copy all events on specific day
    InterfaceCommand copyCommand = parser.parse(
        "copy events on 2023-12-01 --target Target to 2023-12-02");
    CommandResult result = copyCommand.execute(manager);

    assertTrue(result.isSuccess());

    // Verify all events were copied
    InterfaceCalendar targetCalendar = manager.getCalendar("Target");
    List<InterfaceEvent> targetEvents = targetCalendar.getAllEvents();
    assertEquals(3, targetEvents.size());
  }

  @Test
  public void testCopyEventsBetweenDateRanges() {
    // Setup source calendar with events across multiple days
    InterfaceCommand createSource = parser.parse(
        "create calendar --name \"Source\" --timezone America/New_York");
    createSource.execute(manager);
    parser.parse("use calendar --name \"Source\"").execute(manager);

    // Create events across different days
    parser.parse("create event \"Day1 Event\" from 2023-12-01T10:00 to 2023-12-01T11:00")
        .execute(manager);
    parser.parse("create event \"Day2 Event\" from 2023-12-02T10:00 to 2023-12-02T11:00")
        .execute(manager);
    parser.parse("create event \"Day3 Event\" from 2023-12-03T10:00 to 2023-12-03T11:00")
        .execute(manager);
    parser.parse("create event \"Day4 Event\" from 2023-12-04T10:00 to 2023-12-04T11:00")
        .execute(manager);

    // Create target calendar
    InterfaceCommand createTarget = parser.parse(
        "create calendar --name \"Target\" --timezone America/Los_Angeles");
    createTarget.execute(manager);

    // Copy events in date range
    InterfaceCommand copyCommand = parser.parse(
        "copy events between 2023-12-02 and 2023-12-03 --target Target to 2023-12-15");
    CommandResult result = copyCommand.execute(manager);

    assertTrue(result.isSuccess());

    // Verify only events in range were copied
    InterfaceCalendar targetCalendar = manager.getCalendar("Target");
    List<InterfaceEvent> targetEvents = targetCalendar.getAllEvents();
    assertEquals(2, targetEvents.size()); // Day2 and Day3 events
  }

  @Test
  public void testCopyEventWithinSameCalendar() {
    // Setup calendar
    InterfaceCommand createCal = parser.parse(
        "create calendar --name \"Work\" --timezone America/New_York");
    createCal.execute(manager);
    parser.parse("use calendar --name \"Work\"").execute(manager);

    // Create event
    InterfaceCommand createEvent = parser.parse(
        "create event \"Weekly Meeting\" from 2023-12-01T10:00 to 2023-12-01T11:00");
    createEvent.execute(manager);

    // Copy event to same calendar (different time)
    InterfaceCommand copyCommand = parser.parse(
        "copy event \"Weekly Meeting\" on 2023-12-01T10:00 --target Work to 2023-12-08T10:00");
    CommandResult result = copyCommand.execute(manager);

    assertTrue(result.isSuccess());

    // Verify both events exist
    InterfaceCalendar calendar = manager.getCalendar("Work");
    List<InterfaceEvent> events = calendar.getAllEvents();
    assertEquals(2, events.size());
  }

  @Test
  public void testCopyEventWithTimezoneConversion() {
    // Create NY calendar
    InterfaceCommand createNewYork = parser.parse(
        "create calendar --name \"NY\" --timezone America/New_York");
    createNewYork.execute(manager);
    parser.parse("use calendar --name \"NY\"").execute(manager);

    // Create event at 10 AM NY time
    InterfaceCommand createEvent = parser.parse(
        "create event \"NY Meeting\" from 2023-12-01T10:00 to 2023-12-01T11:00");
    createEvent.execute(manager);

    // Create London calendar
    InterfaceCommand createLondon = parser.parse(
        "create calendar --name \"London\" --timezone Europe/London");
    createLondon.execute(manager);

    // Copy event to London calendar (should convert timezone)
    InterfaceCommand copyCommand = parser.parse(
        "copy event \"NY Meeting\" on 2023-12-01T10:00 --target London to 2023-12-01T15:00");
    CommandResult result = copyCommand.execute(manager);

    assertTrue(result.isSuccess());

    // Verify event exists in London calendar
    InterfaceCalendar londonCalendar = manager.getCalendar("London");
    List<InterfaceEvent> londonEvents = londonCalendar.getAllEvents();
    assertEquals(1, londonEvents.size());
    assertEquals("NY Meeting", londonEvents.get(0).getSubject());
  }

  @Test
  public void testCopyNonExistentEvent() {
    // Setup source calendar
    parser.parse("create calendar --name \"Source\" --timezone America/New_York").execute(manager);
    parser.parse("use calendar --name \"Source\"").execute(manager);
    parser.parse("create calendar --name \"Target\" --timezone America/Los_Angeles")
        .execute(manager);

    // Try to copy non-existent event
    InterfaceCommand copyCommand = parser.parse(
        "copy event \"NonExistent\" on 2023-12-01T10:00 --target Target to 2023-12-01T07:00");
    CommandResult result = copyCommand.execute(manager);

    assertFalse(result.isSuccess());
    assertTrue(result.getMessage().toLowerCase().contains("not found"));
  }

  @Test
  public void testCopyToNonExistentCalendar() {
    // Setup source calendar
    parser.parse("create calendar --name \"Source\" --timezone America/New_York").execute(manager);
    parser.parse("use calendar --name \"Source\"").execute(manager);

    // Create event
    parser.parse("create event \"Test Event\" from 2023-12-01T10:00 to 2023-12-01T11:00")
        .execute(manager);

    // Try to copy to non-existent calendar
    InterfaceCommand copyCommand = parser.parse(
        "copy event \"Test Event\" on 2023-12-01T10:00 --target NonExistent to 2023-12-01T07:00");
    CommandResult result = copyCommand.execute(manager);

    assertFalse(result.isSuccess());
    assertTrue(result.getMessage().toLowerCase().contains("not found"));
  }

  @Test
  public void testCopyEventWithConflicts() {
    // Setup source calendar
    parser.parse("create calendar --name \"Source\" --timezone America/New_York").execute(manager);
    parser.parse("use calendar --name \"Source\"").execute(manager);

    // Create event
    parser.parse("create event \"Meeting\" from 2023-12-01T10:00 to 2023-12-01T11:00")
        .execute(manager);

    // Setup target calendar with conflicting event
    parser.parse("create calendar --name \"Target\" --timezone America/New_York").execute(manager);
    parser.parse("use calendar --name \"Target\"").execute(manager);
    parser.parse("create event \"Meeting\" from 2023-12-01T10:00 to 2023-12-01T11:00")
        .execute(manager);

    // Try to copy conflicting event
    InterfaceCommand copyCommand = parser.parse(
        "copy event \"Meeting\" on 2023-12-01T10:00 --target Target to 2023-12-01T10:00");
    CommandResult result = copyCommand.execute(manager);

    assertFalse(result.isSuccess());
    assertTrue(result.getMessage().toLowerCase().contains("conflict"));
  }

  @Test
  public void testCopyEventsFromEmptyCalendar() {
    // Setup empty source calendar
    parser.parse("create calendar --name \"EmptySource\" --timezone America/New_York")
        .execute(manager);
    parser.parse("use calendar --name \"EmptySource\"").execute(manager);
    parser.parse("create calendar --name \"Target\" --timezone America/Los_Angeles")
        .execute(manager);

    // Try to copy from empty calendar
    InterfaceCommand copyCommand = parser.parse(
        "copy events on 2023-12-01 --target Target to 2023-12-02");
    CommandResult result = copyCommand.execute(manager);

    assertTrue(result.isSuccess()); // Should succeed but copy no events

    // Verify target is still empty
    InterfaceCalendar targetCalendar = manager.getCalendar("Target");
    assertTrue(targetCalendar.getAllEvents().isEmpty());
  }

  @Test
  public void testCopyEventsWithInvalidDateRange() {
    // Setup calendars
    parser.parse("create calendar --name \"Source\" --timezone America/New_York").execute(manager);
    parser.parse("use calendar --name \"Source\"").execute(manager);
    parser.parse("create calendar --name \"Target\" --timezone America/Los_Angeles")
        .execute(manager);

    // Try to copy with invalid date range (end before start)
    InterfaceCommand copyCommand = parser.parse(
        "copy events between 2023-12-05 and 2023-12-01 --target Target to 2023-12-10");
    CommandResult result = copyCommand.execute(manager);

    assertFalse(result.isSuccess());
    assertTrue(result.getMessage().toLowerCase().contains("invalid"));
  }

  @Test
  public void testCopyEventSeries() {
    // Setup source calendar with event series
    parser.parse("create calendar --name \"Source\" --timezone America/New_York").execute(manager);
    parser.parse("use calendar --name \"Source\"").execute(manager);

    // Create event series
    InterfaceCommand createSeries = parser.parse(
        "create event \"Daily Standup\" from 2023-12-01T09:00 to 2023-12-01T09:30 "
            + "repeats MTWRF for 5 times");
    createSeries.execute(manager);

    // Create target calendar
    parser.parse("create calendar --name \"Target\" --timezone America/Los_Angeles")
        .execute(manager);

    // Copy events from date range that includes series events
    InterfaceCommand copyCommand = parser.parse(
        "copy events between 2023-12-01 and 2023-12-03 --target Target "
            + "to 2023-12-15");
    CommandResult result = copyCommand.execute(manager);

    assertTrue(result.isSuccess());

    // Verify series events were copied
    InterfaceCalendar targetCalendar = manager.getCalendar("Target");
    List<InterfaceEvent> targetEvents = targetCalendar.getAllEvents();
    assertFalse(targetEvents.isEmpty());
    // Should have copied events from Dec 1-3 (3 events if Mon-Wed)
  }
}