package calendar.integration;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import calendar.controller.CommandParser;
import calendar.controller.CommandResult;
import calendar.controller.InterfaceCommand;
import calendar.model.CalendarManager;
import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import org.junit.Before;
import org.junit.Test;

/**
 * Integration tests for print commands with proper output verification.
 */
public class PrintCommandsIntegrationTest {

  private CommandParser parser;
  private CalendarManager manager;
  private ByteArrayOutputStream outputStream;

  /** Sets up test environment before each test. */
  @Before
  public void setUp() {
    manager = new CalendarManager();
    parser = new CommandParser();
    outputStream = new ByteArrayOutputStream();
    System.setOut(new PrintStream(outputStream));
  }

  @Test
  public void testPrintEventsOnSpecificDate() {
    // Setup calendar with events
    parser.parse("create calendar --name \"Work\" --timezone America/New_York").execute(manager);
    parser.parse("use calendar --name \"Work\"").execute(manager);
    parser.parse("create event \"Morning Meeting\" from 2023-12-01T09:00 to 2023-12-01T10:00")
        .execute(manager);
    parser.parse("create event \"Lunch Break\" from 2023-12-01T12:00 to 2023-12-01T13:00")
        .execute(manager);
    parser.parse("create event \"Afternoon Sync\" from 2023-12-01T15:00 to 2023-12-01T16:00")
        .execute(manager);

    // Print events on specific date
    InterfaceCommand printCommand = parser.parse("print events on 2023-12-01");
    CommandResult result = printCommand.execute(manager);

    assertTrue(result.isSuccess());
    String output = outputStream.toString();

    // Verify all events are listed
    assertTrue(output.contains("Morning Meeting"));
    assertTrue(output.contains("Lunch Break"));
    assertTrue(output.contains("Afternoon Sync"));

    // Verify time information is included
    assertTrue(output.contains("09:00"));
    assertTrue(output.contains("12:00"));
    assertTrue(output.contains("15:00"));
  }

  @Test
  public void testPrintEventsOnDateWithNoEvents() {
    // Setup calendar
    parser.parse("create calendar --name \"Empty\" --timezone America/New_York").execute(manager);
    parser.parse("use calendar --name \"Empty\"").execute(manager);

    // Print events on date with no events
    InterfaceCommand printCommand = parser.parse("print events on 2023-12-01");
    CommandResult result = printCommand.execute(manager);

    assertTrue(result.isSuccess());
    String output = outputStream.toString();

    // Should indicate no events found
    assertTrue(output.toLowerCase().contains("no events")
        || output.toLowerCase().contains("no scheduled"));
  }

  @Test
  public void testPrintEventsFromDateRange() {
    // Setup calendar with events across multiple days
    parser.parse("create calendar --name \"Work\" --timezone America/New_York").execute(manager);
    parser.parse("use calendar --name \"Work\"").execute(manager);
    parser.parse("create event \"Day1 Meeting\" from 2023-12-01T10:00 to 2023-12-01T11:00")
        .execute(manager);
    parser.parse("create event \"Day2 Workshop\" from 2023-12-02T14:00 to 2023-12-02T16:00")
        .execute(manager);
    parser.parse("create event \"Day3 Conference\" from 2023-12-03T09:00 to 2023-12-03T17:00")
        .execute(manager);
    parser.parse("create event \"Day4 Review\" from 2023-12-04T15:00 to 2023-12-04T16:00")
        .execute(manager);

    // Print events in date range
    InterfaceCommand printCommand = parser.parse(
        "print events from 2023-12-01T10:00 to 2023-12-03T20:00");
    CommandResult result = printCommand.execute(manager);

    assertTrue(result.isSuccess());
    String output = outputStream.toString();

    // Should include events within range
    assertTrue(output.contains("Day1 Meeting"));
    assertTrue(output.contains("Day2 Workshop"));
    assertTrue(output.contains("Day3 Conference"));

    // Should not include events outside range
    assertFalse(output.contains("Day4 Review"));

    // Verify format includes start and end dates
    assertTrue(output.contains("starting on"));
    assertTrue(output.contains("ending on"));
  }

  @Test
  public void testPrintEventsWithPartialOverlap() {
    // Setup calendar with events
    parser.parse("create calendar --name \"Work\" --timezone America/New_York").execute(manager);
    parser.parse("use calendar --name \"Work\"").execute(manager);
    parser.parse("create event \"Long Event\" from 2023-12-01T08:00 to 2023-12-01T18:00")
        .execute(manager);
    parser.parse("create event \"Short Event\" from 2023-12-01T10:00 to 2023-12-01T11:00")
        .execute(manager);

    // Print events in range that partially overlaps
    InterfaceCommand printCommand = parser.parse(
        "print events from 2023-12-01T09:00 to 2023-12-01T12:00");
    CommandResult result = printCommand.execute(manager);

    assertTrue(result.isSuccess());
    String output = outputStream.toString();

    // Both events should be included (they overlap with the range)
    assertTrue(output.contains("Long Event"));
    assertTrue(output.contains("Short Event"));
  }

  @Test
  public void testPrintEventsWithAllDayEvents() {
    // Setup calendar with all-day events
    parser.parse("create calendar --name \"Personal\" --timezone America/New_York")
        .execute(manager);
    parser.parse("use calendar --name \"Personal\"").execute(manager);
    parser.parse("create event \"Holiday\" on 2023-12-25").execute(manager);
    parser.parse("create event \"Weekend Trip\" on 2023-12-23").execute(manager);

    // Print events on date with all-day events
    InterfaceCommand printCommand = parser.parse("print events on 2023-12-25");
    CommandResult result = printCommand.execute(manager);

    assertTrue(result.isSuccess());
    String output = outputStream.toString();

    // Should include all-day events
    assertTrue(output.contains("Holiday"));

    // All-day events should show 8am-5pm or similar
    assertTrue(output.contains("08:00") || output.contains("8:00"));
  }

  @Test
  public void testPrintEventsWithMultiDayEvents() {
    // Setup calendar with multi-day event
    parser.parse("create calendar --name \"Work\" --timezone America/New_York").execute(manager);
    parser.parse("use calendar --name \"Work\"").execute(manager);
    parser.parse("create event \"Conference\" from 2023-12-01T09:00 to 2023-12-03T17:00")
        .execute(manager);

    // Print events on first day
    InterfaceCommand printCommand1 = parser.parse("print events on 2023-12-01");
    CommandResult result1 = printCommand1.execute(manager);
    assertTrue(result1.isSuccess());
    String output1 = outputStream.toString();
    assertTrue(output1.contains("Conference"));

    // Print events on middle day
    outputStream.reset();
    InterfaceCommand printCommand2 = parser.parse("print events on 2023-12-02");
    CommandResult result2 = printCommand2.execute(manager);
    assertTrue(result2.isSuccess());
    String output2 = outputStream.toString();
    assertTrue(output2.contains("Conference"));

    // Print events on last day
    outputStream.reset();
    InterfaceCommand printCommand3 = parser.parse("print events on 2023-12-03");
    CommandResult result3 = printCommand3.execute(manager);
    assertTrue(result3.isSuccess());
    String output3 = outputStream.toString();
    assertTrue(output3.contains("Conference"));
  }

  @Test
  public void testPrintEventsWithEventSeries() {
    // Setup calendar with event series
    parser.parse("create calendar --name \"Work\" --timezone America/New_York").execute(manager);
    parser.parse("use calendar --name \"Work\"").execute(manager);
    parser.parse(
        "create event \"Daily Standup\" from 2023-12-01T09:00 to 2023-12-01T09:30 "
            + "repeats MTWRF for 5 times")
        .execute(manager);

    // Print events on different days
    InterfaceCommand printCommand = parser.parse("print events on 2023-12-01");
    CommandResult result = printCommand.execute(manager);

    assertTrue(result.isSuccess());
    String output = outputStream.toString();

    // Should include the series event for that day
    assertTrue(output.contains("Daily Standup"));
    assertTrue(output.contains("09:00"));
  }

  @Test
  public void testPrintEventsWithLocations() {
    // Setup calendar with events that have locations
    parser.parse("create calendar --name \"Work\" --timezone America/New_York").execute(manager);
    parser.parse("use calendar --name \"Work\"").execute(manager);
    parser.parse("create event \"Board Meeting\" from 2023-12-01T14:00 to 2023-12-01T16:00")
        .execute(manager);
    // Note: The current implementation doesn't support setting location in create event command
    // So we'll test with events that might have locations set through editing

    // Print events
    InterfaceCommand printCommand = parser.parse("print events on 2023-12-01");
    CommandResult result = printCommand.execute(manager);

    assertTrue(result.isSuccess());
    String output = outputStream.toString();
    assertTrue(output.contains("Board Meeting"));
  }

  @Test
  public void testPrintEventsWithPrivateEvents() {
    // Setup calendar with private events
    parser.parse("create calendar --name \"Personal\" --timezone America/New_York")
        .execute(manager);
    parser.parse("use calendar --name \"Personal\"").execute(manager);
    parser.parse("create event \"Doctor Appointment\" from 2023-12-01T10:00 to 2023-12-01T11:00")
        .execute(manager);

    // Print events
    InterfaceCommand printCommand = parser.parse("print events on 2023-12-01");
    CommandResult result = printCommand.execute(manager);

    assertTrue(result.isSuccess());
    String output = outputStream.toString();
    assertTrue(output.contains("Doctor Appointment"));
  }

  @Test
  public void testPrintEventsWithDifferentTimezones() {
    // Setup calendar with different timezone
    parser.parse("create calendar --name \"Europe\" --timezone Europe/London").execute(manager);
    parser.parse("use calendar --name \"Europe\"").execute(manager);
    parser.parse("create event \"London Meeting\" from 2023-12-01T15:00 to 2023-12-01T16:00")
        .execute(manager);

    // Print events
    InterfaceCommand printCommand = parser.parse("print events on 2023-12-01");
    CommandResult result = printCommand.execute(manager);

    assertTrue(result.isSuccess());
    String output = outputStream.toString();
    assertTrue(output.contains("London Meeting"));
    // Time should be displayed in the calendar's timezone (15:00 London time)
    assertTrue(output.contains("15:00"));
  }

  @Test
  public void testPrintEventsWithoutActiveCalendar() {
    // Try to print without setting active calendar
    InterfaceCommand printCommand = parser.parse("print events on 2023-12-01");
    CommandResult result = printCommand.execute(manager);

    assertFalse(result.isSuccess());
    assertTrue(result.getMessage().toLowerCase().contains("calendar"));
  }

  @Test
  public void testPrintEventsWithInvalidDate() {
    // Setup calendar
    parser.parse("create calendar --name \"Test\" --timezone America/New_York").execute(manager);
    parser.parse("use calendar --name \"Test\"").execute(manager);

    // Try to print with invalid date
    InterfaceCommand printCommand = parser.parse("print events on invalid-date");
    CommandResult result = printCommand.execute(manager);

    assertFalse(result.isSuccess());
    assertTrue(result.getMessage().toLowerCase().contains("date"));
  }

  @Test
  public void testPrintEventsWithInvalidDateRange() {
    // Setup calendar
    parser.parse("create calendar --name \"Test\" --timezone America/New_York").execute(manager);
    parser.parse("use calendar --name \"Test\"").execute(manager);

    // Try to print with invalid date range (end before start)
    InterfaceCommand printCommand = parser.parse(
        "print events from 2023-12-05T10:00 to 2023-12-01T10:00");
    CommandResult result = printCommand.execute(manager);

    assertFalse(result.isSuccess());
    assertTrue(result.getMessage().toLowerCase().contains("invalid")
        || result.getMessage().toLowerCase().contains("range"));
  }

  @Test
  public void testPrintEventsWithEmptyCalendar() {
    // Setup empty calendar
    parser.parse("create calendar --name \"Empty\" --timezone America/New_York").execute(manager);
    parser.parse("use calendar --name \"Empty\"").execute(manager);

    // Print events
    InterfaceCommand printCommand = parser.parse("print events on 2023-12-01");
    CommandResult result = printCommand.execute(manager);

    assertTrue(result.isSuccess());
    String output = outputStream.toString();

    // Should indicate no events
    assertTrue(output.toLowerCase().contains("no events")
        || output.toLowerCase().contains("no scheduled"));
  }

  @Test
  public void testPrintEventsInDateRangeWithNoEvents() {
    // Setup calendar with events outside the range
    parser.parse("create calendar --name \"Work\" --timezone America/New_York").execute(manager);
    parser.parse("use calendar --name \"Work\"").execute(manager);
    parser.parse("create event \"Other Event\" from 2023-12-05T10:00 to 2023-12-05T11:00")
        .execute(manager);

    // Print events in range with no events
    InterfaceCommand printCommand = parser.parse(
        "print events from 2023-12-01T10:00 to 2023-12-03T10:00");
    CommandResult result = printCommand.execute(manager);

    assertTrue(result.isSuccess());
    String output = outputStream.toString();

    // Should indicate no events in range
    assertTrue(output.toLowerCase().contains("no events")
        || output.toLowerCase().contains("no scheduled"));
  }
}