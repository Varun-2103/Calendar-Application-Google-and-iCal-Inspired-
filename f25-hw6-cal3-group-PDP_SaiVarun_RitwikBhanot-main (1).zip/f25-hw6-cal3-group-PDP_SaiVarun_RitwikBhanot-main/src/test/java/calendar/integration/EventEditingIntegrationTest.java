package calendar.integration;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import calendar.controller.CommandParser;
import calendar.controller.CommandResult;
import calendar.controller.InterfaceCommand;
import calendar.model.CalendarManager;
import calendar.model.InterfaceCalendar;
import calendar.model.InterfaceEvent;
import java.util.List;
import org.junit.Before;
import org.junit.Test;

/**
 * Integration tests for event editing functionality with correct command syntax from README.
 */
public class EventEditingIntegrationTest {

  private CommandParser parser;
  private CalendarManager manager;

  /** Sets up test environment before each test. */
  @Before
  public void setUp() {
    manager = new CalendarManager();
    parser = new CommandParser();
  }

  @Test
  public void testEditSingleEvent() {
    // Setup calendar with event
    parser.parse("create calendar --name \"Work\" --timezone America/New_York").execute(manager);
    parser.parse("use calendar --name \"Work\"").execute(manager);
    parser.parse("create event \"Team Meeting\" from 2023-12-01T10:00 to 2023-12-01T11:00")
        .execute(manager);

    // Edit single event subject
    InterfaceCommand editCommand = parser.parse(
        "edit event subject \"Team Meeting\" from 2023-12-01T10:00 to 2023-12-01T11:00 "
            + "with \"Updated Meeting\"");
    CommandResult result = editCommand.execute(manager);

    assertTrue(result.isSuccess());

    // Verify event was edited
    InterfaceCalendar calendar = manager.getActiveCalendar();
    List<InterfaceEvent> events = calendar.getAllEvents();
    assertEquals(1, events.size());
    assertEquals("Updated Meeting", events.get(0).getSubject());
  }

  @Test
  public void testEditSingleEventLocation() {
    // Setup calendar with event
    parser.parse("create calendar --name \"Work\" --timezone America/New_York").execute(manager);
    parser.parse("use calendar --name \"Work\"").execute(manager);
    parser.parse("create event \"Conference\" from 2023-12-01T14:00 to 2023-12-01T16:00")
        .execute(manager);

    // Edit event location
    InterfaceCommand editCommand = parser.parse(
        "edit event location \"Conference\" from 2023-12-01T14:00 to 2023-12-01T16:00 "
            + "with \"Room 101\"");
    CommandResult result = editCommand.execute(manager);

    assertTrue(result.isSuccess());

    // Verify location was updated
    InterfaceCalendar calendar = manager.getActiveCalendar();
    List<InterfaceEvent> events = calendar.getAllEvents();
    assertEquals(1, events.size());
    assertEquals("Room 101", events.get(0).getLocation());
  }

  @Test
  public void testEditSingleEventStartTime() {
    // Setup calendar with event
    parser.parse("create calendar --name \"Work\" --timezone America/New_York").execute(manager);
    parser.parse("use calendar --name \"Work\"").execute(manager);
    parser.parse("create event \"Meeting\" from 2023-12-01T10:00 to 2023-12-01T11:00")
        .execute(manager);

    // Edit event start time
    InterfaceCommand editCommand = parser.parse(
        "edit event start \"Meeting\" from 2023-12-01T10:00 to 2023-12-01T11:00 "
            + "with 2023-12-01T09:30");
    CommandResult result = editCommand.execute(manager);

    assertTrue(result.isSuccess());

    // Verify start time was updated
    InterfaceCalendar calendar = manager.getActiveCalendar();
    List<InterfaceEvent> events = calendar.getAllEvents();
    assertEquals(1, events.size());
    assertEquals(9, events.get(0).getStart().getHour());
    assertEquals(30, events.get(0).getStart().getMinute());
  }

  @Test
  public void testEditSingleEventEndTime() {
    // Setup calendar with event
    parser.parse("create calendar --name \"Work\" --timezone America/New_York").execute(manager);
    parser.parse("use calendar --name \"Work\"").execute(manager);
    parser.parse("create event \"Meeting\" from 2023-12-01T10:00 to 2023-12-01T11:00")
        .execute(manager);

    // Edit event end time
    InterfaceCommand editCommand = parser.parse(
        "edit event end \"Meeting\" from 2023-12-01T10:00 to 2023-12-01T11:00 "
            + "with 2023-12-01T12:00");
    CommandResult result = editCommand.execute(manager);

    assertTrue(result.isSuccess());

    // Verify end time was updated
    InterfaceCalendar calendar = manager.getActiveCalendar();
    List<InterfaceEvent> events = calendar.getAllEvents();
    assertEquals(1, events.size());
    assertEquals(12, events.get(0).getEnd().getHour());
    assertEquals(0, events.get(0).getEnd().getMinute());
  }

  @Test
  public void testEditSingleEventDescription() {
    // Setup calendar with event
    parser.parse("create calendar --name \"Work\" --timezone America/New_York").execute(manager);
    parser.parse("use calendar --name \"Work\"").execute(manager);
    parser.parse("create event \"Meeting\" from 2023-12-01T10:00 to 2023-12-01T11:00")
        .execute(manager);

    // Edit event description
    InterfaceCommand editCommand = parser.parse(
        "edit event description \"Meeting\" from 2023-12-01T10:00 to 2023-12-01T11:00 "
            + "with \"Weekly team sync\"");
    CommandResult result = editCommand.execute(manager);

    assertTrue(result.isSuccess());

    // Verify description was updated
    InterfaceCalendar calendar = manager.getActiveCalendar();
    List<InterfaceEvent> events = calendar.getAllEvents();
    assertEquals(1, events.size());
    assertEquals("Weekly team sync", events.get(0).getDescription());
  }

  @Test
  public void testEditSingleEventStatus() {
    // Setup calendar with event
    parser.parse("create calendar --name \"Work\" --timezone America/New_York").execute(manager);
    parser.parse("use calendar --name \"Work\"").execute(manager);
    parser.parse("create event \"Meeting\" from 2023-12-01T10:00 to 2023-12-01T11:00")
        .execute(manager);

    // Edit event status to private
    InterfaceCommand editCommand = parser.parse(
        "edit event status \"Meeting\" from 2023-12-01T10:00 to 2023-12-01T11:00 "
            + "with private");
    CommandResult result = editCommand.execute(manager);

    assertTrue(result.isSuccess());

    // Verify status was updated
    InterfaceCalendar calendar = manager.getActiveCalendar();
    List<InterfaceEvent> events = calendar.getAllEvents();
    assertEquals(1, events.size());
    assertEquals("private", events.get(0).getStatus());
  }

  @Test
  public void testEditEventsFromSeries() {
    // Setup calendar with event series
    parser.parse("create calendar --name \"Work\" --timezone America/New_York").execute(manager);
    parser.parse("use calendar --name \"Work\"").execute(manager);
    parser.parse(
        "create event \"Daily Standup\" from 2023-12-01T09:00 to 2023-12-01T09:30 "
            + "repeats MWF for 5 times")
        .execute(manager);

    // Edit events from specific point forward
    InterfaceCommand editCommand = parser.parse(
        "edit events subject \"Daily Standup\" from 2023-12-06T09:00 "
            + "with \"Updated Standup\"");
    CommandResult result = editCommand.execute(manager);

    assertTrue(result.isSuccess());

    // Verify events from that point were edited
    InterfaceCalendar calendar = manager.getActiveCalendar();
    List<InterfaceEvent> events = calendar.getAllEvents();
    assertEquals(5, events.size());

    // Count original vs updated events
    long originalCount =
        events.stream().filter(e -> e.getSubject().equals("Daily Standup")).count();
    long updatedCount =
        events.stream().filter(e -> e.getSubject().equals("Updated Standup")).count();

    assertEquals(2, originalCount); // First 2 events should remain unchanged
    assertEquals(3, updatedCount); // Last 3 events should be updated
  }

  @Test
  public void testEditEntireSeries() {
    // Setup calendar with event series
    parser.parse("create calendar --name \"Work\" --timezone America/New_York").execute(manager);
    parser.parse("use calendar --name \"Work\"").execute(manager);
    parser.parse(
        "create event \"Weekly Review\" from 2023-12-01T15:00 to 2023-12-01T16:00 "
            + "repeats F for 4 times")
        .execute(manager);

    // Edit entire series
    InterfaceCommand editCommand = parser.parse(
        "edit series subject \"Weekly Review\" from 2023-12-01T15:00 "
            + "with \"Monthly Review\"");
    CommandResult result = editCommand.execute(manager);

    assertTrue(result.isSuccess());

    // Verify all events in series were edited
    InterfaceCalendar calendar = manager.getActiveCalendar();
    List<InterfaceEvent> events = calendar.getAllEvents();
    assertEquals(4, events.size());

    // All events should have updated subject
    assertTrue(events.stream().allMatch(e -> e.getSubject().equals("Monthly Review")));
  }

  @Test
  public void testEditSeriesWithDifferentProperties() {
    // Setup calendar with event series
    parser.parse("create calendar --name \"Work\" --timezone America/New_York").execute(manager);
    parser.parse("use calendar --name \"Work\"").execute(manager);
    parser.parse(
        "create event \"Team Sync\" from 2023-12-01T10:00 to 2023-12-01T10:30 "
            + "repeats MTWRF for 5 times")
        .execute(manager);

    // Edit series location
    InterfaceCommand editLocation = parser.parse(
        "edit series location \"Team Sync\" from 2023-12-01T10:00 "
            + "with \"Conference Room\"");
    CommandResult result1 = editLocation.execute(manager);
    assertTrue(result1.isSuccess());

    // Edit series description
    InterfaceCommand editDescription = parser.parse(
        "edit series description \"Team Sync\" from 2023-12-01T10:00 "
            + "with \"Daily team synchronization\"");
    CommandResult result2 = editDescription.execute(manager);
    assertTrue(result2.isSuccess());

    // Verify all events were updated
    InterfaceCalendar calendar = manager.getActiveCalendar();
    List<InterfaceEvent> events = calendar.getAllEvents();
    assertEquals(5, events.size());

    assertTrue(events.stream().allMatch(e -> e.getLocation().equals("Conference Room")));
    assertTrue(
        events.stream().allMatch(e -> e.getDescription().equals("Daily team synchronization")));
  }

  @Test
  public void testEditEventWithConflictingTime() {
    // Setup calendar with two events
    parser.parse("create calendar --name \"Work\" --timezone America/New_York").execute(manager);
    parser.parse("use calendar --name \"Work\"").execute(manager);
    parser.parse("create event \"Meeting1\" from 2023-12-01T10:00 to 2023-12-01T11:00")
        .execute(manager);
    parser.parse("create event \"Meeting2\" from 2023-12-01T11:00 to 2023-12-01T12:00")
        .execute(manager);

    // Try to edit Meeting1 to conflict with Meeting2
    InterfaceCommand editCommand = parser.parse(
        "edit event start \"Meeting1\" from 2023-12-01T10:00 to 2023-12-01T11:00 "
            + "with 2023-12-01T11:30");
    CommandResult result = editCommand.execute(manager);

    // Should fail due to conflict
    assertFalse(result.isSuccess());
    assertTrue(result.getMessage().toLowerCase().contains("conflict"));
  }

  @Test
  public void testEditNonExistentEvent() {
    // Setup calendar
    parser.parse("create calendar --name \"Work\" --timezone America/New_York").execute(manager);
    parser.parse("use calendar --name \"Work\"").execute(manager);

    // Try to edit non-existent event
    InterfaceCommand editCommand = parser.parse(
        "edit event subject \"NonExistent\" from 2023-12-01T10:00 to 2023-12-01T11:00 "
            + "with \"New Name\"");
    CommandResult result = editCommand.execute(manager);

    assertFalse(result.isSuccess());
    assertTrue(result.getMessage().toLowerCase().contains("not found"));
  }

  @Test
  public void testEditEventWithoutActiveCalendar() {
    // Try to edit without setting active calendar
    InterfaceCommand editCommand = parser.parse(
        "edit event subject \"Meeting\" from 2023-12-01T10:00 to 2023-12-01T11:00 "
            + "with \"New Meeting\"");
    CommandResult result = editCommand.execute(manager);

    assertFalse(result.isSuccess());
    assertTrue(result.getMessage().toLowerCase().contains("calendar"));
  }

  @Test
  public void testEditEventWithInvalidProperty() {
    // Setup calendar with event
    parser.parse("create calendar --name \"Work\" --timezone America/New_York").execute(manager);
    parser.parse("use calendar --name \"Work\"").execute(manager);
    parser.parse("create event \"Meeting\" from 2023-12-01T10:00 to 2023-12-01T11:00")
        .execute(manager);

    // Try to edit with invalid property
    InterfaceCommand editCommand = parser.parse(
        "edit event invalid \"Meeting\" from 2023-12-01T10:00 to 2023-12-01T11:00 "
            + "with \"value\"");
    CommandResult result = editCommand.execute(manager);

    assertFalse(result.isSuccess());
    assertTrue(result.getMessage().toLowerCase().contains("property"));
  }

  @Test
  public void testEditEventWithInvalidDateTime() {
    // Setup calendar with event
    parser.parse("create calendar --name \"Work\" --timezone America/New_York").execute(manager);
    parser.parse("use calendar --name \"Work\"").execute(manager);
    parser.parse("create event \"Meeting\" from 2023-12-01T10:00 to 2023-12-01T11:00")
        .execute(manager);

    // Try to edit with invalid datetime
    InterfaceCommand editCommand = parser.parse(
        "edit event start \"Meeting\" from 2023-12-01T10:00 to 2023-12-01T11:00 "
            + "with invalid-datetime");
    CommandResult result = editCommand.execute(manager);

    assertFalse(result.isSuccess());
    assertTrue(result.getMessage().toLowerCase().contains("date")
        || result.getMessage().toLowerCase().contains("time"));
  }

  @Test
  public void testEditAllDayEvent() {
    // Setup calendar with all-day event
    parser.parse("create calendar --name \"Personal\" --timezone America/New_York")
        .execute(manager);
    parser.parse("use calendar --name \"Personal\"").execute(manager);
    parser.parse("create event \"Holiday\" on 2023-12-25").execute(manager);

    // Edit all-day event subject
    InterfaceCommand editCommand = parser.parse(
        "edit event subject \"Holiday\" from 2023-12-25T08:00 to 2023-12-25T17:00 "
            + "with \"Christmas Holiday\"");
    CommandResult result = editCommand.execute(manager);

    assertTrue(result.isSuccess());

    // Verify event was edited
    InterfaceCalendar calendar = manager.getActiveCalendar();
    List<InterfaceEvent> events = calendar.getAllEvents();
    assertEquals(1, events.size());
    assertEquals("Christmas Holiday", events.get(0).getSubject());
    // Should still be all-day (8am-5pm)
    assertEquals(8, events.get(0).getStart().getHour());
    assertEquals(17, events.get(0).getEnd().getHour());
  }

  @Test
  public void testEditMultiDayEvent() {
    // Setup calendar with multi-day event
    parser.parse("create calendar --name \"Work\" --timezone America/New_York").execute(manager);
    parser.parse("use calendar --name \"Work\"").execute(manager);
    parser.parse("create event \"Conference\" from 2023-12-01T09:00 to 2023-12-03T17:00")
        .execute(manager);

    // Edit multi-day event location
    InterfaceCommand editCommand = parser.parse(
        "edit event location \"Conference\" from 2023-12-01T09:00 to 2023-12-03T17:00 "
            + "with \"Convention Center\"");
    CommandResult result = editCommand.execute(manager);

    assertTrue(result.isSuccess());

    // Verify location was updated
    InterfaceCalendar calendar = manager.getActiveCalendar();
    List<InterfaceEvent> events = calendar.getAllEvents();
    assertEquals(1, events.size());
    assertEquals("Convention Center", events.get(0).getLocation());
  }
}