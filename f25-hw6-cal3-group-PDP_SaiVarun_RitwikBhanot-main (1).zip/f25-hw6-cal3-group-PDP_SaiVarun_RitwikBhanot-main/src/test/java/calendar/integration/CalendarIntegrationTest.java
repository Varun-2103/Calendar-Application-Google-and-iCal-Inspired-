package calendar.integration;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import calendar.controller.CalendarController;
import calendar.controller.CommandParser;
import calendar.controller.CommandResult;
import calendar.controller.InterfaceCommand;
import calendar.model.Calendar;
import calendar.model.CalendarManager;
import calendar.model.Event;
import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.time.LocalDateTime;
import java.util.List;
import org.junit.Before;
import org.junit.Test;

/**
 * Integration tests for complete calendar workflows.
 */
public class CalendarIntegrationTest {

  private CalendarController controller;
  private CommandParser parser;
  private CalendarManager manager;
  private ByteArrayOutputStream outputStream;

  /**
   * Sets up test environment before each test.
   */
  @Before
  public void setUp() {
    manager = new CalendarManager();
    controller = new CalendarController(manager);
    parser = new CommandParser();
    outputStream = new ByteArrayOutputStream();
    System.setOut(new PrintStream(outputStream));
  }

  @Test
  public void testBasicCalendarCreation() {
    // Create calendar
    InterfaceCommand command =
        parser.parse("create calendar --name \"Work Calendar\" --timezone America/New_York");
    CommandResult result = command.execute(manager);
    assertTrue(result.isSuccess());

    // Use calendar
    command = parser.parse("use calendar --name \"Work Calendar\"");
    result = command.execute(manager);
    assertTrue(result.isSuccess());
  }

  @Test
  public void testEventCreation() {
    // Setup
    InterfaceCommand command =
        parser.parse("create calendar --name \"Test\" --timezone America/New_York");
    command.execute(manager);
    command = parser.parse("use calendar --name \"Test\"");
    command.execute(manager);

    // Create event
    command =
        parser.parse("create event \"Team Meeting\" from 2023-12-01T10:00 "
            + "to 2023-12-01T11:00");
    CommandResult result = command.execute(manager);
    assertTrue(result.isSuccess());
  }

  @Test
  public void testEventSeriesCreation() {
    // Setup
    InterfaceCommand command =
        parser.parse("create calendar --name \"Series Test\" --timezone America/New_York");
    command.execute(manager);
    command = parser.parse("use calendar --name \"Series Test\"");
    command.execute(manager);

    // Create event series
    command = parser.parse(
        "create event \"Daily Standup\" from 2023-12-01T09:00 "
            + "to 2023-12-01T09:30 repeats MWF for 5 times");
    CommandResult result = command.execute(manager);
    assertTrue(result.isSuccess());
  }

  @Test
  public void testEventEditing() {
    // Setup
    InterfaceCommand command =
        parser.parse("create calendar --name \"Edit Test\" --timezone America/New_York");
    command.execute(manager);
    command = parser.parse("use calendar --name \"Edit Test\"");
    command.execute(manager);
    command =
        parser.parse("create event \"Original Title\" from 2023-12-01T10:00 "
            + "to 2023-12-01T11:00");
    command.execute(manager);

    // Edit event title
    command = parser.parse(
        "edit event subject \"Original Title\" from 2023-12-01T10:00 to 2023-12-01T11:00 "
            + "with \"New Title\"");
    CommandResult result = command.execute(manager);
    assertTrue(result.isSuccess());
  }

  @Test
  public void testEventCopying() {
    // Setup source calendar
    InterfaceCommand command =
        parser.parse("create calendar --name \"Source\" --timezone America/New_York");
    command.execute(manager);
    command = parser.parse("use calendar --name \"Source\"");
    command.execute(manager);
    command = parser.parse("create event \"Copy Me\" from 2023-12-01T10:00 "
        + "to 2023-12-01T11:00");
    command.execute(manager);

    // Create destination calendar
    command = parser.parse("create calendar --name \"Destination\" --timezone America/Los_Angeles");
    command.execute(manager);

    // Copy event
    command = parser.parse(
        "copy event \"Copy Me\" on 2023-12-01T10:00 --target Destination to 2023-12-01T07:00");
    CommandResult result = command.execute(manager);
    assertTrue(result.isSuccess());
  }

  @Test
  public void testExportFunctionality() {
    // Setup calendar with events
    InterfaceCommand command =
        parser.parse("create calendar --name \"Export Test\" --timezone America/New_York");
    command.execute(manager);
    command = parser.parse("use calendar --name \"Export Test\"");
    command.execute(manager);
    command = parser.parse("create event \"Export Me\" from 2023-12-01T10:00 "
        + "to 2023-12-01T11:00");
    command.execute(manager);

    // Export to CSV
    command = parser.parse("export cal \"test_export.csv\"");
    CommandResult result = command.execute(manager);
    assertTrue(result.isSuccess());

    // Export to iCal
    command = parser.parse("export cal \"test_export.ical\"");
    result = command.execute(manager);
    assertTrue(result.isSuccess());
  }

  @Test
  public void testMultipleCalendarManagement() {
    // Create multiple calendars
    InterfaceCommand command =
        parser.parse("create calendar --name \"Work\" --timezone America/New_York");
    command.execute(manager);
    command = parser.parse("create calendar --name \"Personal\" --timezone Europe/London");
    command.execute(manager);
    command = parser.parse("create calendar --name \"Family\" --timezone Asia/Kolkata");
    command.execute(manager);

    // Use one of the calendars
    command = parser.parse("use calendar --name \"Work\"");
    command.execute(manager);

    // Show status
    command = parser.parse("show status on 2023-12-01T10:00");
    CommandResult result = command.execute(manager);
    assertTrue(result.isSuccess());
  }

  @Test
  public void testErrorHandling() {
    // Try to use non-existent calendar
    InterfaceCommand command = parser.parse("use calendar --name \"NonExistent\"");
    CommandResult result = command.execute(manager);
    assertFalse(result.isSuccess());

    // Try to create event without active calendar
    command =
        parser.parse("create event \"No Calendar\" from 2023-12-01T10:00 "
            + "to 2023-12-01T11:00");
    result = command.execute(manager);
    assertFalse(result.isSuccess());
  }

  @Test
  public void testDateTimeValidation() {
    InterfaceCommand command =
        parser.parse("create calendar --name \"Time Test\" --timezone America/New_York");
    command.execute(manager);
    command = parser.parse("use calendar --name \"Time Test\"");
    command.execute(manager);

    // Test valid date-time formats
    command = parser.parse("create event \"Valid1\" from 2023-12-01T10:00 "
        + "to 2023-12-01T11:00");
    CommandResult result = command.execute(manager);
    assertTrue(result.isSuccess());

    // Test invalid date-time formats
    command = parser.parse("create event \"Invalid1\" from not-a-date to 2023-12-01T11:00");
    result = command.execute(manager);
    assertFalse(result.isSuccess());
  }

  @Test
  public void testEventSeriesWithWeekdays() {
    InterfaceCommand command =
        parser.parse("create calendar --name \"Series Test\" --timezone America/New_York");
    command.execute(manager);
    command = parser.parse("use calendar --name \"Series Test\"");
    command.execute(manager);

    // Test series with different weekday combinations
    command = parser.parse(
        "create event \"Weekly Meeting\" from 2023-12-01T10:00 "
            + "to 2023-12-01T11:00 repeats MWF for 4 times");
    CommandResult result = command.execute(manager);
    assertTrue(result.isSuccess());
  }

  @Test
  public void testPrintCommands() {
    InterfaceCommand command =
        parser.parse("create calendar --name \"Print Test\" --timezone America/New_York");
    command.execute(manager);
    command = parser.parse("use calendar --name \"Print Test\"");
    command.execute(manager);
    command = parser.parse("create event \"Test Event\" from 2023-12-01T10:00 "
        + "to 2023-12-01T11:00");
    command.execute(manager);

    // Test print commands
    command = parser.parse("print events on 2023-12-01");
    CommandResult result = command.execute(manager);
    assertTrue(result.isSuccess());

    command = parser.parse("print events from 2023-12-01T10:00 to 2023-12-02T10:00");
    result = command.execute(manager);
    assertTrue(result.isSuccess());
  }
}