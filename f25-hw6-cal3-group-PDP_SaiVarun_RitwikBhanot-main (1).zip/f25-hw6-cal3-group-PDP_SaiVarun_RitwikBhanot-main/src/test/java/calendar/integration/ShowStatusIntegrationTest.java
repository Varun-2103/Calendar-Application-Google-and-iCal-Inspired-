package calendar.integration;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import calendar.controller.CommandParser;
import calendar.controller.CommandResult;
import calendar.controller.InterfaceCommand;
import calendar.model.CalendarManager;
import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import org.junit.Before;
import org.junit.Test;

/**
 * Integration tests for show status command with timezone scenarios.
 */
public class ShowStatusIntegrationTest {

  private CommandParser parser;
  private CalendarManager manager;
  private ByteArrayOutputStream outputStream;

  /** Sets up test environment before each test. */
  @Before
  public void setUp() {
    manager = new CalendarManager();
    parser = new CommandParser();
    outputStream = new ByteArrayOutputStream();
    System.setOut(new PrintStream(outputStream));
  }

  @Test
  public void testShowStatusWhenBusy() {
    // Setup calendar with event
    parser.parse("create calendar --name \"Work\" --timezone America/New_York").execute(manager);
    parser.parse("use calendar --name \"Work\"").execute(manager);
    parser.parse("create event \"Meeting\" from 2023-12-01T10:00 to 2023-12-01T11:00")
        .execute(manager);

    // Check status during event time
    InterfaceCommand statusCommand = parser.parse("show status on 2023-12-01T10:30");
    CommandResult result = statusCommand.execute(manager);

    assertTrue(result.isSuccess());
    String output = outputStream.toString();

    // Should indicate busy status
    assertTrue(output.toLowerCase().contains("busy"));
  }

  @Test
  public void testShowStatusWhenAvailable() {
    // Setup calendar with event
    parser.parse("create calendar --name \"Work\" --timezone America/New_York").execute(manager);
    parser.parse("use calendar --name \"Work\"").execute(manager);
    parser.parse("create event \"Meeting\" from 2023-12-01T10:00 to 2023-12-01T11:00")
        .execute(manager);

    // Check status outside event time
    InterfaceCommand statusCommand = parser.parse("show status on 2023-12-01T09:00");
    CommandResult result = statusCommand.execute(manager);

    assertTrue(result.isSuccess());
    String output = outputStream.toString();

    // Should indicate available status
    assertTrue(output.toLowerCase().contains("available"));
  }

  @Test
  public void testShowStatusWithAllDayEvent() {
    // Setup calendar with all-day event
    parser.parse("create calendar --name \"Personal\" --timezone America/New_York")
        .execute(manager);
    parser.parse("use calendar --name \"Personal\"").execute(manager);
    parser.parse("create event \"Holiday\" on 2023-12-25").execute(manager);

    // Check status during all-day event (should be busy during 8am-5pm)
    InterfaceCommand statusCommand = parser.parse("show status on 2023-12-25T14:00");
    CommandResult result = statusCommand.execute(manager);

    assertTrue(result.isSuccess());
    String output = outputStream.toString();

    // Should indicate busy during all-day event hours
    assertTrue(output.toLowerCase().contains("busy"));
  }

  @Test
  public void testShowStatusWithAllDayEventOutsideHours() {
    // Setup calendar with all-day event
    parser.parse("create calendar --name \"Personal\" --timezone America/New_York")
        .execute(manager);
    parser.parse("use calendar --name \"Personal\"").execute(manager);
    parser.parse("create event \"Holiday\" on 2023-12-25").execute(manager);

    // Check status outside all-day event hours (after 5pm)
    InterfaceCommand statusCommand = parser.parse("show status on 2023-12-25T20:00");
    CommandResult result = statusCommand.execute(manager);

    assertTrue(result.isSuccess());
    String output = outputStream.toString();

    // Should indicate available outside all-day event hours
    assertTrue(output.toLowerCase().contains("available"));
  }

  @Test
  public void testShowStatusWithMultiDayEvent() {
    // Setup calendar with multi-day event
    parser.parse("create calendar --name \"Work\" --timezone America/New_York").execute(manager);
    parser.parse("use calendar --name \"Work\"").execute(manager);
    parser.parse("create event \"Conference\" from 2023-12-01T09:00 to 2023-12-03T17:00")
        .execute(manager);

    // Check status during event on second day
    InterfaceCommand statusCommand = parser.parse("show status on 2023-12-02T14:00");
    CommandResult result = statusCommand.execute(manager);

    assertTrue(result.isSuccess());
    String output = outputStream.toString();

    // Should indicate busy during multi-day event
    assertTrue(output.toLowerCase().contains("busy"));
  }

  @Test
  public void testShowStatusWithEventSeries() {
    // Setup calendar with event series
    parser.parse("create calendar --name \"Work\" --timezone America/New_York").execute(manager);
    parser.parse("use calendar --name \"Work\"").execute(manager);
    parser.parse(
        "create event \"Daily Standup\" from 2023-12-01T09:00 to 2023-12-01T09:30 "
            + "repeats MTWRF for 5 times")
        .execute(manager);

    // Check status during one of the series events
    InterfaceCommand statusCommand = parser.parse("show status on 2023-12-05T09:15");
    CommandResult result = statusCommand.execute(manager);

    assertTrue(result.isSuccess());
    String output = outputStream.toString();

    // Should indicate busy during series event
    assertTrue(output.toLowerCase().contains("busy"));
  }

  @Test
  public void testShowStatusWithDifferentTimezones() {
    // Setup calendar with different timezone
    parser.parse("create calendar --name \"Europe\" --timezone Europe/London").execute(manager);
    parser.parse("use calendar --name \"Europe\"").execute(manager);
    parser.parse("create event \"London Meeting\" from 2023-12-01T15:00 to 2023-12-01T16:00")
        .execute(manager);

    // Check status during event time (in calendar's timezone)
    InterfaceCommand statusCommand = parser.parse("show status on 2023-12-01T15:30");
    CommandResult result = statusCommand.execute(manager);

    assertTrue(result.isSuccess());
    String output = outputStream.toString();

    // Should indicate busy (time is interpreted in calendar's timezone)
    assertTrue(output.toLowerCase().contains("busy"));
  }

  @Test
  public void testShowStatusAtEventStart() {
    // Setup calendar with event
    parser.parse("create calendar --name \"Work\" --timezone America/New_York").execute(manager);
    parser.parse("use calendar --name \"Work\"").execute(manager);
    parser.parse("create event \"Meeting\" from 2023-12-01T10:00 to 2023-12-01T11:00")
        .execute(manager);

    // Check status exactly at event start time
    InterfaceCommand statusCommand = parser.parse("show status on 2023-12-01T10:00");
    CommandResult result = statusCommand.execute(manager);

    assertTrue(result.isSuccess());
    String output = outputStream.toString();

    // Should indicate busy at event start
    assertTrue(output.toLowerCase().contains("busy"));
  }

  @Test
  public void testShowStatusAtEventEnd() {
    // Setup calendar with event
    parser.parse("create calendar --name \"Work\" --timezone America/New_York").execute(manager);
    parser.parse("use calendar --name \"Work\"").execute(manager);
    parser.parse("create event \"Meeting\" from 2023-12-01T10:00 to 2023-12-01T11:00")
        .execute(manager);

    // Check status exactly at event end time
    InterfaceCommand statusCommand = parser.parse("show status on 2023-12-01T11:00");
    CommandResult result = statusCommand.execute(manager);

    assertTrue(result.isSuccess());
    String output = outputStream.toString();

    // Should indicate available at event end (events are typically not inclusive of end time)
    assertTrue(output.toLowerCase().contains("available"));
  }

  @Test
  public void testShowStatusWithEmptyCalendar() {
    // Setup empty calendar
    parser.parse("create calendar --name \"Empty\" --timezone America/New_York").execute(manager);
    parser.parse("use calendar --name \"Empty\"").execute(manager);

    // Check status
    InterfaceCommand statusCommand = parser.parse("show status on 2023-12-01T10:00");
    CommandResult result = statusCommand.execute(manager);

    assertTrue(result.isSuccess());
    String output = outputStream.toString();

    // Should indicate available with no events
    assertTrue(output.toLowerCase().contains("available"));
  }

  @Test
  public void testShowStatusWithoutActiveCalendar() {
    // Try to check status without setting active calendar
    InterfaceCommand statusCommand = parser.parse("show status on 2023-12-01T10:00");
    CommandResult result = statusCommand.execute(manager);

    assertFalse(result.isSuccess());
    assertTrue(result.getMessage().toLowerCase().contains("calendar"));
  }

  @Test
  public void testShowStatusWithInvalidDateTime() {
    // Setup calendar
    parser.parse("create calendar --name \"Test\" --timezone America/New_York").execute(manager);
    parser.parse("use calendar --name \"Test\"").execute(manager);

    // Try to check status with invalid datetime
    InterfaceCommand statusCommand = parser.parse("show status on invalid-datetime");
    CommandResult result = statusCommand.execute(manager);

    assertFalse(result.isSuccess());
    assertTrue(result.getMessage().toLowerCase().contains("date")
        || result.getMessage().toLowerCase().contains("time"));
  }

  @Test
  public void testShowStatusWithMultipleEventsSameTime() {
    // Setup calendar with overlapping events (shouldn't be possible, but test anyway)
    parser.parse("create calendar --name \"Work\" --timezone America/New_York").execute(manager);
    parser.parse("use calendar --name \"Work\"").execute(manager);
    parser.parse("create event \"Meeting1\" from 2023-12-01T10:00 to 2023-12-01T11:00")
        .execute(manager);

    // Check status during event
    InterfaceCommand statusCommand = parser.parse("show status on 2023-12-01T10:30");
    CommandResult result = statusCommand.execute(manager);

    assertTrue(result.isSuccess());
    String output = outputStream.toString();

    // Should indicate busy
    assertTrue(output.toLowerCase().contains("busy"));
  }

  @Test
  public void testShowStatusWithPartialOverlap() {
    // Setup calendar with event
    parser.parse("create calendar --name \"Work\" --timezone America/New_York").execute(manager);
    parser.parse("use calendar --name \"Work\"").execute(manager);
    parser.parse("create event \"Long Meeting\" from 2023-12-01T10:00 to 2023-12-01T14:00")
        .execute(manager);

    // Check status during event
    InterfaceCommand statusCommand = parser.parse("show status on 2023-12-01T12:00");
    CommandResult result = statusCommand.execute(manager);

    assertTrue(result.isSuccess());
    String output = outputStream.toString();

    // Should indicate busy during partial overlap
    assertTrue(output.toLowerCase().contains("busy"));
  }

  @Test
  public void testShowStatusWithEdgeOfEvent() {
    // Setup calendar with event
    parser.parse("create calendar --name \"Work\" --timezone America/New_York").execute(manager);
    parser.parse("use calendar --name \"Work\"").execute(manager);
    parser.parse("create event \"Meeting\" from 2023-12-01T10:00 to 2023-12-01T11:00")
        .execute(manager);

    // Check status just before event starts
    InterfaceCommand statusCommand = parser.parse("show status on 2023-12-01T09:59");
    CommandResult result = statusCommand.execute(manager);

    assertTrue(result.isSuccess());
    String output = outputStream.toString();

    // Should indicate available just before event
    assertTrue(output.toLowerCase().contains("available"));
  }

  @Test
  public void testShowStatusWithLateNightTime() {
    // Setup calendar with standard business hours event
    parser.parse("create calendar --name \"Work\" --timezone America/New_York").execute(manager);
    parser.parse("use calendar --name \"Work\"").execute(manager);
    parser.parse("create event \"Meeting\" from 2023-12-01T09:00 to 2023-12-01T17:00")
        .execute(manager);

    // Check status late at night
    InterfaceCommand statusCommand = parser.parse("show status on 2023-12-01T23:00");
    CommandResult result = statusCommand.execute(manager);

    assertTrue(result.isSuccess());
    String output = outputStream.toString();

    // Should indicate available late at night
    assertTrue(output.toLowerCase().contains("available"));
  }

  @Test
  public void testShowStatusWithEarlyMorningTime() {
    // Setup calendar with standard business hours event
    parser.parse("create calendar --name \"Work\" --timezone America/New_York").execute(manager);
    parser.parse("use calendar --name \"Work\"").execute(manager);
    parser.parse("create event \"Meeting\" from 2023-12-01T09:00 to 2023-12-01T17:00")
        .execute(manager);

    // Check status early in the morning
    InterfaceCommand statusCommand = parser.parse("show status on 2023-12-01T06:00");
    CommandResult result = statusCommand.execute(manager);

    assertTrue(result.isSuccess());
    String output = outputStream.toString();

    // Should indicate available early in the morning
    assertTrue(output.toLowerCase().contains("available"));
  }

  @Test
  public void testShowStatusWithWeekendEvents() {
    // Setup calendar with weekend event
    parser.parse("create calendar --name \"Personal\" --timezone America/New_York")
        .execute(manager);
    parser.parse("use calendar --name \"Personal\"").execute(manager);
    parser.parse("create event \"Weekend Party\" from 2023-12-02T20:00 to 2023-12-02T23:00")
        .execute(manager);

    // Check status during weekend event
    InterfaceCommand statusCommand = parser.parse("show status on 2023-12-02T21:00");
    CommandResult result = statusCommand.execute(manager);

    assertTrue(result.isSuccess());
    String output = outputStream.toString();

    // Should indicate busy during weekend event
    assertTrue(output.toLowerCase().contains("busy"));
  }
}