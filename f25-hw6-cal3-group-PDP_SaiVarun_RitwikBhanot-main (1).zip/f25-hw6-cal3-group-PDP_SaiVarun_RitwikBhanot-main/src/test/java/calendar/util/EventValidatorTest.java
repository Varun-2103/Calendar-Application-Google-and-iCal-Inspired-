package calendar.util;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

import java.time.LocalDate;
import java.time.LocalDateTime;
import org.junit.Test;

/**
 * Comprehensive test suite for EventValidator class.
 * Tests all validation functionality including subjects, times, weekdays, and edit parameters.
 */
public class EventValidatorTest {

  private static final LocalDateTime START = LocalDateTime.of(2023, 12, 15, 10, 0);
  private static final LocalDateTime END = LocalDateTime.of(2023, 12, 15, 11, 0);
  private static final LocalDate DATE = LocalDate.of(2023, 12, 15);

  @Test
  public void testValidateSubjectValidSubjectDoesNotThrow() {
    String validSubject = "Team Meeting";

    EventValidator.validateSubject(validSubject);
  }

  @Test
  public void testValidateSubjectSubjectWithSpacesDoesNotThrow() {
    String validSubject = "Meeting with spaces";

    EventValidator.validateSubject(validSubject);
  }

  @Test
  public void testValidateSubjectSubjectWithSpecialCharactersDoesNotThrow() {
    String validSubject = "Meeting @ Conference Room #1!";

    EventValidator.validateSubject(validSubject);
  }

  @Test
  public void testValidateSubjectSubjectWithUnicodeDoesNotThrow() {
    String validSubject = "会议 📅 Calendrier";

    EventValidator.validateSubject(validSubject);
  }

  @Test
  public void testValidateSubjectSubjectWithNumbersDoesNotThrow() {
    String validSubject = "Meeting 123";

    EventValidator.validateSubject(validSubject);
  }

  @Test
  public void testValidateSubjectSingleCharacterDoesNotThrow() {
    String validSubject = "M";

    EventValidator.validateSubject(validSubject);
  }

  @Test
  public void testValidateSubjectVeryLongSubjectDoesNotThrow() {
    String longSubject = "This is a very long subject that contains many words "
        + "and should be handled correctly by the validator without any issues";

    EventValidator.validateSubject(longSubject);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testValidateSubjectNullSubjectThrowsException() {
    EventValidator.validateSubject(null);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testValidateSubjectEmptySubjectThrowsException() {
    EventValidator.validateSubject("");
  }

  @Test(expected = IllegalArgumentException.class)
  public void testValidateSubjectWhitespaceOnlySubjectThrowsException() {
    EventValidator.validateSubject("   ");
  }

  @Test(expected = IllegalArgumentException.class)
  public void testValidateSubjectTabOnlySubjectThrowsException() {
    EventValidator.validateSubject("\t");
  }

  @Test(expected = IllegalArgumentException.class)
  public void testValidateSubjectNewlineOnlySubjectThrowsException() {
    EventValidator.validateSubject("\n");
  }

  @Test(expected = IllegalArgumentException.class)
  public void testValidateSubjectMixedWhitespaceOnlySubjectThrowsException() {
    EventValidator.validateSubject(" \t\n ");
  }

  @Test
  public void testValidateTimesValidTimesDoesNotThrow() {
    EventValidator.validateTimes(START, END);
  }

  @Test
  public void testValidateTimesSameDayDifferentTimesDoesNotThrow() {
    LocalDateTime sameDayStart = LocalDateTime.of(2023, 12, 15, 10, 0);
    LocalDateTime sameDayEnd = LocalDateTime.of(2023, 12, 15, 11, 0);

    EventValidator.validateTimes(sameDayStart, sameDayEnd);
  }

  @Test
  public void testValidateTimesMultiDayEventDoesNotThrow() {
    LocalDateTime multiDayStart = LocalDateTime.of(2023, 12, 15, 10, 0);
    LocalDateTime multiDayEnd = LocalDateTime.of(2023, 12, 16, 15, 0);

    EventValidator.validateTimes(multiDayStart, multiDayEnd);
  }

  @Test
  public void testValidateTimesOneMinuteDifferenceDoesNotThrow() {
    LocalDateTime start = LocalDateTime.of(2023, 12, 15, 10, 0);
    LocalDateTime end = LocalDateTime.of(2023, 12, 15, 10, 1);

    EventValidator.validateTimes(start, end);
  }

  @Test
  public void testValidateTimesOneSecondDifferenceDoesNotThrow() {
    LocalDateTime start = LocalDateTime.of(2023, 12, 15, 10, 0, 0);
    LocalDateTime end = LocalDateTime.of(2023, 12, 15, 10, 0, 1);

    EventValidator.validateTimes(start, end);
  }

  @Test
  public void testValidateTimesNanoSecondDifferenceDoesNotThrow() {
    LocalDateTime start = LocalDateTime.of(2023, 12, 15, 10, 0, 0, 0);
    LocalDateTime end = LocalDateTime.of(2023, 12, 15, 10, 0, 0, 1);

    EventValidator.validateTimes(start, end);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testValidateTimesNullStartThrowsException() {
    EventValidator.validateTimes(null, END);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testValidateTimesNullEndThrowsException() {
    EventValidator.validateTimes(START, null);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testValidateTimesBothNullThrowsException() {
    EventValidator.validateTimes(null, null);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testValidateTimesStartAfterEndThrowsException() {
    LocalDateTime invalidStart = LocalDateTime.of(2023, 12, 15, 12, 0);
    LocalDateTime invalidEnd = LocalDateTime.of(2023, 12, 15, 10, 0);

    EventValidator.validateTimes(invalidStart, invalidEnd);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testValidateTimesStartEqualsEndThrowsException() {
    LocalDateTime sameTime = LocalDateTime.of(2023, 12, 15, 10, 0);

    EventValidator.validateTimes(sameTime, sameTime);
  }

  @Test
  public void testValidateSameDaySameDayTimesDoesNotThrow() {
    LocalDateTime sameDayStart = LocalDateTime.of(2023, 12, 15, 10, 0);
    LocalDateTime sameDayEnd = LocalDateTime.of(2023, 12, 15, 11, 0);

    EventValidator.validateSameDay(sameDayStart, sameDayEnd);
  }

  @Test
  public void testValidateSameDayMidnightToMidnightSameDayDoesNotThrow() {
    LocalDateTime start = LocalDateTime.of(2023, 12, 15, 0, 0);
    LocalDateTime end = LocalDateTime.of(2023, 12, 15, 23, 59);

    EventValidator.validateSameDay(start, end);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testValidateSameDayDifferentDaysThrowsException() {
    LocalDateTime start = LocalDateTime.of(2023, 12, 15, 10, 0);
    LocalDateTime end = LocalDateTime.of(2023, 12, 16, 11, 0);

    EventValidator.validateSameDay(start, end);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testValidateSameDayNextDayThrowsException() {
    LocalDateTime start = LocalDateTime.of(2023, 12, 15, 23, 0);
    LocalDateTime end = LocalDateTime.of(2023, 12, 16, 1, 0);

    EventValidator.validateSameDay(start, end);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testValidateSameDayPreviousDayThrowsException() {
    LocalDateTime start = LocalDateTime.of(2023, 12, 14, 23, 0);
    LocalDateTime end = LocalDateTime.of(2023, 12, 15, 1, 0);

    EventValidator.validateSameDay(start, end);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testValidateSameDayManyDaysApartThrowsException() {
    LocalDateTime start = LocalDateTime.of(2023, 12, 15, 10, 0);
    LocalDateTime end = LocalDateTime.of(2023, 12, 20, 11, 0);

    EventValidator.validateSameDay(start, end);
  }

  @Test
  public void testValidateWeekdaysValidWeekdaysDoesNotThrow() {
    EventValidator.validateWeekdays("MWF");
  }

  @Test
  public void testValidateWeekdaysAllWeekdaysDoesNotThrow() {
    EventValidator.validateWeekdays("MTWRFSU");
  }

  @Test
  public void testValidateWeekdaysSingleWeekdayDoesNotThrow() {
    EventValidator.validateWeekdays("M");
  }

  @Test
  public void testValidateWeekdaysWeekendsOnlyDoesNotThrow() {
    EventValidator.validateWeekdays("SU");
  }

  @Test
  public void testValidateWeekdaysWeekdaysOnlyDoesNotThrow() {
    EventValidator.validateWeekdays("MTWRF");
  }

  @Test
  public void testValidateWeekdaysRepeatedDaysDoesNotThrow() {
    EventValidator.validateWeekdays("MMMTTT");
  }

  @Test(expected = IllegalArgumentException.class)
  public void testValidateWeekdaysNullWeekdaysThrowsException() {
    EventValidator.validateWeekdays(null);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testValidateWeekdaysEmptyWeekdaysThrowsException() {
    EventValidator.validateWeekdays("");
  }

  @Test(expected = IllegalArgumentException.class)
  public void testValidateWeekdaysWhitespaceOnlyWeekdaysThrowsException() {
    EventValidator.validateWeekdays("   ");
  }

  @Test(expected = IllegalArgumentException.class)
  public void testValidateWeekdaysInvalidCharacterThrowsException() {
    EventValidator.validateWeekdays("MX");
  }

  @Test(expected = IllegalArgumentException.class)
  public void testValidateWeekdaysLowercaseLettersThrowsException() {
    EventValidator.validateWeekdays("mwf");
  }

  @Test(expected = IllegalArgumentException.class)
  public void testValidateWeekdaysNumbersThrowsException() {
    EventValidator.validateWeekdays("M3W");
  }

  @Test(expected = IllegalArgumentException.class)
  public void testValidateWeekdaysSpecialCharactersThrowsException() {
    EventValidator.validateWeekdays("M@W");
  }

  @Test(expected = IllegalArgumentException.class)
  public void testValidateWeekdaysFullDayNamesThrowsException() {
    EventValidator.validateWeekdays("Monday");
  }

  @Test(expected = IllegalArgumentException.class)
  public void testValidateWeekdaysAbbreviatedNamesThrowsException() {
    EventValidator.validateWeekdays("MonWedFri");
  }

  @Test(expected = IllegalArgumentException.class)
  public void testValidateWeekdaysMixedValidInvalidThrowsException() {
    EventValidator.validateWeekdays("MWX");
  }

  @Test
  public void testValidateOccurrencesPositiveOccurrencesDoesNotThrow() {
    EventValidator.validateOccurrences(1);
  }

  @Test
  public void testValidateOccurrencesLargeOccurrencesDoesNotThrow() {
    EventValidator.validateOccurrences(1000);
  }

  @Test
  public void testValidateOccurrencesMaxIntegerDoesNotThrow() {
    EventValidator.validateOccurrences(Integer.MAX_VALUE);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testValidateOccurrencesZeroOccurrencesThrowsException() {
    EventValidator.validateOccurrences(0);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testValidateOccurrencesNegativeOccurrencesThrowsException() {
    EventValidator.validateOccurrences(-1);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testValidateOccurrencesMinIntegerThrowsException() {
    EventValidator.validateOccurrences(Integer.MIN_VALUE);
  }

  @Test
  public void testValidateUntilDateValidUntilDateDoesNotThrow() {
    LocalDate startDate = LocalDate.of(2023, 12, 15);
    LocalDate untilDate = LocalDate.of(2023, 12, 20);

    EventValidator.validateUntilDate(startDate, untilDate);
  }

  @Test
  public void testValidateUntilDateSameDateDoesNotThrow() {
    LocalDate startDate = LocalDate.of(2023, 12, 15);
    LocalDate untilDate = LocalDate.of(2023, 12, 15);

    EventValidator.validateUntilDate(startDate, untilDate);
  }

  @Test
  public void testValidateUntilDateNextDayDoesNotThrow() {
    LocalDate startDate = LocalDate.of(2023, 12, 15);
    LocalDate untilDate = LocalDate.of(2023, 12, 16);

    EventValidator.validateUntilDate(startDate, untilDate);
  }

  @Test
  public void testValidateUntilDateMuchLaterDateDoesNotThrow() {
    LocalDate startDate = LocalDate.of(2023, 12, 15);
    LocalDate untilDate = LocalDate.of(2024, 12, 15);

    EventValidator.validateUntilDate(startDate, untilDate);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testValidateUntilDateNullUntilDateThrowsException() {
    EventValidator.validateUntilDate(DATE, null);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testValidateUntilDateBeforeStartDateThrowsException() {
    LocalDate startDate = LocalDate.of(2023, 12, 15);
    LocalDate untilDate = LocalDate.of(2023, 12, 14);

    EventValidator.validateUntilDate(startDate, untilDate);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testValidateUntilDateMuchBeforeStartDateThrowsException() {
    LocalDate startDate = LocalDate.of(2023, 12, 15);
    LocalDate untilDate = LocalDate.of(2022, 12, 15);

    EventValidator.validateUntilDate(startDate, untilDate);
  }

  @Test
  public void testValidateEditParametersValidParametersDoesNotThrow() {
    EventValidator.validateEditParameters("subject", "New Subject");
  }

  @Test
  public void testValidateEditParametersValidPropertyWithSpacesDoesNotThrow() {
    EventValidator.validateEditParameters("location", "Conference Room");
  }

  @Test
  public void testValidateEditParametersPropertyWithSpecialCharactersDoesNotThrow() {
    EventValidator.validateEditParameters("description", "Meeting @ office");
  }

  @Test
  public void testValidateEditParametersValueWithSpecialCharactersDoesNotThrow() {
    EventValidator.validateEditParameters("subject", "Meeting! @ #1");
  }

  @Test
  public void testValidateEditParametersValueWithUnicodeDoesNotThrow() {
    EventValidator.validateEditParameters("subject", "会议 📅");
  }

  @Test
  public void testValidateEditParametersEmptyValueDoesNotThrow() {
    EventValidator.validateEditParameters("location", "");
  }

  @Test
  public void testValidateEditParametersSingleCharacterPropertyDoesNotThrow() {
    EventValidator.validateEditParameters("s", "value");
  }

  @Test
  public void testValidateEditParametersVeryLongParametersDoesNotThrow() {
    String longProperty = "this-is-a-very-long-property-name-that-should-be-accepted";
    String longValue = "this is a very long value that should be accepted by the validator";

    EventValidator.validateEditParameters(longProperty, longValue);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testValidateEditParametersNullPropertyThrowsException() {
    EventValidator.validateEditParameters(null, "value");
  }

  @Test(expected = IllegalArgumentException.class)
  public void testValidateEditParametersEmptyPropertyThrowsException() {
    EventValidator.validateEditParameters("", "value");
  }

  @Test(expected = IllegalArgumentException.class)
  public void testValidateEditParametersWhitespaceOnlyPropertyThrowsException() {
    EventValidator.validateEditParameters("   ", "value");
  }

  @Test(expected = IllegalArgumentException.class)
  public void testValidateEditParametersTabOnlyPropertyThrowsException() {
    EventValidator.validateEditParameters("\t", "value");
  }

  @Test(expected = IllegalArgumentException.class)
  public void testValidateEditParametersNewlineOnlyPropertyThrowsException() {
    EventValidator.validateEditParameters("\n", "value");
  }

  @Test(expected = IllegalArgumentException.class)
  public void testValidateEditParametersMixedWhitespaceOnlyPropertyThrowsException() {
    EventValidator.validateEditParameters(" \t\n ", "value");
  }

  @Test(expected = IllegalArgumentException.class)
  public void testValidateEditParametersNullValueThrowsException() {
    EventValidator.validateEditParameters("property", null);
  }

  @Test
  public void testValidateSubjectErrorMessages() {
    try {
      EventValidator.validateSubject(null);
      fail("Should have thrown IllegalArgumentException");
    } catch (IllegalArgumentException e) {
      assertEquals("Subject cannot be null or empty", e.getMessage());
    }

    try {
      EventValidator.validateSubject("");
      fail("Should have thrown IllegalArgumentException");
    } catch (IllegalArgumentException e) {
      assertEquals("Subject cannot be null or empty", e.getMessage());
    }
  }

  @Test
  public void testValidateTimesErrorMessages() {
    try {
      EventValidator.validateTimes(null, END);
      fail("Should have thrown IllegalArgumentException");
    } catch (IllegalArgumentException e) {
      assertEquals("Start time cannot be null", e.getMessage());
    }

    try {
      EventValidator.validateTimes(START, null);
      fail("Should have thrown IllegalArgumentException");
    } catch (IllegalArgumentException e) {
      assertEquals("End time cannot be null", e.getMessage());
    }

    try {
      EventValidator.validateTimes(END, START);
      fail("Should have thrown IllegalArgumentException");
    } catch (IllegalArgumentException e) {
      assertEquals("Start time must be before end time", e.getMessage());
    }
  }

  @Test
  public void testValidateSameDayErrorMessages() {
    LocalDateTime start = LocalDateTime.of(2023, 12, 15, 10, 0);
    LocalDateTime end = LocalDateTime.of(2023, 12, 16, 11, 0);

    try {
      EventValidator.validateSameDay(start, end);
      fail("Should have thrown IllegalArgumentException");
    } catch (IllegalArgumentException e) {
      assertEquals("Events in a series must start and end on the same day", e.getMessage());
    }
  }

  @Test
  public void testValidateWeekdaysErrorMessages() {
    try {
      EventValidator.validateWeekdays(null);
      fail("Should have thrown IllegalArgumentException");
    } catch (IllegalArgumentException e) {
      assertEquals("Weekdays cannot be null or empty", e.getMessage());
    }

    try {
      EventValidator.validateWeekdays("");
      fail("Should have thrown IllegalArgumentException");
    } catch (IllegalArgumentException e) {
      assertEquals("Weekdays cannot be null or empty", e.getMessage());
    }

    try {
      EventValidator.validateWeekdays("MX");
      fail("Should have thrown IllegalArgumentException");
    } catch (IllegalArgumentException e) {
      assertEquals("Invalid weekday code: X", e.getMessage());
    }
  }

  @Test
  public void testValidateOccurrencesErrorMessages() {
    try {
      EventValidator.validateOccurrences(0);
      fail("Should have thrown IllegalArgumentException");
    } catch (IllegalArgumentException e) {
      assertEquals("Invalid number of occurrences: must be positive", e.getMessage());
    }

    try {
      EventValidator.validateOccurrences(-1);
      fail("Should have thrown IllegalArgumentException");
    } catch (IllegalArgumentException e) {
      assertEquals("Invalid number of occurrences: must be positive", e.getMessage());
    }
  }

  @Test
  public void testValidateUntilDateErrorMessages() {
    LocalDate startDate = LocalDate.of(2023, 12, 15);
    LocalDate beforeDate = LocalDate.of(2023, 12, 14);

    try {
      EventValidator.validateUntilDate(startDate, null);
      fail("Should have thrown IllegalArgumentException");
    } catch (IllegalArgumentException e) {
      assertEquals("Until date cannot be null", e.getMessage());
    }

    try {
      EventValidator.validateUntilDate(startDate, beforeDate);
      fail("Should have thrown IllegalArgumentException");
    } catch (IllegalArgumentException e) {
      assertEquals("Until date must be on or after start date", e.getMessage());
    }
  }

  @Test
  public void testValidateEditParametersErrorMessages() {
    try {
      EventValidator.validateEditParameters(null, "value");
      fail("Should have thrown IllegalArgumentException");
    } catch (IllegalArgumentException e) {
      assertEquals("Property cannot be null or empty", e.getMessage());
    }

    try {
      EventValidator.validateEditParameters("", "value");
      fail("Should have thrown IllegalArgumentException");
    } catch (IllegalArgumentException e) {
      assertEquals("Property cannot be null or empty", e.getMessage());
    }

    try {
      EventValidator.validateEditParameters("property", null);
      fail("Should have thrown IllegalArgumentException");
    } catch (IllegalArgumentException e) {
      assertEquals("New value cannot be null", e.getMessage());
    }
  }
}