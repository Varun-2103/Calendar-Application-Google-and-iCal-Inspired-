package calendar.util;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.time.DayOfWeek;
import java.util.Set;
import org.junit.Test;

/**
 * Comprehensive test suite for WeekdayParser class.
 * Tests all functionality including parsing weekdays and converting back to string format.
 */
public class WeekdayParserTest {

  @Test
  public void testParseSingleWeekdayParsesCorrectly() {
    Set<DayOfWeek> result = WeekdayParser.parse("M");

    assertEquals(1, result.size());
    assertTrue(result.contains(DayOfWeek.MONDAY));
  }

  @Test
  public void testParseMultipleWeekdaysParsesCorrectly() {
    Set<DayOfWeek> result = WeekdayParser.parse("MWF");

    assertEquals(3, result.size());
    assertTrue(result.contains(DayOfWeek.MONDAY));
    assertTrue(result.contains(DayOfWeek.WEDNESDAY));
    assertTrue(result.contains(DayOfWeek.FRIDAY));
  }

  @Test
  public void testParseAllWeekdaysParsesCorrectly() {
    Set<DayOfWeek> result = WeekdayParser.parse("MTWRFSU");

    assertEquals(7, result.size());
    assertTrue(result.contains(DayOfWeek.MONDAY));
    assertTrue(result.contains(DayOfWeek.TUESDAY));
    assertTrue(result.contains(DayOfWeek.WEDNESDAY));
    assertTrue(result.contains(DayOfWeek.THURSDAY));
    assertTrue(result.contains(DayOfWeek.FRIDAY));
    assertTrue(result.contains(DayOfWeek.SATURDAY));
    assertTrue(result.contains(DayOfWeek.SUNDAY));
  }

  @Test
  public void testParseWeekdaysOnlyParsesCorrectly() {
    Set<DayOfWeek> result = WeekdayParser.parse("MTWRF");

    assertEquals(5, result.size());
    assertTrue(result.contains(DayOfWeek.MONDAY));
    assertTrue(result.contains(DayOfWeek.TUESDAY));
    assertTrue(result.contains(DayOfWeek.WEDNESDAY));
    assertTrue(result.contains(DayOfWeek.THURSDAY));
    assertTrue(result.contains(DayOfWeek.FRIDAY));
    assertFalse(result.contains(DayOfWeek.SATURDAY));
    assertFalse(result.contains(DayOfWeek.SUNDAY));
  }

  @Test
  public void testParseWeekendsOnlyParsesCorrectly() {
    Set<DayOfWeek> result = WeekdayParser.parse("SU");

    assertEquals(2, result.size());
    assertTrue(result.contains(DayOfWeek.SATURDAY));
    assertTrue(result.contains(DayOfWeek.SUNDAY));
    assertFalse(result.contains(DayOfWeek.MONDAY));
    assertFalse(result.contains(DayOfWeek.TUESDAY));
    assertFalse(result.contains(DayOfWeek.WEDNESDAY));
    assertFalse(result.contains(DayOfWeek.THURSDAY));
    assertFalse(result.contains(DayOfWeek.FRIDAY));
  }

  @Test
  public void testParseRepeatedDaysParsesCorrectly() {
    Set<DayOfWeek> result = WeekdayParser.parse("MMMTTT");

    assertEquals(2, result.size());
    assertTrue(result.contains(DayOfWeek.MONDAY));
    assertTrue(result.contains(DayOfWeek.TUESDAY));
    assertFalse(result.contains(DayOfWeek.WEDNESDAY));
    assertFalse(result.contains(DayOfWeek.THURSDAY));
    assertFalse(result.contains(DayOfWeek.FRIDAY));
    assertFalse(result.contains(DayOfWeek.SATURDAY));
    assertFalse(result.contains(DayOfWeek.SUNDAY));
  }

  @Test
  public void testParseUnorderedDaysParsesCorrectly() {
    Set<DayOfWeek> result = WeekdayParser.parse("FWM");

    assertEquals(3, result.size());
    assertTrue(result.contains(DayOfWeek.MONDAY));
    assertTrue(result.contains(DayOfWeek.WEDNESDAY));
    assertTrue(result.contains(DayOfWeek.FRIDAY));
  }

  @Test
  public void testParseReverseOrderParsesCorrectly() {
    Set<DayOfWeek> result = WeekdayParser.parse("UFSRWTM");

    assertEquals(7, result.size());
    assertTrue(result.contains(DayOfWeek.MONDAY));
    assertTrue(result.contains(DayOfWeek.TUESDAY));
    assertTrue(result.contains(DayOfWeek.WEDNESDAY));
    assertTrue(result.contains(DayOfWeek.THURSDAY));
    assertTrue(result.contains(DayOfWeek.FRIDAY));
    assertTrue(result.contains(DayOfWeek.SATURDAY));
    assertTrue(result.contains(DayOfWeek.SUNDAY));
  }

  @Test(expected = IllegalArgumentException.class)
  public void testParseNullWeekdaysThrowsException() {
    WeekdayParser.parse(null);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testParseEmptyWeekdaysThrowsException() {
    WeekdayParser.parse("");
  }

  @Test(expected = IllegalArgumentException.class)
  public void testParseWhitespaceOnlyWeekdaysThrowsException() {
    WeekdayParser.parse("   ");
  }

  @Test(expected = IllegalArgumentException.class)
  public void testParseInvalidCharacterThrowsException() {
    WeekdayParser.parse("MX");
  }

  @Test(expected = IllegalArgumentException.class)
  public void testParseLowercaseLettersThrowsException() {
    WeekdayParser.parse("mwf");
  }

  @Test(expected = IllegalArgumentException.class)
  public void testParseNumbersThrowsException() {
    WeekdayParser.parse("M3W");
  }

  @Test(expected = IllegalArgumentException.class)
  public void testParseSpecialCharactersThrowsException() {
    WeekdayParser.parse("M@W");
  }

  @Test(expected = IllegalArgumentException.class)
  public void testParseFullDayNamesThrowsException() {
    WeekdayParser.parse("Monday");
  }

  @Test(expected = IllegalArgumentException.class)
  public void testParseAbbreviatedNamesThrowsException() {
    WeekdayParser.parse("MonWedFri");
  }

  @Test(expected = IllegalArgumentException.class)
  public void testParseMixedValidInvalidThrowsException() {
    WeekdayParser.parse("MWX");
  }

  @Test
  public void testToStringSingleDayConvertsCorrectly() {
    Set<DayOfWeek> days = Set.of(DayOfWeek.MONDAY);

    String result = WeekdayParser.toString(days);

    assertEquals("M", result);
  }

  @Test
  public void testToStringMultipleDaysConvertsCorrectly() {
    Set<DayOfWeek> days = Set.of(DayOfWeek.MONDAY, DayOfWeek.WEDNESDAY, DayOfWeek.FRIDAY);

    String result = WeekdayParser.toString(days);

    assertEquals("MWF", result);
  }

  @Test
  public void testToStringAllDaysConvertsCorrectly() {
    Set<DayOfWeek> days = Set.of(
        DayOfWeek.MONDAY, DayOfWeek.TUESDAY, DayOfWeek.WEDNESDAY,
        DayOfWeek.THURSDAY, DayOfWeek.FRIDAY, DayOfWeek.SATURDAY, DayOfWeek.SUNDAY
    );

    String result = WeekdayParser.toString(days);

    assertEquals("MTWRFSU", result);
  }

  @Test
  public void testToStringWeekdaysOnlyConvertsCorrectly() {
    Set<DayOfWeek> days = Set.of(
        DayOfWeek.MONDAY, DayOfWeek.TUESDAY, DayOfWeek.WEDNESDAY,
        DayOfWeek.THURSDAY, DayOfWeek.FRIDAY
    );

    String result = WeekdayParser.toString(days);

    assertEquals("MTWRF", result);
  }

  @Test
  public void testToStringWeekendsOnlyConvertsCorrectly() {
    Set<DayOfWeek> days = Set.of(DayOfWeek.SATURDAY, DayOfWeek.SUNDAY);

    String result = WeekdayParser.toString(days);

    assertEquals("SU", result);
  }

  @Test
  public void testToStringEmptySetReturnsEmptyString() {
    Set<DayOfWeek> days = Set.of();

    String result = WeekdayParser.toString(days);

    assertEquals("", result);
  }

  @Test
  public void testToStringNullSetReturnsEmptyString() {
    String result = WeekdayParser.toString(null);

    assertEquals("", result);
  }

  @Test
  public void testToStringUnorderedDaysReturnsOrderedString() {
    Set<DayOfWeek> days = Set.of(DayOfWeek.FRIDAY, DayOfWeek.MONDAY, DayOfWeek.WEDNESDAY);

    String result = WeekdayParser.toString(days);

    assertEquals("MWF", result);
  }

  @Test
  public void testToStringRoundTripParsesBackToSameSet() {
    String original = "MWF";
    Set<DayOfWeek> parsed = WeekdayParser.parse(original);
    String convertedBack = WeekdayParser.toString(parsed);

    assertEquals(original, convertedBack);
  }

  @Test
  public void testToStringRoundTripAllDaysParsesBackToSameSet() {
    String original = "MTWRFSU";
    Set<DayOfWeek> parsed = WeekdayParser.parse(original);
    String convertedBack = WeekdayParser.toString(parsed);

    assertEquals(original, convertedBack);
  }

  @Test
  public void testToStringRoundTripWeekendsParsesBackToSameSet() {
    String original = "SU";
    Set<DayOfWeek> parsed = WeekdayParser.parse(original);
    String convertedBack = WeekdayParser.toString(parsed);

    assertEquals(original, convertedBack);
  }

  @Test
  public void testToStringRoundTripWeekdaysParsesBackToSameSet() {
    String original = "MTWRF";
    Set<DayOfWeek> parsed = WeekdayParser.parse(original);
    String convertedBack = WeekdayParser.toString(parsed);

    assertEquals(original, convertedBack);
  }

  @Test
  public void testParseDayMappingMonday() {
    Set<DayOfWeek> result = WeekdayParser.parse("M");

    assertEquals(1, result.size());
    assertTrue(result.contains(DayOfWeek.MONDAY));
  }

  @Test
  public void testParseDayMappingTuesday() {
    Set<DayOfWeek> result = WeekdayParser.parse("T");

    assertEquals(1, result.size());
    assertTrue(result.contains(DayOfWeek.TUESDAY));
  }

  @Test
  public void testParseDayMappingWednesday() {
    Set<DayOfWeek> result = WeekdayParser.parse("W");

    assertEquals(1, result.size());
    assertTrue(result.contains(DayOfWeek.WEDNESDAY));
  }

  @Test
  public void testParseDayMappingThursday() {
    Set<DayOfWeek> result = WeekdayParser.parse("R");

    assertEquals(1, result.size());
    assertTrue(result.contains(DayOfWeek.THURSDAY));
  }

  @Test
  public void testParseDayMappingFriday() {
    Set<DayOfWeek> result = WeekdayParser.parse("F");

    assertEquals(1, result.size());
    assertTrue(result.contains(DayOfWeek.FRIDAY));
  }

  @Test
  public void testParseDayMappingSaturday() {
    Set<DayOfWeek> result = WeekdayParser.parse("S");

    assertEquals(1, result.size());
    assertTrue(result.contains(DayOfWeek.SATURDAY));
  }

  @Test
  public void testParseDayMappingSunday() {
    Set<DayOfWeek> result = WeekdayParser.parse("U");

    assertEquals(1, result.size());
    assertTrue(result.contains(DayOfWeek.SUNDAY));
  }

  @Test
  public void testParseDayMappingAllIndividualDays() {
    Set<DayOfWeek> mondayResult = WeekdayParser.parse("M");
    Set<DayOfWeek> tuesdayResult = WeekdayParser.parse("T");
    Set<DayOfWeek> wednesdayResult = WeekdayParser.parse("W");

    assertTrue(mondayResult.contains(DayOfWeek.MONDAY));
    assertTrue(tuesdayResult.contains(DayOfWeek.TUESDAY));
    assertTrue(wednesdayResult.contains(DayOfWeek.WEDNESDAY));

    Set<DayOfWeek> thursdayResult = WeekdayParser.parse("R");
    assertTrue(thursdayResult.contains(DayOfWeek.THURSDAY));

    Set<DayOfWeek> fridayResult = WeekdayParser.parse("F");
    assertTrue(fridayResult.contains(DayOfWeek.FRIDAY));

    Set<DayOfWeek> saturdayResult = WeekdayParser.parse("S");
    assertTrue(saturdayResult.contains(DayOfWeek.SATURDAY));

    Set<DayOfWeek> sundayResult = WeekdayParser.parse("U");
    assertTrue(sundayResult.contains(DayOfWeek.SUNDAY));
  }

  @Test
  public void testParseDuplicateDaysInInputHandlesCorrectly() {
    Set<DayOfWeek> result = WeekdayParser.parse("MMMMWWWWFFFF");

    assertEquals(3, result.size());
    assertTrue(result.contains(DayOfWeek.MONDAY));
    assertTrue(result.contains(DayOfWeek.WEDNESDAY));
    assertTrue(result.contains(DayOfWeek.FRIDAY));
  }

  @Test
  public void testParseManyDuplicatesHandlesCorrectly() {
    Set<DayOfWeek> result = WeekdayParser.parse("MMMMMMMMMMMM");

    assertEquals(1, result.size());
    assertTrue(result.contains(DayOfWeek.MONDAY));
  }

  @Test
  public void testParseEachDayMultipleTimesHandlesCorrectly() {
    Set<DayOfWeek> result = WeekdayParser.parse("MMMTTTWWWRRRFFFSSSUUU");

    assertEquals(7, result.size());
    for (DayOfWeek day : DayOfWeek.values()) {
      assertTrue(result.contains(day));
    }
  }

  @Test
  public void testParseErrorMessages() {
    try {
      WeekdayParser.parse("MX");
      fail("Should have thrown IllegalArgumentException");
    } catch (IllegalArgumentException e) {
      assertEquals("Invalid weekday code: X", e.getMessage());
    }

    try {
      WeekdayParser.parse("M@");
      fail("Should have thrown IllegalArgumentException");
    } catch (IllegalArgumentException e) {
      assertEquals("Invalid weekday code: @", e.getMessage());
    }

    try {
      WeekdayParser.parse("M3");
      fail("Should have thrown IllegalArgumentException");
    } catch (IllegalArgumentException e) {
      assertEquals("Invalid weekday code: 3", e.getMessage());
    }
  }

  @Test
  public void testParseEdgeCaseSingleCharacterInputs() {
    for (char c : "MTWRFSU".toCharArray()) {
      String input = String.valueOf(c);
      Set<DayOfWeek> result = WeekdayParser.parse(input);
      assertEquals(1, result.size());
    }
  }

  @Test
  public void testParseEdgeCaseAllValidCharactersTogether() {
    String input = "MTWRFSU";
    Set<DayOfWeek> result = WeekdayParser.parse(input);
    assertEquals(7, result.size());
    for (DayOfWeek day : DayOfWeek.values()) {
      assertTrue(result.contains(day));
    }
  }

  @Test
  public void testParseEdgeCaseLongValidString() {
    String input = "MTWRFSUMTWRFSUMTWRFSU";
    Set<DayOfWeek> result = WeekdayParser.parse(input);
    assertEquals(7, result.size());
    for (DayOfWeek day : DayOfWeek.values()) {
      assertTrue(result.contains(day));
    }
  }

  @Test
  public void testParseEdgeCaseAlternatingPattern() {
    String input = "MFMFMFMF";
    Set<DayOfWeek> result = WeekdayParser.parse(input);
    assertEquals(2, result.size());
    assertTrue(result.contains(DayOfWeek.MONDAY));
    assertTrue(result.contains(DayOfWeek.FRIDAY));
  }

  @Test
  public void testParseEdgeCaseWeekendPattern() {
    String input = "SUSUSUSU";
    Set<DayOfWeek> result = WeekdayParser.parse(input);
    assertEquals(2, result.size());
    assertTrue(result.contains(DayOfWeek.SATURDAY));
    assertTrue(result.contains(DayOfWeek.SUNDAY));
  }

  @Test
  public void testParseEdgeCaseWeekdayPattern() {
    String input = "MTWRFMTWRF";
    Set<DayOfWeek> result = WeekdayParser.parse(input);
    assertEquals(5, result.size());
    assertTrue(result.contains(DayOfWeek.MONDAY));
    assertTrue(result.contains(DayOfWeek.TUESDAY));
    assertTrue(result.contains(DayOfWeek.WEDNESDAY));
    assertTrue(result.contains(DayOfWeek.THURSDAY));
    assertTrue(result.contains(DayOfWeek.FRIDAY));
  }

  @Test
  public void testToStringEdgeCaseEmptySet() {
    Set<DayOfWeek> emptySet = Set.of();
    String result = WeekdayParser.toString(emptySet);
    assertEquals("", result);
  }

  @Test
  public void testToStringEdgeCaseSingleDaySets() {
    for (DayOfWeek day : DayOfWeek.values()) {
      Set<DayOfWeek> singleDaySet = Set.of(day);
      String result = WeekdayParser.toString(singleDaySet);
      assertEquals(1, result.length());
      assertTrue("MTWRFSU".contains(result));
    }
  }

  @Test
  public void testToStringEdgeCaseAllPossibleSubsets() {
    DayOfWeek[] allDays = DayOfWeek.values();
    
    for (int i = 1; i < (1 << allDays.length); i++) {
      Set<DayOfWeek> subset = Set.of();
      for (int j = 0; j < allDays.length; j++) {
        if ((i & (1 << j)) != 0) {
          subset = Set.of(allDays[j]);
        }
      }
      
      String result = WeekdayParser.toString(subset);
      Set<DayOfWeek> parsedBack = WeekdayParser.parse(result);
      assertEquals(subset, parsedBack);
    }
  }

  @Test
  public void testParseAndToStringConsistencyCheck() {
    String[] testCases = {
        "M", "T", "W", "R", "F", "S", "U",
        "MT", "MW", "MF", "MS", "MU",
        "MTW", "MWF", "MTWR", "MTWRF", "MTWRFS", "MTWRFSU",
        "MWF", "TR", "FS", "SU", "MTWRFSU",
        "MMMM", "TTTT", "WWWW", "RRRR", "FFFF", "SSSS", "UUUU",
        "MTWRFSUMTWRFSUMTWRFSU"
    };

    for (String testCase : testCases) {
      Set<DayOfWeek> parsed = WeekdayParser.parse(testCase);
      String converted = WeekdayParser.toString(parsed);
      Set<DayOfWeek> reparsed = WeekdayParser.parse(converted);
      assertEquals("Round-trip failed for: " + testCase, parsed, reparsed);
    }
  }
}