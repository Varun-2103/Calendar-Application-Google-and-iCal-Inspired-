package calendar.util;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import org.junit.Test;

/**
 * Comprehensive test suite for DateTimeParser class.
 * Tests all functionality including date, time, and datetime parsing with various formats
 * and edge cases.
 */
public class DateTimeParserTest {

  @Test
  public void testParseDateValidDateParsesCorrectly() {
    String dateString = "2023-12-15";
    LocalDate expected = LocalDate.of(2023, 12, 15);

    LocalDate result = DateTimeParser.parseDate(dateString);

    assertEquals(expected, result);
  }

  @Test
  public void testParseDateLeapYearParsesCorrectly() {
    String dateString = "2024-02-29";
    LocalDate expected = LocalDate.of(2024, 2, 29);

    LocalDate result = DateTimeParser.parseDate(dateString);

    assertEquals(expected, result);
  }

  @Test
  public void testParseDateNewYearParsesCorrectly() {
    String dateString = "2024-01-01";
    LocalDate expected = LocalDate.of(2024, 1, 1);

    LocalDate result = DateTimeParser.parseDate(dateString);

    assertEquals(expected, result);
  }

  @Test
  public void testParseDateEndOfYearParsesCorrectly() {
    String dateString = "2023-12-31";
    LocalDate expected = LocalDate.of(2023, 12, 31);

    LocalDate result = DateTimeParser.parseDate(dateString);

    assertEquals(expected, result);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testParseDateNullDateThrowsException() {
    DateTimeParser.parseDate(null);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testParseDateEmptyDateThrowsException() {
    DateTimeParser.parseDate("");
  }

  @Test(expected = IllegalArgumentException.class)
  public void testParseDateInvalidFormatThrowsException() {
    DateTimeParser.parseDate("12/15/2023");
  }

  @Test(expected = IllegalArgumentException.class)
  public void testParseDateMissingYearThrowsException() {
    DateTimeParser.parseDate("12-15");
  }

  @Test(expected = IllegalArgumentException.class)
  public void testParseDateMissingMonthThrowsException() {
    DateTimeParser.parseDate("2023-15");
  }

  @Test(expected = IllegalArgumentException.class)
  public void testParseDateMissingDayThrowsException() {
    DateTimeParser.parseDate("2023-12");
  }

  @Test(expected = IllegalArgumentException.class)
  public void testParseDateInvalidMonthThrowsException() {
    DateTimeParser.parseDate("2023-13-15");
  }

  @Test(expected = IllegalArgumentException.class)
  public void testParseDateInvalidDayThrowsException() {
    DateTimeParser.parseDate("2023-12-32");
  }

  @Test(expected = IllegalArgumentException.class)
  public void testParseDateInvalidDayForMonthThrowsException() {
    DateTimeParser.parseDate("2023-02-30");
  }

  @Test(expected = IllegalArgumentException.class)
  public void testParseDateNonLeapYearFeb29ThrowsException() {
    DateTimeParser.parseDate("2023-02-29");
  }

  @Test(expected = IllegalArgumentException.class)
  public void testParseDateNegativeYearThrowsException() {
    DateTimeParser.parseDate("-2023-12-15");
  }

  @Test(expected = IllegalArgumentException.class)
  public void testParseDateZeroMonthThrowsException() {
    DateTimeParser.parseDate("2023-00-15");
  }

  @Test(expected = IllegalArgumentException.class)
  public void testParseDateZeroDayThrowsException() {
    DateTimeParser.parseDate("2023-12-00");
  }

  @Test(expected = IllegalArgumentException.class)
  public void testParseDateExtraSeparatorsThrowsException() {
    DateTimeParser.parseDate("2023--12--15");
  }

  @Test(expected = IllegalArgumentException.class)
  public void testParseDateWrongSeparatorsThrowsException() {
    DateTimeParser.parseDate("2023/12/15");
  }

  @Test(expected = IllegalArgumentException.class)
  public void testParseDateSpacesInsteadOfSeparatorsThrowsException() {
    DateTimeParser.parseDate("2023 12 15");
  }

  @Test(expected = IllegalArgumentException.class)
  public void testParseDateLettersInsteadOfNumbersThrowsException() {
    DateTimeParser.parseDate("abcd-ef-gh");
  }

  @Test(expected = IllegalArgumentException.class)
  public void testParseDateSpecialCharactersThrowsException() {
    DateTimeParser.parseDate("2023-12-15!");
  }

  @Test
  public void testParseTimeValidTimeParsesCorrectly() {
    String timeString = "10:30";
    LocalTime expected = LocalTime.of(10, 30);

    LocalTime result = DateTimeParser.parseTime(timeString);

    assertEquals(expected, result);
  }

  @Test
  public void testParseTimeMidnightParsesCorrectly() {
    String timeString = "00:00";
    LocalTime expected = LocalTime.of(0, 0);

    LocalTime result = DateTimeParser.parseTime(timeString);

    assertEquals(expected, result);
  }

  @Test
  public void testParseTimeNoonParsesCorrectly() {
    String timeString = "12:00";
    LocalTime expected = LocalTime.of(12, 0);

    LocalTime result = DateTimeParser.parseTime(timeString);

    assertEquals(expected, result);
  }

  @Test
  public void testParseTimeEndOfDayParsesCorrectly() {
    String timeString = "23:59";
    LocalTime expected = LocalTime.of(23, 59);

    LocalTime result = DateTimeParser.parseTime(timeString);

    assertEquals(expected, result);
  }

  @Test
  public void testParseTimeSingleDigitHourParsesCorrectly() {
    String timeString = "9:05";
    LocalTime expected = LocalTime.of(9, 5);

    LocalTime result = DateTimeParser.parseTime(timeString);

    assertEquals(expected, result);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testParseTimeNullTimeThrowsException() {
    DateTimeParser.parseTime(null);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testParseTimeEmptyTimeThrowsException() {
    DateTimeParser.parseTime("");
  }

  @Test(expected = IllegalArgumentException.class)
  public void testParseTimeInvalidFormatThrowsException() {
    DateTimeParser.parseTime("10.30");
  }

  @Test(expected = IllegalArgumentException.class)
  public void testParseTimeMissingHourThrowsException() {
    DateTimeParser.parseTime(":30");
  }

  @Test(expected = IllegalArgumentException.class)
  public void testParseTimeMissingMinuteThrowsException() {
    DateTimeParser.parseTime("10:");
  }

  @Test(expected = IllegalArgumentException.class)
  public void testParseTimeInvalidHourThrowsException() {
    DateTimeParser.parseTime("24:00");
  }

  @Test(expected = IllegalArgumentException.class)
  public void testParseTimeInvalidMinuteThrowsException() {
    DateTimeParser.parseTime("10:60");
  }

  @Test(expected = IllegalArgumentException.class)
  public void testParseTimeNegativeHourThrowsException() {
    DateTimeParser.parseTime("-1:00");
  }

  @Test(expected = IllegalArgumentException.class)
  public void testParseTimeNegativeMinuteThrowsException() {
    DateTimeParser.parseTime("10:-1");
  }

  @Test(expected = IllegalArgumentException.class)
  public void testParseTimeNonNumericThrowsException() {
    DateTimeParser.parseTime("ab:cd");
  }

  @Test(expected = IllegalArgumentException.class)
  public void testParseTimeSpecialCharactersThrowsException() {
    DateTimeParser.parseTime("10:30!");
  }

  @Test(expected = IllegalArgumentException.class)
  public void testParseTimeExtraSeparatorsThrowsException() {
    DateTimeParser.parseTime("10::30");
  }

  @Test(expected = IllegalArgumentException.class)
  public void testParseTimeWrongSeparatorThrowsException() {
    DateTimeParser.parseTime("10.30");
  }

  @Test
  public void testParseDateTimeValidDateTimeParsesCorrectly() {
    String dateTimeString = "2023-12-15T10:30";
    LocalDateTime expected = LocalDateTime.of(2023, 12, 15, 10, 30);

    LocalDateTime result = DateTimeParser.parseDateTime(dateTimeString);

    assertEquals(expected, result);
  }

  @Test
  public void testParseDateTimeMidnightParsesCorrectly() {
    String dateTimeString = "2023-12-15T00:00";
    LocalDateTime expected = LocalDateTime.of(2023, 12, 15, 0, 0);

    LocalDateTime result = DateTimeParser.parseDateTime(dateTimeString);

    assertEquals(expected, result);
  }

  @Test
  public void testParseDateTimeEndOfDayParsesCorrectly() {
    String dateTimeString = "2023-12-15T23:59";
    LocalDateTime expected = LocalDateTime.of(2023, 12, 15, 23, 59);

    LocalDateTime result = DateTimeParser.parseDateTime(dateTimeString);

    assertEquals(expected, result);
  }

  @Test
  public void testParseDateTimeLeapYearParsesCorrectly() {
    String dateTimeString = "2024-02-29T12:00";
    LocalDateTime expected = LocalDateTime.of(2024, 2, 29, 12, 0);

    LocalDateTime result = DateTimeParser.parseDateTime(dateTimeString);

    assertEquals(expected, result);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testParseDateTimeNullDateTimeThrowsException() {
    DateTimeParser.parseDateTime(null);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testParseDateTimeEmptyDateTimeThrowsException() {
    DateTimeParser.parseDateTime("");
  }

  @Test(expected = IllegalArgumentException.class)
  public void testParseDateTimeInvalidFormatThrowsException() {
    DateTimeParser.parseDateTime("2023-12-15 10:30");
  }

  @Test(expected = IllegalArgumentException.class)
  public void testParseDateTimeMissingDateThrowsException() {
    DateTimeParser.parseDateTime("T10:30");
  }

  @Test(expected = IllegalArgumentException.class)
  public void testParseDateTimeMissingTimeThrowsException() {
    DateTimeParser.parseDateTime("2023-12-15T");
  }

  @Test(expected = IllegalArgumentException.class)
  public void testParseDateTimeWrongSeparatorThrowsException() {
    DateTimeParser.parseDateTime("2023-12-15 10:30");
  }

  @Test(expected = IllegalArgumentException.class)
  public void testParseDateTimeInvalidDateThrowsException() {
    DateTimeParser.parseDateTime("2023-13-15T10:30");
  }

  @Test(expected = IllegalArgumentException.class)
  public void testParseDateTimeInvalidTimeThrowsException() {
    DateTimeParser.parseDateTime("2023-12-15T24:00");
  }

  @Test(expected = IllegalArgumentException.class)
  public void testParseDateTimeNonLeapYearFeb29ThrowsException() {
    DateTimeParser.parseDateTime("2023-02-29T10:30");
  }

  @Test(expected = IllegalArgumentException.class)
  public void testParseDateTimeSpecialCharactersThrowsException() {
    DateTimeParser.parseDateTime("2023-12-15T10:30!");
  }

  @Test
  public void testParseDateTimeEdgeCasesParsesCorrectly() {
    LocalDateTime expected1 = LocalDateTime.of(1, 1, 1, 0, 0);
    LocalDateTime expected2 = LocalDateTime.of(9999, 12, 31, 23, 59);

    LocalDateTime result1 = DateTimeParser.parseDateTime("0001-01-01T00:00");
    LocalDateTime result2 = DateTimeParser.parseDateTime("9999-12-31T23:59");

    assertEquals(expected1, result1);
    assertEquals(expected2, result2);
  }

  @Test
  public void testParseDateEdgeCasesParsesCorrectly() {
    LocalDate expected1 = LocalDate.of(1, 1, 1);
    LocalDate expected2 = LocalDate.of(9999, 12, 31);

    LocalDate result1 = DateTimeParser.parseDate("0001-01-01");
    LocalDate result2 = DateTimeParser.parseDate("9999-12-31");

    assertEquals(expected1, result1);
    assertEquals(expected2, result2);
  }

  @Test
  public void testParseTimeEdgeCasesParsesCorrectly() {
    LocalTime expected1 = LocalTime.of(0, 0);
    LocalTime expected2 = LocalTime.of(23, 59);

    LocalTime result1 = DateTimeParser.parseTime("00:00");
    LocalTime result2 = DateTimeParser.parseTime("23:59");

    assertEquals(expected1, result1);
    assertEquals(expected2, result2);
  }

  @Test
  public void testParseDateTimeWithLeadingZerosParsesCorrectly() {
    String dateTimeString = "0001-01-01T00:00";
    LocalDateTime expected = LocalDateTime.of(1, 1, 1, 0, 0);

    LocalDateTime result = DateTimeParser.parseDateTime(dateTimeString);

    assertEquals(expected, result);
  }

  @Test
  public void testParseDateWithLeadingZerosParsesCorrectly() {
    String dateString = "0001-01-01";
    LocalDate expected = LocalDate.of(1, 1, 1);

    LocalDate result = DateTimeParser.parseDate(dateString);

    assertEquals(expected, result);
  }

  @Test
  public void testParseTimeWithLeadingZerosParsesCorrectly() {
    String timeString = "00:00";
    LocalTime expected = LocalTime.of(0, 0);

    LocalTime result = DateTimeParser.parseTime(timeString);

    assertEquals(expected, result);
  }

  @Test
  public void testParseDateTimeErrorMessageContainsInput() {
    String invalidInput = "invalid-format";

    try {
      DateTimeParser.parseDateTime(invalidInput);
      fail("Should have thrown IllegalArgumentException");
    } catch (IllegalArgumentException e) {
      String message = e.getMessage();
      assertTrue(message.contains(invalidInput));
    }
  }

  @Test
  public void testParseDateErrorMessageContainsInput() {
    String invalidInput = "invalid-date";

    try {
      DateTimeParser.parseDate(invalidInput);
      fail("Should have thrown IllegalArgumentException");
    } catch (IllegalArgumentException e) {
      String message = e.getMessage();
      assertTrue(message.contains(invalidInput));
    }
  }

  @Test
  public void testParseTimeErrorMessageContainsInput() {
    String invalidInput = "invalid-time";

    try {
      DateTimeParser.parseTime(invalidInput);
      fail("Should have thrown IllegalArgumentException");
    } catch (IllegalArgumentException e) {
      String message = e.getMessage();
      assertTrue(message.contains(invalidInput));
    }
  }

  @Test
  public void testParseDateTimeErrorMessageContainsExpectedFormat() {
    try {
      DateTimeParser.parseDateTime("invalid");
      fail("Should have thrown IllegalArgumentException");
    } catch (IllegalArgumentException e) {
      String message = e.getMessage();
      assertTrue(message.contains("YYYY-MM-DDTHH:mm"));
    }
  }

  @Test
  public void testParseDateErrorMessageContainsExpectedFormat() {
    try {
      DateTimeParser.parseDate("invalid");
      fail("Should have thrown IllegalArgumentException");
    } catch (IllegalArgumentException e) {
      String message = e.getMessage();
      assertTrue(message.contains("YYYY-MM-DD"));
    }
  }

  @Test
  public void testParseTimeErrorMessageContainsExpectedFormat() {
    try {
      DateTimeParser.parseTime("invalid");
      fail("Should have thrown IllegalArgumentException");
    } catch (IllegalArgumentException e) {
      String message = e.getMessage();
      assertTrue(message.contains("HH:mm"));
    }
  }

  @Test(expected = IllegalArgumentException.class)
  public void testParseDateAprilWith31Days() {
    DateTimeParser.parseDate("2023-04-31");
  }

  @Test(expected = IllegalArgumentException.class)
  public void testParseDateJuneWith31Days() {
    DateTimeParser.parseDate("2023-06-31");
  }

  @Test(expected = IllegalArgumentException.class)
  public void testParseDateSeptemberWith31Days() {
    DateTimeParser.parseDate("2023-09-31");
  }

  @Test(expected = IllegalArgumentException.class)
  public void testParseDateNovemberWith31Days() {
    DateTimeParser.parseDate("2023-11-31");
  }

  @Test(expected = IllegalArgumentException.class)
  public void testParseDateJanuaryWith32Days() {
    DateTimeParser.parseDate("2023-01-32");
  }

  @Test(expected = IllegalArgumentException.class)
  public void testParseDateMarchWith32Days() {
    DateTimeParser.parseDate("2023-03-32");
  }

  @Test(expected = IllegalArgumentException.class)
  public void testParseDateMayWith32Days() {
    DateTimeParser.parseDate("2023-05-32");
  }

  @Test(expected = IllegalArgumentException.class)
  public void testParseDateJulyWith32Days() {
    DateTimeParser.parseDate("2023-07-32");
  }

  @Test(expected = IllegalArgumentException.class)
  public void testParseDateAugustWith32Days() {
    DateTimeParser.parseDate("2023-08-32");
  }

  @Test(expected = IllegalArgumentException.class)
  public void testParseDateOctoberWith32Days() {
    DateTimeParser.parseDate("2023-10-32");
  }

  @Test(expected = IllegalArgumentException.class)
  public void testParseDateDecemberWith32Days() {
    DateTimeParser.parseDate("2023-12-32");
  }

  @Test
  public void testParseDateLeapYearDivisibleBy400() {
    LocalDate result = DateTimeParser.parseDate("2000-02-29");
    assertEquals(LocalDate.of(2000, 2, 29), result);
  }

  @Test
  public void testParseDateLeapYearDivisibleBy4Not100() {
    LocalDate result = DateTimeParser.parseDate("2024-02-29");
    assertEquals(LocalDate.of(2024, 2, 29), result);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testParseDateNonLeapYearDivisibleBy100Not400() {
    DateTimeParser.parseDate("1900-02-29");
  }

  @Test(expected = IllegalArgumentException.class)
  public void testParseDateTimeMissingParts() {
    DateTimeParser.parseDateTime("2023-12-15-10:30");
  }

  @Test
  public void testParseDateValidJanuary31() {
    LocalDate result = DateTimeParser.parseDate("2023-01-31");
    assertEquals(LocalDate.of(2023, 1, 31), result);
  }

  @Test
  public void testParseDateValidMarch31() {
    LocalDate result = DateTimeParser.parseDate("2023-03-31");
    assertEquals(LocalDate.of(2023, 3, 31), result);
  }

  @Test
  public void testParseDateValidMay31() {
    LocalDate result = DateTimeParser.parseDate("2023-05-31");
    assertEquals(LocalDate.of(2023, 5, 31), result);
  }

  @Test
  public void testParseDateValidJuly31() {
    LocalDate result = DateTimeParser.parseDate("2023-07-31");
    assertEquals(LocalDate.of(2023, 7, 31), result);
  }

  @Test
  public void testParseDateValidAugust31() {
    LocalDate result = DateTimeParser.parseDate("2023-08-31");
    assertEquals(LocalDate.of(2023, 8, 31), result);
  }

  @Test
  public void testParseDateValidOctober31() {
    LocalDate result = DateTimeParser.parseDate("2023-10-31");
    assertEquals(LocalDate.of(2023, 10, 31), result);
  }

  @Test
  public void testParseDateValidDecember31() {
    LocalDate result = DateTimeParser.parseDate("2023-12-31");
    assertEquals(LocalDate.of(2023, 12, 31), result);
  }

  @Test
  public void testParseDateValidApril30() {
    LocalDate result = DateTimeParser.parseDate("2023-04-30");
    assertEquals(LocalDate.of(2023, 4, 30), result);
  }

  @Test
  public void testParseDateValidJune30() {
    LocalDate result = DateTimeParser.parseDate("2023-06-30");
    assertEquals(LocalDate.of(2023, 6, 30), result);
  }

  @Test
  public void testParseDateValidSeptember30() {
    LocalDate result = DateTimeParser.parseDate("2023-09-30");
    assertEquals(LocalDate.of(2023, 9, 30), result);
  }

  @Test
  public void testParseDateValidNovember30() {
    LocalDate result = DateTimeParser.parseDate("2023-11-30");
    assertEquals(LocalDate.of(2023, 11, 30), result);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testParseDateResultMismatch() {
    DateTimeParser.parseDate("2023-02-30");
  }


}